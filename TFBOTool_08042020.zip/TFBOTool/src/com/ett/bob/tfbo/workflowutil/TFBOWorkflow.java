package com.ett.bob.tfbo.workflowutil;

import org.apache.log4j.Logger;

import com.ett.bob.tfbo.commonutil.CommonMethods;
import com.ett.bob.tfbo.dbutil.WorkflowHelper;
import com.ett.bob.tfbo.util.ActionConstants;

public class TFBOWorkflow {
	private static Logger logger = Logger.getLogger(TFBOWorkflow.class
			.getName());
	WorkflowHelper aWorkflowHelper = null;
	CommonMethods aCommonMethods = null;

	public String getFirstStep() throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD + "getFirstStep");
		aWorkflowHelper = new WorkflowHelper();
		String stepName = null;
		stepName = aWorkflowHelper.getFirstStepFromDB();
		logger.info(ActionConstants.EXITING_METHOD + "getFirstStep");
		return stepName;
	}

	public String getNextStep(String stepName) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD + "getNextStep");
		aWorkflowHelper = new WorkflowHelper();
		String nextStepName = null;
		nextStepName = aWorkflowHelper.getNextStepFromDB(stepName);
		logger.info(ActionConstants.EXITING_METHOD + "getNextStep");
		return nextStepName;
	}

	public String getPreviousStep(String stepName) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD + "getPreviousStep");
		aWorkflowHelper = new WorkflowHelper();
		String previousStepName = null;
		previousStepName = aWorkflowHelper.getPreviousStepFromDB(stepName);
		logger.info(ActionConstants.EXITING_METHOD + "getPreviousStep");
		return previousStepName;
	}

	public String getAssignStatus(String stepName) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD + "getAssignStatus");
		aWorkflowHelper = new WorkflowHelper();
		String assignStatus = null;
		assignStatus = aWorkflowHelper.getAssignStatusFromDB(stepName);
		logger.info(ActionConstants.EXITING_METHOD + "getAssignStatus");
		return assignStatus;
	}

	public String getCompletedStatus(String stepName) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD + "getCompletedStatus");
		aWorkflowHelper = new WorkflowHelper();
		String completedStatus = null;
		completedStatus = aWorkflowHelper.getCompletedStatusFromDB(stepName);
		logger.info(ActionConstants.EXITING_METHOD + "getCompletedStatus");
		return completedStatus;
	}

	public String getRejectStatus(String stepName) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD + "getRejectStatus");
		aWorkflowHelper = new WorkflowHelper();
		String rejectStatus = null;
		rejectStatus = aWorkflowHelper.getRejectStatusFromDB(stepName);
		logger.info(ActionConstants.EXITING_METHOD + "getRejectStatus");
		return rejectStatus;
	}

	public String getAbortStatus(String stepName) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD + "getAbortStatus");
		aWorkflowHelper = new WorkflowHelper();
		String abortStatus = null;
		abortStatus = aWorkflowHelper.getAbortStatusFromDB(stepName);
		logger.info(ActionConstants.EXITING_METHOD + "getAbortStatus");
		return abortStatus;
	}

	public String getPendStatus(String stepName) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD + "getPendStatus");
		aWorkflowHelper = new WorkflowHelper();
		String pendStatus = null;
		pendStatus = aWorkflowHelper.getPendStatusFromDB(stepName);
		logger.info(ActionConstants.EXITING_METHOD + "getPendStatus");
		return pendStatus;
	}

	public String getStepTeam(String stepName) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD + "getStepTeam");
		aWorkflowHelper = new WorkflowHelper();
		String stepTeam = null;
		stepTeam = aWorkflowHelper.getStepTeamFromDB(stepName);
		logger.info(ActionConstants.EXITING_METHOD + "getStepTeam");
		return stepTeam;
	}
}
