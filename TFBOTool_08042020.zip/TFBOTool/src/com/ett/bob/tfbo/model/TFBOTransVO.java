package com.ett.bob.tfbo.model;

public class TFBOTransVO {
	public String requestId;
	public String tiReferenceNo;
	public String productCode;
	public String eventCode;
	public String subProductCode;
	public String step;
	public String stepStatus;
	public String transCreatedDate;
	public String transModifiedDate;
	// Added by divya starts
	public String tiMasterRef;
	public String tfboMasterRef;
	// Offshore team Changes 04012020 starts

	public String productCodeDescription;
	public String eventCodeDescription;

	// Dashboard changes 23012020 starts
	public String solIdGrid;
	public String customerCifGrid;
	public String customerNameGrid;
	public String lastModifiedUserGrid;
	public String directGrid;
	public String financeSameDayGrid;
	public String amount;
	public String currency;
	public String NoAmend;//pandi
	public String BranchAlpha;//pandi
	public String rateTaken;
	
	
	// Dashboard changes 23012020 ends

	public String getRateTaken() {
		return rateTaken;
	}

	public void setRateTaken(String rateTaken) {
		this.rateTaken = rateTaken;
	}

	//pandi
	public String getBranchAlpha() {
		return BranchAlpha;
	}

	public void setBranchAlpha(String branchAlpha) {
		BranchAlpha = branchAlpha;
	}

	public String getAmount() {
		return amount;
	}

	public String getNoAmend() {
		return NoAmend;
	}

	public void setNoAmend(String noAmend) {
		NoAmend = noAmend;
	}

	public void setAmount(String amount) {
		this.amount = amount;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}
	//pandi
	public String getSolIdGrid() {
		return solIdGrid;
	}

	public void setSolIdGrid(String solIdGrid) {
		this.solIdGrid = solIdGrid;
	}

	public String getCustomerCifGrid() {
		return customerCifGrid;
	}

	public void setCustomerCifGrid(String customerCifGrid) {
		this.customerCifGrid = customerCifGrid;
	}

	public String getCustomerNameGrid() {
		return customerNameGrid;
	}

	public void setCustomerNameGrid(String customerNameGrid) {
		this.customerNameGrid = customerNameGrid;
	}

	public String getLastModifiedUserGrid() {
		return lastModifiedUserGrid;
	}

	public void setLastModifiedUserGrid(String lastModifiedUserGrid) {
		this.lastModifiedUserGrid = lastModifiedUserGrid;
	}

	public String getDirectGrid() {
		return directGrid;
	}

	public void setDirectGrid(String directGrid) {
		this.directGrid = directGrid;
	}

	public String getFinanceSameDayGrid() {
		return financeSameDayGrid;
	}

	public void setFinanceSameDayGrid(String financeSameDayGrid) {
		this.financeSameDayGrid = financeSameDayGrid;
	}

	public String getProductCodeDescription() {
		return productCodeDescription;
	}

	public void setProductCodeDescription(String productCodeDescription) {
		this.productCodeDescription = productCodeDescription;
	}

	public String getEventCodeDescription() {
		return eventCodeDescription;
	}

	public void setEventCodeDescription(String eventCodeDescription) {
		this.eventCodeDescription = eventCodeDescription;
	}

	// Offshore team Changes 04012020 starts

	public String getTiMasterRef() {
		return tiMasterRef;
	}

	public void setTiMasterRef(String tiMasterRef) {
		this.tiMasterRef = tiMasterRef;
	}

	public String getTfboMasterRef() {
		return tfboMasterRef;
	}

	public void setTfboMasterRef(String tfboMasterRef) {
		this.tfboMasterRef = tfboMasterRef;
	}

	// Added by divya ends
	public String getSubProductCode() {
		return subProductCode;
	}

	public void setSubProductCode(String subProductCode) {
		this.subProductCode = subProductCode;
	}

	public String getRequestId() {
		return requestId;
	}

	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}

	public String getTiReferenceNo() {
		return tiReferenceNo;
	}

	public void setTiReferenceNo(String tiReferenceNo) {
		this.tiReferenceNo = tiReferenceNo;
	}

	public String getProductCode() {
		return productCode;
	}

	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}

	public String getEventCode() {
		return eventCode;
	}

	public void setEventCode(String eventCode) {
		this.eventCode = eventCode;
	}

	public String getStep() {
		return step;
	}

	public void setStep(String step) {
		this.step = step;
	}

	public String getStepStatus() {
		return stepStatus;
	}

	public void setStepStatus(String stepStatus) {
		this.stepStatus = stepStatus;
	}

	public String getTransCreatedDate() {
		return transCreatedDate;
	}

	public void setTransCreatedDate(String transCreatedDate) {
		this.transCreatedDate = transCreatedDate;
	}

	public String getTransModifiedDate() {
		return transModifiedDate;
	}

	public void setTransModifiedDate(String transModifiedDate) {
		this.transModifiedDate = transModifiedDate;
	}

}
