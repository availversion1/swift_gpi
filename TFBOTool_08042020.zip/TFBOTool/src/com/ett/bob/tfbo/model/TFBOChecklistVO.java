package com.ett.bob.tfbo.model;

public class TFBOChecklistVO {

	String checklistId;
	String checklistDetails;
	String checklistValue;
	String checklistRemarks;
	String checklistHeader;

	public String getChecklistId() {
		return checklistId;
	}

	public void setChecklistId(String checklistId) {
		this.checklistId = checklistId;
	}

	public String getChecklistDetails() {
		return checklistDetails;
	}

	public void setChecklistDetails(String checklistDetails) {
		this.checklistDetails = checklistDetails;
	}

	public String getChecklistValue() {
		return checklistValue;
	}

	public void setChecklistValue(String checklistValue) {
		this.checklistValue = checklistValue;
	}

	public String getChecklistRemarks() {
		return checklistRemarks;
	}

	public void setChecklistRemarks(String checklistRemarks) {
		this.checklistRemarks = checklistRemarks;
	}

	public String getChecklistHeader() {
		return checklistHeader;
	}

	public void setChecklistHeader(String checklistHeader) {
		this.checklistHeader = checklistHeader;
	}

	
	
}
