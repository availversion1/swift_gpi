package com.ett.bob.tfbo.model;

public class AlertMessagesVO {
	private String errorDetails;

	public String getErrorDetails() {
		return errorDetails;
	}

	public void setErrorDetails(String errorDetails) {
		this.errorDetails = errorDetails;
	}

}
