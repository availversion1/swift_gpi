package com.ett.bob.tfbo.model;

import java.util.List;

public class ProfileManagementVO {
	
	public String BranchAddr;
	public String MobileNo;
	public String BRPhoneSTD;
	public String SwiftCode;
	public String AlphaCode;
	public String SolID;
	public String currentPage;
	public String userFlag;
	public String errorDetailsList;
	public String sessionUserName;

	
	public String getSessionUserName() {
		return sessionUserName;
	}
	public void setSessionUserName(String sessionUserName) {
		this.sessionUserName = sessionUserName;
	}
	public  List<BrabchProfileMgmt> branchProfileSolid;
	
	
	
	public String getUserFlag() {
		return userFlag;
	}
	public void setUserFlag(String userFlag) {
		this.userFlag = userFlag;
	}
	public String getErrorDetailsList() {
		return errorDetailsList;
	}
	public void setErrorDetailsList(String errorDetailsList) {
		this.errorDetailsList = errorDetailsList;
	}
	public String getCurrentPage() {
		return currentPage;
	}
	public void setCurrentPage(String currentPage) {
		this.currentPage = currentPage;
	}
	public List<BrabchProfileMgmt> getBranchProfileSolid() {
		return branchProfileSolid;
	}
	public void setBranchProfileSolid(List<BrabchProfileMgmt> branchProfileSolid) {
		this.branchProfileSolid = branchProfileSolid;
	}
	public String getBranchAddr() {
		return BranchAddr;
	}
	public void setBranchAddr(String branchAddr) {
		BranchAddr = branchAddr;
	}
	public String getMobileNo() {
		return MobileNo;
	}
	public void setMobileNo(String mobileNo) {
		MobileNo = mobileNo;
	}
	public String getBRPhoneSTD() {
		return BRPhoneSTD;
	}
	public void setBRPhoneSTD(String bRPhoneSTD) {
		BRPhoneSTD = bRPhoneSTD;
	}
	public String getSwiftCode() {
		return SwiftCode;
	}
	public void setSwiftCode(String swiftCode) {
		SwiftCode = swiftCode;
	}
	public String getAlphaCode() {
		return AlphaCode;
	}
	public void setAlphaCode(String alphaCode) {
		AlphaCode = alphaCode;
	}
	public String getSolID() {
		return SolID;
	}
	public void setSolID(String solID) {
		SolID = solID;
	}

	
}
