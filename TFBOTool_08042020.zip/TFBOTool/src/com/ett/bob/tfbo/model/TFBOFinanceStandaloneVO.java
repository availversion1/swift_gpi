package com.ett.bob.tfbo.model;

public class TFBOFinanceStandaloneVO {
	public String requestId;
	public String tiReferenceNo;
	public String subProductCode;
	public String customeCif;
	public String amount;
	public String currency;
	public String solID;
	public String usancePeriod;
	public String rateTaken;
	public String token;
	public String rateTakenK;
	public String rate;
	public String maturityDate;
	public String pcAmount;
	public String partLiqu;
	
	
	public String getPcAmount() {
		return pcAmount;
	}
	public void setPcAmount(String pcAmount) {
		this.pcAmount = pcAmount;
	}
	public String getPartLiqu() {
		return partLiqu;
	}
	public void setPartLiqu(String partLiqu) {
		this.partLiqu = partLiqu;
	}
	public String getMaturityDate() {
		return maturityDate;
	}
	public void setMaturityDate(String maturityDate) {
		this.maturityDate = maturityDate;
	}
	public String getRequestId() {
		return requestId;
	}
	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}
	public String getTiReferenceNo() {
		return tiReferenceNo;
	}
	public void setTiReferenceNo(String tiReferenceNo) {
		this.tiReferenceNo = tiReferenceNo;
	}
	public String getSubProductCode() {
		return subProductCode;
	}
	public void setSubProductCode(String subProductCode) {
		this.subProductCode = subProductCode;
	}
	public String getCustomeCif() {
		return customeCif;
	}
	public void setCustomeCif(String customeCif) {
		this.customeCif = customeCif;
	}
	public String getAmount() {
		return amount;
	}
	public void setAmount(String amount) {
		this.amount = amount;
	}
	public String getCurrency() {
		return currency;
	}
	public void setCurrency(String currency) {
		this.currency = currency;
	}
	public String getSolID() {
		return solID;
	}
	public void setSolID(String solID) {
		this.solID = solID;
	}
	public String getUsancePeriod() {
		return usancePeriod;
	}
	public void setUsancePeriod(String usancePeriod) {
		this.usancePeriod = usancePeriod;
	}
	public String getRateTaken() {
		return rateTaken;
	}
	public void setRateTaken(String rateTaken) {
		this.rateTaken = rateTaken;
	}
	public String getToken() {
		return token;
	}
	public void setToken(String token) {
		this.token = token;
	}
	public String getRateTakenK() {
		return rateTakenK;
	}
	public void setRateTakenK(String rateTakenK) {
		this.rateTakenK = rateTakenK;
	}
	public String getRate() {
		return rate;
	}
	public void setRate(String rate) {
		this.rate = rate;
	}
	
}
