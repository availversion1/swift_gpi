package com.ett.bob.tfbo.model;

import java.util.List;

public class TFBODashboardVO {

	List<TFBODashboardCountVO> dashboardBranchCountList;
	List<TFBODashboardCountVO> dashboardFBOCountList;

	public List<TFBODashboardCountVO> getDashboardBranchCountList() {
		return dashboardBranchCountList;
	}

	public void setDashboardBranchCountList(
			List<TFBODashboardCountVO> dashboardBranchCountList) {
		this.dashboardBranchCountList = dashboardBranchCountList;
	}

	public List<TFBODashboardCountVO> getDashboardFBOCountList() {
		return dashboardFBOCountList;
	}

	public void setDashboardFBOCountList(
			List<TFBODashboardCountVO> dashboardFBOCountList) {
		this.dashboardFBOCountList = dashboardFBOCountList;
	}

}
