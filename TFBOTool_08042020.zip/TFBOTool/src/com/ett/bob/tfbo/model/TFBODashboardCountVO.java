package com.ett.bob.tfbo.model;

public class TFBODashboardCountVO {

	int sno;
	String lableName;
	int ilcCount;
	int elcCount;
	int idcCount;
	int odcCount;
	int felCount;
	int focCount;
	int isbCount;
	int cpcoCount;
	int igtCount;
	// Inward Remittance changes 23-12-2019 starts
	int cpciCount;
	// Inward Remittance changes 23-12-2019 ends

	int idcDirectCount;
	int idcInDirectCount;
	int odcInDirectCount;
	int elcFinSameDayYes;
	int elcFinSameDayNo;
	public int getElcFinSameDayNo() {
		return elcFinSameDayNo;
	}

	public void setElcFinSameDayNo(int elcFinSameDayNo) {
		this.elcFinSameDayNo = elcFinSameDayNo;
	}

	int elcFinSameDayQueue;

	public int getElcFinSameDayQueue() {
		return elcFinSameDayQueue;
	}

	public void setElcFinSameDayQueue(int elcFinSameDayQueue) {
		this.elcFinSameDayQueue = elcFinSameDayQueue;
	}

	public int getElcFinSameDayYes() {
		return elcFinSameDayYes;
	}

	public void setElcFinSameDayYes(int elcFinSameDayYes) {
		this.elcFinSameDayYes = elcFinSameDayYes;
	}

	public int getOdcInDirectCount() {
		return odcInDirectCount;
	}

	public void setOdcInDirectCount(int odcInDirectCount) {
		this.odcInDirectCount = odcInDirectCount;
	}

	int misData;

	public int getMisData() {
		return misData;
	}

	public void setMisData(int misData) {
		this.misData = misData;
	}

	int idcCheck;
	int odcDirectSameDFinYes;
	int odcDirectSameDFinNo;
	int odcDirectMtNonPart;
	int odcDirectMtFull;
	int mtFullPayQueue;
	int FinSameDayQueue;
	int subFullPayQueue;
	int subFullPay;

	public int getOdcDirectSameDFinYes() {
		return odcDirectSameDFinYes;
	}

	public void setOdcDirectSameDFinYes(int odcDirectSameDFinYes) {
		this.odcDirectSameDFinYes = odcDirectSameDFinYes;
	}

	public int getOdcDirectSameDFinNo() {
		return odcDirectSameDFinNo;
	}

	public void setOdcDirectSameDFinNo(int odcDirectSameDFinNo) {
		this.odcDirectSameDFinNo = odcDirectSameDFinNo;
	}

	public int getOdcDirectMtNonPart() {
		return odcDirectMtNonPart;
	}

	public void setOdcDirectMtNonPart(int odcDirectMtNonPart) {
		this.odcDirectMtNonPart = odcDirectMtNonPart;
	}

	public int getOdcDirectMtFull() {
		return odcDirectMtFull;
	}

	public void setOdcDirectMtFull(int odcDirectMtFull) {
		this.odcDirectMtFull = odcDirectMtFull;
	}

	public int getMtFullPayQueue() {
		return mtFullPayQueue;
	}

	public void setMtFullPayQueue(int mtFullPayQueue) {
		this.mtFullPayQueue = mtFullPayQueue;
	}

	public int getFinSameDayQueue() {
		return FinSameDayQueue;
	}

	public void setFinSameDayQueue(int finSameDayQueue) {
		FinSameDayQueue = finSameDayQueue;
	}

	public int getSubFullPayQueue() {
		return subFullPayQueue;
	}

	public void setSubFullPayQueue(int subFullPayQueue) {
		this.subFullPayQueue = subFullPayQueue;
	}

	public int getSubFullPay() {
		return subFullPay;
	}

	public void setSubFullPay(int subFullPay) {
		this.subFullPay = subFullPay;
	}

	public int getIdcDirectCount() {
		return idcDirectCount;
	}

	public void setIdcDirectCount(int idcDirectCount) {
		this.idcDirectCount = idcDirectCount;
	}

	public int getIdcInDirectCount() {
		return idcInDirectCount;
	}

	public void setIdcInDirectCount(int idcInDirectCount) {
		this.idcInDirectCount = idcInDirectCount;
	}

	public int getIdcCheck() {
		return idcCheck;
	}

	public void setIdcCheck(int idcCheck) {
		this.idcCheck = idcCheck;
	}

	// Miscellanous changes starts 08-01-2020
	int corCount;

	public int getCorCount() {
		return corCount;
	}

	public void setCorCount(int corCount) {
		this.corCount = corCount;
	}

	// Miscellanous changes ends 08-01-2020

	public int getFsaCount() {
		return fsaCount;
	}

	public int getIsbCount() {
		return isbCount;
	}

	public void setIsbCount(int isbCount) {
		this.isbCount = isbCount;
	}

	public int getCpcoCount() {
		return cpcoCount;
	}

	public void setCpcoCount(int cpcoCount) {
		this.cpcoCount = cpcoCount;
	}

	public int getIgtCount() {
		return igtCount;
	}

	public void setIgtCount(int igtCount) {
		this.igtCount = igtCount;
	}

	public void setFsaCount(int fsaCount) {
		this.fsaCount = fsaCount;
	}

	int fsaCount;

	public int getFocCount() {
		return focCount;
	}

	public void setFocCount(int focCount) {
		this.focCount = focCount;
	}

	public int getFelCount() {
		return felCount;
	}

	public void setFelCount(int felCount) {
		this.felCount = felCount;
	}

	public int getElcCount() {
		return elcCount;
	}

	public void setElcCount(int elcCount) {
		this.elcCount = elcCount;
	}

	public int getIdcCount() {
		return idcCount;
	}

	public void setIdcCount(int idcCount) {
		this.idcCount = idcCount;
	}

	public int getOdcCount() {
		return odcCount;
	}

	public void setOdcCount(int odcCount) {
		this.odcCount = odcCount;
	}

	public int getSno() {
		return sno;
	}

	public void setSno(int sno) {
		this.sno = sno;
	}

	public String getLableName() {
		return lableName;
	}

	public void setLableName(String lableName) {
		this.lableName = lableName;
	}

	public int getIlcCount() {
		return ilcCount;
	}

	public void setIlcCount(int ilcCount) {
		this.ilcCount = ilcCount;
	}

	// Inward Remittance changes 23-12-2019 starts
	public int getCpciCount() {
		return cpciCount;
	}

	public void setCpciCount(int cpciCount) {
		this.cpciCount = cpciCount;
	}

	// Inward Remittance changes 23-12-2019 ends
}
