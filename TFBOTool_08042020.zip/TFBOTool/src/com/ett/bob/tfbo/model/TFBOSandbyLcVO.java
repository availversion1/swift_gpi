package com.ett.bob.tfbo.model;

import java.util.List;

public class TFBOSandbyLcVO {

	public String requestId;
	public String solID;
	public String tiReferanceNo;
	public String customeCif;
	public String customeName;
	public String amount;
	public String currency;
	public String rateTaken;
	public String billUsancePeriod;
	public String bgRefNo;
	public String billrefno;
	public String subProductCode;
	public String ConBillRef;
	public String billreference;
	public String tenure;
	public String token;
	public String valueK;
	public String rate;

	public String getToken() {
		return token;
	}

	public void setToken(String token) {
		this.token = token;
	}

	public String getValueK() {
		return valueK;
	}

	public void setValueK(String valueK) {
		this.valueK = valueK;
	}

	public String getRate() {
		return rate;
	}

	public void setRate(String rate) {
		this.rate = rate;
	}

	public String getTenure() {
		return tenure;
	}

	public void setTenure(String tenure) {
		this.tenure = tenure;
	}

	public String getBillreference() {
		return billreference;
	}

	public void setBillreference(String billreference) {
		this.billreference = billreference;
	}

	public List<String> billReference;

	public List<String> getBillReference() {
		return billReference;
	}

	public void setBillReference(List<String> billReference) {
		this.billReference = billReference;
	}

	public String getConBillRef() {
		return ConBillRef;
	}

	public void setConBillRef(String conBillRef) {
		ConBillRef = conBillRef;
	}

	public String getRequestId() {
		return requestId;
	}

	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}

	public String getSolID() {
		return solID;
	}

	public void setSolID(String solID) {
		this.solID = solID;
	}

	public String getTiReferanceNo() {
		return tiReferanceNo;
	}

	public void setTiReferanceNo(String tiReferanceNo) {
		this.tiReferanceNo = tiReferanceNo;
	}

	public String getCustomeCif() {
		return customeCif;
	}

	public void setCustomeCif(String customeCif) {
		this.customeCif = customeCif;
	}

	public String getCustomeName() {
		return customeName;
	}

	public void setCustomeName(String customeName) {
		this.customeName = customeName;
	}

	public String getAmount() {
		return amount;
	}

	public void setAmount(String amount) {
		this.amount = amount;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public String getRateTaken() {
		return rateTaken;
	}

	public void setRateTaken(String rateTaken) {
		this.rateTaken = rateTaken;
	}

	public String getBillUsancePeriod() {
		return billUsancePeriod;
	}

	public void setBillUsancePeriod(String billUsancePeriod) {
		this.billUsancePeriod = billUsancePeriod;
	}

	public String getBgRefNo() {
		return bgRefNo;
	}

	public void setBgRefNo(String bgRefNo) {
		this.bgRefNo = bgRefNo;
	}

	public String getBillrefno() {
		return billrefno;
	}

	public void setBillrefno(String billrefno) {
		this.billrefno = billrefno;
	}

	public String getSubProductCode() {
		return subProductCode;
	}

	public void setSubProductCode(String subProductCode) {
		this.subProductCode = subProductCode;
	}

}
