package com.ett.bob.tfbo.model;

public class TFBOExportLcVO {
	public String requestId;
	public String tiReferenceNo;
	public String customeCif;
	public String customeName;
	public String amount;
	public String currency;
	public String solID;
	public String lcType;
	public String usancePeriod;
	public String LCreceivedSWIFT;
	public String senderRefno;
	public String subProductCode;
	// Changes for ELC and IGT Starts 25-12-2019
	public String acceptanceAmount;
	public String rateTaken;
	public String token;
	public String valueK;
	public String rate;
	public String userRemark;
	public String finSameDay;

	public String getFinSameDay() {
		return finSameDay;
	}

	public void setFinSameDay(String finSameDay) {
		this.finSameDay = finSameDay;
	}

	public String getUserRemark() {
		return userRemark;
	}

	public void setUserRemark(String userRemark) {
		this.userRemark = userRemark;
	}

	public String billReference;

	public String getBillReference() {
		return billReference;
	}

	public void setBillReference(String billReference) {
		this.billReference = billReference;
	}

	public String getAcceptanceAmount() {
		return acceptanceAmount;
	}

	public void setAcceptanceAmount(String acceptanceAmount) {
		this.acceptanceAmount = acceptanceAmount;
	}

	public String getRateTaken() {
		return rateTaken;
	}

	public void setRateTaken(String rateTaken) {
		this.rateTaken = rateTaken;
	}

	public String getToken() {
		return token;
	}

	public void setToken(String token) {
		this.token = token;
	}

	public String getValueK() {
		return valueK;
	}

	public void setValueK(String valueK) {
		this.valueK = valueK;
	}

	public String getRate() {
		return rate;
	}

	public void setRate(String rate) {
		this.rate = rate;
	}

	// Changes for ELC and IGT ends 25-12-2019
	// ELC DOP Issue Fix 20-12-2019 starts
	public String preshipAccSetteld;

	public String getPreshipAccSetteld() {
		return preshipAccSetteld;
	}

	public void setPreshipAccSetteld(String preshipAccSetteld) {
		this.preshipAccSetteld = preshipAccSetteld;
	}

	// ELC DOP Issue Fix 20-12-2019 ends

	public String getSubProductCode() {
		return subProductCode;
	}

	public void setSubProductCode(String subProductCode) {
		this.subProductCode = subProductCode;
	}

	public String getRequestId() {
		return requestId;
	}

	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}

	public String getTiReferenceNo() {
		return tiReferenceNo;
	}

	public void setTiReferenceNo(String tiReferenceNo) {
		this.tiReferenceNo = tiReferenceNo;
	}

	public String getCustomeCif() {
		return customeCif;
	}

	public void setCustomeCif(String customeCif) {
		this.customeCif = customeCif;
	}

	public String getAmount() {
		return amount;
	}

	public void setAmount(String amount) {
		this.amount = amount;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public String getSolID() {
		return solID;
	}

	public void setSolID(String solID) {
		this.solID = solID;
	}

	public String getLcType() {
		return lcType;
	}

	public void setLcType(String lcType) {
		this.lcType = lcType;
	}

	public String getUsancePeriod() {
		return usancePeriod;
	}

	public void setUsancePeriod(String usancePeriod) {
		this.usancePeriod = usancePeriod;
	}

	public String getCustomeName() {
		return customeName;
	}

	public void setCustomeName(String customeName) {
		this.customeName = customeName;
	}

	public String getLCreceivedSWIFT() {
		return LCreceivedSWIFT;
	}

	public void setLCreceivedSWIFT(String lCreceivedSWIFT) {
		LCreceivedSWIFT = lCreceivedSWIFT;
	}

	public String getSenderRefno() {
		return senderRefno;
	}

	public void setSenderRefno(String senderRefno) {
		this.senderRefno = senderRefno;
	}
}