package com.ett.bob.tfbo.model;

import java.util.List;

public class UserTransactionVO {

	public String userName;
	public String password;
	public String formToken;

	public String rtetkn;
	public String rte;
	public String tkn;
	public String k;
	public boolean transLockFlag;
	public String lockUser;
	public String lockTransno;
	public String typeOfDoc;
	
	// Added by Kamakshya for SAC transaction start
		public String userNameSAC;
		public String requestIDSAC;
	// Added by Kamakshya for SAC transaction end

	
	
	public String getTypeOfDoc() {
		return typeOfDoc;
	}

	public String getUserNameSAC() {
		return userNameSAC;
	}

	public void setUserNameSAC(String userNameSAC) {
		this.userNameSAC = userNameSAC;
	}

	public String getRequestIDSAC() {
		return requestIDSAC;
	}

	public void setRequestIDSAC(String requestIDSAC) {
		this.requestIDSAC = requestIDSAC;
	}

	public void setTypeOfDoc(String typeOfDoc) {
		this.typeOfDoc = typeOfDoc;
	}
	public String getLockTransno() {
		return lockTransno;
	}

	public void setLockTransno(String lockTransno) {
		this.lockTransno = lockTransno;
	}

	public String getLockUser() {
		return lockUser;
	}

	public void setLockUser(String lockUser) {
		this.lockUser = lockUser;
	}

	public boolean isTransLockFlag() {
		return transLockFlag;
	}

	public void setTransLockFlag(boolean transLockFlag) {
		this.transLockFlag = transLockFlag;
	}

	public String docID;
	public String custCif;
	public String tiRefNo;
	public String documentPath;
	public String documentName;
	public String directOption;

	public String currentPage;

	public String userComment;
	public String sentMailToBranch;
	public String sentMailToCustomer;
	public String mailToCustomer;

	public String requestIdGridValue;
	public String productCodeGridValue;
	public String eventCodeGridValue;
	public String requestId;
	public String productCode;
	public String eventCode;
	public String subProductCode;
	public String productName;
	public String eventName;
	public String tiReferanceNo;
	public String customeCif;
	public String customeName;
	public String amount;
	public String currency;
	public String solID;
	public String lcType;
	public String usancePeriod;
	public String lcReceivedSWIFT;
	public String senderRefno;
	public String finalPayment;
	public String senderRefNo;
	public String billRefNo;
	public String devolvementAmount;

	/* Dashboard changes 23012020 starts */
	public String solIdFilter;
	public String customerNameFilter;
	/* Dashboard changes 23012020 ends */

	// Inward Remittance changes 23-12-2019 starts
	public String dummyIrex;
	// Inward Remittance changes 23-12-2019 ends

	// Outward Remittance Changes 23/12/2019 start
	public String bankpayment;
	public List<TFBOOutwardRemittanceVO> outwardRemittanceList;
	// Outward Remittance Changes 23/12/2019 end

	public String partpay;
	public String prdType;
	public String acceptBillAmt;
	public List<TFBOIdcVO> importIdcList;

	public List<DocumentUploadVO> documentList;
	public List<TFBOTransVO> transactionList;
	public String sessionUserName;
	public List<TFBOImportLcVO> importLcList;
	public List<UserCommentVO> userCommentList;
	public List<UserCommentVO> customerCommentList;
	public List<AlertMessagesVO> errorDetailsList;
	public List<TFBOChecklistVO> branchMakerCheckList;
	public List<TFBOChecklistVO> fboScrutinizerCheckList;
	public List<TFBOExportLcVO> exportLcList;

	// Inward Remittance changes 23-12-2019 starts
	public List<TFBOInwardRemittanceVO> inwardRemittanceList;
	// Inward Remittance changes 23-12-2019 ends

	public String requestIdFilter;
	public String productFilter;
	public String eventFilter;
	public String productCodeFilter;
	public String eventCodeFilter;
	public String fromDateFilter;
	public String toDateFilter;
	public String statusFilter;
	public String isQueriedFilter;
	public String stepFilter;
	public String returnPage;
	public String isTiTransFlag;

	public String checklistValue;

	public String userFlag;
	public String userFBOMaker;
	public String userFBOChecker;

	public String prdCode;
	public String evtCode;

	public String billAmount;
	public String payType;
	public boolean partAmount;
	public String claimAmount;
	public String billUsancePeriod;
	public String rateTaken;
	public String token;
	public String valueK;
	public String rate;
	public String billReference;
	public List<String> billReferenceList;

	public String direct;
	public String partPayment;
	public String preshipAccSetteld;
	public String rateTakenK;
	public String mtReceived;
	public String directCompFlag;
	public String idenOdcType;

	public String productTypeIDC;
	public String documentDispatch;
	public String financeSameDay;
	public String shipBillFetch;
	public String exchangeRate;
	public String docketNo;

	public String lcRefNum;
	public String billReferenceNo;
	public String fncAmount;
	public String billTenure;
	public String preshipAcc;
	public String pcAmount;
	public String partliqu;

	// SBLC_25122019
	public String ConBillRef;
	public String bgRefNo;
	public String billrefno;
	public List<TFBOSandbyLcVO> standByLCList;

	// Changes for ELC and IGT Starts 25-12-2019

	public String expiryDate;
	public String tenureDays;
	public String reqInvAmt;
	public String guarnteeAmtPrevInv;
	public String partInvocation;
	public String KplusValue;
	public String acceptanceAmount;
	public String tenure;
	public List<TFBOImportGTVO> importGuaranteeList;
	public String userRemark;
	// Tat Report starts

	public String tatfromDateFilter;
	public String tattoDateFilter;

	public String subProdCode;
	public String tot;
	public String daysCount1;
	public String daysPer1;
	public String daysCount2;
	public String daysPer2;
	public String daysCount3;
	public String daysPer3;
	public String daysCount4;
	public String daysPer4;
	public String odiSubProductType;

	public String remarks;

	public String othersSubProductType;

	// Rate taken Fix Offshore Team 06012020 starts
	public String irexRefNo;
	// Dashboard Changes starts 07-01-2020
	public List<TFBOMiscellanousVO> miscellanousVOList;
	public String subProductFilter;
	public String tiReferenceFilter;
	public String tiReferanceNoGridValue;

	public String miscellComment;
	public String miscellcheckerComment;

	public String team;
	public String branch;
	public String masReferanceNo;
    public String finCurrency;
    public String bevStatus;
    
    public String stepPhase;

    
	public String getStepPhase() {
		return stepPhase;
	}

	public void setStepPhase(String stepPhase) {
		this.stepPhase = stepPhase;
	}

		
	public String getBevStatus() {
		return bevStatus;
	}

	public void setBevStatus(String bevStatus) {
		this.bevStatus = bevStatus;
	}

	public String getFinCurrency() {
		return finCurrency;
	}

	public void setFinCurrency(String finCurrency) {
		this.finCurrency = finCurrency;
	}
	

	public String getMasReferanceNo() {
		return masReferanceNo;
	}

	public void setMasReferanceNo(String masReferanceNo) {
		this.masReferanceNo = masReferanceNo;
	}

	public String getTeam() {
		return team;
	}

	public void setTeam(String team) {
		this.team = team;
	}

	public String getBranch() {
		return branch;
	}

	public void setBranch(String branch) {
		this.branch = branch;
	}

	public String getMiscellcheckerComment() {
		return miscellcheckerComment;
	}

	public void setMiscellcheckerComment(String miscellcheckerComment) {
		this.miscellcheckerComment = miscellcheckerComment;
	}

	public String getMiscellComment() {
		return miscellComment;
	}

	public void setMiscellComment(String miscellComment) {
		this.miscellComment = miscellComment;
	}

	public String getRtetkn() {
		return rtetkn;
	}

	public void setRtetkn(String rtetkn) {
		this.rtetkn = rtetkn;
	}

	public String getRte() {
		return rte;
	}

	public void setRte(String rte) {
		this.rte = rte;
	}

	public String getTkn() {
		return tkn;
	}

	public void setTkn(String tkn) {
		this.tkn = tkn;
	}

	public String getK() {
		return k;
	}

	public void setK(String k) {
		this.k = k;
	}

	public String getDirectOption() {
		return directOption;
	}

	public void setDirectOption(String directOption) {
		this.directOption = directOption;
	}

	public String getDirectCompFlag() {
		return directCompFlag;
	}

	public void setDirectCompFlag(String directCompFlag) {
		this.directCompFlag = directCompFlag;
	}

	public String getIdenOdcType() {
		return idenOdcType;
	}

	public void setIdenOdcType(String idenOdcType) {
		this.idenOdcType = idenOdcType;
	}

	public String getSolIdFilter() {
		return solIdFilter;
	}

	public void setSolIdFilter(String solIdFilter) {
		this.solIdFilter = solIdFilter;
	}

	public String getCustomerNameFilter() {
		return customerNameFilter;
	}

	public void setCustomerNameFilter(String customerNameFilter) {
		this.customerNameFilter = customerNameFilter;
	}

	public String getSubProdCode() {
		return subProdCode;
	}

	public void setSubProdCode(String subProdCode) {
		this.subProdCode = subProdCode;
	}

	public String getTot() {
		return tot;
	}

	public void setTot(String tot) {
		this.tot = tot;
	}

	public String getDaysCount1() {
		return daysCount1;
	}

	public void setDaysCount1(String daysCount1) {
		this.daysCount1 = daysCount1;
	}

	public String getDaysPer1() {
		return daysPer1;
	}

	public void setDaysPer1(String daysPer1) {
		this.daysPer1 = daysPer1;
	}

	public String getDaysCount2() {
		return daysCount2;
	}

	public void setDaysCount2(String daysCount2) {
		this.daysCount2 = daysCount2;
	}

	public String getDaysPer2() {
		return daysPer2;
	}

	public void setDaysPer2(String daysPer2) {
		this.daysPer2 = daysPer2;
	}

	public String getDaysCount3() {
		return daysCount3;
	}

	public void setDaysCount3(String daysCount3) {
		this.daysCount3 = daysCount3;
	}

	public String getDaysPer3() {
		return daysPer3;
	}

	public void setDaysPer3(String daysPer3) {
		this.daysPer3 = daysPer3;
	}

	public String getDaysCount4() {
		return daysCount4;
	}

	public void setDaysCount4(String daysCount4) {
		this.daysCount4 = daysCount4;
	}

	public String getDaysPer4() {
		return daysPer4;
	}

	public void setDaysPer4(String daysPer4) {
		this.daysPer4 = daysPer4;
	}

	public String getTatfromDateFilter() {
		return tatfromDateFilter;
	}

	public void setTatfromDateFilter(String tatfromDateFilter) {
		this.tatfromDateFilter = tatfromDateFilter;
	}

	public String getTattoDateFilter() {
		return tattoDateFilter;
	}

	public void setTattoDateFilter(String tattoDateFilter) {
		this.tattoDateFilter = tattoDateFilter;
	}

	// Tat Report ends

	// Miscellanous changes starts 08-01-2020

	public String getOthersSubProductType() {
		return othersSubProductType;
	}

	public void setOthersSubProductType(String othersSubProductType) {
		this.othersSubProductType = othersSubProductType;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public String getOdiSubProductType() {
		return odiSubProductType;
	}

	public void setOdiSubProductType(String odiSubProductType) {
		this.odiSubProductType = odiSubProductType;
	}

	public List<TFBOMiscellanousVO> getMiscellanousVOList() {
		return miscellanousVOList;
	}

	public void setMiscellanousVOList(
			List<TFBOMiscellanousVO> miscellanousVOList) {
		this.miscellanousVOList = miscellanousVOList;
	}

	// Miscellanous changes ends 08-01-2020

	public String getUserRemark() {
		return userRemark;
	}

	public void setUserRemark(String userRemark) {
		this.userRemark = userRemark;
	}

	public String getTiReferanceNoGridValue() {
		return tiReferanceNoGridValue;
	}

	public void setTiReferanceNoGridValue(String tiReferanceNoGridValue) {
		this.tiReferanceNoGridValue = tiReferanceNoGridValue;
	}

	public String getSubProductFilter() {
		return subProductFilter;
	}

	public void setSubProductFilter(String subProductFilter) {
		this.subProductFilter = subProductFilter;
	}

	public String getTiReferenceFilter() {
		return tiReferenceFilter;
	}

	public void setTiReferenceFilter(String tiReferenceFilter) {
		this.tiReferenceFilter = tiReferenceFilter;
	}

	// Dashboard Changes ends 07-01-2020

	public String getIrexRefNo() {
		return irexRefNo;
	}

	public void setIrexRefNo(String irexRefNo) {
		this.irexRefNo = irexRefNo;
	}

	// Rate taken Fix Offshore Team 06012020 ends
	// FREEZING(SCENARIO) off shore team starts 31122019
	public String directCREEvent;

	public String getDirectCREEvent() {
		return directCREEvent;
	}

	public void setDirectCREEvent(String directCREEvent) {
		this.directCREEvent = directCREEvent;
	}

	// FREEZING(SCENARIO) off shore team ends 31122019

	public List<TFBOImportGTVO> getImportGuaranteeList() {
		return importGuaranteeList;
	}

	public void setImportGuaranteeList(List<TFBOImportGTVO> importGuaranteeList) {
		this.importGuaranteeList = importGuaranteeList;
	}

	// Changes for ELC and IGT ends 25-12-2019
	public String getTenure() {
		return tenure;
	}

	public void setTenure(String tenure) {
		this.tenure = tenure;
	}

	public String getExpiryDate() {
		return expiryDate;
	}

	public void setExpiryDate(String expiryDate) {
		this.expiryDate = expiryDate;
	}

	public String getTenureDays() {
		return tenureDays;
	}

	public void setTenureDays(String tenureDays) {
		this.tenureDays = tenureDays;
	}

	public String getReqInvAmt() {
		return reqInvAmt;
	}

	public void setReqInvAmt(String reqInvAmt) {
		this.reqInvAmt = reqInvAmt;
	}

	public String getGuarnteeAmtPrevInv() {
		return guarnteeAmtPrevInv;
	}

	public void setGuarnteeAmtPrevInv(String guarnteeAmtPrevInv) {
		this.guarnteeAmtPrevInv = guarnteeAmtPrevInv;
	}

	public String getPartInvocation() {
		return partInvocation;
	}

	public void setPartInvocation(String partInvocation) {
		this.partInvocation = partInvocation;
	}

	public String getKplusValue() {
		return KplusValue;
	}

	public void setKplusValue(String kplusValue) {
		KplusValue = kplusValue;
	}

	public String getAcceptanceAmount() {
		return acceptanceAmount;
	}

	public void setAcceptanceAmount(String acceptanceAmount) {
		this.acceptanceAmount = acceptanceAmount;
	}

	public String getConBillRef() {
		return ConBillRef;
	}

	public void setConBillRef(String conBillRef) {
		ConBillRef = conBillRef;
	}

	public String getBgRefNo() {
		return bgRefNo;
	}

	public void setBgRefNo(String bgRefNo) {
		this.bgRefNo = bgRefNo;
	}

	public String getBillrefno() {
		return billrefno;
	}

	public void setBillrefno(String billrefno) {
		this.billrefno = billrefno;
	}

	public List<TFBOSandbyLcVO> getStandByLCList() {
		return standByLCList;
	}

	public void setStandByLCList(List<TFBOSandbyLcVO> standByLCList) {
		this.standByLCList = standByLCList;
	}

	public String getPcAmount() {
		return pcAmount;
	}

	public void setPcAmount(String pcAmount) {
		this.pcAmount = pcAmount;
	}

	public String getPartliqu() {
		return partliqu;
	}

	public void setPartliqu(String partliqu) {
		this.partliqu = partliqu;
	}

	public List<TFBOExportCollectionVO> exportCollectionList;
	public List<TFBOFinanceExportLcVO> financeExportLCList;
	// Added by divya for FOC-CRE starts
	public String financeAmount;

	public String getFinanceAmount() {
		return financeAmount;
	}

	public void setFinanceAmount(String financeAmount) {
		this.financeAmount = financeAmount;
	}

	public List<TFBOFinanceExportColVO> getFinExportCollectionList() {
		return FinExportCollectionList;
	}

	public void setFinExportCollectionList(
			List<TFBOFinanceExportColVO> finExportCollectionList) {
		FinExportCollectionList = finExportCollectionList;
	}

	public String getFOCProductType() {
		return FOCProductType;
	}

	public void setFOCProductType(String fOCProductType) {
		FOCProductType = fOCProductType;
	}

	public String getMaturityDate() {
		return maturityDate;
	}

	public void setMaturityDate(String maturityDate) {
		this.maturityDate = maturityDate;
	}

	public List<TFBOFinanceExportColVO> FinExportCollectionList;
	public List<TFBOFinanceStandaloneVO> FinStandaloneList;

	public List<TFBOFinanceStandaloneVO> getFinStandaloneList() {
		return FinStandaloneList;
	}

	public void setFinStandaloneList(
			List<TFBOFinanceStandaloneVO> finStandaloneList) {
		FinStandaloneList = finStandaloneList;
	}

	public String FOCProductType;
	// FOC - ADJ
	public String maturityDate;

	public String getDevolvementAmount() {
		return devolvementAmount;
	}

	public void setDevolvementAmount(String devolvementAmount) {
		this.devolvementAmount = devolvementAmount;
	}

	public String getBillRefNo() {
		return billRefNo;
	}

	public void setBillRefNo(String billRefNo) {
		this.billRefNo = billRefNo;
	}

	public List<TFBOFinanceExportLcVO> getFinanceExportLCList() {
		return financeExportLCList;
	}

	public void setFinanceExportLCList(
			List<TFBOFinanceExportLcVO> financeExportLCList) {
		this.financeExportLCList = financeExportLCList;
	}

	public String getBillReference() {
		return billReference;
	}

	public void setBillReference(String billReference) {
		this.billReference = billReference;
	}

	public String getLcRefNum() {
		return lcRefNum;
	}

	public void setLcRefNum(String lcRefNum) {
		this.lcRefNum = lcRefNum;
	}

	public String getBillReferenceNo() {
		return billReferenceNo;
	}

	public void setBillReferenceNo(String billReferenceNo) {
		this.billReferenceNo = billReferenceNo;
	}

	public String getFncAmount() {
		return fncAmount;
	}

	public void setFncAmount(String fncAmount) {
		this.fncAmount = fncAmount;
	}

	public String getBillTenure() {
		return billTenure;
	}

	public void setBillTenure(String billTenure) {
		this.billTenure = billTenure;
	}

	public String getPreshipAcc() {
		return preshipAcc;
	}

	public void setPreshipAcc(String preshipAcc) {
		this.preshipAcc = preshipAcc;
	}

	public String getFinalPayment() {
		return finalPayment;
	}

	public void setFinalPayment(String finalPayment) {
		this.finalPayment = finalPayment;
	}

	public String getSenderRefNo() {
		return senderRefNo;
	}

	public void setSenderRefNo(String senderRefNo) {
		this.senderRefNo = senderRefNo;
	}

	public String getPartpay() {
		return partpay;
	}

	public void setPartpay(String partpay) {
		this.partpay = partpay;
	}

	public String getPrdType() {
		return prdType;
	}

	public String getAcceptBillAmt() {
		return acceptBillAmt;
	}

	public void setAcceptBillAmt(String acceptBillAmt) {
		this.acceptBillAmt = acceptBillAmt;
	}

	public void setPrdType(String prdType) {
		this.prdType = prdType;
	}

	public List<TFBOIdcVO> getImportIdcList() {
		return importIdcList;
	}

	public void setImportIdcList(List<TFBOIdcVO> importIdcList) {
		this.importIdcList = importIdcList;
	}

	public String getLcReceivedSWIFT() {
		return lcReceivedSWIFT;
	}

	public void setLcReceivedSWIFT(String lcReceivedSWIFT) {
		this.lcReceivedSWIFT = lcReceivedSWIFT;
	}

	public String getSenderRefno() {
		return senderRefno;
	}

	public void setSenderRefno(String senderRefno) {
		this.senderRefno = senderRefno;
	}

	public String getToken() {
		return token;
	}

	public List<TFBOExportLcVO> getExportLcList() {
		return exportLcList;
	}

	public void setExportLcList(List<TFBOExportLcVO> exportLcList) {
		this.exportLcList = exportLcList;
	}

	public String getDirect() {
		return direct;
	}

	public void setDirect(String direct) {
		this.direct = direct;
	}

	public String getPartPayment() {
		return partPayment;
	}

	public void setPartPayment(String partPayment) {
		this.partPayment = partPayment;
	}

	public String getPreshipAccSetteld() {
		return preshipAccSetteld;
	}

	public void setPreshipAccSetteld(String preshipAccSetteld) {
		this.preshipAccSetteld = preshipAccSetteld;
	}

	public String getRateTakenK() {
		return rateTakenK;
	}

	public void setRateTakenK(String rateTakenK) {
		this.rateTakenK = rateTakenK;
	}

	public String getMtReceived() {
		return mtReceived;
	}

	public void setMtReceived(String mtReceived) {
		this.mtReceived = mtReceived;
	}

	public String getProductTypeIDC() {
		return productTypeIDC;
	}

	public void setProductTypeIDC(String productTypeIDC) {
		this.productTypeIDC = productTypeIDC;
	}

	public String getDocumentDispatch() {
		return documentDispatch;
	}

	public void setDocumentDispatch(String documentDispatch) {
		this.documentDispatch = documentDispatch;
	}

	public String getFinanceSameDay() {
		return financeSameDay;
	}

	public void setFinanceSameDay(String financeSameDay) {
		this.financeSameDay = financeSameDay;
	}

	public String getShipBillFetch() {
		return shipBillFetch;
	}

	public void setShipBillFetch(String shipBillFetch) {
		this.shipBillFetch = shipBillFetch;
	}

	public String getExchangeRate() {
		return exchangeRate;
	}

	public void setExchangeRate(String exchangeRate) {
		this.exchangeRate = exchangeRate;
	}

	public String getDocketNo() {
		return docketNo;
	}

	public void setDocketNo(String docketNo) {
		this.docketNo = docketNo;
	}

	public List<TFBOExportCollectionVO> getExportCollectionList() {
		return exportCollectionList;
	}

	public void setExportCollectionList(
			List<TFBOExportCollectionVO> exportCollectionList) {
		this.exportCollectionList = exportCollectionList;
	}

	public void setToken(String token) {
		this.token = token;
	}

	public String getValueK() {
		return valueK;
	}

	public void setValueK(String valueK) {
		this.valueK = valueK;
	}

	public String getRate() {
		return rate;
	}

	public void setRate(String rate) {
		this.rate = rate;
	}

	public String getBillAmount() {
		return billAmount;
	}

	public void setBillAmount(String billAmount) {
		this.billAmount = billAmount;
	}

	public String getPayType() {
		return payType;
	}

	public void setPayType(String payType) {
		this.payType = payType;
	}

	public boolean isPartAmount() {
		return partAmount;
	}

	public void setPartAmount(boolean partAmount) {
		this.partAmount = partAmount;
	}

	public String getClaimAmount() {
		return claimAmount;
	}

	public void setClaimAmount(String claimAmount) {
		this.claimAmount = claimAmount;
	}

	public String getBillUsancePeriod() {
		return billUsancePeriod;
	}

	public void setBillUsancePeriod(String billUsancePeriod) {
		this.billUsancePeriod = billUsancePeriod;
	}

	public String getRateTaken() {
		return rateTaken;
	}

	public void setRateTaken(String rateTaken) {
		this.rateTaken = rateTaken;
	}

	public List<String> getBillReferenceList() {
		return billReferenceList;
	}

	public void setBillReferenceList(List<String> billReferenceList) {
		this.billReferenceList = billReferenceList;
	}

	public String getFormToken() {
		return formToken;
	}

	public void setFormToken(String formToken) {
		this.formToken = formToken;
	}

	public String getSubProductCode() {
		return subProductCode;
	}

	public void setSubProductCode(String subProductCode) {
		this.subProductCode = subProductCode;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getPrdCode() {
		return prdCode;
	}

	public void setPrdCode(String prdCode) {
		this.prdCode = prdCode;
	}

	public String getEvtCode() {
		return evtCode;
	}

	public void setEvtCode(String evtCode) {
		this.evtCode = evtCode;
	}

	public String getUsancePeriod() {
		return usancePeriod;
	}

	public void setUsancePeriod(String usancePeriod) {
		this.usancePeriod = usancePeriod;
	}

	public String getLcType() {
		return lcType;
	}

	public void setLcType(String lcType) {
		this.lcType = lcType;
	}

	public String getTiRefNo() {
		return tiRefNo;
	}

	public void setTiRefNo(String tiRefNo) {
		this.tiRefNo = tiRefNo;
	}

	public String getCustCif() {
		return custCif;
	}

	public void setCustCif(String custCif) {
		this.custCif = custCif;
	}

	public String getCurrentPage() {
		return currentPage;
	}

	public void setCurrentPage(String currentPage) {
		this.currentPage = currentPage;
	}

	public String getIsTiTransFlag() {
		return isTiTransFlag;
	}

	public void setIsTiTransFlag(String isTiTransFlag) {
		this.isTiTransFlag = isTiTransFlag;
	}

	public String getIsQueriedFilter() {
		return isQueriedFilter;
	}

	public void setIsQueriedFilter(String isQueriedFilter) {
		this.isQueriedFilter = isQueriedFilter;
	}

	public String getStepFilter() {
		return stepFilter;
	}

	public void setStepFilter(String stepFilter) {
		this.stepFilter = stepFilter;
	}

	public String getSentMailToBranch() {
		return sentMailToBranch;
	}

	public void setSentMailToBranch(String sentMailToBranch) {
		this.sentMailToBranch = sentMailToBranch;
	}

	public String getSentMailToCustomer() {
		return sentMailToCustomer;
	}

	public void setSentMailToCustomer(String sentMailToCustomer) {
		this.sentMailToCustomer = sentMailToCustomer;
	}

	public String getUserFBOMaker() {
		return userFBOMaker;
	}

	public void setUserFBOMaker(String userFBOMaker) {
		this.userFBOMaker = userFBOMaker;
	}

	public String getUserFBOChecker() {
		return userFBOChecker;
	}

	public void setUserFBOChecker(String userFBOChecker) {
		this.userFBOChecker = userFBOChecker;
	}

	public String getProductCodeGridValue() {
		return productCodeGridValue;
	}

	public void setProductCodeGridValue(String productCodeGridValue) {
		this.productCodeGridValue = productCodeGridValue;
	}

	public String getEventCodeGridValue() {
		return eventCodeGridValue;
	}

	public void setEventCodeGridValue(String eventCodeGridValue) {
		this.eventCodeGridValue = eventCodeGridValue;
	}

	public String getChecklistValue() {
		return checklistValue;
	}

	public void setChecklistValue(String checklistValue) {
		this.checklistValue = checklistValue;
	}

	public String getDocumentPath() {
		return documentPath;
	}

	public void setDocumentPath(String documentPath) {
		this.documentPath = documentPath;
	}

	public String getDocumentName() {
		return documentName;
	}

	public void setDocumentName(String documentName) {
		this.documentName = documentName;
	}

	public List<TFBOChecklistVO> getBranchMakerCheckList() {
		return branchMakerCheckList;
	}

	public void setBranchMakerCheckList(
			List<TFBOChecklistVO> branchMakerCheckList) {
		this.branchMakerCheckList = branchMakerCheckList;
	}

	public List<TFBOChecklistVO> getFboScrutinizerCheckList() {
		return fboScrutinizerCheckList;
	}

	public void setFboScrutinizerCheckList(
			List<TFBOChecklistVO> fboScrutinizerCheckList) {
		this.fboScrutinizerCheckList = fboScrutinizerCheckList;
	}

	public List<UserCommentVO> getUserCommentList() {
		return userCommentList;
	}

	public void setUserCommentList(List<UserCommentVO> userCommentList) {
		this.userCommentList = userCommentList;
	}

	public List<UserCommentVO> getCustomerCommentList() {
		return customerCommentList;
	}

	public void setCustomerCommentList(List<UserCommentVO> customerCommentList) {
		this.customerCommentList = customerCommentList;
	}

	public String getUserComment() {
		return userComment;
	}

	public void setUserComment(String userComment) {
		this.userComment = userComment;
	}

	public String getMailToCustomer() {
		return mailToCustomer;
	}

	public void setMailToCustomer(String mailToCustomer) {
		this.mailToCustomer = mailToCustomer;
	}

	public String getReturnPage() {
		return returnPage;
	}

	public void setReturnPage(String returnPage) {
		this.returnPage = returnPage;
	}

	public String getDocID() {
		return docID;
	}

	public void setDocID(String docID) {
		this.docID = docID;
	}

	public String getUserFlag() {
		return userFlag;
	}

	public void setUserFlag(String userFlag) {
		this.userFlag = userFlag;
	}

	public List<AlertMessagesVO> getErrorDetailsList() {
		return errorDetailsList;
	}

	public void setErrorDetailsList(List<AlertMessagesVO> errorDetailsList) {
		this.errorDetailsList = errorDetailsList;
	}

	public String getRequestIdGridValue() {
		return requestIdGridValue;
	}

	public void setRequestIdGridValue(String requestIdGridValue) {
		this.requestIdGridValue = requestIdGridValue;
	}

	public List<TFBOImportLcVO> getImportLcList() {
		return importLcList;
	}

	public void setImportLcList(List<TFBOImportLcVO> importLcList) {
		this.importLcList = importLcList;
	}

	public List<TFBOTransVO> getTransactionList() {
		return transactionList;
	}

	public String getProductFilter() {
		return productFilter;
	}

	public void setProductFilter(String productFilter) {
		this.productFilter = productFilter;
	}

	public String getEventFilter() {
		return eventFilter;
	}

	public void setEventFilter(String eventFilter) {
		this.eventFilter = eventFilter;
	}

	public void setTransactionList(List<TFBOTransVO> transactionList) {
		this.transactionList = transactionList;
	}

	public String getRequestIdFilter() {
		return requestIdFilter;
	}

	public void setRequestIdFilter(String requestIdFilter) {
		this.requestIdFilter = requestIdFilter;
	}

	public String getProductCodeFilter() {
		return productCodeFilter;
	}

	public void setProductCodeFilter(String productCodeFilter) {
		this.productCodeFilter = productCodeFilter;
	}

	public String getEventCodeFilter() {
		return eventCodeFilter;
	}

	public void setEventCodeFilter(String eventCodeFilter) {
		this.eventCodeFilter = eventCodeFilter;
	}

	public String getFromDateFilter() {
		return fromDateFilter;
	}

	public void setFromDateFilter(String fromDateFilter) {
		this.fromDateFilter = fromDateFilter;
	}

	public String getToDateFilter() {
		return toDateFilter;
	}

	public void setToDateFilter(String toDateFilter) {
		this.toDateFilter = toDateFilter;
	}

	public String getStatusFilter() {
		return statusFilter;
	}

	public void setStatusFilter(String statusFilter) {
		this.statusFilter = statusFilter;
	}

	public String getProductCode() {
		return productCode;
	}

	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getEventName() {
		return eventName;
	}

	public void setEventName(String eventName) {
		this.eventName = eventName;
	}

	public String getEventCode() {
		return eventCode;
	}

	public void setEventCode(String eventCode) {
		this.eventCode = eventCode;
	}

	public String getCustomeCif() {
		return customeCif;
	}

	public void setCustomeCif(String customeCif) {
		this.customeCif = customeCif;
	}

	public String getCustomeName() {
		return customeName;
	}

	public void setCustomeName(String customeName) {
		this.customeName = customeName;
	}

	public String getAmount() {
		return amount;
	}

	public void setAmount(String amount) {
		this.amount = amount;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public String getSolID() {
		return solID;
	}

	public void setSolID(String solID) {
		this.solID = solID;
	}

	public String getTiReferanceNo() {
		return tiReferanceNo;
	}

	public void setTiReferanceNo(String tiReferanceNo) {
		this.tiReferanceNo = tiReferanceNo;
	}

	public String getSessionUserName() {
		return sessionUserName;
	}

	public void setSessionUserName(String sessionUserName) {
		this.sessionUserName = sessionUserName;
	}

	public String getRequestId() {
		return requestId;
	}

	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}

	public List<DocumentUploadVO> getDocumentList() {
		return documentList;
	}

	public void setDocumentList(List<DocumentUploadVO> documentList) {
		this.documentList = documentList;
	}

	public String getDummyIrex() {
		return dummyIrex;
	}

	public void setDummyIrex(String dummyIrex) {
		this.dummyIrex = dummyIrex;
	}

	public List<TFBOInwardRemittanceVO> getInwardRemittanceList() {
		return inwardRemittanceList;
	}

	public void setInwardRemittanceList(
			List<TFBOInwardRemittanceVO> inwardRemittanceList) {
		this.inwardRemittanceList = inwardRemittanceList;
	}

	// Outward Remittance Changes 23/12/2019 start
	public String getBankpayment() {
		return bankpayment;
	}

	public void setBankpayment(String bankpayment) {
		this.bankpayment = bankpayment;
	}

	public List<TFBOOutwardRemittanceVO> getOutwardRemittanceList() {
		return outwardRemittanceList;
	}

	public void setOutwardRemittanceList(
			List<TFBOOutwardRemittanceVO> outwardRemittanceList) {
		this.outwardRemittanceList = outwardRemittanceList;
	}

	// //Outward Remittance Changes 23/12/2019 end

}
