package com.ett.bob.tfbo.model;

import java.util.List;

public class TFBOImportLcVO {
	public String requestId;
	public String tiReferenceNo;
	public String customeCif;
	public String amount;
	public String currency;
	public String solID;
	public String lcType;
	public String usancePeriod;
	public String subProductCode;

	public String billAmount;
	public String payType;
	public boolean partAmount;
	public String claimAmount;
	public String billUsancePeriod;
	public boolean rateTaken;
	public String token;
	public String valueK;
	public String rate;
	private List<String> billReference;
	public String userRemark;
	

	public String getUserRemark() {
		return userRemark;
	}

	public void setUserRemark(String userRemark) {
		this.userRemark = userRemark;
	}

	public String getSubProductCode() {
		return subProductCode;
	}

	public void setSubProductCode(String subProductCode) {
		this.subProductCode = subProductCode;
	}

	public String getToken() {
		return token;
	}

	public void setToken(String token) {
		this.token = token;
	}

	public String getValueK() {
		return valueK;
	}

	public void setValueK(String valueK) {
		this.valueK = valueK;
	}

	public String getRate() {
		return rate;
	}

	public void setRate(String rate) {
		this.rate = rate;
	}

	public String getBillAmount() {
		return billAmount;
	}

	public void setBillAmount(String billAmount) {
		this.billAmount = billAmount;
	}

	public String getPayType() {
		return payType;
	}

	public void setPayType(String payType) {
		this.payType = payType;
	}

	public boolean isPartAmount() {
		return partAmount;
	}

	public void setPartAmount(boolean partAmount) {
		this.partAmount = partAmount;
	}

	public String getClaimAmount() {
		return claimAmount;
	}

	public void setClaimAmount(String claimAmount) {
		this.claimAmount = claimAmount;
	}

	public String getBillUsancePeriod() {
		return billUsancePeriod;
	}

	public void setBillUsancePeriod(String billUsancePeriod) {
		this.billUsancePeriod = billUsancePeriod;
	}

	public boolean isRateTaken() {
		return rateTaken;
	}

	public void setRateTaken(boolean rateTaken) {
		this.rateTaken = rateTaken;
	}

	public List<String> getBillReference() {
		return billReference;
	}

	public void setBillReference(List<String> billReference) {
		this.billReference = billReference;
	}

	public String getUsancePeriod() {
		return usancePeriod;
	}

	public void setUsancePeriod(String usancePeriod) {
		this.usancePeriod = usancePeriod;
	}

	public String getLcType() {
		return lcType;
	}

	public void setLcType(String lcType) {
		this.lcType = lcType;
	}

	public String getRequestId() {
		return requestId;
	}

	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}

	public String getTiReferenceNo() {
		return tiReferenceNo;
	}

	public void setTiReferenceNo(String tiReferenceNo) {
		this.tiReferenceNo = tiReferenceNo;
	}

	public String getCustomeCif() {
		return customeCif;
	}

	public void setCustomeCif(String customeCif) {
		this.customeCif = customeCif;
	}

	public String getAmount() {
		return amount;
	}

	public void setAmount(String amount) {
		this.amount = amount;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public String getSolID() {
		return solID;
	}

	public void setSolID(String solID) {
		this.solID = solID;
	}

}
