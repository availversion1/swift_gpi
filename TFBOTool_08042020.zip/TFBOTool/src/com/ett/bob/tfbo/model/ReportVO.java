package com.ett.bob.tfbo.model;

public class ReportVO {

	public String productName;
	public String productCodeList;
	public String solID;
	public String currency;
	public String rstatusFilter;
	public String fromDateFilter;
	public String toDateFilter;
	public String reportCheckList;
	public String userIdList;
	public String reportFrequency;
	public String subProduct;
	public String transType;
	public String frequencyRange;
	public String countSummary;
	public int sNo;
	public String requestType;
	public String requestId;
	public String finacleTranNo;
	public String transTime;
	public String solid;
	public String branchAlpha;
	public String customerName;
	public String currencyDetailed;
	public String transAmt;
	public String status;
	public String statusChangeBy;
	public String statusChangeTime;
	public String requestCycle;
	public String senderRefNo;
	public String dummyIrex;
	public String ifPcfc;
	public String amendNo;
	public String underLc;
	public String docDisNonDis;
	public String inputuser;
	public String reviewuser;
	public String authuser;
	public String fbomaker;
	public String fbochecker;
	
	
	
	

	public String getInputuser() {
		return inputuser;
	}

	public void setInputuser(String inputuser) {
		this.inputuser = inputuser;
	}

	public String getReviewuser() {
		return reviewuser;
	}

	public void setReviewuser(String reviewuser) {
		this.reviewuser = reviewuser;
	}

	public String getAuthuser() {
		return authuser;
	}

	public void setAuthuser(String authuser) {
		this.authuser = authuser;
	}

	public String getFbomaker() {
		return fbomaker;
	}

	public void setFbomaker(String fbomaker) {
		this.fbomaker = fbomaker;
	}

	public String getFbochecker() {
		return fbochecker;
	}

	public void setFbochecker(String fbochecker) {
		this.fbochecker = fbochecker;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getSubProduct() {
		return subProduct;
	}

	public void setSubProduct(String subProduct) {
		this.subProduct = subProduct;
	}

	public int getsNo() {
		return sNo;
	}

	public void setsNo(int sNo) {
		this.sNo = sNo;
	}

	public String getRequestType() {
		return requestType;
	}

	public void setRequestType(String requestType) {
		this.requestType = requestType;
	}

	public String getRequestId() {
		return requestId;
	}

	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}

	public String getFinacleTranNo() {
		return finacleTranNo;
	}

	public void setFinacleTranNo(String finacleTranNo) {
		this.finacleTranNo = finacleTranNo;
	}

	public String getTransTime() {
		return transTime;
	}

	public void setTransTime(String transTime) {
		this.transTime = transTime;
	}

	public String getSolid() {
		return solid;
	}

	public void setSolid(String solid) {
		this.solid = solid;
	}

	public String getBranchAlpha() {
		return branchAlpha;
	}

	public void setBranchAlpha(String branchAlpha) {
		this.branchAlpha = branchAlpha;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getCurrencyDetailed() {
		return currencyDetailed;
	}

	public void setCurrencyDetailed(String currencyDetailed) {
		this.currencyDetailed = currencyDetailed;
	}

	public String getTransAmt() {
		return transAmt;
	}

	public void setTransAmt(String transAmt) {
		this.transAmt = transAmt;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getStatusChangeBy() {
		return statusChangeBy;
	}

	public void setStatusChangeBy(String statusChangeBy) {
		this.statusChangeBy = statusChangeBy;
	}

	public String getStatusChangeTime() {
		return statusChangeTime;
	}

	public void setStatusChangeTime(String statusChangeTime) {
		this.statusChangeTime = statusChangeTime;
	}

	public String getRequestCycle() {
		return requestCycle;
	}

	public void setRequestCycle(String requestCycle) {
		this.requestCycle = requestCycle;
	}

	public String getSenderRefNo() {
		return senderRefNo;
	}

	public void setSenderRefNo(String senderRefNo) {
		this.senderRefNo = senderRefNo;
	}

	public String getDummyIrex() {
		return dummyIrex;
	}

	public void setDummyIrex(String dummyIrex) {
		this.dummyIrex = dummyIrex;
	}

	public String getIfPcfc() {
		return ifPcfc;
	}

	public void setIfPcfc(String ifPcfc) {
		this.ifPcfc = ifPcfc;
	}

	public String getAmendNo() {
		return amendNo;
	}

	public void setAmendNo(String amendNo) {
		this.amendNo = amendNo;
	}

	public String getUnderLc() {
		return underLc;
	}

	public void setUnderLc(String underLc) {
		this.underLc = underLc;
	}

	public String getDocDisNonDis() {
		return docDisNonDis;
	}

	public void setDocDisNonDis(String docDisNonDis) {
		this.docDisNonDis = docDisNonDis;
	}

	public String getTransType() {
		return transType;
	}

	public void setTransType(String transType) {
		this.transType = transType;
	}

	public String getFrequencyRange() {
		return frequencyRange;
	}

	public void setFrequencyRange(String frequencyRange) {
		this.frequencyRange = frequencyRange;
	}

	public String getCountSummary() {
		return countSummary;
	}

	public void setCountSummary(String countSummary) {
		this.countSummary = countSummary;
	}

	public String getProductCodeList() {
		return productCodeList;
	}

	public void setProductCodeList(String productCodeList) {
		this.productCodeList = productCodeList;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public String getReportFrequency() {
		return reportFrequency;
	}

	public void setReportFrequency(String reportFrequency) {
		this.reportFrequency = reportFrequency;
	}

	public String getSolID() {
		return solID;
	}

	public void setSolID(String solID) {
		this.solID = solID;
	}

	public String getRstatusFilter() {
		return rstatusFilter;
	}

	public void setRstatusFilter(String rstatusFilter) {
		this.rstatusFilter = rstatusFilter;
	}

	public String getFromDateFilter() {
		return fromDateFilter;
	}

	public void setFromDateFilter(String fromDateFilter) {
		this.fromDateFilter = fromDateFilter;
	}

	public String getToDateFilter() {
		return toDateFilter;
	}

	public void setToDateFilter(String toDateFilter) {
		this.toDateFilter = toDateFilter;
	}

	public String getReportCheckList() {
		return reportCheckList;
	}

	public void setReportCheckList(String reportCheckList) {
		this.reportCheckList = reportCheckList;
	}

	public String getUserIdList() {
		return userIdList;
	}

	public void setUserIdList(String userIdList) {
		this.userIdList = userIdList;
	}
}
