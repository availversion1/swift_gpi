package com.ett.bob.tfbo.model;

public class TFBOFinanceExportColVO {
	public String requestId;
	public String tiReferenceNo;
	public String subProductCode;
	public String customeCif;
	public String amount;
	public String currency;
	public String solID;
	public String usancePeriod;
	public String preshipAccSettled;
	public String FOCProductType;
	public String rateTaken;
	public String token;
	public String rateTakenK;
	public String rate;
	public String financeAmount;
	public String finalRepay;
	public String maturityDate;

	public String senderRefno;

	public String getSenderRefno() {

		return senderRefno;
	}

	public void setSenderRefno(String senderRefno) {
		this.senderRefno = senderRefno;
	}

	public String userRemark;
	public String customeName;

	public String getCustomeName() {
		return customeName;
	}

	public void setCustomeName(String customeName) {
		this.customeName = customeName;
	}

	public String getUserRemark() {
		return userRemark;
	}

	public void setUserRemark(String userRemark) {
		this.userRemark = userRemark;
	}

	public String getMaturityDate() {
		return maturityDate;
	}

	public void setMaturityDate(String maturityDate) {
		this.maturityDate = maturityDate;
	}

	public String getFinalRepay() {
		return finalRepay;
	}

	public void setFinalRepay(String finalRepay) {
		this.finalRepay = finalRepay;
	}

	public String getRateTaken() {
		return rateTaken;
	}

	public void setRateTaken(String rateTaken) {
		this.rateTaken = rateTaken;
	}

	public String getFinanceAmount() {
		return financeAmount;
	}

	public void setFinanceAmount(String financeAmount) {
		this.financeAmount = financeAmount;
	}

	public String getFOCProductType() {
		return FOCProductType;
	}

	public void setFOCProductType(String fOCProductType) {
		FOCProductType = fOCProductType;
	}

	public String getToken() {
		return token;
	}

	public void setToken(String token) {
		this.token = token;
	}

	public String getRateTakenK() {
		return rateTakenK;
	}

	public void setRateTakenK(String rateTakenK) {
		this.rateTakenK = rateTakenK;
	}

	public String getRate() {
		return rate;
	}

	public void setRate(String rate) {
		this.rate = rate;
	}

	public String getRequestId() {
		return requestId;
	}

	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}

	public String getTiReferenceNo() {
		return tiReferenceNo;
	}

	public void setTiReferenceNo(String tiReferenceNo) {
		this.tiReferenceNo = tiReferenceNo;
	}

	public String getSubProductCode() {
		return subProductCode;
	}

	public void setSubProductCode(String subProductCode) {
		this.subProductCode = subProductCode;
	}

	public String getCustomeCif() {
		return customeCif;
	}

	public void setCustomeCif(String customeCif) {
		this.customeCif = customeCif;
	}

	public String getAmount() {
		return amount;
	}

	public void setAmount(String amount) {
		this.amount = amount;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public String getSolID() {
		return solID;
	}

	public void setSolID(String solID) {
		this.solID = solID;
	}

	public String getUsancePeriod() {
		return usancePeriod;
	}

	public void setUsancePeriod(String usancePeriod) {
		this.usancePeriod = usancePeriod;
	}

	public String getPreshipAccSettled() {
		return preshipAccSettled;
	}

	public void setPreshipAccSettled(String preshipAccSettled) {
		this.preshipAccSettled = preshipAccSettled;
	}

}
