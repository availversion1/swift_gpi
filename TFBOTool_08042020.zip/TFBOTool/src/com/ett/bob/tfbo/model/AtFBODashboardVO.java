package com.ett.bob.tfbo.model;

import java.util.List;

public class AtFBODashboardVO {

	List<TFBODashboardCountVO> pendForScrutinity;
	List<TFBODashboardCountVO> queriedRequest;
	List<TFBODashboardCountVO> fboRejected;
	List<TFBODashboardCountVO> fbtiCompleted;

	public List<TFBODashboardCountVO> getPendForScrutinity() {
		return pendForScrutinity;
	}

	public void setPendForScrutinity(List<TFBODashboardCountVO> pendForScrutinity) {
		this.pendForScrutinity = pendForScrutinity;
	}

	public List<TFBODashboardCountVO> getQueriedRequest() {
		return queriedRequest;
	}

	public void setQueriedRequest(List<TFBODashboardCountVO> queriedRequest) {
		this.queriedRequest = queriedRequest;
	}

	public List<TFBODashboardCountVO> getFboRejected() {
		return fboRejected;
	}

	public void setFboRejected(List<TFBODashboardCountVO> fboRejected) {
		this.fboRejected = fboRejected;
	}

	public List<TFBODashboardCountVO> getFbtiCompleted() {
		return fbtiCompleted;
	}

	public void setFbtiCompleted(List<TFBODashboardCountVO> fbtiCompleted) {
		this.fbtiCompleted = fbtiCompleted;
	}
}
