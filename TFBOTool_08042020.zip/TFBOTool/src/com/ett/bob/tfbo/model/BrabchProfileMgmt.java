package com.ett.bob.tfbo.model;



public class BrabchProfileMgmt {
	
	
	public String BranchAddr;
	public String MobileNo;
	public String BRPhoneSTD;
	public String SwiftCode;
	public String AlphaCode;
	public String SolID;
	
	
	
	public String getBranchAddr() {
		return BranchAddr;
	}
	public void setBranchAddr(String branchAddr) {
		BranchAddr = branchAddr;
	}
	public String getMobileNo() {
		return MobileNo;
	}
	public void setMobileNo(String mobileNo) {
		MobileNo = mobileNo;
	}
	public String getBRPhoneSTD() {
		return BRPhoneSTD;
	}
	public void setBRPhoneSTD(String bRPhoneSTD) {
		BRPhoneSTD = bRPhoneSTD;
	}
	public String getSwiftCode() {
		return SwiftCode;
	}
	public void setSwiftCode(String swiftCode) {
		SwiftCode = swiftCode;
	}
	public String getAlphaCode() {
		return AlphaCode;
	}
	public void setAlphaCode(String alphaCode) {
		AlphaCode = alphaCode;
	}
	public String getSolID() {
		return SolID;
	}
	public void setSolID(String solID) {
		SolID = solID;
	}

}
