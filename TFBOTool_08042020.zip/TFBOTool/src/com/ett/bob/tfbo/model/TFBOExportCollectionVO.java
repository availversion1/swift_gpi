package com.ett.bob.tfbo.model;

public class TFBOExportCollectionVO {
	public String requestId;
	public String tiReferenceNo;
	public String subProductCode;
	public String customeCif;
	public String amount;
	public String currency;
	public String solID;
	public String lcType;
	public String usancePeriod;
	public String direct;
	public String mtReceived;
	public String partPayment;
	public String productType;
	public String preshipAccSettled;
	public String documentDispatch;
	public String financeSameDay;
	public String rateTaken;
	public String shipBillFetch;
	public String exchangeRate;
	public String docketNo;
	public String token;
	public String rateTakenK;
	public String rate;
	// Added by divya ODC-CLP
	public String finalPayment;
	// Rate taken Fix Offshore Team 06012020 starts
	public String irexRefNo;
	public String userRemark;
	public String customeName;
	public String senderRefno;
	public String acceptBillAmt;
	public String finAmount;
	public String finCurrency;
		
		

	public String getFinAmount() {
		return finAmount;
	}

	public void setFinAmount(String finAmount) {
		this.finAmount = finAmount;
	}

	public String getFinCurrency() {
		return finCurrency;
	}

	public void setFinCurrency(String finCurrency) {
		this.finCurrency = finCurrency;
	}

	public String getAcceptBillAmt() {
		return acceptBillAmt;
	}

	public void setAcceptBillAmt(String acceptBillAmt) {
		this.acceptBillAmt = acceptBillAmt;
	}

	public String getSenderRefno() {
		return senderRefno;
	}

	public void setSenderRefno(String senderRefno) {
		this.senderRefno = senderRefno;
	}

	public String getCustomeName() {
		return customeName;
	}

	public void setCustomeName(String customeName) {
		this.customeName = customeName;
	}

	public String getUserRemark() {
		return userRemark;
	}

	public void setUserRemark(String userRemark) {
		this.userRemark = userRemark;
	}

	public String getIrexRefNo() {
		return irexRefNo;
	}

	public void setIrexRefNo(String irexRefNo) {
		this.irexRefNo = irexRefNo;
	}

	// Rate taken Fix Offshore Team 06012020 ends

	public String getFinalPayment() {
		return finalPayment;
	}

	public void setFinalPayment(String finalPayment) {
		this.finalPayment = finalPayment;
	}

	public String getSubProductCode() {
		return subProductCode;
	}

	public void setSubProductCode(String subProductCode) {
		this.subProductCode = subProductCode;
	}

	public String getToken() {
		return token;
	}

	public void setToken(String token) {
		this.token = token;
	}

	public String getRateTakenK() {
		return rateTakenK;
	}

	public void setRateTakenK(String rateTakenK) {
		this.rateTakenK = rateTakenK;
	}

	public String getRate() {
		return rate;
	}

	public void setRate(String rate) {
		this.rate = rate;
	}

	public String getRequestId() {
		return requestId;
	}

	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}

	public String getTiReferenceNo() {
		return tiReferenceNo;
	}

	public void setTiReferenceNo(String tiReferenceNo) {
		this.tiReferenceNo = tiReferenceNo;
	}

	public String getCustomeCif() {
		return customeCif;
	}

	public void setCustomeCif(String customeCif) {
		this.customeCif = customeCif;
	}

	public String getAmount() {
		return amount;
	}

	public void setAmount(String amount) {
		this.amount = amount;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public String getSolID() {
		return solID;
	}

	public void setSolID(String solID) {
		this.solID = solID;
	}

	public String getLcType() {
		return lcType;
	}

	public void setLcType(String lcType) {
		this.lcType = lcType;
	}

	public String getUsancePeriod() {
		return usancePeriod;
	}

	public void setUsancePeriod(String usancePeriod) {
		this.usancePeriod = usancePeriod;
	}

	public String getDirect() {
		return direct;
	}

	public void setDirect(String direct) {
		this.direct = direct;
	}

	public String getMtReceived() {
		return mtReceived;
	}

	public void setMtReceived(String mtReceived) {
		this.mtReceived = mtReceived;
	}

	public String getPartPayment() {
		return partPayment;
	}

	public void setPartPayment(String partPayment) {
		this.partPayment = partPayment;
	}

	public String getProductType() {
		return productType;
	}

	public void setProductType(String productType) {
		this.productType = productType;
	}

	public String getPreshipAccSettled() {
		return preshipAccSettled;
	}

	public void setPreshipAccSettled(String preshipAccSettled) {
		this.preshipAccSettled = preshipAccSettled;
	}

	public String getDocumentDispatch() {
		return documentDispatch;
	}

	public void setDocumentDispatch(String documentDispatch) {
		this.documentDispatch = documentDispatch;
	}

	public String getFinanceSameDay() {
		return financeSameDay;
	}

	public void setFinanceSameDay(String financeSameDay) {
		this.financeSameDay = financeSameDay;
	}

	public String getRateTaken() {
		return rateTaken;
	}

	public void setRateTaken(String rateTaken) {
		this.rateTaken = rateTaken;
	}

	public String getShipBillFetch() {
		return shipBillFetch;
	}

	public void setShipBillFetch(String shipBillFetch) {
		this.shipBillFetch = shipBillFetch;
	}

	public String getExchangeRate() {
		return exchangeRate;
	}

	public void setExchangeRate(String exchangeRate) {
		this.exchangeRate = exchangeRate;
	}

	public String getDocketNo() {
		return docketNo;
	}

	public void setDocketNo(String docketNo) {
		this.docketNo = docketNo;
	}

}
