package com.ett.bob.tfbo.model;

public class TFBOMiscellanousVO {
	public String requestId;
	public String tiReferenceNo;
	public String subProductCode;
	public String customeCif;
	public String amount;
	public String currency;
	public String solID;
	public String productType;
	public String odiSubProductType;	
	

	

	/*public String preshipAccSettled;
	public String dummyIrex;*/
	public String rateTaken;
	public String exchangeRate;
	public String docketNo;
	public String token;
	public String rateTakenK;
	public String rate;
	
	public String remarks;
	public String masReferanceNo;
	
	
	
	
	
	
	
	
	public String getMasReferanceNo() {
		return masReferanceNo;
	}

	public void setMasReferanceNo(String masReferanceNo) {
		this.masReferanceNo = masReferanceNo;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

/*	public String getDummyIrex() {
		return dummyIrex;
	}

	public void setDummyIrex(String dummyIrex) {
		this.dummyIrex = dummyIrex;
	}
*/
	
	
	public String getOdiSubProductType() {
		return odiSubProductType;
	}

	public void setOdiSubProductType(String odiSubProductType) {
		this.odiSubProductType = odiSubProductType;
	}
	
	public String getSubProductCode() {
		return subProductCode;
	}

	public void setSubProductCode(String subProductCode) {
		this.subProductCode = subProductCode;
	}

	public String getToken() {
		return token;
	}

	public void setToken(String token) {
		this.token = token;
	}

	public String getRateTakenK() {
		return rateTakenK;
	}

	public void setRateTakenK(String rateTakenK) {
		this.rateTakenK = rateTakenK;
	}

	public String getRate() {
		return rate;
	}

	public void setRate(String rate) {
		this.rate = rate;
	}

	public String getRequestId() {
		return requestId;
	}

	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}

	public String getTiReferenceNo() {
		return tiReferenceNo;
	}

	public void setTiReferenceNo(String tiReferenceNo) {
		this.tiReferenceNo = tiReferenceNo;
	}

	public String getCustomeCif() {
		return customeCif;
	}

	public void setCustomeCif(String customeCif) {
		this.customeCif = customeCif;
	}

	public String getAmount() {
		return amount;
	}

	public void setAmount(String amount) {
		this.amount = amount;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public String getSolID() {
		return solID;
	}

	public void setSolID(String solID) {
		this.solID = solID;
	}

	public String getProductType() {
		return productType;
	}

	public void setProductType(String productType) {
		this.productType = productType;
	}

	/*public String getPreshipAccSettled() {
		return preshipAccSettled;
	}

	public void setPreshipAccSettled(String preshipAccSettled) {
		this.preshipAccSettled = preshipAccSettled;
	}*/

	public String getRateTaken() {
		return rateTaken;
	}

	public void setRateTaken(String rateTaken) {
		this.rateTaken = rateTaken;
	}

	public String getExchangeRate() {
		return exchangeRate;
	}

	public void setExchangeRate(String exchangeRate) {
		this.exchangeRate = exchangeRate;
	}

	public String getDocketNo() {
		return docketNo;
	}

	public void setDocketNo(String docketNo) {
		this.docketNo = docketNo;
	}
}