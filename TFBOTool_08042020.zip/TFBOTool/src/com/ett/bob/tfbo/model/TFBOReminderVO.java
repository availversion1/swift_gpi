package com.ett.bob.tfbo.model;

import java.util.List;

public class TFBOReminderVO {
	
	public String tranId;
	public String requestId;
	public String tiReference;
	public String prodDescription;
	public String evtDescription;
	public String stepStatus;
	public String transCreated;
	public String transModified;
	public String subProductCode;
	public String solId;
	public String emailId;
	public String branchName;
	public String city;
	public String customeCif;
	public String customeName;
	public String amount;
	public String sentMailtoReminder;
	
	public String requestIdGridValue;
	public String tiReferanceNoGridValue;
	public String solIDGridValue;
	public String productCode;
	public String eventCode;
	public String eventCodeGridValue;
	public String productCodeGridValue;
	public String currentPage;
	public String eventDescGridValue;
	public String prdDescGridValue;
	
	
	
	
	public String getEventDescGridValue() {
		return eventDescGridValue;
	}
	public void setEventDescGridValue(String eventDescGridValue) {
		this.eventDescGridValue = eventDescGridValue;
	}
	public String getPrdDescGridValue() {
		return prdDescGridValue;
	}
	public void setPrdDescGridValue(String prdDescGridValue) {
		this.prdDescGridValue = prdDescGridValue;
	}
	public String getCurrentPage() {
		return currentPage;
	}
	public void setCurrentPage(String currentPage) {
		this.currentPage = currentPage;
	}
	public List<TFBOReminderVO> reminderList;
	public List<AlertMessagesVO> errorDetailsList;
	
	/*public List<TFBOReminderVO> reminderList;
	
	public List<TFBOReminderVO> getReminderList() {
		return reminderList;
	}
	public void setReminderList(List<TFBOReminderVO> reminderList) {
		this.reminderList = reminderList;
	}*/
	
	public List<AlertMessagesVO> getErrorDetailsList() {
		return errorDetailsList;
	}
	public void setErrorDetailsList(List<AlertMessagesVO> errorDetailsList) {
		this.errorDetailsList = errorDetailsList;
	}
	public String getTranId() {
		return tranId;
	}
	public void setTranId(String tranId) {
		this.tranId = tranId;
	}
	public String getSentMailtoReminder() {
		return sentMailtoReminder;
	}
	public void setSentMailtoReminder(String sentMailtoReminder) {
		this.sentMailtoReminder = sentMailtoReminder;
	}
	public List<TFBOReminderVO> getReminderList() {
		return reminderList;
	}
	public void setReminderList(List<TFBOReminderVO> reminderList) {
		this.reminderList = reminderList;
	}
	
	public String getRequestId() {
		return requestId;
	}
	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}
	public String getTiReference() {
		return tiReference;
	}
	public void setTiReference(String tiReference) {
		this.tiReference = tiReference;
	}
	public String getProdDescription() {
		return prodDescription;
	}
	public void setProdDescription(String prodDescription) {
		this.prodDescription = prodDescription;
	}
	public String getEvtDescription() {
		return evtDescription;
	}
	public void setEvtDescription(String evtDescription) {
		this.evtDescription = evtDescription;
	}
	public String getStepStatus() {
		return stepStatus;
	}
	public void setStepStatus(String stepStatus) {
		this.stepStatus = stepStatus;
	}
	public String getTransCreated() {
		return transCreated;
	}
	public void setTransCreated(String transCreated) {
		this.transCreated = transCreated;
	}
	public String getTransModified() {
		return transModified;
	}
	public void setTransModified(String transModified) {
		this.transModified = transModified;
	}
	public String getSubProductCode() {
		return subProductCode;
	}
	public void setSubProductCode(String subProductCode) {
		this.subProductCode = subProductCode;
	}

	public String getSolId() {
		return solId;
	}
	public void setSolId(String solId) {
		this.solId = solId;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public String getBranchName() {
		return branchName;
	}
	public void setBranchName(String branchName) {
		this.branchName = branchName;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getCustomeCif() {
		return customeCif;
	}
	public void setCustomeCif(String customeCif) {
		this.customeCif = customeCif;
	}
	public String getCustomeName() {
		return customeName;
	}
	public void setCustomeName(String customeName) {
		this.customeName = customeName;
	}
	public String getAmount() {
		return amount;
	}
	public void setAmount(String amount) {
		this.amount = amount;
	}
	public String getRequestIdGridValue() {
		return requestIdGridValue;
	}
	public void setRequestIdGridValue(String requestIdGridValue) {
		this.requestIdGridValue = requestIdGridValue;
	}
	public String getTiReferanceNoGridValue() {
		return tiReferanceNoGridValue;
	}
	public void setTiReferanceNoGridValue(String tiReferanceNoGridValue) {
		this.tiReferanceNoGridValue = tiReferanceNoGridValue;
	}
	public String getSolIDGridValue() {
		return solIDGridValue;
	}
	public void setSolIDGridValue(String solIDGridValue) {
		this.solIDGridValue = solIDGridValue;
	}
	public String getProductCode() {
		return productCode;
	}
	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}
	public String getEventCode() {
		return eventCode;
	}
	public void setEventCode(String eventCode) {
		this.eventCode = eventCode;
	}
	public String getEventCodeGridValue() {
		return eventCodeGridValue;
	}
	public void setEventCodeGridValue(String eventCodeGridValue) {
		this.eventCodeGridValue = eventCodeGridValue;
	}
	public String getProductCodeGridValue() {
		return productCodeGridValue;
	}
	public void setProductCodeGridValue(String productCodeGridValue) {
		this.productCodeGridValue = productCodeGridValue;
	}
	
	
}
