package com.ett.bob.tfbo.model;

public class TFBOOutwardRemittanceVO {

	public String requestId;
	public String tiRefNo;
	public String subProductCode;
	public String customeCif;
	public String amount;
	public String currency;
	public String solID;
	public String productType;
	public String rateTaken;
	public String token;
	public String valueK;
	public String rate;
	public String bankpayment;
	
	
	public String getTiRefNo() {
		return tiRefNo;
	}
	public void setTiRefNo(String tiRefNo) {
		this.tiRefNo = tiRefNo;
	}
	
	
	public String getBankpayment() {
		return bankpayment;
	}
	public void setBankpayment(String bankpayment) {
		this.bankpayment = bankpayment;
	}
	public String getRequestId() {
		return requestId;
	}
	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}
	
	public String getSubProductCode() {
		return subProductCode;
	}
	public void setSubProductCode(String subProductCode) {
		this.subProductCode = subProductCode;
	}
	public String getCustomeCif() {
		return customeCif;
	}
	public void setCustomeCif(String customeCif) {
		this.customeCif = customeCif;
	}
	public String getAmount() {
		return amount;
	}
	public void setAmount(String amount) {
		this.amount = amount;
	}
	public String getCurrency() {
		return currency;
	}
	public void setCurrency(String currency) {
		this.currency = currency;
	}
	public String getSolID() {
		return solID;
	}
	public void setSolID(String solID) {
		this.solID = solID;
	}
	public String getProductType() {
		return productType;
	}
	public void setProductType(String productType) {
		this.productType = productType;
	}
	public String getRateTaken() {
		return rateTaken;
	}
	public void setRateTaken(String rateTaken) {
		this.rateTaken = rateTaken;
	}
	public String getToken() {
		return token;
	}
	public void setToken(String token) {
		this.token = token;
	}
	
	public String getRate() {
		return rate;
	}
	public void setRate(String rate) {
		this.rate = rate;
	}
	public String getValueK() {
		return valueK;
	}
	public void setValueK(String valueK) {
		this.valueK = valueK;
	}
	
}
