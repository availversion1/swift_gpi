package com.ett.bob.tfbo.model;

public class TFBOImportGTVO {

	public String requestId;
	public String tiReferenceNo;
	public String customeCif;
	public String amount;
	public String currency;
	public String solID;
	public String subProductCode;
	public String tenure;
	public String expiryDate;
	public String reqInvAmt;
	public String guarnteeAmtPrevInv;
	public String partInvocation;
	public String rateTaken;
	public String valueK;
	public String billreference;
	public String token;
	public String rate;

	public String getToken() {
		return token;
	}

	public void setToken(String token) {
		this.token = token;
	}

	public String getRate() {
		return rate;
	}

	public void setRate(String rate) {
		this.rate = rate;
	}

	public String getRequestId() {
		return requestId;
	}

	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}

	public String getTiReferenceNo() {
		return tiReferenceNo;
	}

	public void setTiReferenceNo(String tiReferenceNo) {
		this.tiReferenceNo = tiReferenceNo;
	}

	public String getCustomeCif() {
		return customeCif;
	}

	public void setCustomeCif(String customeCif) {
		this.customeCif = customeCif;
	}

	public String getAmount() {
		return amount;
	}

	public void setAmount(String amount) {
		this.amount = amount;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public String getSolID() {
		return solID;
	}

	public void setSolID(String solID) {
		this.solID = solID;
	}

	public String getSubProductCode() {
		return subProductCode;
	}

	public void setSubProductCode(String subProductCode) {
		this.subProductCode = subProductCode;
	}

	public String getTenure() {
		return tenure;
	}

	public void setTenure(String tenure) {
		this.tenure = tenure;
	}

	public String getExpiryDate() {
		return expiryDate;
	}

	public void setExpiryDate(String expiryDate) {
		this.expiryDate = expiryDate;
	}

	public String getReqInvAmt() {
		return reqInvAmt;
	}

	public void setReqInvAmt(String reqInvAmt) {
		this.reqInvAmt = reqInvAmt;
	}

	public String getGuarnteeAmtPrevInv() {
		return guarnteeAmtPrevInv;
	}

	public void setGuarnteeAmtPrevInv(String guarnteeAmtPrevInv) {
		this.guarnteeAmtPrevInv = guarnteeAmtPrevInv;
	}

	public String getPartInvocation() {
		return partInvocation;
	}

	public void setPartInvocation(String partInvocation) {
		this.partInvocation = partInvocation;
	}

	public String getRateTaken() {
		return rateTaken;
	}

	public void setRateTaken(String rateTaken) {
		this.rateTaken = rateTaken;
	}

	public String getValueK() {
		return valueK;
	}

	public void setValueK(String valueK) {
		this.valueK = valueK;
	}

	public String getBillreference() {
		return billreference;
	}

	public void setBillreference(String billreference) {
		this.billreference = billreference;
	}

}
