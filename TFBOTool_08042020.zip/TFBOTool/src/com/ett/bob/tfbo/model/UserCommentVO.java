package com.ett.bob.tfbo.model;

public class UserCommentVO {
	String commentDateTime;
	String commentUser;
	String commentStep;
	String commentDetails;
	String sendMailToCustomer;
	String mailToCustomer;
	
	public String getCommentDateTime() {
		return commentDateTime;
	}
	public void setCommentDateTime(String commentDateTime) {
		this.commentDateTime = commentDateTime;
	}
	public String getCommentUser() {
		return commentUser;
	}
	public void setCommentUser(String commentUser) {
		this.commentUser = commentUser;
	}
	public String getCommentStep() {
		return commentStep;
	}
	public void setCommentStep(String commentStep) {
		this.commentStep = commentStep;
	}
	public String getCommentDetails() {
		return commentDetails;
	}
	public void setCommentDetails(String commentDetails) {
		this.commentDetails = commentDetails;
	}
}
