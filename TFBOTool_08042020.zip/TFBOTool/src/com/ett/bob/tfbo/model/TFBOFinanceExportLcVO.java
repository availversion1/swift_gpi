//FEL starts 
package com.ett.bob.tfbo.model;

public class TFBOFinanceExportLcVO {
	public String requestId;
	public String LCRefNum;
	public String billReferenceNo;
	public String fncAmount;
	public String amount;
	public String billTenure;
	public String solID;
	public String rateTaken;
	public String rate;
	public String rateTakenK;
	public String token;
	public String subProductCode;
	public String currency;
	public String customeCif;
	public String customeName;
	public String maturityDate;
	public String preshipAcc;
	public String finalPayment;
	public String senderRefNo;
	public String lcType;
	public String userRemark;

	public String getUserRemark() {
		return userRemark;
	}

	public void setUserRemark(String userRemark) {
		this.userRemark = userRemark;
	}

	public String getLcType() {
		return lcType;
	}

	public void setLcType(String lcType) {
		this.lcType = lcType;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public String getRequestId() {
		return requestId;
	}

	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}

	public String getLCRefNum() {
		return LCRefNum;
	}

	public void setLCRefNum(String lCRefNum) {
		LCRefNum = lCRefNum;
	}

	public String getBillReferenceNo() {
		return billReferenceNo;
	}

	public void setBillReferenceNo(String billReferenceNo) {
		this.billReferenceNo = billReferenceNo;
	}

	public String getFncAmount() {
		return fncAmount;
	}

	public void setFncAmount(String fncAmount) {
		this.fncAmount = fncAmount;
	}

	public String getAmount() {
		return amount;
	}

	public void setAmount(String amount) {
		this.amount = amount;
	}

	public String getBillTenure() {
		return billTenure;
	}

	public void setBillTenure(String billTenure) {
		this.billTenure = billTenure;
	}

	public String getSolID() {
		return solID;
	}

	public void setSolID(String solID) {
		this.solID = solID;
	}

	public String getRateTaken() {
		return rateTaken;
	}

	public void setRateTaken(String rateTaken) {
		this.rateTaken = rateTaken;
	}

	public String getRate() {
		return rate;
	}

	public void setRate(String rate) {
		this.rate = rate;
	}

	public String getRateTakenK() {
		return rateTakenK;
	}

	public void setRateTakenK(String rateTakenK) {
		this.rateTakenK = rateTakenK;
	}

	public String getToken() {
		return token;
	}

	public void setToken(String token) {
		this.token = token;
	}

	public String getSubProductCode() {
		return subProductCode;
	}

	public void setSubProductCode(String subProductCode) {
		this.subProductCode = subProductCode;
	}

	public String getCustomeCif() {
		return customeCif;
	}

	public void setCustomeCif(String customeCif) {
		this.customeCif = customeCif;
	}

	public String getCustomeName() {
		return customeName;
	}

	public void setCustomeName(String customeName) {
		this.customeName = customeName;
	}

	public String getMaturityDate() {
		return maturityDate;
	}

	public void setMaturityDate(String maturityDate) {
		this.maturityDate = maturityDate;
	}

	public String getPreshipAcc() {
		return preshipAcc;
	}

	public void setPreshipAcc(String preshipAcc) {
		this.preshipAcc = preshipAcc;
	}

	public String getFinalPayment() {
		return finalPayment;
	}

	public void setFinalPayment(String finalPayment) {
		this.finalPayment = finalPayment;
	}

	public String getSenderRefNo() {
		return senderRefNo;
	}

	public void setSenderRefNo(String senderRefNo) {
		this.senderRefNo = senderRefNo;
	}

}
// FEL ends
