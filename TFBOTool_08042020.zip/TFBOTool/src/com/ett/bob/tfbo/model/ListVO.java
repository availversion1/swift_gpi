package com.ett.bob.tfbo.model;

public class ListVO {

	public String eventList;
	public String eventFilterList;
	public String billReferenceList;

	public String getEventList() {
		return eventList;
	}

	public void setEventList(String eventList) {
		this.eventList = eventList;
	}

	public String getEventFilterList() {
		return eventFilterList;
	}

	public void setEventFilterList(String eventFilterList) {
		this.eventFilterList = eventFilterList;
	}

	public String getBillReferenceList() {
		return billReferenceList;
	}

	public void setBillReferenceList(String billReferenceList) {
		this.billReferenceList = billReferenceList;
	}

}
