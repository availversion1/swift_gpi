package com.ett.bob.tfbo.model;

import java.util.List;

public class CustomerProfileManageVO {

	public String custID;
	public String operSolID;
	public String custName;
	public String lineofActivity;
	public String emailID;
	public String operAccNo;
	public String alphaCode;
	public String mobileNo;
	public String rateMarginFrom;
	public String rateMarginTo;
	public String currentPage;
	public String branchsolID;
	public String branchalphaCode;
	public String branchswiftCode;
	public String branchPhone;
	public String branchMobileNo;
	public String branchAddress;
	public String typeOfDoc;
	public String custSolId;
	public String getCustSolId() {
		return custSolId;
	}
	public void setCustSolId(String custSolId) {
		this.custSolId = custSolId;
	}
	public String getTypeOfDoc() {
		return typeOfDoc;
	}
	public void setTypeOfDoc(String typeOfDoc) {
		this.typeOfDoc = typeOfDoc;
	}
	public List<DocumentUploadVO> getDocumentList() {
		return documentList;
	}
	public void setDocumentList(List<DocumentUploadVO> documentList) {
		this.documentList = documentList;
	}
	public String getSessionUserName() {
		return sessionUserName;
	}
	public void setSessionUserName(String sessionUserName) {
		this.sessionUserName = sessionUserName;
	}
	public String getDocID() {
		return docID;
	}
	public void setDocID(String docID) {
		this.docID = docID;
	}
	public List<AlertMessagesVO> getErrorDetailsList() {
		return errorDetailsList;
	}
	public void setErrorDetailsList(List<AlertMessagesVO> errorDetailsList) {
		this.errorDetailsList = errorDetailsList;
	}
	public List<CustomerProfileManageVO> getCustVerifyList() {
		return custVerifyList;
	}
	public void setCustVerifyList(List<CustomerProfileManageVO> custVerifyList) {
		this.custVerifyList = custVerifyList;
	}
	public int getSeqNo() {
		return seqNo;
	}
	public void setSeqNo(int seqNo) {
		this.seqNo = seqNo;
	}
	public String getUserFlag() {
		return userFlag;
	}
	public void setUserFlag(String userFlag) {
		this.userFlag = userFlag;
	}
	public String getCustVerify() {
		return custVerify;
	}
	public void setCustVerify(String custVerify) {
		this.custVerify = custVerify;
	}
	public String flag;
	public List<DocumentUploadVO> documentList;
	public List<DocumentUploadVO> transDocList;
	
	public List<DocumentUploadVO> getTransDocList() {
		return transDocList;
	}
	public void setTransDocList(List<DocumentUploadVO> transDocList) {
		this.transDocList = transDocList;
	}
	public String sessionUserName;
	public String docID;
	public List<AlertMessagesVO> errorDetailsList;
	public List<CustomerProfileManageVO> custVerifyList;
	public int seqNo;
	public String userFlag;
	public String custVerify;
	
	public String getFlag() {
		return flag;
	}
	public void setFlag(String flag) {
		this.flag = flag;
	}
	public String getBranchsolID() {
		return branchsolID;
	}
	public void setBranchsolID(String branchsolID) {
		this.branchsolID = branchsolID;
	}
	public String getBranchalphaCode() {
		return branchalphaCode;
	}
	public void setBranchalphaCode(String branchalphaCode) {
		this.branchalphaCode = branchalphaCode;
	}
	public String getBranchswiftCode() {
		return branchswiftCode;
	}
	public void setBranchswiftCode(String branchswiftCode) {
		this.branchswiftCode = branchswiftCode;
	}
	public String getBranchPhone() {
		return branchPhone;
	}
	public void setBranchPhone(String branchPhone) {
		this.branchPhone = branchPhone;
	}
	public String getBranchMobileNo() {
		return branchMobileNo;
	}
	public void setBranchMobileNo(String branchMobileNo) {
		this.branchMobileNo = branchMobileNo;
	}
	public String getBranchAddress() {
		return branchAddress;
	}
	public void setBranchAddress(String branchAddress) {
		this.branchAddress = branchAddress;
	}
	public String getCurrentPage() {
		return currentPage;
	}
	public void setCurrentPage(String currentPage) {
		this.currentPage = currentPage;
	}
	public String getCustID() {
		return custID;
	}
	public void setCustID(String custID) {
		this.custID = custID;
	}
	public String getOperSolID() {
		return operSolID;
	}
	public void setOperSolID(String operSolID) {
		this.operSolID = operSolID;
	}
	public String getCustName() {
		return custName;
	}
	public void setCustName(String custName) {
		this.custName = custName;
	}
	public String getLineofActivity() {
		return lineofActivity;
	}
	public void setLineofActivity(String lineofActivity) {
		this.lineofActivity = lineofActivity;
	}
	public String getEmailID() {
		return emailID;
	}
	public void setEmailID(String emailID) {
		this.emailID = emailID;
	}
	public String getOperAccNo() {
		return operAccNo;
	}
	public void setOperAccNo(String operAccNo) {
		this.operAccNo = operAccNo;
	}
	public String getAlphaCode() {
		return alphaCode;
	}
	public void setAlphaCode(String alphaCode) {
		this.alphaCode = alphaCode;
	}
	public String getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	public String getRateMarginFrom() {
		return rateMarginFrom;
	}
	public void setRateMarginFrom(String rateMarginFrom) {
		this.rateMarginFrom = rateMarginFrom;
	}
	public String getRateMarginTo() {
		return rateMarginTo;
	}
	public void setRateMarginTo(String rateMarginTo) {
		this.rateMarginTo = rateMarginTo;
	}
	
}
