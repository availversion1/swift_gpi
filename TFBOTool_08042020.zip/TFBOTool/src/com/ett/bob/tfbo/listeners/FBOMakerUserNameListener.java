package com.ett.bob.tfbo.listeners;

import java.net.InetAddress;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.concurrent.TimeUnit;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

import org.apache.log4j.Logger;
import org.quartz.CronScheduleBuilder;
import org.quartz.JobBuilder;
import org.quartz.JobDetail;
import org.quartz.Scheduler;
import org.quartz.SchedulerException;
import org.quartz.Trigger;
import org.quartz.TriggerBuilder;
import org.quartz.impl.StdSchedulerFactory;

import com.ett.bob.tfbo.dbutil.DBUtility;
import com.ett.bob.tfbo.dbutil.PropertyUtil;

public class FBOMakerUserNameListener implements ServletContextListener {

	Scheduler scheduler = null;

	private static Logger logger = Logger
			.getLogger(FBOMakerUserNameListener.class.getName());

	public static Thread thread;

	public static String schemaName;

	static {
		try {
			schemaName = PropertyUtil.getPropertiesValue().getProperty(
					"UserName")
					+ ".";
		} catch (Exception e) {

		}
	}

	public static void main(String[] args) {
		proceUpdatingON();
	}

	@Override
	public void contextDestroyed(ServletContextEvent arg0) {
		logger.info("PostingStagingListener destroyed..!");
	}

	@Override
	public void contextInitialized(ServletContextEvent arg0) {

		try {

			thread = new Thread(new Runnable() {
				public void run() {
					try {
						boolean flag = true;
						while (flag) {
							try {
								// MAIN MATHOD//
								proceUpdatingON();

							} catch (NullPointerException e) {
								logger.info("PostingStagingListener Null Pointer exceptions! "
										+ e.getMessage());
								e.printStackTrace();

							} catch (Exception e) {
								logger.info("PostingStagingListener Exceptions! "
										+ e.getMessage());
								e.printStackTrace();
							}

							Thread.sleep(TimeUnit.SECONDS
									.toMillis(60 * 60 * 1000));

						}
					} catch (NullPointerException e) {
						logger.info("PostingStagingListener Null Pointer exceptions! "
								+ e.getMessage());
						e.printStackTrace();

					} catch (Exception e) {
						logger.info("PostingStagingListener Exceptions! "
								+ e.getMessage());
						e.printStackTrace();

					}
				}
			});
			thread.start();

		} catch (Exception e) {
			e.printStackTrace();
			logger.info("Job Scheduling Error in K+................... "
					+ e.getStackTrace());
		}
	}

	private static boolean controllerCheck() {
		Connection aConnection = null;
		Statement aPreparedStatement = null;
		ResultSet aResultSet = null;
		String hostName;
		InetAddress ip;
		String host;
		boolean result = false;
		String sqlQuery = "SELECT * FROM BRIDGEPROPERTIES WHERE KEY='PrimaryHostName'";
		try {
			logger.info("Controller Check method entered");
			ip = InetAddress.getLocalHost();
			host = ip.getHostName();
			logger.info("Controller Check method Server IP " + ip);
			logger.info("Controller Check method Server Host Name " + host);
			aConnection = DBUtility.getZoneConnection();
			// connection = ConnectionMaster.getThemebridgeConnection();
			aPreparedStatement = aConnection.createStatement();
			aResultSet = aPreparedStatement.executeQuery(sqlQuery);
			logger.info("Controller Check method Query " + sqlQuery);
			while (aResultSet.next()) {
				hostName = aResultSet.getString("VALUE");
				logger.info("Controller Check method Primary Host From Bridge Properties "
						+ hostName);
				if (hostName != null && hostName.trim().length() > 0
						&& host.equalsIgnoreCase(hostName)) {
					result = true;
				} else {
					result = false;
				}
			}

		} catch (Exception e) {

			e.printStackTrace();
		} finally {
			DBUtility.surrenderDB(aConnection, null, aResultSet);
			if (aPreparedStatement != null) {
				try {
					aPreparedStatement.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}

		return false;

	}

	public static boolean proceUpdatingON() {
		Connection aConnection = null;
		PreparedStatement aPreparedStatement = null;
		ResultSet aResultSet = null;

		boolean check = controllerCheck();

		if (check == true) {
			try {
				aConnection = DBUtility.getZoneConnection();
				String getTFBOData = "{call " + schemaName
						+ "TFBO_UPDATE_FBOUSER_PROC}";
				aPreparedStatement = aConnection.prepareCall(getTFBOData);
				aPreparedStatement.executeUpdate();

			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				DBUtility.surrenderDB(aConnection, aPreparedStatement,
						aResultSet);
			}
			return check;
		}
		return check;
	}

}
