package com.ett.bob.tfbo.listeners;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.concurrent.TimeUnit;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

import org.apache.log4j.Logger;
import org.quartz.Scheduler;

import com.ett.bob.tfbo.dbutil.DBUtility;
import com.ett.bob.tfbo.dbutil.PropertyUtil;

public class TFBOAbortListener implements ServletContextListener {

	Scheduler scheduler = null;

	private static Logger logger = Logger.getLogger(TFBOAbortListener.class
			.getName());

	public static Thread thread;

	public static String schemaName;

	static {
		try {
			schemaName = PropertyUtil.getPropertiesValue().getProperty(
					"UserName")
					+ ".";
		} catch (Exception e) {

		}
	}

	public static void main(String[] args) {
		callTFBOAbortListener();
	}

	@Override
	public void contextDestroyed(ServletContextEvent arg0) {
		logger.info("PostingStagingListener destroyed..!");
	}

	@Override
	public void contextInitialized(ServletContextEvent arg0) {

		try {

			thread = new Thread(new Runnable() {
				public void run() {
					try {
						boolean flag = true;
						while (flag) {
							try {
								callTFBOAbortListener();
							} catch (NullPointerException e) {
								logger.info("PostingStagingListener Null Pointer exceptions! "
										+ e.getMessage());
								e.printStackTrace();

							} catch (Exception e) {
								logger.info("PostingStagingListener Exceptions! "
										+ e.getMessage());
								e.printStackTrace();
							}
							// Thread.sleep(2 * 60 * 1000);
							Thread.sleep(TimeUnit.SECONDS
									.toMillis(120 * 60 * 1000));
							// long timeInterval =
							// Long.parseLong(ConfigurationUtil.getValueFromKey(ThemeConstant.POSTING_STAGING_LISTNER_FREQUENCY));
							// Thread.sleep(timeInterval);
						}
					} catch (NullPointerException e) {
						logger.info("PostingStagingListener Null Pointer exceptions! "
								+ e.getMessage());
						e.printStackTrace();

					} catch (Exception e) {
						logger.info("PostingStagingListener Exceptions! "
								+ e.getMessage());
						e.printStackTrace();

					}
				}
			});
			thread.start();
		} catch (Exception e) {
			e.printStackTrace();
			logger.info("Job Scheduling Error in K+................... "
					+ e.getStackTrace());
		}
	}

	public static void callTFBOAbortListener() {

		Connection conn = null;
		PreparedStatement pst = null;
		int rs = 0;
		String query = "";
		try {
			conn = DBUtility.getZoneConnection();
			query = "update Tfbo_Trans SET STEPSTATUS   = 'FBO Rejected',step = 'FBO Maker',ISRELEASED  = 0 where REQUESTID in (SELECT Exte.Requstid "
					+ " FROM" +schemaName+"master mas,"+schemaName+"Baseevent bev,"+schemaName+"extevent exte "
					+ " WHERE Mas.Key97          = Bev.Master_Key "
					+ " AND Bev.Key97            = Exte.Event "
					+ " AND trim(Exte.Requstid) IS NOT NULL "
					+ " AND Bev.Status           = 'a' "
					+ " AND Bev.Timefinish + Interval '330' Minute  between Systimestamp - Interval '30' Minute  "
					+ " AND Systimestamp )";
			pst = conn.prepareStatement(query);
			rs = pst.executeUpdate();
			logger.info("TFBO TOOL --->" + rs);
			// auditEntry("TFBOListener",null,"SUCCEEDED");
		} catch (Exception e) {
			e.printStackTrace();
			// auditEntry("TFBOListener",e.getStackTrace(),"FAILED");
		} finally {
			DBUtility.surrenderDB(conn, pst, null);
		}
	}
}
