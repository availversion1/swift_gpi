package com.ett.bob.tfbo.listeners;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.concurrent.TimeUnit;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

import org.apache.log4j.Logger;
import org.quartz.Scheduler;

import com.ett.bob.tfbo.dbutil.DBUtility;
import com.ett.bob.tfbo.dbutil.PropertyUtil;

public class TransLockEnableListener implements ServletContextListener {
	Scheduler scheduler = null;

	private static Logger logger = Logger.getLogger(TFBOAbortListener.class
			.getName());

	public static Thread thread;

	public static String schemaName;

	static {
		try {
			schemaName = PropertyUtil.getPropertiesValue().getProperty(
					"UserName")
					+ ".";
		} catch (Exception e) {

		}
	}

	public static void main(String[] args) {
		callTransLockEnableListener();
	}

	@Override
	public void contextDestroyed(ServletContextEvent arg0) {
		logger.info("PostingStagingListener destroyed..!");
	}

	@Override
	public void contextInitialized(ServletContextEvent arg0) {

		try {

			thread = new Thread(new Runnable() {
				public void run() {
					try {
						boolean flag = true;
						while (flag) {
							try {
								callTransLockEnableListener();
							} catch (NullPointerException e) {
								logger.info("PostingStagingListener Null Pointer exceptions! "
										+ e.getMessage());
								e.printStackTrace();

							} catch (Exception e) {
								logger.info("PostingStagingListener Exceptions! "
										+ e.getMessage());
								e.printStackTrace();
							}
							// Thread.sleep(2 * 60 * 1000);
							Thread.sleep(TimeUnit.SECONDS.toMillis(120*60*1000));
							// long timeInterval =
							// Long.parseLong(ConfigurationUtil.getValueFromKey(ThemeConstant.POSTING_STAGING_LISTNER_FREQUENCY));
							// Thread.sleep(timeInterval);
						}
					} catch (NullPointerException e) {
						logger.info("PostingStagingListener Null Pointer exceptions! "
								+ e.getMessage());
						e.printStackTrace();

					} catch (Exception e) {
						logger.info("PostingStagingListener Exceptions! "
								+ e.getMessage());
						e.printStackTrace();

					}
				}
			});
			thread.start();
		} catch (Exception e) {
			e.printStackTrace();
			logger.info("Job Scheduling Error in K+................... "
					+ e.getStackTrace());
		}
	}

	public static void callTransLockEnableListener() {

		Connection conn = null;
		PreparedStatement pst = null;
		int rs = 0;
		String query = "";
		try {
			conn = DBUtility.getZoneConnection();
			query = "UPDATE TFBO_TRANS SET TRAN_LOCK = 0 WHERE TRAN_LOCK = 1";
			pst = conn.prepareStatement(query);
			rs = pst.executeUpdate();
			logger.info("TFBO TOOL --->" + rs);
			// auditEntry("TFBOListener",null,"SUCCEEDED");
		} catch (Exception e) {
			e.printStackTrace();
			// auditEntry("TFBOListener",e.getStackTrace(),"FAILED");
		} finally {
			DBUtility.surrenderDB(conn, pst, null);
		}
	}
}
