package com.ett.bob.tfbo.dao;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;
import java.util.Properties;

import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.apache.struts2.ServletActionContext;

import com.ett.bob.tfbo.businessdelegate.TFBOHomeActionBD;
import com.ett.bob.tfbo.commonutil.CommonMethods;
import com.ett.bob.tfbo.commonutil.EJBProcessManager;
import com.ett.bob.tfbo.commonutil.EmailProcessManager;
import com.ett.bob.tfbo.dbutil.DBHelper;
import com.ett.bob.tfbo.dbutil.PropertyUtil;
import com.ett.bob.tfbo.model.AlertMessagesVO;
import com.ett.bob.tfbo.model.BrabchProfileMgmt;
import com.ett.bob.tfbo.model.CustomerProfileManageVO;
import com.ett.bob.tfbo.model.ProfileManagementVO;
import com.ett.bob.tfbo.model.ReportVO;
import com.ett.bob.tfbo.model.TFBOChecklistVO;
import com.ett.bob.tfbo.model.TFBOExportCollectionVO;
import com.ett.bob.tfbo.model.TFBOExportLcVO;
import com.ett.bob.tfbo.model.TFBOFinanceExportColVO;
import com.ett.bob.tfbo.model.TFBOFinanceExportLcVO;
import com.ett.bob.tfbo.model.TFBOFinanceStandaloneVO;
import com.ett.bob.tfbo.model.TFBOIdcVO;
import com.ett.bob.tfbo.model.TFBOImportGTVO;
import com.ett.bob.tfbo.model.TFBOImportLcVO;
import com.ett.bob.tfbo.model.TFBOInwardRemittanceVO;
import com.ett.bob.tfbo.model.TFBOMiscellanousVO;
import com.ett.bob.tfbo.model.TFBOOutwardRemittanceVO;
import com.ett.bob.tfbo.model.TFBOReminderVO;
import com.ett.bob.tfbo.model.TFBOSandbyLcVO;
import com.ett.bob.tfbo.model.TFBOTransVO;
import com.ett.bob.tfbo.model.UserTransactionVO;
import com.ett.bob.tfbo.util.ActionConstants;
import com.ett.bob.tfbo.workflowutil.TFBOWorkflow;

public class TFBOHomeDAO {
	private static Logger logger = Logger
			.getLogger(TFBOHomeDAO.class.getName());
	
	
	public static String schemaName;

	static {
		try {
			schemaName = PropertyUtil.getPropertiesValue().getProperty(
					"UserName")
					+ ".";
		} catch (Exception e) {

		}
	}

	public UserTransactionVO getSolId(UserTransactionVO userVo) {
		System.out.println("GET SOL ID >>---> ENTERING");
		TFBOHomeActionBD aTFBOHomeActionBD = new TFBOHomeActionBD();
		try {
			if ((userVo.getProductCode().equals("ODC") && userVo.getEventCode()
					.equals("CRE"))
					|| (userVo.getProductCode().equals("ISB") && userVo
							.getEventCode().equals("ISS"))
					|| (userVo.getProductCode().equals("ILC") && userVo
							.getEventCode().equals("ISI"))
					|| (userVo.getProductCode().equals("IGT") && userVo
							.getEventCode().equals("IIG"))
					|| (userVo.getProductCode().equals("IDC") && userVo
							.getEventCode().equals("CRE"))
					|| (userVo.getProductCode().equals("FSA") && userVo
							.getEventCode().equals("CSA"))
					// || (userVo.getProductCode().equals("FOC") && userVo
					// .getEventCode().equals("CSA1"))
					 || (userVo.getProductCode().equals("COR") && userVo
					 .getEventCode().equals("CRCR"))//pandi for MIS sol id autopopulation
					|| (userVo.getProductCode().equals("ELC") && userVo
							.getEventCode().equals("ADE"))
					|| (userVo.getProductCode().equals("CPCO") && userVo
							.getEventCode().equals("PCOC"))
					|| (userVo.getProductCode().equals("CPCI") && userVo
							.getEventCode().equals("PCIC"))
					|| (userVo.getProductCode().equals("CPBI") && userVo
							.getEventCode().equals("PBIC")))
				userVo.setSolID(aTFBOHomeActionBD.getSessionSolId());
			System.out.println("GET SOL ID >>---> ENTERING");
		} catch (Exception e) {
			e.printStackTrace();
		}
		return userVo;
	}

	public void sentMailToBranch(UserTransactionVO userVo) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		TFBOEmailProcessDAO aTFBOEmailProcessDAO = new TFBOEmailProcessDAO();
		EmailProcessManager aEmailProcessManager = new EmailProcessManager();
		CommonMethods aCommonMethods = new CommonMethods();
		String emailUserId = "";
		String emailPassword = "";
		String mailBody = "";
		String mailSubject = "";
		String branchEmailAddresss = "";
		String DefaultBranchId = "";
		String[] toEmailId = null;
		try {
			Properties aProperties = PropertyUtil.getPropertiesValue();
			emailUserId = aProperties.getProperty("EmailUserId");
			emailPassword = aProperties.getProperty("EmailPassword");
			DefaultBranchId = aProperties.getProperty("DefaultBranchId");
			branchEmailAddresss = getBranchEmailAddress(userVo.getSolID());
			if (aCommonMethods.isValueAvailable(branchEmailAddresss)) {
				toEmailId = branchEmailAddresss.split(",|\\;");
				logger.info("toEmailId-->" + toEmailId);
				// Only for testing
				toEmailId = DefaultBranchId.split(",|\\;");
				//
				mailSubject = aTFBOEmailProcessDAO
						.getMailSubjectToBranch(userVo);
				mailBody = aTFBOEmailProcessDAO.getMailBodyToBranch(userVo);
				aEmailProcessManager.sendMail(emailUserId, emailPassword,
						toEmailId, mailSubject, mailBody);
				logger.info("Mail body-->" + mailBody);
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		logger.info(ActionConstants.EXITING_METHOD);
	}

	public void sentMailToCustomer(UserTransactionVO userVo) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		TFBOEmailProcessDAO aTFBOEmailProcessDAO = new TFBOEmailProcessDAO();
		EmailProcessManager aEmailProcessManager = new EmailProcessManager();
		CommonMethods aCommonMethods = new CommonMethods();
		Properties aProperties = PropertyUtil.getPropertiesValue();
		String emailUserId = "";
		String emailPassword = "";
		String mailBody = "";
		String mailSubject = "";
		String DefaultCustomerId = "";
		String customerEmailAddresss = "";
		String[] toEmailId = null;
		emailUserId = aProperties.getProperty("EmailUserId");
		emailPassword = aProperties.getProperty("EmailPassword");
		DefaultCustomerId = aProperties.getProperty("DefaultCustomerId");
		customerEmailAddresss = getCustomerEmailAddress(userVo.getCustomeCif());
		if (aCommonMethods.isValueAvailable(customerEmailAddresss)) {
			toEmailId = customerEmailAddresss.split(",|\\;");
			logger.info("toEmailId-->" + toEmailId);
			// Only for testing
			toEmailId = DefaultCustomerId.split(",|\\;");
			//
			mailSubject = aTFBOEmailProcessDAO.getMailSubjectToCustomer(userVo);
			mailBody = aTFBOEmailProcessDAO.getMailBodyToCustomer(userVo);
			aEmailProcessManager.sendMail(emailUserId, emailPassword,
					toEmailId, mailSubject, mailBody);
			logger.info("Mail body-->" + mailBody);
		}
		logger.info(ActionConstants.EXITING_METHOD);
	}

	public String getBranchEmailAddress(String solId) throws Exception {
		DBHelper aDBHelper = new DBHelper();
		String branchEmailAddress = null;
		logger.info("requestId-->" + solId);
		branchEmailAddress = aDBHelper.getValueFromDB(solId,
				ActionConstants.GETBRANCHMAILADDRESS_QUERY);
		logger.info("tiReferanceNumber-->" + branchEmailAddress);
		return branchEmailAddress;
	}

	public String getCustomerEmailAddress(String customerCif) throws Exception {
		DBHelper aDBHelper = new DBHelper();
		String customerEmailAddress = null;
		logger.info("requestId-->" + customerCif);
		customerEmailAddress = aDBHelper.getValueFromDB(customerCif,
				ActionConstants.GETCUSTOMERMAILADDRESS_QUERY);
		logger.info("tiReferanceNumber-->" + customerEmailAddress);
		return customerEmailAddress;
	}

	public String getTiReferenceNumber(String requestId) throws Exception {
		DBHelper aDBHelper = new DBHelper();
		String tiReferanceNumber = "";
		logger.info("requestId-->" + requestId);
		tiReferanceNumber = aDBHelper.getValueFromDB(requestId,
				ActionConstants.GETTIREFERANCE_QUERY);
		logger.info("tiReferanceNumber-->" + tiReferanceNumber);
		return tiReferanceNumber;
	}

	public void updateTiReferenceNumber(String tiReferanceNumber,
			String requestId) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		DBHelper aDBHelper = new DBHelper();
		aDBHelper.setValueInDB(tiReferanceNumber, requestId,
				ActionConstants.GETUPDATETIREFERANCE_QUERY);
		logger.info(ActionConstants.EXITING_METHOD);
	}

	public UserTransactionVO getMakerChecklist(UserTransactionVO userVo)
			throws Exception {
		DBHelper aDBHelper = new DBHelper();
		CommonMethods aCommonMethods = new CommonMethods();
		List<TFBOChecklistVO> makerChecklist = new LinkedList<TFBOChecklistVO>();
		try {
			String requestId = userVo.getRequestId();
			String subProductCode = userVo.getSubProductCode();
			logger.info("Sub-Product Code-->" + subProductCode);
			logger.info("Request ID-->" + requestId);
			if (!aCommonMethods.isValueAvailable(subProductCode))
				subProductCode = "%";
			makerChecklist = aDBHelper.getChecklistFromDB(requestId,
					subProductCode, ActionConstants.MAKER,
					ActionConstants.GETTFBOMAKERCHECKLIST_QUERY);
			logger.info("Size-->" + makerChecklist.size());
			userVo.setBranchMakerCheckList(makerChecklist);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		return userVo;
	}

	public UserTransactionVO getCheckerChecklist(UserTransactionVO userVo)
			throws Exception {
		DBHelper aDBHelper = new DBHelper();
		CommonMethods aCommonMethods = new CommonMethods();
		List<TFBOChecklistVO> checkerChecklist = new LinkedList<TFBOChecklistVO>();
		try {
			String requestId = userVo.getRequestId();
			String subProductCode = userVo.getSubProductCode();
			logger.info("Sub-Product Code-->" + subProductCode);
			logger.info("Request ID-->" + requestId);
			if (!aCommonMethods.isValueAvailable(subProductCode))
				subProductCode = "%";
			checkerChecklist = aDBHelper.getChecklistFromDB(requestId,
					subProductCode, ActionConstants.FBOSCRUTINIZER,
					ActionConstants.GETTFBOCHECKERCHECKLIST_QUERY);
			logger.info("Size-->" + checkerChecklist.size());
			userVo.setFboScrutinizerCheckList(checkerChecklist);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		return userVo;
	}

	public UserTransactionVO getUserCommentList(
			UserTransactionVO aUserTransactionVO) throws Exception {
		DBHelper aDBHelper = new DBHelper();
		try {
			logger.info("Tran ID inside getDocumentList-->"
					+ aUserTransactionVO.getRequestId());
			aUserTransactionVO.setUserCommentList(aDBHelper
					.getCommentListFromDB(aUserTransactionVO.getRequestId(),
							ActionConstants.GETUSERCOMMENT_QUERY));
			logger.info("Size-->"
					+ aUserTransactionVO.getUserCommentList().size());
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		return aUserTransactionVO;
	}

	public UserTransactionVO getCustomerCommentList(
			UserTransactionVO aUserTransactionVO) throws Exception {
		DBHelper aDBHelper = new DBHelper();
		try {
			logger.info("Tran ID inside getDocumentList-->"
					+ aUserTransactionVO.getRequestId());
			aUserTransactionVO.setCustomerCommentList(aDBHelper
					.getCommentListFromDB(aUserTransactionVO.getRequestId(),
							ActionConstants.GETCUSTOMERCOMMENT_QUERY));
			logger.info("Size-->"
					+ aUserTransactionVO.getCustomerCommentList().size());
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		return aUserTransactionVO;
	}

	public String getSessionUser() {
		logger.info(ActionConstants.ENTERING_METHOD);
		String userName = "";
		HttpSession session = ServletActionContext.getRequest().getSession();
		userName = (String) session.getAttribute("sessionUserName");
		logger.info(ActionConstants.EXITING_METHOD + "UserName received is-->"
				+ userName);
		return userName;
	}

	public String getSessionSolId() {
		logger.info(ActionConstants.ENTERING_METHOD);
		String solId = "";
		HttpSession session = ServletActionContext.getRequest().getSession();
		solId = (String) session.getAttribute("solId");
		if (solId != null && !solId.trim().equals("")) {
			solId = solId.trim();
		}
		logger.info(ActionConstants.EXITING_METHOD + "UserName received is-->"
				+ solId);
		return solId;
	}

	public String getSessionId() throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		DBHelper aDBHelper = new DBHelper();
		String sessionId = "";
		sessionId = aDBHelper
				.getValueFromDB(ActionConstants.GETSESSIONID_QUERY);
		logger.info(ActionConstants.EXITING_METHOD + "sessionId received is-->"
				+ sessionId);
		return sessionId;
	}

	public void setSessionUsername(String username) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		DBHelper aDBHelper = new DBHelper();
		String loginStatus = "LOGIN_INITIATED";
		aDBHelper.setValueInDB(username, loginStatus,
				ActionConstants.GETINSERTTFBOSESSIONUSER_QUERY);
		logger.info(ActionConstants.EXITING_METHOD);
	}

	public void setSessionStatus(String sessionId, String loginStatus) {
		logger.info(ActionConstants.ENTERING_METHOD);
		DBHelper aDBHelper = new DBHelper();
		try {
			aDBHelper.setValueInDB(loginStatus, sessionId,
					ActionConstants.GETUPDATETFBOSESSIONUSER_QUERY);
		} catch (Exception e) {
			e.printStackTrace();
		}
		logger.info(ActionConstants.EXITING_METHOD);
	}

	public String getReturnPage(UserTransactionVO userVo, String productCode,
			String eventCode, String stepName) throws Exception {
		String returnPage = "";
		if (stepName.trim().equals(ActionConstants.INPUT)) {
			logger.info(ActionConstants.ENTERING_METHOD + ">> isValidUser");
			returnPage = "maker" + productCode.trim() + eventCode.trim();
		}
		if (stepName.trim().equals(ActionConstants.REVIEW)) {
			logger.info(ActionConstants.ENTERING_METHOD + ">> isValidUser");
			returnPage = "checker" + productCode.trim() + eventCode.trim();
		}
		if (stepName.trim().equals(ActionConstants.AUTHORIZE)) {
			logger.info(ActionConstants.ENTERING_METHOD + ">> isValidUser");
			returnPage = "scrutinizer" + productCode.trim() + eventCode.trim();
		}
			//pandi start for FBo maker submit starts here
		if (stepName.trim().equals(ActionConstants.FBOMAKER_1)) {
			logger.info(ActionConstants.ENTERING_METHOD + ">> isValidUser");
			if (userVo.getUserFBOMaker().equals("YES"))
				returnPage = "fbomaker" + productCode.trim() + eventCode.trim();
		}
		
		if (stepName.trim().equals(ActionConstants.FBOCHECKER_1)) {
			logger.info(ActionConstants.ENTERING_METHOD + ">> isValidUser");
			if (userVo.getUserFBOChecker().equals("YES"))
				returnPage = "fbochecker" + productCode.trim()
						+ eventCode.trim();
		}
		
		if (stepName.trim().equals(ActionConstants.RELEASE)) {
			logger.info(ActionConstants.ENTERING_METHOD + ">> isValidUser");
			if (userVo.getUserFBOMaker().equals("YES"))
				returnPage = "viewer" + productCode.trim() + eventCode.trim();
			if (userVo.getUserFBOChecker().equals("YES"))
				returnPage = "viewer" + productCode.trim()
						+ eventCode.trim();
		}
		//pandi start for FBo maker submit ends here
		return returnPage;
	}

	public Boolean initiateTransactionInTI(UserTransactionVO userVo)
			throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		logger.info("product Code in initiateTransactionInTI-->"
				+ userVo.getProductCode());
		logger.info("event Code in initiateTransactionInTI-->"
				+ userVo.getEventCode());
		TFBOXmlProcessDAO aTFBOXmlProcessDAO = new TFBOXmlProcessDAO();
		EJBProcessManager aEJBProcessManager = new EJBProcessManager();
		DBHelper aDBHelper = new DBHelper();
		String xmlStringtoPush = "";
		logger.info("Currency in initiateTransactionInTI method-->"
				+ userVo.getCurrency());
		xmlStringtoPush = aTFBOXmlProcessDAO.getXMLtoPush(userVo);
		// Miscellanous changes starts 08-01-2020
		CommonMethods aCommonMethods = new CommonMethods();

		if (userVo.getProductCode().trim().equalsIgnoreCase("COR")) {

			if (userVo.getEventCode().trim().equalsIgnoreCase("CRCR")) {

				System.out
						.println("Getting sub product code in initiate transaction"
								+ userVo.getSubProductCode());

				if (aCommonMethods.isValueAvailable(userVo.getSubProductCode())) {

					if (userVo.getSubProductCode().trim()
							.equalsIgnoreCase("EEFC")
							|| userVo.getSubProductCode().trim()
									.equalsIgnoreCase("ODI")
							|| userVo.getSubProductCode().trim()
									.equalsIgnoreCase("RFC")) {

						System.out
								.println("No EJB call for EEFC,ODI and RFC==>");

						logger.info("No EJB call for EEFC,ODI and RFC==>");
						return true;
					}
				}
			}
		}
		// Miscellanous changes ends 08-01-2020
		if (aEJBProcessManager.postTIXml(xmlStringtoPush, userVo)) {
			aDBHelper.setValueInDB(userVo.getRequestId(),
					ActionConstants.GETUPDATETFBOTRANSRELEASED_QUERY);
			logger.info(ActionConstants.EXITING_METHOD);
			return true;
		}
		logger.info(ActionConstants.EXITING_METHOD);
		return false;
	}

	public void clearTFBOTransUser(String stepName, String requestId)
			throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		if (stepName.trim().equals(ActionConstants.INPUT)) {
			clearTFBOTransUserInDB(requestId,
					ActionConstants.GETCLEARFBOTRANSINPUTUSER_QUERY);
			clearTFBOTransUserInDB(requestId,
					ActionConstants.GETCLEARTFBOTRANSREVIEWUSER_QUERY);
			clearTFBOTransUserInDB(requestId,
					ActionConstants.GETCLEARTFBOTRANSAUTHUSER_QUERY);
			logger.info(ActionConstants.ENTERING_METHOD + ">> isValidUser");
		}
		if (stepName.trim().equals(ActionConstants.REVIEW)) {
			clearTFBOTransUserInDB(requestId,
					ActionConstants.GETCLEARTFBOTRANSREVIEWUSER_QUERY);
			clearTFBOTransUserInDB(requestId,
					ActionConstants.GETCLEARTFBOTRANSAUTHUSER_QUERY);
			logger.info(ActionConstants.ENTERING_METHOD + ">> isValidUser");
		}
		if (stepName.trim().equals(ActionConstants.AUTHORIZE)) {
			clearTFBOTransUserInDB(requestId,
					ActionConstants.GETCLEARTFBOTRANSAUTHUSER_QUERY);
			logger.info(ActionConstants.ENTERING_METHOD + ">> isValidUser");
		}
		logger.info(ActionConstants.EXITING_METHOD);
	}

	public List<AlertMessagesVO> isChecklistFilled(UserTransactionVO userVo,
			List<TFBOChecklistVO> aTFBOChecklist,
			List<AlertMessagesVO> errorDetailList) throws Exception {
		CommonMethods aCommonMethods = new CommonMethods();
		String checklistValue = "";
		String checklistRemarks = "";
		for (TFBOChecklistVO aTFBOChecklistVO : aTFBOChecklist) {
			checklistValue = aTFBOChecklistVO.getChecklistValue();
			checklistRemarks = aTFBOChecklistVO.getChecklistRemarks();
			if (!aCommonMethods.isValueAvailable(checklistValue)) {
				if (!aCommonMethods.isValueAvailable(checklistRemarks)) {
					logger.info("Please fill all the checklist");
					errorDetailList = aCommonMethods.setErrorInList(
							ActionConstants.ERRORCODE007, errorDetailList);
					return errorDetailList;
				}
			} else if (checklistValue.equalsIgnoreCase("Other")) {
				if (!aCommonMethods.isValueAvailable(checklistRemarks)) {
					logger.info("Checklist Remarks should be filled for Others");
					errorDetailList = aCommonMethods.setErrorInList(
							ActionConstants.ERRORCODE008, errorDetailList);
					return errorDetailList;
				}
			}
		}
		return errorDetailList;
	}

	public Boolean isValidScrutinizerVerifyRequest(UserTransactionVO userVo)
			throws Exception {
		List<AlertMessagesVO> errorDetailList = new LinkedList<AlertMessagesVO>();
		Boolean isValidTransactionRequest = true;
		if (userVo.getFboScrutinizerCheckList() != null) {
			errorDetailList = isChecklistFilled(userVo,
					userVo.getFboScrutinizerCheckList(), errorDetailList);
		}
		errorDetailList = isValidScrutinizerFieldValues(userVo, errorDetailList);
		// ADDED BY CHANDRU
		errorDetailList = isTransLocked(userVo, errorDetailList);
		// ADDED BY CHANDRU
		userVo.setErrorDetailsList(errorDetailList);
		if (!(userVo.getErrorDetailsList().size() == 0)) {
			isValidTransactionRequest = false;
		}
		return isValidTransactionRequest;
	}

	// Added on 21-12-2019 after ODC release starts
	public void updateTFBOScrutinizerDetails(UserTransactionVO userVo)
			throws Exception {
		String rate = "";
		// Rate taken Fix Offshore Team 30122019 starts
		if (userVo.getProductCode().trim().equalsIgnoreCase("ILC")) {

			if (userVo.getEventCode().trim().equalsIgnoreCase("POCP")) {

				// ADDED BY CHANDRU
				rate = userVo.getRateTaken();
				if (rate.equals("false")) {
					rate = "N";
				} else {
					rate = "Y";
				}
				// ENDS

				logger.info(ActionConstants.ENTERING_METHOD);
				DBHelper aDBHelper = new DBHelper();

				aDBHelper.setValueRateTakenLCInDB(rate, userVo.getRate(),
						userVo.getToken(), userVo.getValueK(),
						userVo.getRequestId(),
						ActionConstants.GETUPDATERATETAKENDETAILS_ILCPAY_QUERY);
				logger.info(ActionConstants.EXITING_METHOD);
			}
			if (userVo.getEventCode().trim().equalsIgnoreCase("POCD")) {

				// ADDED BY CHANDRU
				rate = userVo.getRateTaken();
				if (rate.equals("false")) {
					rate = "N";
				} else {
					rate = "Y";
				}
				// ENDS

				logger.info(ActionConstants.ENTERING_METHOD);
				DBHelper aDBHelper = new DBHelper();
				aDBHelper.setValueRateTakenLCInDB(rate, userVo.getRate(),
						userVo.getToken(), userVo.getValueK(),
						userVo.getRequestId(),
						ActionConstants.GETUPDATERATETAKENDETAILS_ILCDEV_QUERY);
				logger.info(ActionConstants.EXITING_METHOD);
			}
		}
		if (userVo.getProductCode().trim().equalsIgnoreCase("ELC")) {

			if (userVo.getEventCode().trim().equalsIgnoreCase("PODP")) {

				// ADDED BY CHANDRU
				rate = userVo.getRateTaken();
				if (rate == null || rate.equals("false")) {
					rate = "N";
				} else {
					rate = "Y";
				}
				// ENDS

				logger.info(ActionConstants.ENTERING_METHOD);
				DBHelper aDBHelper = new DBHelper();
				aDBHelper.setValueRateTakenODCInDB(rate, userVo.getRate(),
						userVo.getToken(), userVo.getValueK(),
						userVo.getRequestId(), userVo.getSenderRefno(),
						ActionConstants.GETUPDATERATETAKENDETAILS_ELCPAY_QUERY);
				logger.info(ActionConstants.EXITING_METHOD);
			}
			if (userVo.getEventCode().trim().equalsIgnoreCase("PODA")) {

				// ADDED BY CHANDRU
				rate = userVo.getRateTaken();
				if (rate == null || rate.equals("false")) {
					rate = "N";
				} else {
					rate = "Y";
				}
				// ENDS

				logger.info(ActionConstants.ENTERING_METHOD);
				DBHelper aDBHelper = new DBHelper();
				aDBHelper.setValueRateTakenELCInDB(userVo.getRequestId(),
						userVo.getSenderRefno(),
						ActionConstants.GETUPDATERATETAKENDETAILS_ELCACC_QUERY);
				logger.info(ActionConstants.EXITING_METHOD);
			}

		}
		/*
		 * if (userVo.getProductCode().trim().equalsIgnoreCase("ODC")) { if
		 * (userVo.getEventCode().trim().equalsIgnoreCase("CLP")) {
		 * logger.info(ActionConstants.ENTERING_METHOD); DBHelper aDBHelper =
		 * new DBHelper(); // ADDED BY CHANDRU rate = userVo.getRateTaken();
		 * CommonMethods acommMethods = new CommonMethods();
		 * 
		 * if (acommMethods.isValueAvailable(rate)) { if (rate.equals("false"))
		 * { rate = "N"; } else { rate = "Y"; } } // ENDS
		 * 
		 * aDBHelper.setValueRateTakenODCInDB(rate, userVo.getRate(),
		 * userVo.getToken(), userVo.getValueK(), userVo.getRequestId(),
		 * userVo.getSenderRefno(),
		 * ActionConstants.GETUPDATERATETAKENDETAILS_ODCPAY_QUERY);
		 * logger.info(ActionConstants.EXITING_METHOD);
		 * 
		 * } }
		 */
		// FREEZING(SCENARIO) off shore team starts 31122019
		/*
		 * if (userVo.getProductCode().trim().equalsIgnoreCase("IDC")) { if
		 * (userVo.getEventCode().trim().equalsIgnoreCase("CLP")) {
		 * logger.info(ActionConstants.ENTERING_METHOD); DBHelper aDBHelper =
		 * new DBHelper();
		 * aDBHelper.setValueRateTakenLCInDB(userVo.getRateTaken(),
		 * userVo.getRate(), userVo.getToken(), userVo.getValueK(),
		 * userVo.getRequestId(),
		 * ActionConstants.GETUPDATERATETAKENDETAILS_IDCPAY_QUERY);
		 * logger.info(ActionConstants.EXITING_METHOD);
		 * 
		 * } }
		 */
		// FREEZING(SCENARIO) off shore team ends 31122019
		// Rate taken Fix Offshore Team 30122019 ends
		/*
		 * if (userVo.getProductCode().trim().equalsIgnoreCase("ODC")) { if
		 * (userVo.getEventCode().trim().equalsIgnoreCase("CRE")) {
		 * 
		 * logger.info(ActionConstants.ENTERING_METHOD); DBHelper aDBHelper =
		 * new DBHelper(); aDBHelper .setValueInDB( userVo.getRateTakenK(),
		 * userVo.getRate(), userVo.getShipBillFetch(), userVo.getRequestId(),
		 * ActionConstants.GETUPDATESCRUTINIZERDETAILS_ODCCRE_QUERY);
		 * logger.info(ActionConstants.EXITING_METHOD); }
		 */
		/*
		 * if (userVo.getEventCode().trim().equalsIgnoreCase("CLP")) {
		 * 
		 * logger.info(ActionConstants.ENTERING_METHOD); DBHelper aDBHelper =
		 * new DBHelper(); aDBHelper .setValueInDB( userVo.getRateTakenK(),
		 * userVo.getRate(), userVo.getSenderRefNo(), userVo.getRequestId(),
		 * ActionConstants.GETUPDATESCRUTINIZERDETAILS_ODCCLP_QUERY);
		 * logger.info(ActionConstants.EXITING_METHOD); } }
		 */
		/*
		 * if (userVo.getProductCode().trim().equalsIgnoreCase("FOC")) { if
		 * (userVo.getEventCode().trim().equalsIgnoreCase("RSA1")) {
		 * 
		 * logger.info(ActionConstants.ENTERING_METHOD); DBHelper aDBHelper =
		 * new DBHelper(); aDBHelper .setValueInDB( userVo.getRateTakenK(),
		 * userVo.getRate(), userVo.getShipBillFetch(), userVo.getRequestId(),
		 * ActionConstants.GETUPDATESCRUTINIZERDETAILS_FOCREPAY_QUERY);
		 * logger.info(ActionConstants.EXITING_METHOD); } }
		 */

		// STARTS : ADDED BY CHANDRU FOR FOC VERIFICATION METHOD

		if (userVo.getProductCode().equalsIgnoreCase("FOC")) {
			if (userVo.getEventCode().equalsIgnoreCase("CRYST")) {
				// System.out.println("userVo.getRateTaken1()--->" +
				// userVo.getRateTaken());

				// CHANGED BY CHANDRU
				rate = userVo.getRateTaken();

				if (rate.equals("false")) {
					rate = "N";
				} else {
					rate = "Y";
				}
				// ENDS
				DBHelper aDBHelper = new DBHelper();
				aDBHelper.setValueInDB(userVo.getToken(), rate,
						userVo.getRate(), userVo.getRateTakenK(),
						userVo.getRequestId(),
						ActionConstants.GETUPDATETFBOFOCRYSTPSCRU_QUERY);
			}

		}

		if (userVo.getProductCode().equalsIgnoreCase("FOC")) {
			if (userVo.getEventCode().equalsIgnoreCase("RSA1")) {
				// System.out.println("userVo.getRateTaken1()--->" +
				// userVo.getRateTaken());

				// CHANGED BY CHANDRU
				rate = userVo.getRateTaken();
				if (rate.equals("false")) {
					rate = "N";
				} else {
					rate = "Y";
				}
				// ENDS
				DBHelper aDBHelper = new DBHelper();
				aDBHelper.setValueInDB(userVo.getToken(), rate,
						userVo.getRate(), userVo.getRateTakenK(),
						userVo.getSenderRefNo(), userVo.getPreshipAccSetteld(),
						userVo.getRequestId(),
						ActionConstants.GETUPDATETFBOFOCREPSCRU_QUERY);
			}
		}

		if (userVo.getProductCode().equalsIgnoreCase("FOC")) {
			if (userVo.getEventCode().equalsIgnoreCase("CSA1")) {
				// System.out.println("userVo.getRateTaken1()--->" +
				// userVo.getRateTaken());

				// CHANGED BY CHANDRU
				rate = userVo.getRateTaken();
				if (rate.equals("false")) {
					rate = "N";
				} else {
					rate = "Y";
				}
				// ENDS
				DBHelper aDBHelper = new DBHelper();
				aDBHelper.setValueInDB(userVo.getToken(), rate,
						userVo.getRate(), userVo.getRateTakenK(),
						userVo.getRequestId(),
						ActionConstants.GETUPDATETFBOFOCCRESCRU_QUERY);
			}
		}

		// ENDS : ADDED BY CHANDRU FOR FOC VERIFICATION METHOD

		if (userVo.getProductCode().trim().equalsIgnoreCase("FSA")) {
			if (userVo.getEventCode().trim().equalsIgnoreCase("CSA")) {

				logger.info(ActionConstants.ENTERING_METHOD);
				DBHelper aDBHelper = new DBHelper();
				aDBHelper
						.setValueInDB(
								userVo.getRateTakenK(),
								userVo.getRate(),
								userVo.getRequestId(),
								ActionConstants.GETUPDATESCRUTINIZERDETAILS_FSACRE_QUERY);
				logger.info(ActionConstants.EXITING_METHOD);
			}
		}
		// Miscellanous changes starts 08-01-2020

		if (userVo.getProductCode().trim().equalsIgnoreCase("COR")) {
			if (userVo.getEventCode().trim().equalsIgnoreCase("CRCR")) {

				logger.info(ActionConstants.ENTERING_METHOD);
				logger.info("Rate Details updation in updateTFBOScrutinizerDetails method==>");

				DBHelper aDBHelper = new DBHelper();
				CommonMethods aCommonMethods = new CommonMethods();

				if (aCommonMethods.isValueAvailable(userVo.getRateTaken())
						&& userVo.getRateTaken().equalsIgnoreCase("false")) {
					userVo.setToken("");
					userVo.setRate("");
					userVo.setRateTakenK("");
					userVo.setRateTaken("No");
				}

				if (aCommonMethods.isValueAvailable(userVo.getRateTaken())
						&& userVo.getRateTaken().equalsIgnoreCase("true")) {
					userVo.setRateTaken("Yes");
				}

				aDBHelper.setValueRateTakenLCInDB(userVo.getRateTaken(),
						userVo.getRate(), userVo.getToken(),
						userVo.getRateTakenK(), userVo.getRequestId(),
						ActionConstants.GETUPDATERATETAKENDETAILS_MISCRE_QUERY);
				logger.info(ActionConstants.EXITING_METHOD);
			}
		}

		// Miscellanous changes ends 08-01-2020

	}

	// Added on 21-12-2019 after ODC release starts
	public Boolean isValidTransactionCreationRequest(UserTransactionVO userVo)
			throws Exception {
		List<AlertMessagesVO> errorDetailList = new LinkedList<AlertMessagesVO>();
		Boolean isValidTransactionRequest = true;
		if (userVo.getBranchMakerCheckList() != null) {
			errorDetailList = isChecklistFilled(userVo,
					userVo.getBranchMakerCheckList(), errorDetailList);
		}
		errorDetailList = isValidFieldValues(userVo, errorDetailList);

		// ADDED BY CHANDRU
		errorDetailList = isTransLocked(userVo, errorDetailList);
		//errorDetailList = checkTransInProgressTI(userVo, errorDetailList)--commented by Pandi;
		// ADDED BY CHANDRU

		userVo.setErrorDetailsList(errorDetailList);
		if (!(userVo.getErrorDetailsList().size() == 0)) {
			isValidTransactionRequest = false;
		}
		return isValidTransactionRequest;
	}

	public Boolean isValidUserTransaction(UserTransactionVO userVo)
			throws Exception {
		List<AlertMessagesVO> errorDetailList = new LinkedList<AlertMessagesVO>();
		Boolean isValidTransactionRequest = true;
		errorDetailList = isTransLocked(userVo, errorDetailList);
		userVo.setErrorDetailsList(errorDetailList);
		if (!(userVo.getErrorDetailsList().size() == 0)) {
			isValidTransactionRequest = false;
		}
		return isValidTransactionRequest;
	}

	public List<AlertMessagesVO> isValidScrutinizerFieldValues(
			UserTransactionVO userVo, List<AlertMessagesVO> errorDetailList) {
		CommonMethods aCommonMethods = new CommonMethods();
		logger.info("ProductCode in isValidFieldValues==>"
				+ userVo.getProductCode());
		logger.info("EventCode in isValidFieldValues==>"
				+ userVo.getEventCode());
		/* changes for rate taken starts 010120 */
		/*
		 * if (userVo.getProductCode().trim().equalsIgnoreCase("ODC")) { if
		 * (userVo.getEventCode().trim().equalsIgnoreCase("CRE")) {
		 * 
		 * // rate taken null checking 31122019 if
		 * (aCommonMethods.isValueAvailable(userVo.getRateTaken()) &&
		 * userVo.getRateTaken().equalsIgnoreCase("true")) {
		 * 
		 * if (!aCommonMethods.isValueAvailable(userVo.getRate())) {
		 * logger.info("Exchange rate is empty"); errorDetailList =
		 * aCommonMethods.setErrorInList( ActionConstants.ERRORCODE028,
		 * errorDetailList); } if (!aCommonMethods
		 * .isValueAvailable(userVo.getRateTakenK())) {
		 * logger.info("DocketNo/k+ is empty"); errorDetailList =
		 * aCommonMethods.setErrorInList( ActionConstants.ERRORCODE029,
		 * errorDetailList); } } } if
		 * (userVo.getEventCode().trim().equalsIgnoreCase("CLP")) {
		 * 
		 * // rate taken null checking 31122019
		 * 
		 * if (aCommonMethods.isValueAvailable(userVo.getRateTaken())) {
		 * 
		 * if (userVo.getRateTaken().equalsIgnoreCase("true")) {
		 * 
		 * if (!aCommonMethods.isValueAvailable(userVo.getRate())) {
		 * logger.info("Exchange rate is empty");
		 * 
		 * errorDetailList = aCommonMethods.setErrorInList(
		 * ActionConstants.ERRORCODE028, errorDetailList); }
		 * 
		 * if (!aCommonMethods.isValueAvailable(userVo .getRateTakenK())) {
		 * logger.info("DocketNo/k+ is empty");
		 * 
		 * 
		 * 
		 * }
		 * 
		 * } } }
		 */
		/* changes for rate taken ends 010120 */
		// Inward Remittance changes 23-12-2019 starts
		if (userVo.getProductCode().trim().equalsIgnoreCase("ODC")) {

			System.out.println("userVo.getRateTaken() >>-->"
					+ userVo.getRateTaken());
			System.out.println("userVo.getFinanceSameDay() >>-->"
					+ userVo.getFinanceSameDay());
			System.out.println("userVo.getDirect() >>-->" + userVo.getDirect());

			if (userVo.getEventCode().trim().equalsIgnoreCase("CRE")) {
				if (aCommonMethods.isValueAvailable(userVo.getDirect())
						&& userVo.getDirect().equalsIgnoreCase("true")) {
					if (aCommonMethods.isValueAvailable(userVo.getMtReceived())
							&& (userVo.getMtReceived()
									.equalsIgnoreCase("Full Amount"))) {
						if (aCommonMethods.isValueAvailable(userVo
								.getRateTaken())) {
							if (userVo.getRateTaken().equals("false")
									|| !(aCommonMethods.isValueAvailable(userVo
											.getRate()))
									// ||
									// !(aCommonMethods.isValueAvailable(userVo
									// .getToken()))
									|| !(aCommonMethods.isValueAvailable(userVo
											.getRateTakenK()))) {
								errorDetailList = aCommonMethods
										.setErrorInList(
												ActionConstants.ERRORCODE1429,
												errorDetailList);
							}
						}
					}
				}

				if (aCommonMethods.isValueAvailable(userVo.getDirect())
						&& userVo.getDirect().equalsIgnoreCase("false")) {
					if (aCommonMethods.isValueAvailable(userVo
							.getFinanceSameDay())
							&& userVo.getFinanceSameDay().equalsIgnoreCase(
									"yes")) {
						if (aCommonMethods.isValueAvailable(userVo
								.getRateTaken())) {
							if (userVo.getRateTaken().equals("false")
									|| !(aCommonMethods.isValueAvailable(userVo
											.getRate()))
									// ||
									// !(aCommonMethods.isValueAvailable(userVo
									// .getToken()))
									|| !(aCommonMethods.isValueAvailable(userVo
											.getRateTakenK()))) {
								errorDetailList = aCommonMethods
										.setErrorInList(
												ActionConstants.ERRORCODE1429,
												errorDetailList);
							}
						}
					}

				}

			}

		}
		// Miscellanous changes starts 08-01-2020
		if (userVo.getProductCode().trim().equalsIgnoreCase("COR")) {

			if (userVo.getEventCode().trim().equalsIgnoreCase("CRCR")) {

				logger.info("Madatory checking for rate taken details in isValidScrutinizerFieldValues method==>");

				if (!aCommonMethods.isValueAvailable(userVo.getRateTaken())
						|| userVo.getRateTaken().equalsIgnoreCase("false")) {
					logger.info("Rate Taken is not selected");
					errorDetailList = aCommonMethods.setErrorInList(
							ActionConstants.ERRORCODE022, errorDetailList);
				}
				
				if (aCommonMethods.isValueAvailable(userVo.getRateTaken())) {

					if (userVo.getRateTaken().equalsIgnoreCase("true")
							&& !aCommonMethods.isValueAvailable(userVo
									.getRate())) {

						logger.info("Exchange rate is empty");
						errorDetailList = aCommonMethods.setErrorInList(
								ActionConstants.ERRORCODE028, errorDetailList);
					}
					if (userVo.getRateTaken().equalsIgnoreCase("true")
							&& !aCommonMethods.isValueAvailable(userVo
									.getRateTakenK())) {
						logger.info("DocketNo/k+ is empty");
						errorDetailList = aCommonMethods.setErrorInList(
								ActionConstants.ERRORCODE029, errorDetailList);
					}

					/*
					 * if (userVo.getRateTaken().equalsIgnoreCase("true") &&
					 * !aCommonMethods.isValueAvailable(userVo .getToken())) {
					 * logger.info("Token is empty"); errorDetailList =
					 * aCommonMethods.setErrorInList(
					 * ActionConstants.ERRORCODETOKENMANDATORY,
					 * errorDetailList); }
					 */

				}
			}
		}

		// Miscellanous changes ends 08-01-2020

		if (userVo.getProductCode().trim().equalsIgnoreCase("IDC")) {
			if (userVo.getEventCode().trim().equalsIgnoreCase("CRE")) {
				
				if (!aCommonMethods.isValueAvailable(userVo.getRateTaken())
						|| userVo.getRateTaken().equalsIgnoreCase("false")) {
					logger.info("Rate Taken is not selected");
					errorDetailList = aCommonMethods.setErrorInList(
							ActionConstants.ERRORCODE022, errorDetailList);
				}
				if (aCommonMethods.isValueAvailable(userVo.getRateTaken())) {

					if (userVo.getRateTaken().equalsIgnoreCase("true")) {
						// FREEZING(SCENARIO) off shore team starts 31122019
						/*
						 * if
						 * (!aCommonMethods.isValueAvailable(userVo.getToken()))
						 * { logger.info("Token is empty"); errorDetailList =
						 * aCommonMethods.setErrorInList(
						 * ActionConstants.ERRORCODETOKENMANDATORY,
						 * errorDetailList); }
						 */
						if (!aCommonMethods.isValueAvailable(userVo.getRate())) {
							logger.info("Exchange rate is empty");
							errorDetailList = aCommonMethods.setErrorInList(
									ActionConstants.ERRORCODE028,
									errorDetailList);
						}
						if (!aCommonMethods
								.isValueAvailable(userVo.getValueK())) {
							logger.info("DocketNo/k+ is empty");

							errorDetailList = aCommonMethods.setErrorInList(
									ActionConstants.ERRORCODE029,
									errorDetailList);
						}
						// FREEZING(SCENARIO) off shore team ends 31122019
					}
				}

				// FREEZING(SCENARIO) off shore team starts 31122019

				if (aCommonMethods.isValueAvailable(userVo.getDirect())
						&& userVo.getDirect().equalsIgnoreCase("true")) {
					if (!aCommonMethods.isValueAvailable(userVo.getRateTaken())
							|| userVo.getRateTaken().equalsIgnoreCase("false")) {
						logger.info("Rate Taken is not selected");
						errorDetailList = aCommonMethods.setErrorInList(
								ActionConstants.ERRORCODE022, errorDetailList);
					}
				}
				// FREEZING(SCENARIO) off shore team ends 31122019
			}
		}
		// Issue Fix Offshore Team 31122019 starts
		if (userVo.getProductCode().trim().equalsIgnoreCase("CPCI")) {
			if (userVo.getEventCode().trim().equalsIgnoreCase("PCIC")) {
				if (aCommonMethods.isValueAvailable(userVo.getRateTaken())
						&& userVo.getRateTaken().equals("false")) {
					logger.info(" rate  Taken is empty or false");
					errorDetailList = aCommonMethods.setErrorInList(
							ActionConstants.ERRORCODE043, errorDetailList);
				}
				// rate taken null checking 31122019
				if (aCommonMethods.isValueAvailable(userVo.getRateTaken())
						&& userVo.getRateTaken().equals("true")) {

					if (!aCommonMethods.isValueAvailable(userVo.getRate())) {

						logger.info("Exchange rate is empty");
						errorDetailList = aCommonMethods.setErrorInList(
								ActionConstants.ERRORCODE028, errorDetailList);
					}
					if (!aCommonMethods
							.isValueAvailable(userVo.getRateTakenK())) {
						logger.info("DocketNo/k+ is empty");
						errorDetailList = aCommonMethods.setErrorInList(
								ActionConstants.ERRORCODE029, errorDetailList);
					}
					/*
					 * if (!aCommonMethods.isValueAvailable(userVo.getToken()))
					 * { logger.info("token is empty"); errorDetailList =
					 * aCommonMethods.setErrorInList(
					 * ActionConstants.ERRORCODE042, errorDetailList); }
					 */

				}
			}
		}

		// Inward Remittance changes 23-12-2019 ends

		// Outward Remittance Changes 23/12/2019 start
		// Issue Fix Offshore Team 31122019 starts
		if (userVo.getProductCode().trim().equalsIgnoreCase("CPCO")) {
			if (userVo.getEventCode().trim().equalsIgnoreCase("PCOC")) {

				if (!aCommonMethods.isValueAvailable(userVo.getRateTaken())
						|| userVo.getRateTaken().equalsIgnoreCase("false")) {
					logger.info("Rate Taken is not selected");
					errorDetailList = aCommonMethods.setErrorInList(
							ActionConstants.ERRORCODE022, errorDetailList);
				}
				// rate taken null checking 31122019
				if (aCommonMethods.isValueAvailable(userVo.getRateTaken())) {

					if (userVo.getRateTaken().equalsIgnoreCase("true")
							&& !aCommonMethods.isValueAvailable(userVo
									.getRate())) {
						logger.info("Exchange rate is empty");
						errorDetailList = aCommonMethods.setErrorInList(
								ActionConstants.ERRORCODE028, errorDetailList);
					}
					if (userVo.getRateTaken().equalsIgnoreCase("true")
							&& !aCommonMethods.isValueAvailable(userVo
									.getValueK())) {
						logger.info("DocketNo/k+ is empty");
						errorDetailList = aCommonMethods.setErrorInList(
								ActionConstants.ERRORCODE029, errorDetailList);
					}
				}

			}
		}

		// Outward Remittance Changes 23/12/2019 end
		/* changes for rate taken starts 010120 */
		// if (userVo.getProductCode().trim().equalsIgnoreCase("IDC")) {
		/*
		 * if (userVo.getEventCode().trim().equalsIgnoreCase("CRE")) { // rate
		 * taken null checking 31122019 if
		 * (aCommonMethods.isValueAvailable(userVo.getRateTaken())) {
		 * 
		 * if (userVo.getRateTaken().equalsIgnoreCase("true")) { if
		 * (!aCommonMethods.isValueAvailable(userVo.getRate())) {
		 * logger.info("Exchange rate is empty"); errorDetailList =
		 * aCommonMethods.setErrorInList( ActionConstants.ERRORCODE028,
		 * errorDetailList); } if (!aCommonMethods
		 * .isValueAvailable(userVo.getValueK())) {
		 * logger.info("DocketNo/k+ is empty");
		 * 
		 * errorDetailList = aCommonMethods.setErrorInList(
		 * ActionConstants.ERRORCODE029, errorDetailList); } } } }
		 */
		/*
		 * if (userVo.getEventCode().trim().equalsIgnoreCase("CLP")) {
		 * 
		 * // rate taken null checking 31122019 if
		 * (aCommonMethods.isValueAvailable(userVo.getRateTaken())) {
		 * 
		 * if (userVo.getRateTaken().equalsIgnoreCase("true")) { if
		 * (!aCommonMethods.isValueAvailable(userVo.getRate())) {
		 * logger.info("Exchange rate is empty"); errorDetailList =
		 * aCommonMethods.setErrorInList( ActionConstants.ERRORCODE028,
		 * errorDetailList); } if (!aCommonMethods
		 * .isValueAvailable(userVo.getValueK())) {
		 * logger.info("DocketNo/k+ is empty");
		 * 
		 * errorDetailList = aCommonMethods.setErrorInList(
		 * ActionConstants.ERRORCODE029, errorDetailList); } if
		 * (userVo.getProductCode().trim() .equalsIgnoreCase("FOC")) { if
		 * (userVo.getEventCode().trim() .equalsIgnoreCase("RSA1")) { if
		 * (!aCommonMethods.isValueAvailable(userVo .getRate())) {
		 * logger.info("Exchange rate is empty"); errorDetailList =
		 * aCommonMethods .setErrorInList( ActionConstants.ERRORCODE028,
		 * errorDetailList); } if (!aCommonMethods.isValueAvailable(userVo
		 * .getRateTakenK())) { logger.info("DocketNo/k+ is empty");
		 * 
		 * errorDetailList = aCommonMethods .setErrorInList(
		 * ActionConstants.ERRORCODE029, errorDetailList); } } if
		 * (userVo.getEventCode().trim() .equalsIgnoreCase("CRYST")) { if
		 * (!aCommonMethods.isValueAvailable(userVo .getRate())) {
		 * logger.info("Exchange rate is empty"); errorDetailList =
		 * aCommonMethods .setErrorInList( ActionConstants.ERRORCODE028,
		 * errorDetailList); } if (!aCommonMethods.isValueAvailable(userVo
		 * .getRateTakenK())) { logger.info("DocketNo/k+ is empty");
		 * 
		 * errorDetailList = aCommonMethods .setErrorInList(
		 * ActionConstants.ERRORCODE029, errorDetailList); } } } } }
		 * 
		 * }
		 */
		// }
		/* changes for rate taken starts 010120 */
		if (userVo.getProductCode().trim().equalsIgnoreCase("FOC")) {
			if (userVo.getEventCode().trim().equalsIgnoreCase("RSA1")) {

				if (!aCommonMethods.isValueAvailable(userVo.getRateTaken())
						|| userVo.getRateTaken().equalsIgnoreCase("false")) {
					logger.info("Rate Taken is not selected");
					errorDetailList = aCommonMethods.setErrorInList(
							ActionConstants.ERRORCODE022, errorDetailList);
				}
				
				if (aCommonMethods.isValueAvailable(userVo.getRateTaken())) {

					if (userVo.getRateTaken().equalsIgnoreCase("true")) {
						if (!aCommonMethods.isValueAvailable(userVo.getRate())) {
							logger.info("Exchange rate is empty");
							errorDetailList = aCommonMethods.setErrorInList(
									ActionConstants.ERRORCODE028,
									errorDetailList);
						}
						if (!aCommonMethods.isValueAvailable(userVo
								.getRateTakenK())) {
							logger.info("DocketNo/k+ is empty");

							errorDetailList = aCommonMethods.setErrorInList(
									ActionConstants.ERRORCODE029,
									errorDetailList);
						}

					}
				}

			}

			if (userVo.getEventCode().trim().equalsIgnoreCase("CRYST")) {
				
				if (!aCommonMethods.isValueAvailable(userVo.getRateTaken())
						|| userVo.getRateTaken().equalsIgnoreCase("false")) {
					logger.info("Rate Taken is not selected");
					errorDetailList = aCommonMethods.setErrorInList(
							ActionConstants.ERRORCODE022, errorDetailList);
				}
				if (!aCommonMethods.isValueAvailable(userVo.getRate())) {
					logger.info("Exchange rate is empty");
					errorDetailList = aCommonMethods.setErrorInList(
							ActionConstants.ERRORCODE028, errorDetailList);
				}
				if (!aCommonMethods.isValueAvailable(userVo.getRateTakenK())) {
					logger.info("DocketNo/k+ is empty");

					errorDetailList = aCommonMethods.setErrorInList(
							ActionConstants.ERRORCODE029, errorDetailList);
				}
			}
		}
		// FOC validation placed here ends 31122019
		if (userVo.getProductCode().trim().equalsIgnoreCase("FEL")) {
			if (userVo.getEventCode().trim().equalsIgnoreCase("CSA4")) {

				if (!aCommonMethods.isValueAvailable(userVo.getRateTaken())
						|| userVo.getRateTaken().equalsIgnoreCase("false")) {
					logger.info("Rate Taken is not selected");
					errorDetailList = aCommonMethods.setErrorInList(
							ActionConstants.ERRORCODE022, errorDetailList);
				}
				// rate taken null checking 31122019
				if (aCommonMethods.isValueAvailable(userVo.getRateTaken())) {

					if (userVo.getRateTaken().equalsIgnoreCase("true")) {
						if (!aCommonMethods.isValueAvailable(userVo.getRate())) {
							logger.info("Exchange rate is empty");
							errorDetailList = aCommonMethods.setErrorInList(
									ActionConstants.ERRORCODE028,
									errorDetailList);
						}
						if (!aCommonMethods.isValueAvailable(userVo
								.getRateTakenK())) {
							logger.info("DocketNo/k+ is empty");

							errorDetailList = aCommonMethods.setErrorInList(
									ActionConstants.ERRORCODE029,
									errorDetailList);
						}
					}

				}

			}
			if (userVo.getEventCode().trim().equalsIgnoreCase("CRYST")) {

				if (!aCommonMethods.isValueAvailable(userVo.getRateTaken())
						|| userVo.getRateTaken().equalsIgnoreCase("false")) {
					logger.info("Rate Taken is not selected");
					errorDetailList = aCommonMethods.setErrorInList(
							ActionConstants.ERRORCODE022, errorDetailList);
				}
				// rate taken null checking 31122019
				if (aCommonMethods.isValueAvailable(userVo.getRateTaken())) {

					if (userVo.getRateTaken().equalsIgnoreCase("true")) {
						if (!aCommonMethods.isValueAvailable(userVo.getRate())) {
							logger.info("Exchange rate is empty");
							errorDetailList = aCommonMethods.setErrorInList(
									ActionConstants.ERRORCODE028,
									errorDetailList);
						}
						if (!aCommonMethods.isValueAvailable(userVo
								.getRateTakenK())) {
							logger.info("DocketNo/k+ is empty");

							errorDetailList = aCommonMethods.setErrorInList(
									ActionConstants.ERRORCODE029,
									errorDetailList);
						}
					}

				}

			}
			if (userVo.getEventCode().trim().equalsIgnoreCase("RSA4")) {

				if (!aCommonMethods.isValueAvailable(userVo.getRateTaken())
						|| userVo.getRateTaken().equalsIgnoreCase("false")) {
					logger.info("Rate Taken is not selected");
					errorDetailList = aCommonMethods.setErrorInList(
							ActionConstants.ERRORCODE022, errorDetailList);
				}
				// rate taken null checking 31122019
				if (aCommonMethods.isValueAvailable(userVo.getRateTaken())) {

					if (userVo.getRateTaken().equalsIgnoreCase("true")) {
						if (!aCommonMethods.isValueAvailable(userVo.getRate())) {
							logger.info("Exchange rate is empty");
							errorDetailList = aCommonMethods.setErrorInList(
									ActionConstants.ERRORCODE028,
									errorDetailList);
						}
						if (!aCommonMethods.isValueAvailable(userVo
								.getRateTakenK())) {
							logger.info("DocketNo/k+ is empty");

							errorDetailList = aCommonMethods.setErrorInList(
									ActionConstants.ERRORCODE029,
									errorDetailList);
						}
					}

				}
			}
		}

		// Changes done by offshore team starts
		/*
		 * if (userVo.getProductCode().trim().equalsIgnoreCase("FSA")) { if
		 * (userVo.getEventCode().trim().equalsIgnoreCase("CSA")) { if
		 * (!aCommonMethods.isValueAvailable(userVo.getRate())) {
		 * logger.info("Exchange rate is empty"); errorDetailList =
		 * aCommonMethods.setErrorInList( ActionConstants.ERRORCODE028,
		 * errorDetailList); } if
		 * (!aCommonMethods.isValueAvailable(userVo.getRateTakenK())) {
		 * logger.info("DocketNo/k+ is empty");
		 * 
		 * errorDetailList = aCommonMethods.setErrorInList(
		 * ActionConstants.ERRORCODE029, errorDetailList); } } }
		 */
		// Changes done by offshore team ends
		return errorDetailList;
	}

	public List<AlertMessagesVO> isValidFieldValues(UserTransactionVO userVo,
			List<AlertMessagesVO> errorDetailList) {
		CommonMethods aCommonMethods = new CommonMethods();
		logger.info("ProductCode in isValidFieldValues==>"
				+ userVo.getProductCode());
		logger.info("EventCode in isValidFieldValues==>"
				+ userVo.getEventCode());
		if (userVo.getProductCode().trim().equalsIgnoreCase("ILC")) {
			if (userVo.getEventCode().trim().equalsIgnoreCase("ISI")) {
				if (!aCommonMethods.isValueAvailable(userVo.getCustomeCif())) {
					logger.info("CustomeCif is empty");
					errorDetailList = aCommonMethods.setErrorInList(
							ActionConstants.ERRORCODE003, errorDetailList);
				}
				if (!aCommonMethods.isValueAvailable(userVo.getAmount())) {
					logger.info("Amount is empty");
					errorDetailList = aCommonMethods.setErrorInList(
							ActionConstants.ERRORCODE004, errorDetailList);
				}
				if (!aCommonMethods.isValueAvailable(userVo.getCurrency())) {
					logger.info("Currency is empty");
					errorDetailList = aCommonMethods.setErrorInList(
							ActionConstants.ERRORCODE005, errorDetailList);
				}
				if (!aCommonMethods
						.isValueAvailable(userVo.getSubProductCode())) {
					logger.info("Sub-Product is empty");
					errorDetailList = aCommonMethods.setErrorInList(
							ActionConstants.ERRORCODE024, errorDetailList);
				}
				if (!aCommonMethods.isValueAvailable(userVo.getSolID())) {
					logger.info("SolID is empty");
					errorDetailList = aCommonMethods.setErrorInList(
							ActionConstants.ERRORCODE006, errorDetailList);
				}
				if (!aCommonMethods.isValueAvailable(userVo.getLcType())) {
					logger.info("LC Type is empty");
					errorDetailList = aCommonMethods.setErrorInList(
							ActionConstants.ERRORCODE012, errorDetailList);
				} else {
					if (userVo.getLcType().trim().equalsIgnoreCase("Usance")) {
						if (!aCommonMethods.isValueAvailable(userVo
								.getUsancePeriod())) {
							logger.info("Usance Period is empty");
							errorDetailList = aCommonMethods.setErrorInList(
									ActionConstants.ERRORCODE013,
									errorDetailList);
						}
					}
				}
			}
			if (userVo.getEventCode().trim().equalsIgnoreCase("NAMI")) {
				if (!aCommonMethods.isValueAvailable(userVo.getTiReferanceNo())) {
					logger.info("TiReferanceNo is empty");
					errorDetailList = aCommonMethods.setErrorInList(
							ActionConstants.ERRORCODE009, errorDetailList);
				}
			}
			// Bill reference Changes 10012020 starts
			if (userVo.getEventCode().trim().equalsIgnoreCase("POCA")
					|| userVo.getEventCode().trim().equalsIgnoreCase("POCP")
					|| userVo.getEventCode().trim().equalsIgnoreCase("POCD")) {
				
				if (!aCommonMethods.isValueAvailable(userVo
						.getBillReference())) {
					logger.info("Bill Reference is empty");
					errorDetailList = aCommonMethods.setErrorInList(
							ActionConstants.ERRORCODE037, errorDetailList);
				}
				if (!aCommonMethods.isValueAvailable(userVo.getClaimAmount())) {
					logger.info("Finance Amount is empty");
					errorDetailList = aCommonMethods.setErrorInList(
							ActionConstants.ERRORCODE033, errorDetailList);
				}
				
				userVo.setBillReferenceList(getBillReference(userVo,
						userVo.getTiReferanceNo()));
			}
			// Bill reference Changes 10012020 ends
		}

		// Miscellanous changes starts 08-01-2020
		if (userVo.getProductCode().trim().equalsIgnoreCase("COR")) {
			if (userVo.getEventCode().trim().equalsIgnoreCase("CRCR")) {

				logger.info("Validations in isValidFieldValues method==> ");

				if (!aCommonMethods.isValueAvailable(userVo.getCustomeCif())) {
					logger.info("CustomeCif is empty");
					errorDetailList = aCommonMethods.setErrorInList(
							ActionConstants.ERRORCODE003, errorDetailList);
				}
				if (!aCommonMethods.isValueAvailable(userVo.getAmount())) {
					logger.info("Amount is empty");
					errorDetailList = aCommonMethods.setErrorInList(
							ActionConstants.ERRORCODE004, errorDetailList);
				}
				if (!aCommonMethods.isValueAvailable(userVo.getCurrency())) {
					logger.info("Currency is empty");
					errorDetailList = aCommonMethods.setErrorInList(
							ActionConstants.ERRORCODE005, errorDetailList);
				}
				if (!aCommonMethods.isValueAvailable(userVo.getSolID())) {
					logger.info("SolID is empty");
					errorDetailList = aCommonMethods.setErrorInList(
							ActionConstants.ERRORCODE006, errorDetailList);
				}

				if (!aCommonMethods
						.isValueAvailable(userVo.getSubProductCode())) {
					logger.info("Sub Product type is empty");
					errorDetailList = aCommonMethods.setErrorInList(
							ActionConstants.ERRORCODEMIS003, errorDetailList);
				}

				if (aCommonMethods.isValueAvailable(userVo.getRateTaken())) {

					if (userVo.getRateTaken().equalsIgnoreCase("true")
							&& !aCommonMethods.isValueAvailable(userVo
									.getRate())) {
						logger.info("Rate is empty");
						errorDetailList = aCommonMethods.setErrorInList(
								ActionConstants.ERRORCODE025, errorDetailList);
					}
				}

				if (aCommonMethods.isValueAvailable(userVo.getSubProductCode())) {

					if (userVo.getSubProductCode().equalsIgnoreCase("ODI")
							&& !aCommonMethods.isValueAvailable(userVo
									.getOdiSubProductType())) {
						logger.info("ODI Sub product type is empty");
						errorDetailList = aCommonMethods.setErrorInList(
								ActionConstants.ERRORCODEMIS001,
								errorDetailList);
					}

					if (userVo.getSubProductCode().equalsIgnoreCase("OTH")
							&& !aCommonMethods.isValueAvailable(userVo
									.getMasReferanceNo())) {
						logger.info("TI Reference number is empty");
						errorDetailList = aCommonMethods.setErrorInList(
								ActionConstants.ERRORCODE009, errorDetailList);
					}

					if (userVo.getSubProductCode().equalsIgnoreCase("OTH")
							&& !aCommonMethods.isValueAvailable(userVo
									.getRemarks())) {
						logger.info("Remarks is empty");
						errorDetailList = aCommonMethods.setErrorInList(
								ActionConstants.ERRORCODEMIS002,
								errorDetailList);
					}

				}

			}
		}
		// Miscellanous changes ends 08-01-2020

		// Inward Remittance changes 23-12-2019 starts
		if (userVo.getProductCode().trim().equalsIgnoreCase("CPCI")) {
			if (userVo.getEventCode().trim().equalsIgnoreCase("PCIC")) {
				if (!aCommonMethods.isValueAvailable(userVo.getCustomeCif())) {
					logger.info("CustomeCif is empty");
					errorDetailList = aCommonMethods.setErrorInList(
							ActionConstants.ERRORCODE003, errorDetailList);
				}
				if (!aCommonMethods.isValueAvailable(userVo.getAmount())) {
					logger.info("Amount is empty");
					errorDetailList = aCommonMethods.setErrorInList(
							ActionConstants.ERRORCODE004, errorDetailList);
				}
				if (!aCommonMethods.isValueAvailable(userVo.getCurrency())) {
					logger.info("Currency is empty");
					errorDetailList = aCommonMethods.setErrorInList(
							ActionConstants.ERRORCODE005, errorDetailList);
				}
				if (!aCommonMethods.isValueAvailable(userVo.getSolID())) {
					logger.info("SolID is empty");
					errorDetailList = aCommonMethods.setErrorInList(
							ActionConstants.ERRORCODE006, errorDetailList);
				}

				if (!aCommonMethods
						.isValueAvailable(userVo.getSubProductCode())) {
					logger.info("Product type is empty");
					errorDetailList = aCommonMethods.setErrorInList(
							ActionConstants.ERRORCODE017, errorDetailList);
				}

				// rate taken null checking 31122019
				if (aCommonMethods.isValueAvailable(userVo.getRateTaken())) {

					if (userVo.getRateTaken().equalsIgnoreCase("true")
							&& !aCommonMethods.isValueAvailable(userVo
									.getRate())) {
						logger.info("Rate is empty");
						errorDetailList = aCommonMethods.setErrorInList(
								ActionConstants.ERRORCODE025, errorDetailList);
					}
				}

			}
		}
		// Inward Remittance changes 23-12-2019 ends

		// Outward Remittance Changes 23/12/2019 start
		if (userVo.getProductCode().trim().equalsIgnoreCase("CPCO")) {
			if (userVo.getEventCode().trim().equalsIgnoreCase("PCOC")) {
				if (!aCommonMethods.isValueAvailable(userVo.getCustomeCif())) {
					logger.info("CustomeCif is empty");
					errorDetailList = aCommonMethods.setErrorInList(
							ActionConstants.ERRORCODE003, errorDetailList);
				}

				if (!aCommonMethods.isValueAvailable(userVo.getAmount())) {
					logger.info("Amount is empty");
					errorDetailList = aCommonMethods.setErrorInList(
							ActionConstants.ERRORCODE004, errorDetailList);
				}
				if (!aCommonMethods.isValueAvailable(userVo.getCurrency())) {
					logger.info("Currency is empty");
					errorDetailList = aCommonMethods.setErrorInList(
							ActionConstants.ERRORCODE005, errorDetailList);
				}
				if (!aCommonMethods.isValueAvailable(userVo.getSolID())) {
					logger.info("SolID is empty");
					errorDetailList = aCommonMethods.setErrorInList(
							ActionConstants.ERRORCODE006, errorDetailList);
				}
				if (!aCommonMethods
						.isValueAvailable(userVo.getSubProductCode())) {
					logger.info("Product type is empty");
					errorDetailList = aCommonMethods.setErrorInList(
							ActionConstants.ERRORCODE017, errorDetailList);
				}

				// rate taken null checking 31122019
				if (aCommonMethods.isValueAvailable(userVo.getRateTaken())) {

					if (userVo.getRateTaken().equalsIgnoreCase("true")
							&& !aCommonMethods.isValueAvailable(userVo
									.getRate())) {
						logger.info("Rate is empty");
						errorDetailList = aCommonMethods.setErrorInList(
								ActionConstants.ERRORCODE025, errorDetailList);
					}

				}

			}

		}
		// Outward Remittance Changes 23/12/2019 end

		if (userVo.getProductCode().trim().equalsIgnoreCase("ODC")) {
			if (userVo.getEventCode().trim().equalsIgnoreCase("CRE")) {
				if (!aCommonMethods.isValueAvailable(userVo.getCustomeCif())) {
					logger.info("CustomeCif is empty");
					errorDetailList = aCommonMethods.setErrorInList(
							ActionConstants.ERRORCODE003, errorDetailList);
				}
				if (!aCommonMethods.isValueAvailable(userVo.getAmount())) {
					logger.info("Amount is empty");
					errorDetailList = aCommonMethods.setErrorInList(
							ActionConstants.ERRORCODE004, errorDetailList);
				}
				if (!aCommonMethods.isValueAvailable(userVo.getCurrency())) {
					logger.info("Currency is empty");
					errorDetailList = aCommonMethods.setErrorInList(
							ActionConstants.ERRORCODE005, errorDetailList);
				}
				if (!aCommonMethods.isValueAvailable(userVo.getSolID())) {
					logger.info("SolID is empty");
					errorDetailList = aCommonMethods.setErrorInList(
							ActionConstants.ERRORCODE006, errorDetailList);
				}
				/*
				 * if (userVo.getDirect().equalsIgnoreCase("true")) { if
				 * (!aCommonMethods .isValueAvailable(userVo.getMtReceived())) {
				 * logger.info("MT Received is empty"); errorDetailList =
				 * aCommonMethods.setErrorInList( ActionConstants.ERRORCODE015,
				 * errorDetailList); } } else { if
				 * (!aCommonMethods.isValueAvailable(userVo
				 * .getDocumentDispatch())) {
				 * logger.info("Document Dispatch is empty"); errorDetailList =
				 * aCommonMethods.setErrorInList( ActionConstants.ERRORCODE020,
				 * errorDetailList); } }
				 */
				if (!aCommonMethods
						.isValueAvailable(userVo.getSubProductCode())) {
					logger.info("Product type is empty");
					errorDetailList = aCommonMethods.setErrorInList(
							ActionConstants.ERRORCODE017, errorDetailList);
				}
				if ((userVo.getSubProductCode().equalsIgnoreCase("FBU"))
						|| (userVo.getSubProductCode().equalsIgnoreCase("OBU"))) {
					if (!aCommonMethods.isValueAvailable(userVo
							.getUsancePeriod())) {
						logger.info("Usance Period is empty");
						errorDetailList = aCommonMethods.setErrorInList(
								ActionConstants.ERRORCODE018, errorDetailList);
					}
				}
				/*
				 * if (!aCommonMethods
				 * .isValueAvailable(userVo.getFinanceSameDay())) {
				 * logger.info("Finance same day is empty"); errorDetailList =
				 * aCommonMethods.setErrorInList( ActionConstants.ERRORCODE021,
				 * errorDetailList); }
				 */
				// Rate taken Fix Offshore Team 30122019 starts
				/*
				 * if (userVo.getRateTaken().equalsIgnoreCase("true") &&
				 * !aCommonMethods.isValueAvailable(userVo.getRate())) {
				 * logger.info("Rate is empty"); errorDetailList =
				 * aCommonMethods.setErrorInList( ActionConstants.ERRORCODE025,
				 * errorDetailList); }
				 */
				// Rate taken Fix Offshore Team 30122019 ends
			}
			if (userVo.getEventCode().trim().equalsIgnoreCase("CLP")) {

				if (!aCommonMethods.isValueAvailable(userVo.getAmount())) {
					logger.info("Amount is empty");
					errorDetailList = aCommonMethods.setErrorInList(
							ActionConstants.ERRORCODE004, errorDetailList);
				}

				// rate taken null checking 31122019
				/*
				 * if (aCommonMethods.isValueAvailable(userVo.getRateTaken())) {
				 * 
				 * if (userVo.getRateTaken().equalsIgnoreCase("true") &&
				 * !aCommonMethods.isValueAvailable(userVo .getRate())) {
				 * logger.info("Rate is empty"); errorDetailList =
				 * aCommonMethods.setErrorInList( ActionConstants.ERRORCODE025,
				 * errorDetailList); }
				 * 
				 * }
				 */
			}
		}
		if (userVo.getProductCode().equalsIgnoreCase("ELC")) {
			if (userVo.getEventCode().equalsIgnoreCase("ADE")) {
				if (!aCommonMethods.isValueAvailable(userVo.getCustomeCif())) {
					logger.info("CustomeCif is empty");
					errorDetailList = aCommonMethods.setErrorInList(
							ActionConstants.ERRORCODE003, errorDetailList);
				}
				if (!aCommonMethods.isValueAvailable(userVo.getAmount())) {
					logger.info("Amount is empty");
					errorDetailList = aCommonMethods.setErrorInList(
							ActionConstants.ERRORCODE004, errorDetailList);
				}
				if (!aCommonMethods.isValueAvailable(userVo.getCurrency())) {
					logger.info("Currency is empty");
					errorDetailList = aCommonMethods.setErrorInList(
							ActionConstants.ERRORCODE005, errorDetailList);
				}
				if (!aCommonMethods.isValueAvailable(userVo.getSenderRefno())) {
					logger.info("SenderRefno is empty");
					errorDetailList = aCommonMethods.setErrorInList(
							ActionConstants.ERRORCODE026, errorDetailList);
				}
				if (!aCommonMethods.isValueAvailable(userVo
						.getLcReceivedSWIFT())) {
					logger.info("LCreceivedSWIFT is empty");
					errorDetailList = aCommonMethods.setErrorInList(
							ActionConstants.ERRORCODE027, errorDetailList);
				}
				if (!aCommonMethods
						.isValueAvailable(userVo.getSubProductCode())) {
					logger.info("Sub-Product is empty");
					errorDetailList = aCommonMethods.setErrorInList(
							ActionConstants.ERRORCODE024, errorDetailList);
				}
				if (!aCommonMethods.isValueAvailable(userVo.getSolID())) {
					logger.info("SolID is empty");
					errorDetailList = aCommonMethods.setErrorInList(
							ActionConstants.ERRORCODE006, errorDetailList);
				}
				if (!aCommonMethods.isValueAvailable(userVo.getLcType())) {
					logger.info("LC Type is empty");
					errorDetailList = aCommonMethods.setErrorInList(
							ActionConstants.ERRORCODE012, errorDetailList);
				} else {
					if (userVo.getLcType().trim().equalsIgnoreCase("Usance")) {
						if (!aCommonMethods.isValueAvailable(userVo
								.getUsancePeriod())) {
							logger.info("Usance Period is empty");
							errorDetailList = aCommonMethods.setErrorInList(
									ActionConstants.ERRORCODE013,
									errorDetailList);
						}
					}
				}
			}
			if (userVo.getEventCode().trim().equalsIgnoreCase("NAME")) {
				if (!aCommonMethods.isValueAvailable(userVo.getTiReferanceNo())) {
					logger.info("TiReferenceNo is empty in ELC amend event");
					errorDetailList = aCommonMethods.setErrorInList(
							ActionConstants.ERRORCODE009, errorDetailList);
				}
			}

			if (userVo.getEventCode().equalsIgnoreCase("DOP")) {
				if (!aCommonMethods.isValueAvailable(userVo.getTiReferanceNo())) {
					logger.info("TiReferenceNo is empty");
					errorDetailList = aCommonMethods.setErrorInList(
							ActionConstants.ERRORCODE009, errorDetailList);
				}
				if (!aCommonMethods.isValueAvailable(userVo.getAmount())) {
					logger.info("Amount is empty");
					errorDetailList = aCommonMethods.setErrorInList(
							ActionConstants.ERRORCODE004, errorDetailList);
				}
				if (userVo.getLcType().trim().equalsIgnoreCase("Usance")) {
					if (!aCommonMethods.isValueAvailable(userVo
							.getUsancePeriod())) {
						logger.info("Usance Period is empty");
						errorDetailList = aCommonMethods.setErrorInList(
								ActionConstants.ERRORCODE013, errorDetailList);
					}
				}
			}
			// Bill reference Changes 10012020 starts
			if (userVo.getEventCode().equalsIgnoreCase("PODA")
					|| userVo.getEventCode().equalsIgnoreCase("PODP")) {
				
				if (!aCommonMethods.isValueAvailable(userVo.getBillReference())) {
					System.out.println("billReference is empty");
					errorDetailList = aCommonMethods.setErrorInList(
							ActionConstants.ERRORCODE037, errorDetailList);
				}
				
				if (!aCommonMethods.isValueAvailable(userVo.getAcceptanceAmount())) {
					System.out.println("Acceptance Amount is empty");
					errorDetailList = aCommonMethods.setErrorInList(
							ActionConstants.ERRORCODE004, errorDetailList);
				}

				userVo.setBillReferenceList(getBillReference(userVo,
						userVo.getTiReferanceNo()));

			}
			// Bill reference Changes 10012020 ends
		}
		if (userVo.getProductCode().trim().equalsIgnoreCase("IDC")) {
			if (userVo.getEventCode().trim().equalsIgnoreCase("CRE")) {
				if (!aCommonMethods.isValueAvailable(userVo.getCustomeCif())) {
					logger.info("CustomeCif is empty");
					errorDetailList = aCommonMethods.setErrorInList(
							ActionConstants.ERRORCODE003, errorDetailList);
				}
				if (!aCommonMethods.isValueAvailable(userVo.getBillAmount())) {
					logger.info("Amount is empty");
					errorDetailList = aCommonMethods.setErrorInList(
							ActionConstants.ERRORCODE004, errorDetailList);
				}
				if (!aCommonMethods.isValueAvailable(userVo.getCurrency())) {
					logger.info("Currency is empty");
					errorDetailList = aCommonMethods.setErrorInList(
							ActionConstants.ERRORCODE005, errorDetailList);
				}
				if (!aCommonMethods.isValueAvailable(userVo.getSolID())) {
					logger.info("SolID is empty");
					errorDetailList = aCommonMethods.setErrorInList(
							ActionConstants.ERRORCODE006, errorDetailList);
				}
				if (!aCommonMethods
						.isValueAvailable(userVo.getSubProductCode())) {
					logger.info("Product type is empty");
					errorDetailList = aCommonMethods.setErrorInList(
							ActionConstants.ERRORCODE017, errorDetailList);
				}
				if (userVo.getSubProductCode().equalsIgnoreCase("IFU")) {
					if (!aCommonMethods.isValueAvailable(userVo
							.getBillUsancePeriod())) {
						logger.info("Usance Period is empty");
						errorDetailList = aCommonMethods.setErrorInList(
								ActionConstants.ERRORCODE018, errorDetailList);
					}
				}
				// Rate taken Fix Offshore Team 30122019 starts
				/*
				 * if (userVo.getRateTaken().equalsIgnoreCase("true") &&
				 * !aCommonMethods.isValueAvailable(userVo.getRate())) {
				 * logger.info("Rate is empty"); errorDetailList =
				 * aCommonMethods.setErrorInList( ActionConstants.ERRORCODE025,
				 * errorDetailList); }
				 */
				// Rate taken Fix Offshore Team 30122019 ends
			}
			if (userVo.getEventCode().trim().equalsIgnoreCase("CAC")) {
				if (!aCommonMethods.isValueAvailable(userVo.getAcceptBillAmt())) {
					logger.info("Amount is empty");
					errorDetailList = aCommonMethods.setErrorInList(
							ActionConstants.ERRORCODE031, errorDetailList);
				}
				if (!aCommonMethods.isValueAvailable(userVo.getTiReferanceNo())) {
					logger.info("TI Ref is empty");
					errorDetailList = aCommonMethods.setErrorInList(
							ActionConstants.ERRORCODE009, errorDetailList);
				}
			}
			if (userVo.getEventCode().trim().equalsIgnoreCase("CLP")) {
				if (!aCommonMethods.isValueAvailable(userVo.getBillAmount())) {
					logger.info("Amount is empty");
					errorDetailList = aCommonMethods.setErrorInList(
							ActionConstants.ERRORCODE004, errorDetailList);
				}
				// FREEZING(SCENARIO) off shore team starts 31122019
				if (!aCommonMethods.isValueAvailable(userVo.getTiReferanceNo())) {
					logger.info("TI Reference number is empty");
					errorDetailList = aCommonMethods.setErrorInList(
							ActionConstants.ERRORCODE009, errorDetailList);
				}
				// FREEZING(SCENARIO) off shore team ends 31122019

				// rate taken null checking 31122019
				/*
				 * if (aCommonMethods.isValueAvailable(userVo.getRateTaken())) {
				 * 
				 * if (userVo.getRateTaken().equalsIgnoreCase("true") &&
				 * !aCommonMethods.isValueAvailable(userVo .getRate())) {
				 * logger.info("Rate is empty"); errorDetailList =
				 * aCommonMethods.setErrorInList( ActionConstants.ERRORCODE025,
				 * errorDetailList); } }
				 */

			}
		}
		if (userVo.getProductCode().trim().equalsIgnoreCase("FEL")) {
			if (userVo.getEventCode().trim().equalsIgnoreCase("CSA4")) {
				if (!aCommonMethods.isValueAvailable(userVo.getLcRefNum())) {
					logger.info("LCREF Num is empty");
					errorDetailList = aCommonMethods.setErrorInList(
							ActionConstants.ERRORCODE032, errorDetailList);
				}
				if (!aCommonMethods.isValueAvailable(userVo.getSolID())) {
					logger.info("SolID is empty");
					errorDetailList = aCommonMethods.setErrorInList(
							ActionConstants.ERRORCODE006, errorDetailList);
				}
				if (!aCommonMethods.isValueAvailable(userVo
						.getBillReferenceNo())) {
					logger.info("Bill Reference is empty");
					errorDetailList = aCommonMethods.setErrorInList(
							ActionConstants.ERRORCODE037, errorDetailList);
				}
				if (!aCommonMethods.isValueAvailable(userVo.getFncAmount())) {
					logger.info("Finance Amount is empty");
					errorDetailList = aCommonMethods.setErrorInList(
							ActionConstants.ERRORCODE033, errorDetailList);
				}
				if (!aCommonMethods
						.isValueAvailable(userVo.getSubProductCode())) {
					logger.info("Sub Product Code is empty");
					errorDetailList = aCommonMethods.setErrorInList(
							ActionConstants.ERRORCODE024, errorDetailList);
				}
				if (!aCommonMethods.isValueAvailable(userVo
						.getPreshipAccSetteld())) {
					logger.info("Preshipment Account type is empty");
					errorDetailList = aCommonMethods.setErrorInList(
							ActionConstants.ERRORCODE034, errorDetailList);
				}

				// rate taken null checking 31122019
				if (aCommonMethods.isValueAvailable(userVo.getRateTaken())) {

					if (userVo.getRateTaken().equalsIgnoreCase("true")
							&& (!aCommonMethods.isValueAvailable(userVo
									.getRate()))) {
						logger.info("Rate is empty");
						errorDetailList = aCommonMethods.setErrorInList(
								ActionConstants.ERRORCODE035, errorDetailList);
					}
				}

				if (aCommonMethods.isValueAvailable(userVo.getLcRefNum())) {
					userVo.setBillReferenceList(getBillReference(userVo,
							userVo.getLcRefNum()));
				}
			}
			if (userVo.getEventCode().trim().equalsIgnoreCase("JSA4")) {
				if (!aCommonMethods.isValueAvailable(userVo.getLcRefNum())) {
					logger.info("LCREF Num is empty");
					errorDetailList = aCommonMethods.setErrorInList(
							ActionConstants.ERRORCODE032, errorDetailList);
				}
				if (!aCommonMethods.isValueAvailable(userVo.getSolID())) {
					logger.info("SolID is empty");
					errorDetailList = aCommonMethods.setErrorInList(
							ActionConstants.ERRORCODE006, errorDetailList);
				}

				if (!aCommonMethods.isValueAvailable(userVo.getMaturityDate())) {
					logger.info("Maturity Date is empty");
					errorDetailList = aCommonMethods.setErrorInList(
							ActionConstants.ERRORCODE038, errorDetailList);
				}
			}

			if (userVo.getEventCode().trim().equalsIgnoreCase("CRYST")) {
				if (!aCommonMethods.isValueAvailable(userVo.getLcRefNum())) {
					logger.info("LCREF Num is empty");
					errorDetailList = aCommonMethods.setErrorInList(
							ActionConstants.ERRORCODE032, errorDetailList);
				}
				if (!aCommonMethods.isValueAvailable(userVo.getSolID())) {
					logger.info("SolID is empty");
					errorDetailList = aCommonMethods.setErrorInList(
							ActionConstants.ERRORCODE006, errorDetailList);
				}

				if (!aCommonMethods.isValueAvailable(userVo.getFncAmount())) {
					logger.info("Repayment Amount is empty");
					errorDetailList = aCommonMethods.setErrorInList(
							ActionConstants.ERRORCODE039, errorDetailList);
				}

				// rate taken null checking 31122019
				if (aCommonMethods.isValueAvailable(userVo.getRateTaken())) {

					if (userVo.getRateTaken().equalsIgnoreCase("true")
							&& (!aCommonMethods.isValueAvailable(userVo
									.getRate()))) {
						logger.info("Rate is empty");
						errorDetailList = aCommonMethods.setErrorInList(
								ActionConstants.ERRORCODE035, errorDetailList);
					}

				}
			}
			if (userVo.getEventCode().trim().equalsIgnoreCase("RSA4")) {
				if (!aCommonMethods.isValueAvailable(userVo.getLcRefNum())) {
					logger.info("LCREF Num is empty");
					errorDetailList = aCommonMethods.setErrorInList(
							ActionConstants.ERRORCODE032, errorDetailList);
				}
				if (!aCommonMethods.isValueAvailable(userVo.getSolID())) {
					logger.info("SolID is empty");
					errorDetailList = aCommonMethods.setErrorInList(
							ActionConstants.ERRORCODE006, errorDetailList);
				}

				if (!aCommonMethods.isValueAvailable(userVo.getFncAmount())) {
					logger.info("Repayment Amount is empty");
					errorDetailList = aCommonMethods.setErrorInList(
							ActionConstants.ERRORCODE039, errorDetailList);
				}

				// rate taken null checking 31122019
				if (aCommonMethods.isValueAvailable(userVo.getRateTaken())) {

					if (userVo.getRateTaken().equalsIgnoreCase("true")
							&& (!aCommonMethods.isValueAvailable(userVo
									.getRate()))) {
						logger.info("Rate is empty");
						errorDetailList = aCommonMethods.setErrorInList(
								ActionConstants.ERRORCODE035, errorDetailList);
					}

				}
			}
		}

		if (userVo.getProductCode().trim().equalsIgnoreCase("FOC")) {
			if (userVo.getEventCode().trim().equalsIgnoreCase("CSA1")) {
				if (!aCommonMethods.isValueAvailable(userVo.getFinanceAmount())) {
					logger.info("Finance Amount is empty");
					errorDetailList = aCommonMethods.setErrorInList(
							ActionConstants.ERRORCODE033, errorDetailList);
				}

				if (!aCommonMethods
						.isValueAvailable(userVo.getSubProductCode())) {
					logger.info("Product Type is empty");
					errorDetailList = aCommonMethods.setErrorInList(
							ActionConstants.ERRORCODE017, errorDetailList);
				}

				// rate taken null checking 31122019
				if (aCommonMethods.isValueAvailable(userVo.getRateTaken())) {

					if (userVo.getRateTaken().equalsIgnoreCase("true")
							&& !aCommonMethods.isValueAvailable(userVo
									.getRate())) {
						logger.info("Rate is empty");
						errorDetailList = aCommonMethods.setErrorInList(
								ActionConstants.ERRORCODE025, errorDetailList);
					}
				}
				if (!aCommonMethods.isValueAvailable(userVo.getSolID())) {
					logger.info("SolID is empty");
					errorDetailList = aCommonMethods.setErrorInList(
							ActionConstants.ERRORCODE006, errorDetailList);
				}
			}
			if (userVo.getEventCode().trim().equalsIgnoreCase("RSA1")) {

				// rate taken null checking 31122019
				if (aCommonMethods.isValueAvailable(userVo.getRateTaken())) {

					if (userVo.getRateTaken().equalsIgnoreCase("true")
							&& !aCommonMethods.isValueAvailable(userVo
									.getRate())) {
						logger.info("Rate is empty");
						errorDetailList = aCommonMethods.setErrorInList(
								ActionConstants.ERRORCODE025, errorDetailList);
					}
				}
			}
			if (userVo.getEventCode().trim().equalsIgnoreCase("CRYST")) {

				// rate taken null checking 31122019
				if (aCommonMethods.isValueAvailable(userVo.getRateTaken())) {
					if (userVo.getRateTaken().equalsIgnoreCase("true")
							&& !aCommonMethods.isValueAvailable(userVo
									.getRate())) {
						logger.info("Rate is empty");
						errorDetailList = aCommonMethods.setErrorInList(
								ActionConstants.ERRORCODE025, errorDetailList);
					}
				}

			}
			if (userVo.getEventCode().trim().equalsIgnoreCase("JSA1")) {
				if (!aCommonMethods.isValueAvailable(userVo.getMaturityDate())) {
					logger.info("MaturityDate is empty");
					errorDetailList = aCommonMethods.setErrorInList(
							ActionConstants.ERRORCODE036, errorDetailList);
				}
				if (!aCommonMethods.isValueAvailable(userVo.getSolID())) {
					logger.info("SolID is empty");
					errorDetailList = aCommonMethods.setErrorInList(
							ActionConstants.ERRORCODE006, errorDetailList);
				}
			}
		}
		if (userVo.getProductCode().trim().equalsIgnoreCase("FSA")) {
			if (userVo.getEventCode().trim().equalsIgnoreCase("CSA")) {
				if (!aCommonMethods.isValueAvailable(userVo.getAmount())) {
					logger.info("Disbursement Amount is empty");
					errorDetailList = aCommonMethods.setErrorInList(
							ActionConstants.ERRORCODE040, errorDetailList);
				}
				if (!aCommonMethods.isValueAvailable(userVo.getCustomeCif())) {
					logger.info("CustomeCif is empty");
					errorDetailList = aCommonMethods.setErrorInList(
							ActionConstants.ERRORCODE003, errorDetailList);
				}

				if (!aCommonMethods.isValueAvailable(userVo.getCurrency())) {
					logger.info("Currency is empty");
					errorDetailList = aCommonMethods.setErrorInList(
							ActionConstants.ERRORCODE005, errorDetailList);
				}
				if (!aCommonMethods.isValueAvailable(userVo.getUsancePeriod())) {
					logger.info("Usance Period is empty");
					errorDetailList = aCommonMethods.setErrorInList(
							ActionConstants.ERRORCODE013, errorDetailList);
				}
				if (!aCommonMethods
						.isValueAvailable(userVo.getSubProductCode())) {
					logger.info("Product Type is empty");
					errorDetailList = aCommonMethods.setErrorInList(
							ActionConstants.ERRORCODE017, errorDetailList);
				}

				// rate taken null checking 31122019
				if (aCommonMethods.isValueAvailable(userVo.getRateTaken())) {

					if (userVo.getRateTaken().equalsIgnoreCase("true")
							&& !aCommonMethods.isValueAvailable(userVo
									.getRate())) {
						logger.info("Rate is empty");
						errorDetailList = aCommonMethods.setErrorInList(
								ActionConstants.ERRORCODE025, errorDetailList);
					}
				}

				if (!aCommonMethods.isValueAvailable(userVo.getSolID())) {
					logger.info("SolID is empty");
					errorDetailList = aCommonMethods.setErrorInList(
							ActionConstants.ERRORCODE006, errorDetailList);
				}
			}
			if (userVo.getEventCode().trim().equalsIgnoreCase("RSA")) {

				// rate taken null checking 31122019
				if (aCommonMethods.isValueAvailable(userVo.getRateTaken())) {
					if (userVo.getRateTaken().equalsIgnoreCase("true")
							&& !aCommonMethods.isValueAvailable(userVo
									.getRate())) {
						logger.info("Rate is empty");
						errorDetailList = aCommonMethods.setErrorInList(
								ActionConstants.ERRORCODE025, errorDetailList);
					}

				}
				if (!aCommonMethods.isValueAvailable(userVo.getAmount())) {
					logger.info("Offset amount is empty");
					errorDetailList = aCommonMethods.setErrorInList(
							ActionConstants.ERRORCODE041, errorDetailList);
				}

			}
			if (userVo.getEventCode().trim().equalsIgnoreCase("JSA")) {
				if (!aCommonMethods.isValueAvailable(userVo.getMaturityDate())) {
					logger.info("MaturityDate is empty");
					errorDetailList = aCommonMethods.setErrorInList(
							ActionConstants.ERRORCODE036, errorDetailList);
				}
				if (!aCommonMethods.isValueAvailable(userVo.getSolID())) {
					logger.info("SolID is empty");
					errorDetailList = aCommonMethods.setErrorInList(
							ActionConstants.ERRORCODE006, errorDetailList);
				}
			}
		}

		// SBLC 251219
		if (userVo.getProductCode().trim().equalsIgnoreCase("ISB")) {
			if (userVo.getEventCode().trim().equalsIgnoreCase("IIS")) {

				if (!aCommonMethods.isValueAvailable(userVo.getCustomeCif())) {
					logger.info("CustomeCif is empty");
					errorDetailList = aCommonMethods.setErrorInList(
							ActionConstants.ERRORCODE003, errorDetailList);
				}
				if (!aCommonMethods.isValueAvailable(userVo.getAmount())) {
					logger.info("Amount is empty");
					errorDetailList = aCommonMethods.setErrorInList(
							ActionConstants.ERRORCODE004, errorDetailList);
				}
				if (!aCommonMethods.isValueAvailable(userVo.getCurrency())) {
					logger.info("Currency is empty");
					errorDetailList = aCommonMethods.setErrorInList(
							ActionConstants.ERRORCODE005, errorDetailList);
				}
				if (!aCommonMethods.isValueAvailable(userVo.getSolID())) {
					logger.info("SolID is empty");
					errorDetailList = aCommonMethods.setErrorInList(
							ActionConstants.ERRORCODE006, errorDetailList);
				}
				if (!aCommonMethods
						.isValueAvailable(userVo.getSubProductCode())) {
					logger.info("Product type is empty");
					errorDetailList = aCommonMethods.setErrorInList(
							ActionConstants.ERRORCODE017, errorDetailList);
				}
				if (!aCommonMethods.isValueAvailable(userVo
						.getBillUsancePeriod())) {
					logger.info("Tenure Period is empty");
					errorDetailList = aCommonMethods.setErrorInList(
							ActionConstants.ERRORCODE018, errorDetailList);
				}

			}

			if (userVo.getEventCode().trim().equalsIgnoreCase("NJIS")) {
				if (!aCommonMethods.isValueAvailable(userVo.getTiReferanceNo())) {
					logger.info("TI Ref is empty");
					errorDetailList = aCommonMethods.setErrorInList(
							ActionConstants.ERRORCODE009, errorDetailList);
				}

			}
			if (userVo.getEventCode().trim().equalsIgnoreCase("NAIS")) {

				if (!aCommonMethods.isValueAvailable(userVo.getTiReferanceNo())) {
					logger.info("TI Ref is empty");
					errorDetailList = aCommonMethods.setErrorInList(
							ActionConstants.ERRORCODE009, errorDetailList);
				}
			}
			if (userVo.getEventCode().trim().equalsIgnoreCase("LIS")) {

				if (!aCommonMethods.isValueAvailable(userVo.getTiReferanceNo())) {
					logger.info("TI Ref is empty");
					errorDetailList = aCommonMethods.setErrorInList(
							ActionConstants.ERRORCODE009, errorDetailList);
				}
			}
			if (userVo.getEventCode().trim().equalsIgnoreCase("OIS")) {

				if (!aCommonMethods.isValueAvailable(userVo.getTiReferanceNo())) {
					logger.info("TI Ref is empty");
					errorDetailList = aCommonMethods.setErrorInList(
							ActionConstants.ERRORCODE009, errorDetailList);
					// Bill reference Changes 10012020 starts
					userVo.setBillReferenceList(getBillReference(userVo,
							userVo.getTiReferanceNo()));
					// Bill reference Changes 10012020 ends
				}
			}

		}
		// SBLC 251219_END
		// changes for IGT on 10012020 starts
		if (userVo.getProductCode().trim().equalsIgnoreCase("IGT")) {
			if (userVo.getEventCode().trim().equalsIgnoreCase("IIG")) {
				if (!aCommonMethods.isValueAvailable(userVo.getCustomeCif())) {
					logger.info("CustomeCif is empty");
					errorDetailList = aCommonMethods.setErrorInList(
							ActionConstants.ERRORCODE003, errorDetailList);
				}
				if (!aCommonMethods.isValueAvailable(userVo.getAmount())) {
					logger.info("Amount is empty");
					errorDetailList = aCommonMethods.setErrorInList(
							ActionConstants.ERRORCODE004, errorDetailList);
				}
				if (!aCommonMethods.isValueAvailable(userVo.getCurrency())) {
					logger.info("Currency is empty");
					errorDetailList = aCommonMethods.setErrorInList(
							ActionConstants.ERRORCODE005, errorDetailList);
				}
				if (!aCommonMethods.isValueAvailable(userVo.getSolID())) {
					logger.info("SolID is empty");
					errorDetailList = aCommonMethods.setErrorInList(
							ActionConstants.ERRORCODE006, errorDetailList);
				}
				if (!aCommonMethods
						.isValueAvailable(userVo.getSubProductCode())) {
					logger.info("Product type is empty");
					errorDetailList = aCommonMethods.setErrorInList(
							ActionConstants.ERRORCODE017, errorDetailList);
				}
			}
			if (userVo.getEventCode().trim().equalsIgnoreCase("NAIG")) {
				if (!aCommonMethods.isValueAvailable(userVo.getTiReferanceNo())) {
					logger.info("TI Ref is empty");
					errorDetailList = aCommonMethods.setErrorInList(
							ActionConstants.ERRORCODE009, errorDetailList);
				}

			}
			if (userVo.getEventCode().trim().equalsIgnoreCase("LIG")) {
				if (!aCommonMethods.isValueAvailable(userVo.getTiReferanceNo())) {
					logger.info("TI Ref is empty");
					errorDetailList = aCommonMethods.setErrorInList(
							ActionConstants.ERRORCODE009, errorDetailList);
				}

			}
			if (userVo.getEventCode().trim().equalsIgnoreCase("OIG")) {
				if (!aCommonMethods.isValueAvailable(userVo.getTiReferanceNo())) {
					logger.info("TI Ref is empty");
					errorDetailList = aCommonMethods.setErrorInList(
							ActionConstants.ERRORCODE009, errorDetailList);
				}
				// Bill reference Changes 10012020 starts
				userVo.setBillReferenceList(getBillReference(userVo,
						userVo.getTiReferanceNo()));
				// Bill reference Changes 10012020 ends
			}

		}
		// changes for IGT on 10012020 ends
		return errorDetailList;
	}

	public Boolean isValidTransactionRequest(UserTransactionVO userVo)
			throws Exception {
		CommonMethods aCommonMethods = new CommonMethods();
		List<AlertMessagesVO> errorDetailList = new LinkedList<AlertMessagesVO>();
		Boolean isValidTransactionRequest = true;
		if (!aCommonMethods.isValueAvailable(userVo.getProductCode())) {
			logger.info("Product is empty");
			errorDetailList = aCommonMethods.setErrorInList(
					ActionConstants.ERRORCODE001, errorDetailList);
			isValidTransactionRequest = false;
		}
		if (!aCommonMethods.isValueAvailable(userVo.getEventCode())) {
			logger.info("Product is empty");
			errorDetailList = aCommonMethods.setErrorInList(
					ActionConstants.ERRORCODE002, errorDetailList);
			isValidTransactionRequest = false;
		}
		userVo.setErrorDetailsList(errorDetailList);
		return isValidTransactionRequest;
	}

	public String getCurrentStatus(String requestId) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		DBHelper aDBHelper = new DBHelper();
		String stepStatus = "";
		stepStatus = aDBHelper.getValueFromDB(requestId,
				ActionConstants.GETCURRENTSTATUS_QUERY);
		logger.info(ActionConstants.EXITING_METHOD);
		return stepStatus;
	}

	public UserTransactionVO getTransDetailsFromDB(UserTransactionVO userVo,
			String tiReferenceNo) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		DBHelper aDBHelper = new DBHelper();
		List<TFBOImportLcVO> importLcVOList = new LinkedList<TFBOImportLcVO>();
		List<TFBOExportCollectionVO> exportCollectionVOList = new LinkedList<TFBOExportCollectionVO>();
		List<TFBOFinanceExportLcVO> financeExportLCVOList = new LinkedList<TFBOFinanceExportLcVO>();
		List<TFBOExportLcVO> exportLcVOlist = new LinkedList<TFBOExportLcVO>();
		List<TFBOIdcVO> importDCVOList = new LinkedList<TFBOIdcVO>();
		List<TFBOFinanceExportColVO> FinExportCollectionList = new LinkedList<TFBOFinanceExportColVO>();
		List<TFBOFinanceStandaloneVO> FinStandaloneList = new LinkedList<TFBOFinanceStandaloneVO>();
		List<TFBOOutwardRemittanceVO> outwardRemittanceList = new LinkedList<TFBOOutwardRemittanceVO>();
		List<TFBOSandbyLcVO> standByLCVoList = new LinkedList<TFBOSandbyLcVO>();
		// Miscellanous changes starts 08-01-2020
		List<TFBOMiscellanousVO> miscellanousVOList = new LinkedList<TFBOMiscellanousVO>();
		// Miscellanous changes ends 08-01-2020
		try {
			if (userVo.getProductCode().equalsIgnoreCase("ILC")) {
				if (userVo.getEventCode().equalsIgnoreCase("POCP")
						|| userVo.getEventCode().equalsIgnoreCase("POCA")
						|| userVo.getEventCode().equalsIgnoreCase("POCD")) {
					userVo.setBillReferenceList(getBillReference(userVo,
							tiReferenceNo));
					logger.info("userVo.getBillReferenceList() >>-->"
							+ userVo.getBillReferenceList());
				}
				importLcVOList = aDBHelper.getTFBOIImportLCISSFromDB(
						tiReferenceNo,
						ActionConstants.GETTIREFNOTRANSDETAILES_QUERY);

				userVo.setImportLcList(importLcVOList);
				setTransactionValuesInVO(userVo);
			}
			// Miscellanous changes starts 08-01-2020
			/*
			 * if (userVo.getProductCode().equalsIgnoreCase("COR") &&
			 * userVo.getEventCode().equalsIgnoreCase("CRCR")) { logger.info(
			 * "Fetching TI reference details in getTransDetailsFromDB method==> "
			 * ); System.out .println(
			 * "Getting sub product type in fetching ti reference details==>" +
			 * userVo.getSubProductCode()); miscellanousVOList = aDBHelper
			 * .getTFBOMISTIReferenceDetailsFromDB( userVo.getSubProductCode(),
			 * tiReferenceNo,
			 * ActionConstants.GETTIREFNOTRANSDETAILES_MIS_MCRE_QUERY);
			 * userVo.setMiscellanousVOList(miscellanousVOList);
			 * setTransactionValuesInVO(userVo); }
			 */
			// Miscellanous changes ends 08-01-2020
			if (userVo.getProductCode().equalsIgnoreCase("COR")
					&& userVo.getEventCode().equalsIgnoreCase("CRCR")) {
				logger.info("Fetching TI reference details in getTransDetailsFromDB method==> ");
				System.out
						.println("Getting sub product type in fetching ti reference details==>"
								+ userVo.getSubProductCode());
				miscellanousVOList = aDBHelper
						.getTFBOMISTIReferenceDetailsFromDB(
								userVo.getSubProductCode(),
								tiReferenceNo,
								ActionConstants.GETTIREFNOTRANSDETAILES_MIS_MCRE_QUERY);
				userVo.setMiscellanousVOList(miscellanousVOList);
				setTransactionValuesInVO(userVo);
			}

			if (userVo.getProductCode().equalsIgnoreCase("ELC")) {
				// Expiry,closure,cancellation Changes Starts
				if (userVo.getEventCode().equalsIgnoreCase("NAME")
						|| userVo.getEventCode().equalsIgnoreCase("EXP")) {
					// Expiry,closure,cancellation Changes Ends
					exportLcVOlist = aDBHelper.getTFBOExportLCAMDFromDB(
							tiReferenceNo,
							ActionConstants.GETTIREFNOTRANSDETAILESELC_QUERY);
					userVo.setExportLcList(exportLcVOlist);
					setTransactionValuesInVO(userVo);
				}
				// karthik 13012020 starts
				/*
				 * if (userVo.getEventCode().equalsIgnoreCase("COE")) {
				 * exportLcVOlist = aDBHelper.getTFBOExportLCAMDFromDB(
				 * tiReferenceNo,
				 * ActionConstants.GETTIREFNOTRANSDETAILESELC_QUERY);
				 * userVo.setExportLcList(exportLcVOlist);
				 * 
				 * setTransactionValuesInVO(userVo); }
				 */
				if (userVo.getEventCode().equalsIgnoreCase("COE")) {
					exportLcVOlist = aDBHelper.getTFBOExportLCAMDFromDB(
							tiReferenceNo,
							ActionConstants.GETTIREFNOTRANSDETAILESELC_QUERY);
					userVo.setExportLcList(exportLcVOlist);

					setTransactionValuesInVO(userVo);
				}
				// karthik 13012020 ends
				// Changes for ELC and IGT Starts 25-12-2019
				if (userVo.getEventCode().equalsIgnoreCase("PODA")
						|| userVo.getEventCode().equalsIgnoreCase("PODP")) {
					/*
					 * exportLcVOlist =
					 * aDBHelper.getTFBOExportLCAMDFromDB(tiReferenceNo,
					 * ActionConstants.GETTIREFNOTRANSDETAILESELCPOC_QUERY);
					 */
					userVo.setBillReferenceList(getBillReference(userVo,
							tiReferenceNo));
					logger.info("userVo.getBillReferenceList() >>-->"
							+ userVo.getBillReferenceList());
					exportLcVOlist = aDBHelper.getTFBOExportLCAMDFromDB(
							tiReferenceNo,
							ActionConstants.GETTIREFNOTRANSDETAILESELC_QUERY);
					userVo.setExportLcList(exportLcVOlist);
					setTransactionValuesInVO(userVo);
				}
				// Changes for ELC and IGT ends 25-12-2019
				// ELC DOP Issue Fix 20-12-2019 starts
				if (userVo.getEventCode().equalsIgnoreCase("DOP")) {
					exportLcVOlist = aDBHelper
							.getTFBOExportLCDOPTranDetailsFromDB(
									tiReferenceNo,
									ActionConstants.GETTIREFNOTRANSDETAILESELC_QUERY);
					userVo.setExportLcList(exportLcVOlist);
					setTransactionValuesInVO(userVo);
				}
				// ELC DOP Issue Fix 20-12-2019 ends
			}
			// Changes for ELC and IGT Starts 25-12-2019
			// Expiry,closure,cancellation Changes Starts
			if (userVo.getProductCode().equalsIgnoreCase("IGT")) {
				if (userVo.getEventCode().equalsIgnoreCase("NAIG")
						|| userVo.getEventCode().equalsIgnoreCase("LIG")
						|| userVo.getEventCode().equalsIgnoreCase("NIG")
						|| userVo.getEventCode().equalsIgnoreCase("KIG")
						|| userVo.getEventCode().equalsIgnoreCase("XIG")) {
					// Expiry,closure,cancellation Changes Ends
					List<TFBOImportGTVO> importGtVOList = new LinkedList<TFBOImportGTVO>();
					importGtVOList = aDBHelper.getTFBOImportGTAMDFromDB(
							tiReferenceNo,
							ActionConstants.GETTIREFNOTRANSDETAILESIGT_QUERY);
					userVo.setImportGuaranteeList(importGtVOList);
					setTransactionValuesInVO(userVo);
				}
				if (userVo.getEventCode().equalsIgnoreCase("LIG")
						|| userVo.getEventCode().equalsIgnoreCase("OIG"))
					//userVo.setGuarnteeAmtPrevInv(getGuaranteeAmount(tiReferenceNo));
				if (userVo.getEventCode().equalsIgnoreCase("OIG")) {
					List<TFBOImportGTVO> importGtVOList = new LinkedList<TFBOImportGTVO>();
					importGtVOList = aDBHelper
							.getTFBOImportGTOIGFromDB(
									tiReferenceNo,
									ActionConstants.GETTIREFNOTRANSDETAILESIGTOIG_QUERY);
					userVo.setBillReferenceList(getBillReference(userVo,
							tiReferenceNo));
					logger.info("userVo.setBillReference "
							+ userVo.getBillReferenceList());
					userVo.setImportGuaranteeList(importGtVOList);
					setTransactionValuesInVO(userVo);
				}
			}

			if (userVo.getProductCode().equalsIgnoreCase("ISB")) {
				if (userVo.getEventCode().equalsIgnoreCase("NIS")
						|| userVo.getEventCode().equalsIgnoreCase("KIS")) {
					System.out.println("------------ISB evt----");
					standByLCVoList = aDBHelper
							.getTFBOISB_NIS_KIS_FromDB(
									tiReferenceNo,
									ActionConstants.GETTIREFTRANSDETAILS_ISB_NIS_KIS_QUERY);
					System.out.println("-----ISB SIZE-----"
							+ standByLCVoList.size());
					userVo.setStandByLCList(standByLCVoList);
					setTransactionValuesInVO(userVo);

				}
			}
			// karthik 13012020 starts
			/*
			 * if (userVo.getProductCode().equalsIgnoreCase("ODC") &&
			 * userVo.getEventCode().equalsIgnoreCase("CCO")) {
			 * System.out.println("Inside ODC CCO"); exportCollectionVOList =
			 * aDBHelper.getTFBOODCCCOFRromDB( tiReferenceNo,
			 * ActionConstants.GETTIREFNOTRANSDETAILES_ODCCCO_QUERY);
			 * userVo.setExportCollectionList(exportCollectionVOList);
			 * setTransactionValuesInVO(userVo); }
			 */
			if (userVo.getProductCode().equalsIgnoreCase("ODC")
					&& userVo.getEventCode().equalsIgnoreCase("CCO")) {
				System.out.println("Inside ODC CCO");
				exportCollectionVOList = aDBHelper.getTFBOODCCCOFRromDB(
						tiReferenceNo,
						ActionConstants.GETTIREFNOTRANSDETAILES_ODCCCO_QUERY);
				userVo.setExportCollectionList(exportCollectionVOList);
				setTransactionValuesInVO(userVo);
			}
			// karthik 13012020 ends
			// Changes for ELC and IGT Ends 25-12-2019
			if (userVo.getProductCode().equalsIgnoreCase("ODC")
					&& userVo.getEventCode().equalsIgnoreCase("CRE")) {
				exportCollectionVOList = aDBHelper.getTFBOIODCCREFromDB(
						tiReferenceNo,
						ActionConstants.GETTIREFNOTRANSDETAILES_ODCCRE_QUERY);
				userVo.setExportCollectionList(exportCollectionVOList);
				setTransactionValuesInVO(userVo);
			}
			if (userVo.getProductCode().equalsIgnoreCase("ODC")
					&& userVo.getEventCode().equalsIgnoreCase("CLP")) {
				System.out.println("Inside ODC create");
				exportCollectionVOList = aDBHelper.getTFBOIODCCLPFromDB(
						tiReferenceNo,
						ActionConstants.GETTIREFNOTRANSDETAILES_ODCCLP_QUERY);
				userVo.setExportCollectionList(exportCollectionVOList);
				setTransactionValuesInVO(userVo);
			}
			// CHANGES FOR ODC CAC 08012020 NY SAI STARTS HERE
			if (userVo.getProductCode().equalsIgnoreCase("ODC")
					&& userVo.getEventCode().equalsIgnoreCase("CAC")) {
				System.out.println("Inside ODC Accept");
				exportCollectionVOList = aDBHelper.getTFBOIODCCACFromDB(
						tiReferenceNo,
						ActionConstants.GETTIREFNOTRANSDETAILES_ODCCAC_QUERY);
				userVo.setExportCollectionList(exportCollectionVOList);
				setTransactionValuesInVO(userVo);
			}
			// CHANGES FOR ODC CAC 08012020 NY SAI ENDS HERE
			if (userVo.getProductCode().equalsIgnoreCase("IDC")
					&& userVo.getEventCode().equalsIgnoreCase("CAC")) {
				System.out.println("Inside IDC ACCEPT");
				importDCVOList = aDBHelper.getTFBOIImportIDCCACFromDB(
						tiReferenceNo,
						ActionConstants.GETTIREFNOTRANSDETAILES_IDC_CAC_QUERY);
				userVo.setImportIdcList(importDCVOList);
				setTransactionValuesInVO(userVo);
			}
			// karthik 13012020 starts
			/*
			 * if (userVo.getProductCode().equalsIgnoreCase("IDC") &&
			 * userVo.getEventCode().equalsIgnoreCase("CCO")) { importDCVOList =
			 * aDBHelper.getTFBOIImportIDCCCOFromDB( tiReferenceNo,
			 * ActionConstants.GETTIREFNOTRANSDETAILES_IDC_CCO_QUERY);
			 * userVo.setImportIdcList(importDCVOList);
			 * setTransactionValuesInVO(userVo); }
			 */
			if (userVo.getProductCode().equalsIgnoreCase("IDC")
					&& userVo.getEventCode().equalsIgnoreCase("CCO")) {
				importDCVOList = aDBHelper.getTFBOIImportIDCCCOFromDB(
						tiReferenceNo,
						ActionConstants.GETTIREFNOTRANSDETAILES_IDC_CCO_QUERY);
				userVo.setImportIdcList(importDCVOList);
				setTransactionValuesInVO(userVo);
			}
			// karthik 13012020 ends

			/*
			 * if (userVo.getProductCode().equalsIgnoreCase("IDC") &&
			 * userVo.getEventCode().equalsIgnoreCase("CLP")) {
			 * System.out.println("Inside IDC PAY"); importDCVOList =
			 * aDBHelper.getTFBOIImportIDCCLPTIFetchFromDB( tiReferenceNo,
			 * ActionConstants.GETTIREFNOTRANSDETAILES_IDC_CLP_QUERY);
			 * userVo.setImportIdcList(importDCVOList);
			 * setTransactionValuesInVO(userVo); }
			 */
			// ZIGZAG VALUE POPULATION 07012020 STARTS
			if (userVo.getProductCode().equalsIgnoreCase("IDC")
					&& userVo.getEventCode().equalsIgnoreCase("CLP")) {
				importDCVOList = aDBHelper.getTFBOIImportIDCCLPFromDB(
						tiReferenceNo,
						ActionConstants.GETTIREFNOTRANSDETAILES_IDC_CLP_QUERY);
				userVo.setImportIdcList(importDCVOList);
				setTransactionValuesInVO(userVo);
			}
			// ZIGZAG VALUE POPULATION 07012020 ENDS
			if (userVo.getProductCode().equalsIgnoreCase("FEL")
					&& userVo.getEventCode().equalsIgnoreCase("CSA4")) {
				System.out.println("Bill Ref-->" + userVo.getBillReferenceNo());
				System.out.println("TI Ref-->" + tiReferenceNo);
				financeExportLCVOList = aDBHelper.getTFBOFELCREFromDB(
						tiReferenceNo, userVo.getBillReferenceNo(),
						ActionConstants.GETTIREFNOTRANSDETAILS_FELCRE_QUERY);
				userVo.setBillReferenceList(getBillReference(userVo,
						tiReferenceNo));
				userVo.setFinanceExportLCList(financeExportLCVOList);
				setTransactionValuesInVO(userVo);
			}
			// karthik 13012020 starts
			/*
			 * if (userVo.getProductCode().equalsIgnoreCase("FEL") &&
			 * userVo.getEventCode().equalsIgnoreCase("PSA4")) {
			 * financeExportLCVOList = aDBHelper.getTFBOFELPSA4FromDB(
			 * tiReferenceNo,
			 * ActionConstants.GETTIREFNOTRANSDETAILES_FELPSA4_QUERY);
			 * userVo.setFinanceExportLCList(financeExportLCVOList);
			 * 
			 * setTransactionValuesInVO(userVo); }
			 */

			if (userVo.getProductCode().equalsIgnoreCase("FEL")
					&& userVo.getEventCode().equalsIgnoreCase("PSA4")) {
				financeExportLCVOList = aDBHelper.getTFBOFELPSA4FromDB(
						tiReferenceNo,
						ActionConstants.GETTIREFNOTRANSDETAILES_FELPSA4_QUERY);
				userVo.setFinanceExportLCList(financeExportLCVOList);

				setTransactionValuesInVO(userVo);
			}
			// karthik 13012020 ends
			if (userVo.getProductCode().equalsIgnoreCase("FEL")
					&& userVo.getEventCode().equalsIgnoreCase("JSA4")) {
				financeExportLCVOList = aDBHelper.getTFBOFELADJFromDB(
						tiReferenceNo,
						ActionConstants.GETTIREFNOTRANSDETAILS_FELADJ_QUERY);
				userVo.setFinanceExportLCList(financeExportLCVOList);
				setTransactionValuesInVO(userVo);
			}
			if (userVo.getProductCode().equalsIgnoreCase("FEL")
					&& userVo.getEventCode().equalsIgnoreCase("CRYST")) {
				financeExportLCVOList = aDBHelper.getTFBOFELRPYFromDB(
						tiReferenceNo,
						ActionConstants.GETTIREFNOTRANSDETAILS_FELCRYST_QUERY);
				userVo.setFinanceExportLCList(financeExportLCVOList);
				setTransactionValuesInVO(userVo);
			}
			if (userVo.getProductCode().equalsIgnoreCase("FEL")
					&& userVo.getEventCode().equalsIgnoreCase("RSA4")) {
				financeExportLCVOList = aDBHelper.getTFBOFELCRYSTFromDB(
						tiReferenceNo,
						ActionConstants.GETTIREFNOTRANSDETAILS_FELRPY_QUERY);
				userVo.setFinanceExportLCList(financeExportLCVOList);
				setTransactionValuesInVO(userVo);
			}
			// FOC - CREATE
			if (userVo.getProductCode().equalsIgnoreCase("FOC")) {
				if (userVo.getEventCode().equalsIgnoreCase("CSA1")) {
					FinExportCollectionList = aDBHelper
							.getTFBOIFOCCREFromDB(
									tiReferenceNo,
									ActionConstants.GETTIREFNOTRANSDETAILES_FOCCRE_QUERY);
					userVo.setFinExportCollectionList(FinExportCollectionList);
					setTransactionValuesInVO(userVo);

				}
				// karthik 13012020 starts
				/*
				 * if (userVo.getEventCode().equalsIgnoreCase("PSA1")) {
				 * FinExportCollectionList = aDBHelper .getTFBOIFOCPSA1FromDB(
				 * tiReferenceNo,
				 * ActionConstants.GETTIREFNOTRANSDETAILES_FOCPSA1_QUERY);
				 * 
				 * userVo.setFinExportCollectionList(FinExportCollectionList);
				 * setTransactionValuesInVO(userVo); }
				 */
				if (userVo.getEventCode().equalsIgnoreCase("PSA1")) {
					FinExportCollectionList = aDBHelper
							.getTFBOIFOCPSA1FromDB(
									tiReferenceNo,
									ActionConstants.GETTIREFNOTRANSDETAILES_FOCPSA1_QUERY);

					userVo.setFinExportCollectionList(FinExportCollectionList);
					setTransactionValuesInVO(userVo);
				}
				// karthik 13012020 ends

				if (userVo.getEventCode().equalsIgnoreCase("JSA1")
						|| (userVo.getEventCode().equalsIgnoreCase("RSA1"))) {
					FinExportCollectionList = aDBHelper
							.getTFBOIFOCADJFromDB(
									tiReferenceNo,
									ActionConstants.GETTIREFNOTRANSDETAILES_FOCADJ_QUERY);

					/*
					 * if (FinExportCollectionList.size() != 0) { if
					 * (userVo.getEventCode().equalsIgnoreCase("RSA1")) {
					 * 
					 * FinExportCollectionList = aDBHelper .getTFBOFOCRPYFromDB(
					 * tiReferenceNo,
					 * ActionConstants.GETTIREFNOTRANSDETAILES_FOCRPY_QUERY);
					 * 
					 * } }
					 */

					userVo.setFinExportCollectionList(FinExportCollectionList);
					setTransactionValuesInVO(userVo);

				}

				// if (userVo.getEventCode().equalsIgnoreCase("RSA1")) {
				// FinExportCollectionList = aDBHelper
				// .getTFBOIFOCADJFromDB(
				// tiReferenceNo,
				// ActionConstants.GETTIREFNOTRANSDETAILES_FOCADJ_QUERY);
				// userVo.setFinExportCollectionList(FinExportCollectionList);
				// setTransactionValuesInVO(userVo);
				// }
				if (userVo.getEventCode().equalsIgnoreCase("CRYST")) {
					FinExportCollectionList = aDBHelper
							.getTFBOIFOCADJFromDB(
									tiReferenceNo,
									ActionConstants.GETTIREFNOTRANSDETAILES_FOCCRYST_QUERY);
					userVo.setFinExportCollectionList(FinExportCollectionList);
					setTransactionValuesInVO(userVo);
				}
			}
			// FOC - CREATE
			if (userVo.getProductCode().equalsIgnoreCase("FSA")) {

				if (userVo.getEventCode().equalsIgnoreCase("JSA")) {
					FinStandaloneList = aDBHelper
							.getTFBOIFSAJSAFromDB(
									tiReferenceNo,
									ActionConstants.GETTIREFNOTRANSDETAILES_FSAADJ_QUERY);
					userVo.setFinStandaloneList(FinStandaloneList);
					setTransactionValuesInVO(userVo);
				}
				if (userVo.getEventCode().equalsIgnoreCase("RSA")) {
					FinStandaloneList = aDBHelper
							.getTFBOIFSARSAFromDB(
									tiReferenceNo,
									ActionConstants.GETTIREFNOTRANSDETAILES_FSAREPAY_QUERY);

					/*
					 * FinStandaloneList = aDBHelper .getTFBORepayOSFromDB(
					 * tiReferenceNo, userVo.getEventCode(),
					 * userVo.getProductCode(),
					 * ActionConstants.GETTIREFNOTRANSDETAILES_OS_FSAREPAY_QUERY
					 * );
					 */
					userVo.setFinStandaloneList(FinStandaloneList);

					setTransactionValuesInVO(userVo);
				}
			}
			// Outward Remittance changes 23/12/2019 start
			if (userVo.getProductCode().equalsIgnoreCase("CPCO")
					&& userVo.getEventCode().equalsIgnoreCase("PCOC")) {
				outwardRemittanceList = aDBHelper.getTFBOCPCOCreFromDB(
						tiReferenceNo,
						ActionConstants.GETTIREFNOTRANSDETAILS_CPCO_QUERY);
				userVo.setOutwardRemittanceList(outwardRemittanceList);
				setTransactionValuesInVO(userVo);
			}
			// Outward Remittance changes 23/12/2019 end

			// SBLC_251219
			if (userVo.getProductCode().equalsIgnoreCase("ISB")
					&& userVo.getEventCode().equalsIgnoreCase("NJIS")) {

				System.out.println("Inside ISB NJIS");
				standByLCVoList = aDBHelper.getTFBOISB_AJ_AD_CR_FrmDB(
						tiReferenceNo,
						ActionConstants.GETTIREFNOTRANSDETAILES_ISB_NJIS_QUERY);
				userVo.setStandByLCList(standByLCVoList);
				setTransactionValuesInVO(userVo);

			}
			if (userVo.getProductCode().equalsIgnoreCase("ISB")
					&& userVo.getEventCode().equalsIgnoreCase("NAIS")) {

				System.out.println("Inside ISB NJIS");
				standByLCVoList = aDBHelper.getTFBOISB_AJ_AD_CR_FrmDB(
						tiReferenceNo,
						ActionConstants.GETTIREFNOTRANSDETAILES_ISB_NAIS_QUERY);
				userVo.setStandByLCList(standByLCVoList);
				setTransactionValuesInVO(userVo);

			}
			if (userVo.getProductCode().equalsIgnoreCase("ISB")
					&& userVo.getEventCode().equalsIgnoreCase("LIS")) {

				System.out.println("Inside ISB NJIS");
				standByLCVoList = aDBHelper.getTFBOISB_AJ_AD_CR_FrmDB(
						tiReferenceNo,
						ActionConstants.GETTIREFNOTRANSDETAILES_ISB_LIS_QUERY);
				userVo.setStandByLCList(standByLCVoList);
				setTransactionValuesInVO(userVo);

			}
			if (userVo.getProductCode().equalsIgnoreCase("ISB")
					&& userVo.getEventCode().equalsIgnoreCase("OIS")) {

				userVo.setBillReferenceList(getBillReference(userVo,
						tiReferenceNo));
				logger.info("userVo.setBillReference "
						+ userVo.getBillReferenceList());

				System.out.println("Inside ISB OIS");
				standByLCVoList = aDBHelper.getTFBOISBOISTransFrmDB(
						tiReferenceNo,
						ActionConstants.GETTIREFNOTRANSDETAILES_ISB_OIS_QUERY);
				userVo.setStandByLCList(standByLCVoList);
				setTransactionValuesInVO(userVo);

			}

			// SBLC_251219_END

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		logger.info(ActionConstants.EXITING_METHOD);
		return userVo;
	}

	public String getCustomerName(String customerCif) {
		logger.info(ActionConstants.ENTERING_METHOD);
		DBHelper aDBHelper = new DBHelper();
		String customerName = "";
		CommonMethods aCommonMethods = new CommonMethods();
		try {
			if (aCommonMethods.isValueAvailable(customerCif)) {
				customerCif = customerCif.trim();
			}
			customerName = aDBHelper.getValueFromDB(customerCif,
					ActionConstants.GETCUSTOMERNAME_QUERY);
		} catch (Exception e) {
			e.printStackTrace();
			logger.info(ActionConstants.ENTERING_METHOD);
			return customerName;
		}
		logger.info(ActionConstants.EXITING_METHOD);
		return customerName;
	}

	public UserTransactionVO setTransactionValuesInVO(UserTransactionVO userVo)
			throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		List<AlertMessagesVO> errorDetailList = new LinkedList<AlertMessagesVO>();
		CommonMethods aCommonMethods = new CommonMethods();
		try {
			if (userVo.importLcList != null)
				for (TFBOImportLcVO aTFBOIlcIssueVO : userVo.importLcList) {
					userVo.tiReferanceNo = aTFBOIlcIssueVO.getTiReferenceNo();
					if (aCommonMethods.isValueAvailable(aTFBOIlcIssueVO
							.getSolID()))
						userVo.solID = aTFBOIlcIssueVO.getSolID();
					userVo.amount = aTFBOIlcIssueVO.getAmount();
					userVo.currency = aTFBOIlcIssueVO.getCurrency();
					userVo.subProductCode = aTFBOIlcIssueVO.getSubProductCode();
					if (aCommonMethods.isValueAvailable(aTFBOIlcIssueVO
							.getCustomeCif())) {
						userVo.customeCif = aTFBOIlcIssueVO.getCustomeCif();
						String customerName = getCustomerName(userVo.customeCif);
						logger.info("customerName-->" + customerName);
						if (!aCommonMethods.isValueAvailable(customerName)) {
							errorDetailList = aCommonMethods.setErrorInList(
									ActionConstants.ERRORCODE010,
									errorDetailList);
							userVo.setErrorDetailsList(errorDetailList);
							logger.info("Error for User validation-->"
									+ userVo.getErrorDetailsList().size());
							logger.info(ActionConstants.EXITING_METHOD
									+ ">>getEventList");
						}
						userVo.setCustomeName(customerName);
					}
					if (aCommonMethods.isValueAvailable(aTFBOIlcIssueVO
							.getLcType())) {
						userVo.lcType = aTFBOIlcIssueVO.getLcType();
						if (userVo.lcType.trim().equalsIgnoreCase("Usance"))
							userVo.usancePeriod = aTFBOIlcIssueVO
									.getUsancePeriod();
					}

					if (aCommonMethods.isValueAvailable(aTFBOIlcIssueVO
							.getUserRemark())) {
						userVo.userRemark = aTFBOIlcIssueVO.getUserRemark();
					}
				}
			// Miscellanous changes starts 08-01-2020
			/*
			 * if (userVo.miscellanousVOList != null) for (TFBOMiscellanousVO
			 * aTFBOMiscellanousVO : userVo.miscellanousVOList) {
			 * 
			 * logger.info(
			 * "Entering setTransactionValuesInVO method for Miscellanous");
			 * 
			 * userVo.tiReferanceNo = aTFBOMiscellanousVO .getTiReferenceNo();
			 * userVo.masReferanceNo = aTFBOMiscellanousVO .getMasReferanceNo();
			 * userVo.solID = aTFBOMiscellanousVO.getSolID(); userVo.amount =
			 * aTFBOMiscellanousVO.getAmount(); userVo.currency =
			 * aTFBOMiscellanousVO.getCurrency(); userVo.rateTaken =
			 * aTFBOMiscellanousVO.getRateTaken(); userVo.token =
			 * aTFBOMiscellanousVO.getToken(); userVo.rateTakenK =
			 * aTFBOMiscellanousVO.getRateTakenK(); userVo.rate =
			 * aTFBOMiscellanousVO.getRate(); userVo.subProductCode =
			 * aTFBOMiscellanousVO .getSubProductCode();
			 * userVo.odiSubProductType = aTFBOMiscellanousVO
			 * .getOdiSubProductType(); userVo.remarks =
			 * aTFBOMiscellanousVO.getRemarks(); if
			 * (aCommonMethods.isValueAvailable(aTFBOMiscellanousVO
			 * .getMasReferanceNo())) { userVo.masReferanceNo =
			 * aTFBOMiscellanousVO .getMasReferanceNo(); } if
			 * (aCommonMethods.isValueAvailable(aTFBOMiscellanousVO
			 * .getCustomeCif())) { userVo.customeCif =
			 * aTFBOMiscellanousVO.getCustomeCif(); String customerName =
			 * getCustomerName(userVo.customeCif); logger.info("customerName-->"
			 * + customerName); if
			 * (!aCommonMethods.isValueAvailable(customerName)) {
			 * errorDetailList = aCommonMethods.setErrorInList(
			 * ActionConstants.ERRORCODE010, errorDetailList);
			 * userVo.setErrorDetailsList(errorDetailList);
			 * logger.info("Error for User validation-->" +
			 * userVo.getErrorDetailsList().size());
			 * logger.info(ActionConstants.EXITING_METHOD + ">>getEventList"); }
			 * userVo.setCustomeName(customerName); } }
			 */
			if (userVo.miscellanousVOList != null)
				for (TFBOMiscellanousVO aTFBOMiscellanousVO : userVo.miscellanousVOList) {

					logger.info("Entering setTransactionValuesInVO method for Miscellanous");
					userVo.tiReferanceNo = aTFBOMiscellanousVO.getTiReferenceNo();
					userVo.masReferanceNo = aTFBOMiscellanousVO.getMasReferanceNo();
					userVo.solID = aTFBOMiscellanousVO.getSolID();
					userVo.amount = aTFBOMiscellanousVO.getAmount();
					userVo.currency = aTFBOMiscellanousVO.getCurrency();
					userVo.rateTaken = aTFBOMiscellanousVO.getRateTaken();
					userVo.token = aTFBOMiscellanousVO.getToken();
					userVo.rateTakenK = aTFBOMiscellanousVO.getRateTakenK();
					userVo.rate = aTFBOMiscellanousVO.getRate();
					userVo.subProductCode = aTFBOMiscellanousVO.getSubProductCode();
					userVo.odiSubProductType = aTFBOMiscellanousVO.getOdiSubProductType();
					userVo.remarks = aTFBOMiscellanousVO.getRemarks();
					
					if (aCommonMethods.isValueAvailable(aTFBOMiscellanousVO.getCustomeCif())) 
					{
						userVo.customeCif = aTFBOMiscellanousVO.getCustomeCif();
						String customerName = getCustomerName(userVo.customeCif);
						logger.info("customerName-->" + customerName);
						if (!aCommonMethods.isValueAvailable(customerName)) 
						{
							errorDetailList = aCommonMethods.setErrorInList(ActionConstants.ERRORCODE010,
									errorDetailList);
							userVo.setErrorDetailsList(errorDetailList);
							logger.info("Error for User validation-->"
									+ userVo.getErrorDetailsList().size());
							logger.info(ActionConstants.EXITING_METHOD
									+ ">>getEventList");
						}
						userVo.setCustomeName(customerName);
					}
				}
			// Miscellanous changes ends 08-01-2020
			if (userVo.exportLcList != null) {
				for (TFBOExportLcVO aTFBOExportLcVO : userVo.exportLcList) {
					userVo.tiReferanceNo = aTFBOExportLcVO.getTiReferenceNo();
					userVo.solID = aTFBOExportLcVO.getSolID();
					userVo.amount = aTFBOExportLcVO.getAmount();
					userVo.currency = aTFBOExportLcVO.getCurrency();
					userVo.lcReceivedSWIFT = aTFBOExportLcVO
							.getLCreceivedSWIFT();
					userVo.senderRefno = aTFBOExportLcVO.getSenderRefno();
					userVo.subProductCode = aTFBOExportLcVO.getSubProductCode();
					// ELC DOP Issue Fix 20-12-2019 starts
					userVo.preshipAccSetteld = aTFBOExportLcVO
							.getPreshipAccSetteld();

					userVo.financeSameDay = aTFBOExportLcVO.getFinSameDay();
					// ELC DOP Issue Fix 20-12-2019 ends
					if (aCommonMethods.isValueAvailable(aTFBOExportLcVO
							.getUsancePeriod())) {
						userVo.usancePeriod = aTFBOExportLcVO.getUsancePeriod();
					}
					// ADDED BY CHANDRU
					if (aCommonMethods.isValueAvailable(aTFBOExportLcVO
							.getRateTaken())) {
						userVo.rateTaken = aTFBOExportLcVO.getRateTaken();
						userVo.token = aTFBOExportLcVO.getToken();
						userVo.valueK = aTFBOExportLcVO.getValueK();
						userVo.rate = aTFBOExportLcVO.getRate();
						// ENDS
					}
					if (aCommonMethods.isValueAvailable(aTFBOExportLcVO
							.getUserRemark())) {
						userVo.userRemark = aTFBOExportLcVO.getUserRemark();
					}
					if (aCommonMethods.isValueAvailable(aTFBOExportLcVO
							.getBillReference())) {
						userVo.billReference = aTFBOExportLcVO
								.getBillReference();
						userVo.acceptanceAmount = aTFBOExportLcVO
								.getAcceptanceAmount();
					}
					if (aCommonMethods.isValueAvailable(aTFBOExportLcVO
							.getCustomeCif())) {
						userVo.customeCif = aTFBOExportLcVO.getCustomeCif();
						String customerName = getCustomerName(userVo.customeCif)
								.trim();
						logger.info("customerName-->" + customerName);
						if (!aCommonMethods.isValueAvailable(customerName)) {
							errorDetailList = aCommonMethods.setErrorInList(
									ActionConstants.ERRORCODE010,
									errorDetailList);
							userVo.setErrorDetailsList(errorDetailList);
							logger.info("Error for User validation-->"
									+ userVo.getErrorDetailsList().size());
							logger.info(ActionConstants.EXITING_METHOD
									+ ">>getEventList");
						}
						userVo.setCustomeName(customerName);
					}
					if (aCommonMethods.isValueAvailable(aTFBOExportLcVO
							.getLcType())) {
						userVo.lcType = aTFBOExportLcVO.getLcType();
						if (userVo.lcType.trim().equalsIgnoreCase("Usance"))
							userVo.usancePeriod = aTFBOExportLcVO
									.getUsancePeriod();
					}
				}
			}

			// Inward Remittance changes 23-12-2019 starts
			if (userVo.inwardRemittanceList != null)
				for (TFBOInwardRemittanceVO aTFBOInwardRemittanceVO : userVo.inwardRemittanceList) {
					userVo.tiReferanceNo = aTFBOInwardRemittanceVO
							.getTiReferenceNo();
					userVo.solID = aTFBOInwardRemittanceVO.getSolID();
					userVo.amount = aTFBOInwardRemittanceVO.getAmount();
					userVo.currency = aTFBOInwardRemittanceVO.getCurrency();
					/*
					 * userVo.productTypeIDC = aTFBOExportCollectionVO
					 * .getProductType();
					 */
					userVo.preshipAccSetteld = aTFBOInwardRemittanceVO
							.getPreshipAccSettled();
					userVo.rateTaken = aTFBOInwardRemittanceVO.getRateTaken();
					userVo.token = aTFBOInwardRemittanceVO.getToken();
					userVo.rateTakenK = aTFBOInwardRemittanceVO.getRateTakenK();
					userVo.rate = aTFBOInwardRemittanceVO.getRate();
					userVo.subProductCode = aTFBOInwardRemittanceVO
							.getProductType();
					userVo.dummyIrex = aTFBOInwardRemittanceVO.getDummyIrex();
					if (aCommonMethods.isValueAvailable(aTFBOInwardRemittanceVO
							.getCustomeCif())) {
						userVo.customeCif = aTFBOInwardRemittanceVO
								.getCustomeCif();
						String customerName = getCustomerName(userVo.customeCif);
						logger.info("customerName-->" + customerName);
						if (!aCommonMethods.isValueAvailable(customerName)) {
							errorDetailList = aCommonMethods.setErrorInList(
									ActionConstants.ERRORCODE010,
									errorDetailList);
							userVo.setErrorDetailsList(errorDetailList);
							logger.info("Error for User validation-->"
									+ userVo.getErrorDetailsList().size());
							logger.info(ActionConstants.EXITING_METHOD
									+ ">>getEventList");
						}
						userVo.setCustomeName(customerName);
					}
				}

			// Inward Remittance changes 23-12-2019 ends
			/* changes for rate taken starts 010120 */
			if (userVo.importGuaranteeList != null) {
				for (TFBOImportGTVO aTFBOImportGTVO : userVo.importGuaranteeList) {
					userVo.tiReferanceNo = aTFBOImportGTVO.getTiReferenceNo();
					userVo.solID = aTFBOImportGTVO.getSolID();
					userVo.amount = aTFBOImportGTVO.getAmount();
					userVo.currency = aTFBOImportGTVO.getCurrency();
					userVo.tenure = aTFBOImportGTVO.getTenure();
					userVo.expiryDate = aTFBOImportGTVO.getExpiryDate();
					userVo.guarnteeAmtPrevInv = aTFBOImportGTVO
							.getGuarnteeAmtPrevInv();
					userVo.partInvocation = aTFBOImportGTVO.getPartInvocation();
					userVo.reqInvAmt = aTFBOImportGTVO.getReqInvAmt();
					/*
					 * if (aCommonMethods.isValueAvailable(aTFBOImportGTVO
					 * .getRateTaken()) &&
					 * aTFBOImportGTVO.getRateTaken().equalsIgnoreCase( "Y"))
					 * userVo.rateTaken = "true"; else userVo.rateTaken =
					 * "false";
					 */
					userVo.rateTaken = aTFBOImportGTVO.getRateTaken();
					userVo.token = aTFBOImportGTVO.getToken();
					userVo.valueK = aTFBOImportGTVO.getValueK();
					userVo.rate = aTFBOImportGTVO.getRate();
					userVo.billReference = aTFBOImportGTVO.getBillreference();
					userVo.subProductCode = aTFBOImportGTVO.getSubProductCode();
					if (aCommonMethods.isValueAvailable(aTFBOImportGTVO
							.getCustomeCif())) {
						userVo.customeCif = aTFBOImportGTVO.getCustomeCif();
						String customerName = getCustomerName(userVo.customeCif);
						logger.info("customerName-->" + customerName);
						if (!aCommonMethods.isValueAvailable(customerName)) {
							errorDetailList = aCommonMethods.setErrorInList(
									ActionConstants.ERRORCODE010,
									errorDetailList);
							userVo.setErrorDetailsList(errorDetailList);
							logger.info("Error for User validation-->"
									+ userVo.getErrorDetailsList().size());
							logger.info(ActionConstants.EXITING_METHOD
									+ ">>getEventList");
						}
						userVo.setCustomeName(customerName);
					}
				}
			}
			/* changes for rate taken starts 010120 */
			// Outward Remittance Changes 23/12/2019 start

			if (userVo.outwardRemittanceList != null)
				for (TFBOOutwardRemittanceVO aTFBOOutwardRemittanceVO : userVo.outwardRemittanceList) {
					userVo.tiReferanceNo = aTFBOOutwardRemittanceVO
							.getTiRefNo();
					userVo.solID = aTFBOOutwardRemittanceVO.getSolID();
					userVo.amount = aTFBOOutwardRemittanceVO.getAmount();
					userVo.currency = aTFBOOutwardRemittanceVO.getCurrency();
					// Issue Fix Offshore Team 30122019 starts
					/*
					 * userVo.rateTaken =
					 * aTFBOOutwardRemittanceVO.getRateTaken();
					 */
					userVo.rateTaken = aTFBOOutwardRemittanceVO.getRateTaken();

					// Issue Fix Offshore Team 30122019 ends
					userVo.token = aTFBOOutwardRemittanceVO.getToken();
					userVo.valueK = aTFBOOutwardRemittanceVO.getValueK();
					userVo.rate = aTFBOOutwardRemittanceVO.getRate();

					// Issue Fix Offshore Team 30122019 starts
					/*
					 * userVo.bankpayment = aTFBOOutwardRemittanceVO
					 * .getBankpayment();
					 */
					if (aCommonMethods
							.isValueAvailable(aTFBOOutwardRemittanceVO
									.getBankpayment())
							&& aTFBOOutwardRemittanceVO.getBankpayment()
									.equalsIgnoreCase("Y"))
						userVo.bankpayment = "true";
					else
						userVo.bankpayment = "false";

					// Issue Fix Offshore Team 30122019 ends
					userVo.subProductCode = aTFBOOutwardRemittanceVO
							.getSubProductCode();
					if (aCommonMethods
							.isValueAvailable(aTFBOOutwardRemittanceVO
									.getCustomeCif())) {
						userVo.customeCif = aTFBOOutwardRemittanceVO
								.getCustomeCif();
						String customerName = getCustomerName(userVo.customeCif);
						logger.info("customerName-->" + customerName);
						if (!aCommonMethods.isValueAvailable(customerName)) {
							errorDetailList = aCommonMethods.setErrorInList(
									ActionConstants.ERRORCODE010,
									errorDetailList);
							userVo.setErrorDetailsList(errorDetailList);
							logger.info("Error for User validation-->"
									+ userVo.getErrorDetailsList().size());
							logger.info(ActionConstants.EXITING_METHOD
									+ ">>getEventList");
						}
						userVo.setCustomeName(customerName);
					}
				}

			// Outward Remittance Changes 23/12/2019 end

			if (userVo.exportCollectionList != null)
				for (TFBOExportCollectionVO aTFBOExportCollectionVO : userVo.exportCollectionList) {

					System.out.println(aTFBOExportCollectionVO
							.getTiReferenceNo());// 0381FBU002964121
					System.out.println(aTFBOExportCollectionVO.getSolID());// 0381
					System.out.println(aTFBOExportCollectionVO.getCustomeCif());// 000011065
					System.out.println(aTFBOExportCollectionVO.getAmount());// NULL
					System.out.println(aTFBOExportCollectionVO.getCurrency());// AED
					System.out.println(aTFBOExportCollectionVO
							.getUsancePeriod());// 90
					System.out.println(aTFBOExportCollectionVO.getDirect());// true
					System.out.println(aTFBOExportCollectionVO.getMtReceived());// Part
																				// Amount
					System.out
							.println(aTFBOExportCollectionVO.getPartPayment());// null
					System.out.println(aTFBOExportCollectionVO
							.getSubProductCode());// FBU
					System.out.println(aTFBOExportCollectionVO
							.getPreshipAccSettled());// true
					System.out.println(aTFBOExportCollectionVO
							.getDocumentDispatch());// NULL
					System.out.println(aTFBOExportCollectionVO
							.getFinanceSameDay());// Yes
					System.out.println(aTFBOExportCollectionVO.getRateTaken());// Y
					System.out.println(aTFBOExportCollectionVO
							.getShipBillFetch());// null
					System.out.println(aTFBOExportCollectionVO.getToken());// 25
					System.out.println(aTFBOExportCollectionVO.getRateTakenK());// 85
					System.out.println(aTFBOExportCollectionVO.getRate());// 45.25
					System.out.println(aTFBOExportCollectionVO.getIrexRefNo());// NULL
					System.out.println(aTFBOExportCollectionVO
							.getFinalPayment());
					System.out
							.println(aTFBOExportCollectionVO.getSenderRefno());

					// tiReferanceNo,solID,amount,currency,usancePeriod,direct,mtReceived,partPayment
					userVo.tiReferanceNo = aTFBOExportCollectionVO
							.getTiReferenceNo();

					userVo.acceptBillAmt = aTFBOExportCollectionVO
							.getAcceptBillAmt();

					userVo.solID = aTFBOExportCollectionVO.getSolID();
					if (aCommonMethods.isValueAvailable(aTFBOExportCollectionVO
							.getSenderRefno())) {
						userVo.senderRefno = aTFBOExportCollectionVO
								.getSenderRefno();
					}
					if (aCommonMethods.isValueAvailable(aTFBOExportCollectionVO
							.getAmount())) {
						userVo.amount = aTFBOExportCollectionVO.getAmount();
					}

					if (aCommonMethods.isValueAvailable(aTFBOExportCollectionVO
							.getCurrency())) {
						userVo.currency = aTFBOExportCollectionVO.getCurrency();
					}
					if (aCommonMethods.isValueAvailable(aTFBOExportCollectionVO
							.getUsancePeriod())) {
						userVo.usancePeriod = aTFBOExportCollectionVO
								.getUsancePeriod();
					}
					if (aCommonMethods.isValueAvailable(aTFBOExportCollectionVO
							.getDirect())) {
						userVo.direct = aTFBOExportCollectionVO.getDirect();
					}
					if (aCommonMethods.isValueAvailable(aTFBOExportCollectionVO
							.getMtReceived())) {
						userVo.mtReceived = aTFBOExportCollectionVO
								.getMtReceived();
					}
					if (aCommonMethods.isValueAvailable(aTFBOExportCollectionVO
							.getPartPayment())) {
						userVo.partPayment = aTFBOExportCollectionVO
								.getPartPayment();
					}
					if (aCommonMethods.isValueAvailable(aTFBOExportCollectionVO
							.getUserRemark())) {
						// USERREMARK
						userVo.userRemark = aTFBOExportCollectionVO
								.getUserRemark();
					}
					// preshipAccSetteld
					if (aCommonMethods.isValueAvailable(aTFBOExportCollectionVO
							.getPreshipAccSettled())) {
						userVo.preshipAccSetteld = aTFBOExportCollectionVO
								.getPreshipAccSettled();
					}
					// documentDispatch
					if (aCommonMethods.isValueAvailable(aTFBOExportCollectionVO
							.getDocumentDispatch())) {
						userVo.documentDispatch = aTFBOExportCollectionVO
								.getDocumentDispatch();
					}
					// financeSameDay,rateTaken,token,rateTakenK,rate,subProductCode,finalPayment,customeCif
					if (aCommonMethods.isValueAvailable(aTFBOExportCollectionVO
							.getFinanceSameDay())) {
						userVo.financeSameDay = aTFBOExportCollectionVO
								.getFinanceSameDay();
					}

					if (aCommonMethods.isValueAvailable(aTFBOExportCollectionVO
							.getRateTaken())) {
						userVo.rateTaken = aTFBOExportCollectionVO
								.getRateTaken();
					}
					if (aCommonMethods.isValueAvailable(aTFBOExportCollectionVO
							.getToken())) {
						userVo.token = aTFBOExportCollectionVO.getToken();
					}
					if (aCommonMethods.isValueAvailable(aTFBOExportCollectionVO
							.getRateTakenK())) {
						userVo.rateTakenK = aTFBOExportCollectionVO
								.getRateTakenK();
					}
					if (aCommonMethods.isValueAvailable(aTFBOExportCollectionVO
							.getRate())) {
						userVo.rate = aTFBOExportCollectionVO.getRate();
					}
					userVo.subProductCode = aTFBOExportCollectionVO
							.getProductType();
					if (aCommonMethods.isValueAvailable(aTFBOExportCollectionVO
							.getFinalPayment())) {
						userVo.finalPayment = aTFBOExportCollectionVO
								.getFinalPayment();
					}
					userVo.customeCif = aTFBOExportCollectionVO
							.getCustomeName();
					if (aCommonMethods.isValueAvailable(aTFBOExportCollectionVO
							.getCustomeCif())) {
						userVo.customeCif = aTFBOExportCollectionVO
								.getCustomeCif();
						String customerName = getCustomerName(userVo.customeCif);
						logger.info("customerName-->" + customerName);
						if (!aCommonMethods.isValueAvailable(customerName)) {
							errorDetailList = aCommonMethods.setErrorInList(
									ActionConstants.ERRORCODE010,
									errorDetailList);
							userVo.setErrorDetailsList(errorDetailList);
							logger.info("Error for User validation-->"
									+ userVo.getErrorDetailsList().size());
							logger.info(ActionConstants.EXITING_METHOD
									+ ">>getEventList");
						}
						userVo.setCustomeName(customerName);
					}
					// Rate taken Fix Offshore Team 06012020 starts
					// subProductCode,irexRefNo
					userVo.subProductCode = aTFBOExportCollectionVO
							.getSubProductCode();
					userVo.irexRefNo = aTFBOExportCollectionVO.getIrexRefNo();
					// Rate taken Fix Offshore Team 06012020 ends
					userVo.fncAmount = aTFBOExportCollectionVO.getFinAmount();
					userVo.finCurrency= aTFBOExportCollectionVO.getFinCurrency();

					System.out.println(userVo.getTiReferanceNo());//
					System.out.println(userVo.getSolID());//
					System.out.println(userVo.getCustomeCif());//
					System.out.println(userVo.getAmount());//
					System.out.println(userVo.getCurrency());//
					System.out.println(userVo.getUsancePeriod());
					System.out.println(userVo.getDirect());//
					System.out.println(userVo.getMtReceived());
					System.out.println(userVo.getPartPayment());
					System.out.println(userVo.getSubProductCode());//
					System.out.println(userVo.getPreshipAccSetteld());//
					System.out.println(userVo.getDocumentDispatch());
					System.out.println(userVo.getFinanceSameDay());
					System.out.println(userVo.getRateTaken());//
					System.out.println(userVo.getShipBillFetch());
					System.out.println(userVo.getToken());
					System.out.println(userVo.getRateTakenK());//
					System.out.println(userVo.getRate());
					System.out.println(userVo.getIrexRefNo());
					System.out.println(userVo.getSenderRefno());

				}
			if (userVo.importIdcList != null)
				for (TFBOIdcVO aTFBOIdcVO : userVo.importIdcList) {
					userVo.tiReferanceNo = aTFBOIdcVO.getTiReferanceNo();
					userVo.solID = aTFBOIdcVO.getSolID();
					userVo.billAmount = aTFBOIdcVO.getBillAmount();
					userVo.acceptBillAmt = aTFBOIdcVO.getAcceptBillAmt();
					userVo.currency = aTFBOIdcVO.getCurrency();
					userVo.billUsancePeriod = aTFBOIdcVO.getBillUsancePeriod();
					userVo.direct = aTFBOIdcVO.getDirect();
					userVo.partpay = aTFBOIdcVO.getPartpay();
					// FREEZING(SCENARIO) off shore team STARTS 070120
					userVo.setDirectCREEvent(aTFBOIdcVO.getDirectCREEvent());
					// FREEZING(SCENARIO) off shore team STARTS 070120
					// changes
					userVo.subProductCode = aTFBOIdcVO.getSubProductCode();
					//

					if (aCommonMethods.isValueAvailable(aTFBOIdcVO.getAmount())) {
						userVo.amount = aTFBOIdcVO.getAmount();
						// userVo.subProductCode =
						// aTFBOIdcVO.getSubProductCode();
					}
					if (aCommonMethods.isValueAvailable(aTFBOIdcVO
							.getUserRemark())) {
						userVo.userRemark = aTFBOIdcVO.getUserRemark();
					}
					if (aCommonMethods.isValueAvailable(aTFBOIdcVO
							.getRateTaken())) {
						userVo.token = aTFBOIdcVO.getToken();
						userVo.valueK = aTFBOIdcVO.getValueK();
						userVo.rate = aTFBOIdcVO.getRate();
						userVo.rateTaken = aTFBOIdcVO.getRateTaken().trim();
					}

					if (aCommonMethods.isValueAvailable(aTFBOIdcVO
							.getCustomeCif())) {
						userVo.customeCif = aTFBOIdcVO.getCustomeCif();
						String customerName = getCustomerName(userVo.customeCif);
						System.out.println("customerName-->" + customerName);
						if (!aCommonMethods.isValueAvailable(customerName)) {
							errorDetailList = aCommonMethods.setErrorInList(
									ActionConstants.ERRORCODE010,
									errorDetailList);
							userVo.setErrorDetailsList(errorDetailList);
							System.out.println("Error for User validation-->"
									+ userVo.getErrorDetailsList().size());
							System.out.println(ActionConstants.EXITING_METHOD
									+ ">>getEventList");
						}
						userVo.setCustomeName(customerName);
					}
				}
			if (userVo.financeExportLCList != null) {
				for (TFBOFinanceExportLcVO aTFBOFelVO : userVo.financeExportLCList) {
					userVo.lcRefNum = aTFBOFelVO.getLCRefNum();
					/*
					 * if (aCommonMethods.isValueAvailable(userVo.lcRefNum) &&
					 * aCommonMethods .isValueAvailable(userVo.billReferenceNo))
					 * { userVo.setBillReferenceList(getBillReference(userVo,
					 * userVo.lcRefNum)); }
					 */
					userVo.amount = aTFBOFelVO.getAmount();
					if (aCommonMethods.isValueAvailable(aTFBOFelVO
							.getBillReferenceNo()))
						userVo.billReferenceNo = aTFBOFelVO
								.getBillReferenceNo();
					userVo.rate = aTFBOFelVO.getRate();
					if (aCommonMethods.isValueAvailable(aTFBOFelVO
							.getFncAmount()))
						userVo.fncAmount = aTFBOFelVO.getFncAmount();
					if (aCommonMethods.isValueAvailable(aTFBOFelVO
							.getRateTaken()))
						userVo.rateTaken = aTFBOFelVO.getRateTaken();
					if (aCommonMethods.isValueAvailable(aTFBOFelVO
							.getRateTakenK()))
						userVo.rateTakenK = aTFBOFelVO.getRateTakenK();
					if (aCommonMethods.isValueAvailable(aTFBOFelVO.getSolID()))
						userVo.solID = aTFBOFelVO.getSolID();
					userVo.subProductCode = aTFBOFelVO.getSubProductCode();
					if (aCommonMethods.isValueAvailable(aTFBOFelVO.getToken()))
						userVo.token = aTFBOFelVO.getToken();
					userVo.billTenure = aTFBOFelVO.getBillTenure();
					userVo.currency = aTFBOFelVO.getCurrency();
					userVo.customeCif = aTFBOFelVO.getCustomeCif();
					userVo.customeName = aTFBOFelVO.getCustomeName();
					userVo.maturityDate = aTFBOFelVO.getMaturityDate();
					userVo.finalPayment = aTFBOFelVO.getFinalPayment();
					// COMMENTED BY CHANDRU
					// userVo.preshipAcc = aTFBOFelVO.getPreshipAcc();
					userVo.preshipAccSetteld = aTFBOFelVO.getPreshipAcc();

					userVo.senderRefno = aTFBOFelVO.getSenderRefNo();
					if (aCommonMethods.isValueAvailable(aTFBOFelVO
							.getUserRemark())) {
						userVo.userRemark = aTFBOFelVO.getUserRemark();
					}
				}
			}
			if (userVo.FinExportCollectionList != null)
				for (TFBOFinanceExportColVO aTFBOFinanceExportColVO : userVo.FinExportCollectionList) {
					userVo.tiReferanceNo = aTFBOFinanceExportColVO
							.getTiReferenceNo();
					userVo.solID = aTFBOFinanceExportColVO.getSolID();
					userVo.amount = aTFBOFinanceExportColVO.getAmount();
					userVo.currency = aTFBOFinanceExportColVO.getCurrency();
					userVo.usancePeriod = aTFBOFinanceExportColVO
							.getUsancePeriod();
					if (aCommonMethods.isValueAvailable(aTFBOFinanceExportColVO
							.getPreshipAccSettled())) {
						userVo.preshipAccSetteld = aTFBOFinanceExportColVO
								.getPreshipAccSettled();
					}
					if (aCommonMethods.isValueAvailable(aTFBOFinanceExportColVO
							.getSenderRefno())) {
						userVo.senderRefNo = aTFBOFinanceExportColVO
								.getSenderRefno();
					}

					System.out.println("Sub-product Code-->"
							+ aTFBOFinanceExportColVO.getSubProductCode());
					userVo.subProductCode = aTFBOFinanceExportColVO
							.getSubProductCode();

					userVo.rateTaken = aTFBOFinanceExportColVO.getRateTaken();
					userVo.token = aTFBOFinanceExportColVO.getToken();
					userVo.rateTakenK = aTFBOFinanceExportColVO.getRateTakenK();
					userVo.rate = aTFBOFinanceExportColVO.getRate();
					userVo.financeAmount = aTFBOFinanceExportColVO
							.getFinanceAmount();
					userVo.finalPayment = aTFBOFinanceExportColVO
							.getFinalRepay();
					userVo.maturityDate = aTFBOFinanceExportColVO
							.getMaturityDate();
					if (aCommonMethods.isValueAvailable(aTFBOFinanceExportColVO
							.getUserRemark())) {
						userVo.userRemark = aTFBOFinanceExportColVO
								.getUserRemark();
					}
					if (aCommonMethods.isValueAvailable(aTFBOFinanceExportColVO
							.getCustomeCif())) {
						userVo.customeCif = aTFBOFinanceExportColVO
								.getCustomeCif();
						String customerName = getCustomerName(userVo.customeCif);
						logger.info("customerName-->" + customerName);
						if (!aCommonMethods.isValueAvailable(customerName)) {
							errorDetailList = aCommonMethods.setErrorInList(
									ActionConstants.ERRORCODE010,
									errorDetailList);
							userVo.setErrorDetailsList(errorDetailList);
							logger.info("Error for User validation-->"
									+ userVo.getErrorDetailsList().size());
							logger.info(ActionConstants.EXITING_METHOD
									+ ">>getEventList");
						}
						userVo.setCustomeName(customerName);
					}
				}
			if (userVo.FinStandaloneList != null)
				for (TFBOFinanceStandaloneVO aTFBOFinanceStandaloneVO : userVo.FinStandaloneList) {
					userVo.tiReferanceNo = aTFBOFinanceStandaloneVO
							.getTiReferenceNo();
					userVo.solID = aTFBOFinanceStandaloneVO.getSolID();
					userVo.amount = aTFBOFinanceStandaloneVO.getAmount();
					userVo.currency = aTFBOFinanceStandaloneVO.getCurrency();
					userVo.usancePeriod = aTFBOFinanceStandaloneVO
							.getUsancePeriod();
					System.out.println("Sub-product Code-->"
							+ aTFBOFinanceStandaloneVO.getSubProductCode());
					userVo.subProductCode = aTFBOFinanceStandaloneVO
							.getSubProductCode();
					userVo.rateTaken = aTFBOFinanceStandaloneVO.getRateTaken();
					userVo.token = aTFBOFinanceStandaloneVO.getToken();
					userVo.rateTakenK = aTFBOFinanceStandaloneVO
							.getRateTakenK();
					userVo.maturityDate = aTFBOFinanceStandaloneVO
							.getMaturityDate();
					userVo.pcAmount = aTFBOFinanceStandaloneVO.getPcAmount();
					userVo.partliqu = aTFBOFinanceStandaloneVO.getPartLiqu();

					userVo.rate = aTFBOFinanceStandaloneVO.getRate();
					if (aCommonMethods
							.isValueAvailable(aTFBOFinanceStandaloneVO
									.getCustomeCif())) {
						userVo.customeCif = aTFBOFinanceStandaloneVO
								.getCustomeCif();
						String customerName = getCustomerName(userVo.customeCif);
						logger.info("customerName-->" + customerName);
						if (!aCommonMethods.isValueAvailable(customerName)) {
							errorDetailList = aCommonMethods.setErrorInList(
									ActionConstants.ERRORCODE010,
									errorDetailList);
							userVo.setErrorDetailsList(errorDetailList);
							logger.info("Error for User validation-->"
									+ userVo.getErrorDetailsList().size());
							logger.info(ActionConstants.EXITING_METHOD
									+ ">>getEventList");
						}
						userVo.setCustomeName(customerName);
					}
				}
			// SBLC_251219
			if (userVo.standByLCList != null)
				for (TFBOSandbyLcVO aTFBOSandbyLcVO : userVo.standByLCList) {

					userVo.tiReferanceNo = aTFBOSandbyLcVO.getTiReferanceNo();
					userVo.solID = aTFBOSandbyLcVO.getSolID();
					if (aCommonMethods.isValueAvailable(aTFBOSandbyLcVO
							.getCustomeCif())) {
						userVo.customeCif = aTFBOSandbyLcVO.getCustomeCif();
						String customerName = getCustomerName(userVo.customeCif);
						System.out.println("customerName-->" + customerName);
						if (!aCommonMethods.isValueAvailable(customerName)) {
							errorDetailList = aCommonMethods.setErrorInList(
									ActionConstants.ERRORCODE010,
									errorDetailList);
							userVo.setErrorDetailsList(errorDetailList);
							System.out.println("Error for User validation-->"
									+ userVo.getErrorDetailsList().size());
							System.out.println(ActionConstants.EXITING_METHOD
									+ ">>getEventList");
						}
						userVo.setCustomeName(customerName);
					}
					if (!aCommonMethods.isValueAvailable(aTFBOSandbyLcVO
							.getTenure())) {
						userVo.tenure = aTFBOSandbyLcVO.getTenure();
					}

					// public static String GETTFBOISBOIS_QUERY =
					// "SELECT TRANS.TIREFERANCE,OIS.SOLID,OIS.CNFBILLREFNO,OIS.CUSTOMERCIF,OIS.CUST_NAME,OIS.AMOUNT,OIS.CURRENCY,OIS.TENURE,OIS.BILLREFNO,OIS.BGREFNO,OIS.PROD_TYPE FROM TFBO_TRANS TRANS,TFBO_ISB_OUTSTDCLM OIS WHERE TRANS.REQUESTID = OIS.REQUESTID AND TRIM(TRANS.REQUESTID)=?";
					userVo.amount = aTFBOSandbyLcVO.getAmount();
					userVo.currency = aTFBOSandbyLcVO.getCurrency();
					userVo.billUsancePeriod = aTFBOSandbyLcVO
							.getBillUsancePeriod();
					userVo.rateTaken = aTFBOSandbyLcVO.getRateTaken();
					userVo.token = aTFBOSandbyLcVO.getToken();
					userVo.valueK = aTFBOSandbyLcVO.getValueK();
					userVo.rate = aTFBOSandbyLcVO.getRate();
					userVo.subProductCode = aTFBOSandbyLcVO.getSubProductCode();
					userVo.bgRefNo = aTFBOSandbyLcVO.getBgRefNo();
					userVo.billrefno = aTFBOSandbyLcVO.getBillrefno();
					userVo.ConBillRef = aTFBOSandbyLcVO.getConBillRef();
					userVo.billReference = aTFBOSandbyLcVO.getBillreference();

				}

			// SBLC_251219_END

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		logger.info(ActionConstants.EXITING_METHOD);
		return userVo;
	}

	public UserTransactionVO getTransactionValues(UserTransactionVO userVo)
			throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		DBHelper aDBHelper = new DBHelper();
		CommonMethods aCommonMethods = new CommonMethods();
		try {
			if (userVo.getProductCodeGridValue().equalsIgnoreCase("ILC")) {

				if (userVo.getEventCodeGridValue().equalsIgnoreCase("COI")) {
					List<TFBOImportLcVO> importLcVOList = new LinkedList<TFBOImportLcVO>();
					importLcVOList = aDBHelper.getTFBOIImportLCCOIFromDB(
							userVo.getRequestId(),
							ActionConstants.GETTFBOILCCOI_QUERY, userVo);
					userVo.setImportLcList(importLcVOList);
				}
				if (userVo.getEventCodeGridValue().equalsIgnoreCase("ISI")) {
					List<TFBOImportLcVO> importLcVOList = new LinkedList<TFBOImportLcVO>();

					importLcVOList = aDBHelper.getTFBOIImportLCISSFromDB(
							userVo.getRequestId(),
							ActionConstants.GETTFBOILCISS_QUERY);
					userVo.setImportLcList(importLcVOList);
				}
				if (userVo.getEventCodeGridValue().equalsIgnoreCase("NAMI")) {
					List<TFBOImportLcVO> importLcVOList = new LinkedList<TFBOImportLcVO>();
					importLcVOList = aDBHelper.getTFBOIImportLCAMDFromDB(
							userVo.getRequestId(),
							ActionConstants.GETTFBOILCAMD_QUERY);
					userVo.setImportLcList(importLcVOList);
				}
				if (userVo.getEventCodeGridValue().equalsIgnoreCase("CRC")) {
					List<TFBOImportLcVO> importLcVOList = new LinkedList<TFBOImportLcVO>();
					importLcVOList = aDBHelper.getTFBOIImportLCCRCFromDB(
							userVo.getRequestId(),
							ActionConstants.GETTFBOILCCLMRVD_QUERY, userVo);
					userVo.setImportLcList(importLcVOList);
					logger.info("userVo.getBillAmount() >>-->"
							+ userVo.getBillAmount());
					logger.info("userVo.getBillUsancePeriod() >>-->"
							+ userVo.getBillUsancePeriod());
				}
				// Expiry,closure,cancellation Changes Starts
				if (userVo.getEventCodeGridValue().equalsIgnoreCase("EXI")) {
					List<TFBOImportLcVO> importLcVOList = new LinkedList<TFBOImportLcVO>();

					importLcVOList = aDBHelper.getTFBOIImportLCEXPFromDB(
							userVo.getRequestId(),
							ActionConstants.GETTFBOILCEXP_QUERY);
					userVo.setImportLcList(importLcVOList);
				}
				// Expiry,closure,cancellation Changes Ends
				if (userVo.getEventCodeGridValue().equalsIgnoreCase("POCA")) {
					List<TFBOImportLcVO> importLcVOList = new LinkedList<TFBOImportLcVO>();
					importLcVOList = aDBHelper.getTFBOIImportLCPOCAFromDB(
							userVo.getRequestId(),
							ActionConstants.GETTFBOILCOSCLMACC_QUERY, userVo);
					userVo.setImportLcList(importLcVOList);
					if (aCommonMethods.isValueAvailable(userVo
							.getTiReferanceNo())) {
						// Bill reference Changes 10012020 starts
						userVo.setBillReferenceList(getBillReference(userVo,
								userVo.getTiReferanceNo()));
						// Bill reference Changes 10012020 ends
					}

				}
				if (userVo.getEventCodeGridValue().equalsIgnoreCase("POCP")) {
					List<TFBOImportLcVO> importLcVOList = new LinkedList<TFBOImportLcVO>();
					importLcVOList = aDBHelper.getTFBOIImportLCPOCPFromDB(
							userVo.getRequestId(),
							ActionConstants.GETTFBOILCOSCLMPAY_QUERY, userVo);
					userVo.setImportLcList(importLcVOList);
					if (aCommonMethods.isValueAvailable(userVo
							.getTiReferanceNo())) {
						// Bill reference Changes 10012020 starts
						userVo.setBillReferenceList(getBillReference(userVo,
								userVo.getTiReferanceNo()));
						// Bill reference Changes 10012020 ends
					}
				}
				if (userVo.getEventCodeGridValue().equalsIgnoreCase("POCD")) {
					List<TFBOImportLcVO> importLcVOList = new LinkedList<TFBOImportLcVO>();
					importLcVOList = aDBHelper.getTFBOIImportLCPOCDFromDB(
							userVo.getRequestId(),
							ActionConstants.GETTFBOILCOSCLMDEV_QUERY, userVo);
					userVo.setImportLcList(importLcVOList);
					if (aCommonMethods.isValueAvailable(userVo
							.getTiReferanceNo())) {
						// Bill reference Changes 10012020 starts
						userVo.setBillReferenceList(getBillReference(userVo,
								userVo.getTiReferanceNo()));
						// Bill reference Changes 10012020 ends
					}
				}
			}
			// Miscellanous changes starts 08-01-2020
			if (userVo.getProductCodeGridValue().equalsIgnoreCase("COR")) {
				if (userVo.getEventCodeGridValue().equalsIgnoreCase("CRCR")) {
					List<TFBOMiscellanousVO> miscellanousVOList = new LinkedList<TFBOMiscellanousVO>();
					logger.info("Entering getTransactionValues method for miscellanous==> ");
					miscellanousVOList = aDBHelper.getTFBOMiscellanousFromDB(
							userVo.getRequestId(),
							ActionConstants.GETTFBOMISCELLANOUSCRE_QUERY);
					userVo.setMiscellanousVOList(miscellanousVOList);
				}
			}
			// Miscellanous changes ends 08-01-2020

			// Inward Remittance changes 23-12-2019 starts
			if (userVo.getProductCodeGridValue().equalsIgnoreCase("CPCI")) {
				if (userVo.getEventCodeGridValue().equalsIgnoreCase("PCIC")) {
					List<TFBOInwardRemittanceVO> inwardRemittanceList = new LinkedList<TFBOInwardRemittanceVO>();
					inwardRemittanceList = aDBHelper
							.getTFBOInwardRemittanceFromDB(
									userVo.getRequestId(),
									ActionConstants.GETTFBOINWARDREMITTANCECRE_QUERY);
					userVo.setInwardRemittanceList(inwardRemittanceList);
				}
			}
			// Inward Remittance changes 23-12-2019 ends
			// changes for ELC and IGT starts here 27-12-19
			if (userVo.getProductCodeGridValue().equalsIgnoreCase("IGT")) {
				if (userVo.getEventCodeGridValue().equalsIgnoreCase("IIG")) {
					List<TFBOImportGTVO> importGTVoList = new LinkedList<TFBOImportGTVO>();

					importGTVoList = aDBHelper.getTFBOGTIIGFromDB(
							userVo.getRequestId(),
							ActionConstants.GETTFBOIGTIIG_QUERY);
					userVo.setImportGuaranteeList(importGTVoList);
				}
				if (userVo.getEventCodeGridValue().equalsIgnoreCase("NAIG")) {
					List<TFBOImportGTVO> importGTVoList = new LinkedList<TFBOImportGTVO>();

					importGTVoList = aDBHelper.getTFBOGTNAIGFromDB(
							userVo.getRequestId(),
							ActionConstants.GETTFBOIGTNAIG_QUERY);
					userVo.setImportGuaranteeList(importGTVoList);
				}
				if (userVo.getEventCodeGridValue().equalsIgnoreCase("XIG")) {
					List<TFBOImportGTVO> importGTVoList = new LinkedList<TFBOImportGTVO>();

					importGTVoList = aDBHelper.getTFBOIGTExpireFromDB(
							userVo.getRequestId(),
							ActionConstants.GETTFBOIGT_XIG_QUERY);
					userVo.setImportGuaranteeList(importGTVoList);

				}
				if (userVo.getEventCodeGridValue().equalsIgnoreCase("LIG")) {
					List<TFBOImportGTVO> importGTVoList = new LinkedList<TFBOImportGTVO>();

					importGTVoList = aDBHelper.getTFBOGTLIGFromDB(
							userVo.getRequestId(),
							ActionConstants.GETTFBOIGTLIG_QUERY);
					userVo.setImportGuaranteeList(importGTVoList);
				}
				// Expiry,closure,cancellation Changes Starts
				if (userVo.getEventCodeGridValue().equalsIgnoreCase("NIG")) {
					List<TFBOImportGTVO> importGTVoList = new LinkedList<TFBOImportGTVO>();

					importGTVoList = aDBHelper.getTFBOIGTCANFromDB(
							userVo.getRequestId(),
							ActionConstants.GETTFBOIGTCAN_QUERY);
					userVo.setImportGuaranteeList(importGTVoList);
				}

				if (userVo.getEventCodeGridValue().equalsIgnoreCase("KIG")) {
					List<TFBOImportGTVO> importGTVoList = new LinkedList<TFBOImportGTVO>();

					importGTVoList = aDBHelper.getTFBOIGTKIGFromDB(
							userVo.getRequestId(),
							ActionConstants.GETTFBOIGTKIG_QUERY);
					userVo.setImportGuaranteeList(importGTVoList);
				}
				// Expiry,closure,cancellation Changes Ends
				/* changes for rate taken starts 010120 */
				if (userVo.getEventCodeGridValue().equalsIgnoreCase("OIG")) {
					List<TFBOImportGTVO> importGTVoList = new LinkedList<TFBOImportGTVO>();

					importGTVoList = aDBHelper.getTFBOGTOIGFromDB(
							userVo.getRequestId(),
							ActionConstants.GETTFBOIGTOIG_QUERY);
					userVo.setImportGuaranteeList(importGTVoList);
					if (aCommonMethods.isValueAvailable(userVo
							.getTiReferanceNo())) {
						// Bill reference Changes 10012020 starts
						userVo.setBillReferenceList(getBillReference(userVo,
								userVo.getTiReferanceNo()));
						// Bill reference Changes 10012020 ends
					}
				}
				/* changes for rate taken ends 010120 */
			}
			// changes for ELC and IGT ends here 27-12-19
			// Outward Remittance Changes 23/12/2019 start

			if (userVo.getProductCodeGridValue().equalsIgnoreCase("CPCO")) {
				if (userVo.getEventCodeGridValue().equalsIgnoreCase("PCOC")) {
					System.out.println("Inside CPCO IF==>");
					List<TFBOOutwardRemittanceVO> outwardRemittanceList = new LinkedList<TFBOOutwardRemittanceVO>();
					outwardRemittanceList = aDBHelper.getTFBOCPCOCREFromDB(
							userVo.getRequestId(),
							ActionConstants.GETTFBOCPCOCRE_QUERY);

					userVo.setOutwardRemittanceList(outwardRemittanceList);
				}
			}

			// Outward Remittance Changes 23/12/2019 end

			if (userVo.getProductCodeGridValue().equalsIgnoreCase("ODC")) {
				if (userVo.getEventCodeGridValue().equalsIgnoreCase("CRE")) {
					List<TFBOExportCollectionVO> exportCollectionList = new LinkedList<TFBOExportCollectionVO>();
					exportCollectionList = aDBHelper.getTFBOIODCCREFromDB(
							userVo.getRequestId(),
							ActionConstants.GETTFBOODCCRE_QUERY);

					userVo.setExportCollectionList(exportCollectionList);
				}
				if (userVo.getEventCodeGridValue().equalsIgnoreCase("CLP")) {
					List<TFBOExportCollectionVO> exportCollectionList = new LinkedList<TFBOExportCollectionVO>();
					exportCollectionList = aDBHelper.getTFBOIODCPAYFromDB(
							userVo.getRequestId(),
							ActionConstants.GETTFBOODCCLP_QUERY);
					userVo.setExportCollectionList(exportCollectionList);
				}
				// CHANGES FOR ODC CAC 08012020 NY SAI STARTS HERE
				/*
				 * if (userVo.getEventCodeGridValue().equalsIgnoreCase("CAC")) {
				 * List<TFBOExportCollectionVO> exportCollectionList = new
				 * LinkedList<TFBOExportCollectionVO>(); exportCollectionList =
				 * aDBHelper.getTFBOODCPAYFromDB( userVo.getRequestId(),
				 * ActionConstants.getTFBOIODCCACFromDB);
				 * userVo.setExportCollectionList(exportCollectionList); }
				 */
				if (userVo.getEventCodeGridValue().equalsIgnoreCase("CAC")) {
					List<TFBOExportCollectionVO> exportCollectionList = new LinkedList<TFBOExportCollectionVO>();
					exportCollectionList = aDBHelper.getTFBOIODCCACFromDB(
							userVo.getRequestId(),
							ActionConstants.GETTFBOODCCAC_QUERY);
					userVo.setExportCollectionList(exportCollectionList);
				}
				if (userVo.getEventCodeGridValue().equalsIgnoreCase("CCO")) {
					List<TFBOExportCollectionVO> exportCollectionList = new LinkedList<TFBOExportCollectionVO>();
					exportCollectionList = aDBHelper.getTFBOIODCCCOFromDB(
							userVo.getRequestId(),
							ActionConstants.GETTFBOODCCCO_QUERY);
					userVo.setExportCollectionList(exportCollectionList);
				}
				// CHANGES FOR ODC CAC 08012020 NY SAI ENDS HERE
			}
			// FOC -Create
			if (userVo.getProductCodeGridValue().equalsIgnoreCase("FOC")) {
				if (userVo.getEventCodeGridValue().equalsIgnoreCase("CSA1")) {
					List<TFBOFinanceExportColVO> FinExportCollectionList = new LinkedList<TFBOFinanceExportColVO>();
					FinExportCollectionList = aDBHelper.getTFBOIFOCCSA1FromDB(
							userVo.getRequestId(),
							ActionConstants.GETTFBOFOCCRE_QUERY);
					userVo.setFinExportCollectionList(FinExportCollectionList);
				}
				if (userVo.getEventCodeGridValue().equalsIgnoreCase("JSA1")) {
					List<TFBOFinanceExportColVO> FinExportCollectionList = new LinkedList<TFBOFinanceExportColVO>();
					FinExportCollectionList = aDBHelper
							.getTFBOIFOCADJUSTFromDB(userVo.getRequestId(),
									ActionConstants.GETTFBOFOCADJ_QUERY);
					userVo.setFinExportCollectionList(FinExportCollectionList);
				}

				if (userVo.getEventCodeGridValue().equalsIgnoreCase("RSA1")) {
					List<TFBOFinanceExportColVO> FinExportCollectionList = new LinkedList<TFBOFinanceExportColVO>();
					FinExportCollectionList = aDBHelper.getTFBOIFOCREPAYFromDB(
							userVo.getRequestId(),
							ActionConstants.GETTFBOFOCREPAY_QUERY);
					userVo.setFinExportCollectionList(FinExportCollectionList);
				}

				if (userVo.getEventCodeGridValue().equalsIgnoreCase("CRYST")) {
					List<TFBOFinanceExportColVO> FinExportCollectionList = new LinkedList<TFBOFinanceExportColVO>();
					FinExportCollectionList = aDBHelper.getTFBOIFOCCRYSTFromDB(
							userVo.getRequestId(),
							ActionConstants.GETTFBOFOCCRYS_QUERY);
					userVo.setFinExportCollectionList(FinExportCollectionList);
				}
				if (userVo.getEventCodeGridValue().equalsIgnoreCase("PSA1")) {
					List<TFBOFinanceExportColVO> FinExportCollectionList = new LinkedList<TFBOFinanceExportColVO>();
					FinExportCollectionList = aDBHelper.getTFBOFOCPSA1FromDB(
							userVo.getRequestId(),
							ActionConstants.GETTFBOFOCPSA1_QUERY);
					userVo.setFinExportCollectionList(FinExportCollectionList);
				}
			}
			if (userVo.getProductCodeGridValue().equalsIgnoreCase("ELC")) {
				if (userVo.getEventCodeGridValue().equalsIgnoreCase("ADE")) {
					List<TFBOExportLcVO> exportLcVoList = new LinkedList<TFBOExportLcVO>();
					exportLcVoList = aDBHelper.getTFBOExportLCADEFromDB(
							userVo.getRequestId(),
							ActionConstants.GETTFBOELCADE_QUERY);
					userVo.setExportLcList(exportLcVoList);
				}
				if (userVo.getEventCodeGridValue().equalsIgnoreCase("NAME")) {
					List<TFBOExportLcVO> exportLcVoList = new LinkedList<TFBOExportLcVO>();
					exportLcVoList = aDBHelper.getTFBOExportLCAMDFromDB(
							userVo.getRequestId(),
							ActionConstants.GETTFBOELCAMD_QUERY);
					userVo.setExportLcList(exportLcVoList);
				}
				if (userVo.getEventCodeGridValue().equalsIgnoreCase("COE")) {
					List<TFBOExportLcVO> exportLcVoList = new LinkedList<TFBOExportLcVO>();
					exportLcVoList = aDBHelper.getTFBOExportLCCOEFromDB(
							userVo.getRequestId(),
							ActionConstants.GETTFBOLCCOE_QUERY, userVo);
					userVo.setExportLcList(exportLcVoList);

				}
				// Expiry,closure,cancellation Changes Starts
				if (userVo.getEventCodeGridValue().equalsIgnoreCase("EXP")) {
					List<TFBOExportLcVO> exportLcVoList = new LinkedList<TFBOExportLcVO>();

					exportLcVoList = aDBHelper.getTFBOIExportLCEXPFromDB(
							userVo.getRequestId(),
							ActionConstants.GETTFBOELCEXP_QUERY);
					userVo.setExportLcList(exportLcVoList);
				}
				// Expiry,closure,cancellation Changes Ends
				// ELC DOP Issue Fix 20-12-2019 starts
				if (userVo.getEventCodeGridValue().equalsIgnoreCase("DOP")) {
					List<TFBOExportLcVO> exportLcVoList = new LinkedList<TFBOExportLcVO>();
					exportLcVoList = aDBHelper.getTFBOExportLCDOPFromDB(
							userVo.getRequestId(),
							ActionConstants.GETTFBOELCDPO_QUERY);
					userVo.setExportLcList(exportLcVoList);
				}
				// ELC DOP Issue Fix 20-12-2019 ends
				// Changes for ELC and IGT Starts here 27-12-19
				if (userVo.getEventCodeGridValue().equalsIgnoreCase("PODA")) {
					List<TFBOExportLcVO> exportLcVoList = new LinkedList<TFBOExportLcVO>();
					exportLcVoList = aDBHelper.getTFBOExportLCPODAFromDB(
							userVo.getRequestId(),
							ActionConstants.GETTFBOELCPODA_QUERY);
					userVo.setExportLcList(exportLcVoList);
					if (aCommonMethods.isValueAvailable(userVo
							.getTiReferanceNo())) {
						// Bill reference Changes 10012020 starts
						userVo.setBillReferenceList(getBillReference(userVo,
								userVo.getTiReferanceNo()));
						// Bill reference Changes 10012020 ends
					}
				}
				if (userVo.getEventCodeGridValue().equalsIgnoreCase("PODP")) {
					List<TFBOExportLcVO> exportLcVoList = new LinkedList<TFBOExportLcVO>();
					exportLcVoList = aDBHelper.getTFBOExportLCPODPFromDB(
							userVo.getRequestId(),
							ActionConstants.GETTFBOELCPODP_QUERY);
					userVo.setExportLcList(exportLcVoList);
					if (aCommonMethods.isValueAvailable(userVo
							.getTiReferanceNo())) {
						// Bill reference Changes 10012020 starts
						userVo.setBillReferenceList(getBillReference(userVo,
								userVo.getTiReferanceNo()));
						// Bill reference Changes 10012020 ends
					}
				}
				// Changes for ELC and IGT ends here 27-12-19

			}
			if (userVo.getProductCodeGridValue().equalsIgnoreCase("IDC")) {
				if (userVo.getEventCodeGridValue().equalsIgnoreCase("CRE")) {

					List<TFBOIdcVO> importIDCVOList = new LinkedList<TFBOIdcVO>();
					importIDCVOList = aDBHelper.getTFBOIImportIDCCREFromDB(
							userVo.getRequestId(),
							ActionConstants.GETTFBOIDCCRE_QUERY);
					userVo.setImportIdcList(importIDCVOList);
				}
				if (userVo.getEventCodeGridValue().equalsIgnoreCase("CAC")) {

					List<TFBOIdcVO> importIDCVOList = new LinkedList<TFBOIdcVO>();
					importIDCVOList = aDBHelper.getTFBOIImportIDCCACFromDB(
							userVo.getRequestId(),
							ActionConstants.GETTFBOIDCCAC_QUERY);
					userVo.setImportIdcList(importIDCVOList);
				}
				/*
				 * if (userVo.getEventCodeGridValue().equalsIgnoreCase("CLP")) {
				 * 
				 * List<TFBOIdcVO> importIDCVOList = new
				 * LinkedList<TFBOIdcVO>(); importIDCVOList =
				 * aDBHelper.getTFBOIImportIDCCLPFromDB( userVo.getRequestId(),
				 * ActionConstants.GETTFBOIDCCLP_QUERY);
				 * userVo.setImportIdcList(importIDCVOList);
				 * 
				 * }
				 */
				if (userVo.getEventCodeGridValue().equalsIgnoreCase("CCO")) {
					List<TFBOIdcVO> importIDCVOList = new LinkedList<TFBOIdcVO>();
					importIDCVOList = aDBHelper
							.getTFBOImportIDCCCODetailsFromDB(
									userVo.getRequestId(),
									ActionConstants.GETTFBOIDCCCO_QUERY);
					userVo.setImportIdcList(importIDCVOList);
				}
				if (userVo.getEventCodeGridValue().equalsIgnoreCase("CLP")) {

					List<TFBOIdcVO> importIDCVOList = new LinkedList<TFBOIdcVO>();
					importIDCVOList = aDBHelper
							.getTFBOIImportIDCCLPDetailsFromDB(
									userVo.getRequestId(),
									ActionConstants.GETTFBOIDCCLP_QUERY);
					userVo.setImportIdcList(importIDCVOList);

				}
			}
			if (userVo.getProductCodeGridValue().equalsIgnoreCase("FEL")) {
				if (userVo.getEventCodeGridValue().equalsIgnoreCase("CSA4")) {
					List<TFBOFinanceExportLcVO> financeExportLC = new LinkedList<TFBOFinanceExportLcVO>();
					financeExportLC = aDBHelper.getTFBOFELCREFromDB(
							userVo.getRequestId(),
							ActionConstants.GETTFBOFELCRE_QUERY);
					String lcReference = aDBHelper
							.getLCReference("SELECT TIREFERENCENO "
									+ " FROM TFBO_FEL_CREATE "
									+ " WHERE REQUESTID = '"
									+ userVo.getRequestId() + "' ");
					// Bill reference Changes 10012020 starts
					userVo.setBillReferenceList(getBillReference(userVo,
							lcReference));
					// Bill reference Changes 10012020 ends
					userVo.setFinanceExportLCList(financeExportLC);
				}
				if (userVo.getEventCodeGridValue().equalsIgnoreCase("JSA4")) {
					List<TFBOFinanceExportLcVO> financeExportLC = new LinkedList<TFBOFinanceExportLcVO>();
					financeExportLC = aDBHelper.getTFBOFELIADJFromDB(
							userVo.getRequestId(),
							ActionConstants.GETTFBOFELADJ_QUERY);
					userVo.setFinanceExportLCList(financeExportLC);
				}
				if (userVo.getEventCodeGridValue().equalsIgnoreCase("CRYST")) {
					List<TFBOFinanceExportLcVO> financeExportLC = new LinkedList<TFBOFinanceExportLcVO>();
					financeExportLC = aDBHelper.getTFBOFELICRYSTFromDB(
							userVo.getRequestId(),
							ActionConstants.GETTFBOFELCRYST_QUERY);
					userVo.setFinanceExportLCList(financeExportLC);
				}
				if (userVo.getEventCodeGridValue().equalsIgnoreCase("RSA4")) {
					List<TFBOFinanceExportLcVO> financeExportLC = new LinkedList<TFBOFinanceExportLcVO>();
					financeExportLC = aDBHelper.getTFBOFELIRPYFromDB(
							userVo.getRequestId(),
							ActionConstants.GETTFBOFELRPY_QUERY);
					userVo.setFinanceExportLCList(financeExportLC);
				}
				if (userVo.getEventCodeGridValue().equalsIgnoreCase("PSA4")) {
					List<TFBOFinanceExportLcVO> financeExportLC = new LinkedList<TFBOFinanceExportLcVO>();
					financeExportLC = aDBHelper.getTFBOFELPSA4DetailsFromDB(
							userVo.getRequestId(),
							ActionConstants.GETTFBOFELPSA4_QUERY);
					userVo.setFinanceExportLCList(financeExportLC);
				}
			}
			if (userVo.getProductCodeGridValue().equalsIgnoreCase("FSA")) {
				if (userVo.getEventCodeGridValue().equalsIgnoreCase("CSA")) {
					List<TFBOFinanceStandaloneVO> FinStandaloneList = new LinkedList<TFBOFinanceStandaloneVO>();
					FinStandaloneList = aDBHelper.getTFBOIFSACREFromDB(
							userVo.getRequestId(),
							ActionConstants.GETTFBOFSACRE_QUERY);
					userVo.setFinStandaloneList(FinStandaloneList);

				}
				if (userVo.getEventCodeGridValue().equalsIgnoreCase("JSA")) {
					List<TFBOFinanceStandaloneVO> FinStandaloneList = new LinkedList<TFBOFinanceStandaloneVO>();
					FinStandaloneList = aDBHelper.getTFBOIFSAADJFromDB(
							userVo.getRequestId(),
							ActionConstants.GETTFBOFSAADJ_QUERY);
					userVo.setFinStandaloneList(FinStandaloneList);

				}
				if (userVo.getEventCodeGridValue().equalsIgnoreCase("RSA")) {
					List<TFBOFinanceStandaloneVO> FinStandaloneList = new LinkedList<TFBOFinanceStandaloneVO>();
					FinStandaloneList = aDBHelper.getTFBOIFSAREPAYFromDB(
							userVo.getRequestId(),
							ActionConstants.GETTFBOFSAREPAY_QUERY);
					userVo.setFinStandaloneList(FinStandaloneList);

				}
			}

			// SBLC_251219
			if (userVo.getProductCodeGridValue().equalsIgnoreCase("ISB")) {
				if (userVo.getEventCodeGridValue().equalsIgnoreCase("IIS")) {

					List<TFBOSandbyLcVO> IsbList = new LinkedList<TFBOSandbyLcVO>();
					IsbList = aDBHelper.getTFBOISBISSFromDB(
							userVo.getRequestId(),
							ActionConstants.GETTFBOISBISS_QUERY);
					userVo.setStandByLCList(IsbList);
				}
				if (userVo.getEventCode().equalsIgnoreCase("KIS")) {
					List<TFBOSandbyLcVO> IsbList = new LinkedList<TFBOSandbyLcVO>();
					IsbList = aDBHelper.getTFBOISBKISFromDB(
							userVo.getRequestId(),
							ActionConstants.GETTFBOISB_KIS_QUERY);
					userVo.setStandByLCList(IsbList);

				}
				if (userVo.getEventCode().equalsIgnoreCase("NIS")) {
					List<TFBOSandbyLcVO> IsbList = new LinkedList<TFBOSandbyLcVO>();
					IsbList = aDBHelper.getTFBOISBNISFromDB(
							userVo.getRequestId(),
							ActionConstants.GETTFBOISB_NIS_QUERY);
					userVo.setStandByLCList(IsbList);
				}
				if (userVo.getEventCodeGridValue().equalsIgnoreCase("NJIS")) {

					List<TFBOSandbyLcVO> IsbList = new LinkedList<TFBOSandbyLcVO>();
					IsbList = aDBHelper.getTFBOISB_AJ_AD_CR_FrmDB(
							userVo.getRequestId(),
							ActionConstants.GETTFBOISBNJIS_QUERY);
					userVo.setStandByLCList(IsbList);
				}
				if (userVo.getEventCodeGridValue().equalsIgnoreCase("NAIS")) {

					List<TFBOSandbyLcVO> IsbList = new LinkedList<TFBOSandbyLcVO>();
					IsbList = aDBHelper.getTFBOISB_AJ_AD_CR_FrmDB(
							userVo.getRequestId(),
							ActionConstants.GETTFBOISBNAIS_QUERY);
					userVo.setStandByLCList(IsbList);
				}
				if (userVo.getEventCodeGridValue().equalsIgnoreCase("LIS")) {

					List<TFBOSandbyLcVO> IsbList = new LinkedList<TFBOSandbyLcVO>();
					IsbList = aDBHelper.getTFBOISB_AJ_AD_CR_FrmDB(
							userVo.getRequestId(),
							ActionConstants.GETTFBOISBLIS_QUERY);
					userVo.setStandByLCList(IsbList);
				}
				if (userVo.getEventCodeGridValue().equalsIgnoreCase("OIS")) {

					List<TFBOSandbyLcVO> IsbList = new LinkedList<TFBOSandbyLcVO>();
					IsbList = aDBHelper.getTFBOISBOISFrmDB(
							userVo.getRequestId(),
							ActionConstants.GETTFBOISBOIS_QUERY);
					userVo.setStandByLCList(IsbList);
					if (aCommonMethods.isValueAvailable(userVo
							.getTiReferanceNo())) {
						// Bill reference Changes 10012020 starts
						userVo.setBillReferenceList(getBillReference(userVo,
								userVo.getTiReferanceNo()));
						// Bill reference Changes 10012020 ends
					}
				}

			}

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		logger.info(ActionConstants.EXITING_METHOD);
		return userVo;
	}

	public String getRequestProdFromDB(String requestId) {
		DBHelper aDBHelper = new DBHelper();
		String prodCode = aDBHelper.getLCReference("SELECT PRODUCTCODE "
				+ " FROM TFBO_TRANS " + " WHERE TRIM(REQUESTID) = '"
				+ requestId + "'");
		return prodCode;
	}

	public void updateTIReferenceInTool(UserTransactionVO userVo)
			throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		DBHelper aDBHelper = new DBHelper();
		try {
			/*
			 * aDBHelper.updateTIReferenceInTool(
			 * ActionConstants.GETTIMASTERREF_QUERY,
			 * ActionConstants.UPDATETFBOMASTERREF);
			 */
			// ADDED BY CHANDRU
			
//			if (userVo.getProductCodeFilter() != null
//					&& !userVo.getProductCodeFilter().trim().equals("")) {
//				userVo.setProductCodeFilter(aDBHelper.getValueFromDB(
//						userVo.getRequestId(),
//						ActionConstants.GETTIMASTERREF_SEARCH_QUERY));
//			}
			if (userVo.getProductCodeFilter().trim().equals("FEL")
					|| userVo.getProductCodeFilter().trim().equals("FOC")) {
				aDBHelper.updateTIReferenceInTool(
						ActionConstants.GETTIMASTERREF_FELFOC_QUERY,
						ActionConstants.UPDATETFBOMASTERREF);
			} else {
				aDBHelper.updateTIReferenceInTool(
						ActionConstants.GETTIMASTERREF_QUERY,
						ActionConstants.UPDATETFBOMASTERREF);
			}

			// ADDED BY CHANDRU
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		logger.info(ActionConstants.EXITING_METHOD);
	}

	/*
	 * public List<TFBOTransVO> getTFBOTransListFromDB(UserTransactionVO userVo)
	 * throws Exception { logger.info(ActionConstants.ENTERING_METHOD); DBHelper
	 * aDBHelper = new DBHelper(); List<TFBOTransVO> transactionList = null;
	 * CommonMethods aCommonMethods = new CommonMethods(); try { if
	 * (!aCommonMethods.isValueAvailable(userVo.getIsTiTransFlag()))
	 * userVo.setIsTiTransFlag("N"); if
	 * (!aCommonMethods.isValueAvailable(userVo.getRequestIdFilter()))
	 * userVo.setRequestIdFilter("%"); if
	 * (!aCommonMethods.isValueAvailable(userVo.getProductCodeFilter()))
	 * userVo.setProductCodeFilter("%"); if
	 * (!aCommonMethods.isValueAvailable(userVo.getEventCodeFilter()))
	 * userVo.setEventCodeFilter("%"); if
	 * (!aCommonMethods.isValueAvailable(userVo.getStepFilter()))
	 * userVo.setStepFilter("%"); if
	 * (!aCommonMethods.isValueAvailable(userVo.getStatusFilter()))
	 * userVo.setStatusFilter("%"); if
	 * (!aCommonMethods.isValueAvailable(userVo.getIsQueriedFilter()))
	 * userVo.setIsQueriedFilter("%"); String fromDateFlag = "N"; String
	 * toDateFlag = "N"; if
	 * (!aCommonMethods.isValueAvailable(userVo.getFromDateFilter())) {
	 * fromDateFlag = "Y"; userVo.setFromDateFilter("01-01-1990"); } if
	 * (!aCommonMethods.isValueAvailable(userVo.getToDateFilter())) {
	 * SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy"); Date
	 * date = new Date(); userVo.setToDateFilter(formatter.format(date));
	 * toDateFlag = "Y"; } if (userVo.getIsTiTransFlag().equalsIgnoreCase("N"))
	 * { transactionList = aDBHelper.getTransactionListFromDB(
	 * userVo.getRequestIdFilter(), userVo.getProductCodeFilter(),
	 * userVo.getEventCodeFilter(), userVo.getStepFilter(),
	 * userVo.getStatusFilter(), userVo.getIsQueriedFilter(),
	 * userVo.getIsTiTransFlag(), userVo.getFromDateFilter(),
	 * userVo.getToDateFilter(), ActionConstants.GETTFBOTRANSLIST_QUERY); } if
	 * (userVo.getIsTiTransFlag().equalsIgnoreCase("Y")) { transactionList =
	 * aDBHelper.getTransactionListFromDB( userVo.getRequestIdFilter(),
	 * userVo.getProductCodeFilter(), userVo.getEventCodeFilter(),
	 * userVo.getStepFilter(), userVo.getStatusFilter(),
	 * userVo.getIsQueriedFilter(), userVo.getIsTiTransFlag(),
	 * userVo.getFromDateFilter(), userVo.getToDateFilter(),
	 * ActionConstants.GETTFBOTITRANSLIST_QUERY); }
	 * 
	 * // Inward Remittance changes 23-12-2019 starts dashboard
	 * logger.info("Product code filter==>" + userVo.getProductCodeFilter()); if
	 * (userVo.getIsTiTransFlag().equalsIgnoreCase("Y") &&
	 * userVo.getProductCodeFilter().equalsIgnoreCase("CPCI")) {
	 * logger.info("Entering if condition in CPCI"); transactionList =
	 * aDBHelper.getTransactionListFromDB( userVo.getRequestIdFilter(),
	 * userVo.getProductCodeFilter(), userVo.getEventCodeFilter(),
	 * userVo.getStepFilter(), userVo.getStatusFilter(),
	 * userVo.getIsQueriedFilter(), userVo.getIsTiTransFlag(),
	 * userVo.getFromDateFilter(), userVo.getToDateFilter(),
	 * ActionConstants.GETTFBOTITRANSLISTCPCI_QUERY); }
	 * 
	 * // Inward Remittance changes 23-12-2019 ends
	 * 
	 * // pandi starts here 07012020
	 * 
	 * transactionList = aDBHelper.getTransactionListFromDB_CPCI(
	 * userVo.getRequestIdFilter(), userVo.getProductCodeFilter(),
	 * userVo.getEventCodeFilter(), userVo.getStatusFilter(),
	 * userVo.getStepFilter(),userVo.getIsTiTransFlag(),
	 * userVo.getFromDateFilter(), userVo.getToDateFilter(),
	 * ActionConstants.GETTFBOTITRANSLISTCPCI_QUERY);
	 * 
	 * // pandi starts ENDS 07012020
	 * 
	 * if (fromDateFlag.equals("Y")) userVo.setFromDateFilter(""); if
	 * (toDateFlag.equals("Y")) userVo.setToDateFilter(""); } catch (Exception
	 * e) { e.printStackTrace(); throw e; }
	 * logger.info(ActionConstants.EXITING_METHOD + "transactionList size-->" +
	 * transactionList.size()); return transactionList; }
	 */
	// karthika 08012020 starts
	public List<TFBOTransVO> getTFBOTransListFromDB(UserTransactionVO userVo)
			throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		DBHelper aDBHelper = new DBHelper();
		List<TFBOTransVO> transactionList = null;
		CommonMethods aCommonMethods = new CommonMethods();
		try {
			if (!aCommonMethods.isValueAvailable(userVo.getIsTiTransFlag()))
				userVo.setIsTiTransFlag("N");
			if (!aCommonMethods.isValueAvailable(userVo.getRequestIdFilter()))
				userVo.setRequestIdFilter("%");
			if (!aCommonMethods.isValueAvailable(userVo.getProductCodeFilter()))
				userVo.setProductCodeFilter("%");
			if (!aCommonMethods.isValueAvailable(userVo.getEventCodeFilter()))
				userVo.setEventCodeFilter("%");
			if (!aCommonMethods.isValueAvailable(userVo.getStepFilter()))
				userVo.setStepFilter("%");
			if (!aCommonMethods.isValueAvailable(userVo.getStatusFilter()))
				userVo.setStatusFilter("%");
			if (!aCommonMethods.isValueAvailable(userVo.getIsQueriedFilter()))
				userVo.setIsQueriedFilter("%");

			// Dashboard Changes starts 07-01-2020
			if (!aCommonMethods.isValueAvailable(userVo.getSubProductFilter()))
				userVo.setSubProductFilter("%");
			if (!aCommonMethods.isValueAvailable(userVo.getTiReferenceFilter()))
				userVo.setTiReferenceFilter("%");
			// Dashboard Changes ends 07-01-2020

			String fromDateFlag = "N";
			String toDateFlag = "N";
			if (!aCommonMethods.isValueAvailable(userVo.getFromDateFilter())) {
				fromDateFlag = "Y";
				userVo.setFromDateFilter("01-01-1990");
			}
			if (!aCommonMethods.isValueAvailable(userVo.getToDateFilter())) {
				SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy");
				Date date = new Date();
				userVo.setToDateFilter(formatter.format(date));
				toDateFlag = "Y";
			}

			if (userVo.getIsTiTransFlag().equalsIgnoreCase("N")) {
				System.out.println("getIsTiTransFlag is N (if condition)==>");

				// Dashboard Changes starts 07-01-2020
				/*
				 * transactionList = aDBHelper.getTransactionListFromDB(
				 * userVo.getRequestIdFilter(), userVo.getProductCodeFilter(),
				 * userVo.getEventCodeFilter(), userVo.getStepFilter(),
				 * userVo.getStatusFilter(), userVo.getIsQueriedFilter(),
				 * userVo.getIsTiTransFlag(), userVo.getFromDateFilter(),
				 * userVo.getToDateFilter(), userVo.getSubProductFilter(),
				 * ActionConstants.GETTFBOTRANSLIST_QUERY); } else {
				 */
				// "SELECT TXN.REQUESTID,
				// TXN.TIREFERANCE,TXN.PRODUCTCODE,TXN.EVENTCODE,
				// PRD.PRODUCTDESCRIPTION,EVT.EVENTDESCRIPTION,TXN.SUBPRODUCTCODE,TXN.STEP,
				// TXN.STEPSTATUS,TXN.TRANS_CREATED, TXN.TRANS_MODIFIED FROM
				// TFBO_TRANS TXN,TFBO_PRODUCT PRD,
				// TFBO_EVENT EVT WHERE TXN.PRODUCTCODE = PRD.PRODUCTCODE AND
				// TXN.EVENTCODE
				// = EVT.EVENTCODE AND TXN.PRODUCTCODE = EVT.PRODUCTCODE
				// AND TXN.REQUESTID LIKE ? AND TXN.PRODUCTCODE LIKE ?
				// AND TXN.EVENTCODE LIKE ? AND TXN.STEP LIKE ?
				// AND TXN.STEPSTATUS LIKE ? AND TXN.ISQUERIEDTRANS LIKE ?
				// AND TO_DATE(TRUNC(TXN.TRANS_CREATED),'DD-MM-YY') BETWEEN
				// TO_DATE(?,'DD-MM-YY')
				// AND TO_DATE(?,'DD-MM-YY') AND TXN.SUBPRODUCTCODE LIKE ? AND
				// ( TXN.TIREFERANCE LIKE ? or trim(TXN.TIREFERANCE) is null)
				// ORDER BY TXN.REQUESTID DESC FETCH FIRST 20 ROW ONLY";

				transactionList = aDBHelper.getTransactionListFromDB(
						userVo.getRequestIdFilter(),
						userVo.getProductCodeFilter(),
						userVo.getEventCodeFilter(), userVo.getStepFilter(),
						userVo.getStatusFilter(), userVo.getIsQueriedFilter(),
						userVo.getIsTiTransFlag(), userVo.getFromDateFilter(),
						userVo.getToDateFilter(), userVo.getSubProductFilter(),
						userVo.getTiReferenceFilter(),
						ActionConstants.GETTFBOTRANSLIST_TIREF_QUERY);
			}

			// Dashboard Changes ends 07-01-2020

			if (userVo.getIsTiTransFlag().equalsIgnoreCase("Y")) {
				System.out.println("getIsTiTransFlag is Y (if condition)==>");

				// Dashboard Changes starts 07-01-2020
				/*
				 * transactionList = aDBHelper.getTransactionListFromDB(
				 * userVo.getRequestIdFilter(), userVo.getProductCodeFilter(),
				 * userVo.getEventCodeFilter(), userVo.getStepFilter(),
				 * userVo.getStatusFilter(), userVo.getIsQueriedFilter(),
				 * userVo.getIsTiTransFlag(), userVo.getFromDateFilter(),
				 * userVo.getToDateFilter(),
				 * ActionConstants.GETTFBOTITRANSLIST_QUERY);
				 */
				transactionList = aDBHelper.getTransactionListFromDB(
						userVo.getRequestIdFilter(),
						userVo.getProductCodeFilter(),
						userVo.getEventCodeFilter(), userVo.getStepFilter(),
						userVo.getStatusFilter(), userVo.getIsQueriedFilter(),
						userVo.getIsTiTransFlag(), userVo.getFromDateFilter(),
						userVo.getToDateFilter(), userVo.getSubProductFilter(),
						userVo.getTiReferenceFilter(),
						ActionConstants.GETTFBOTITRANSLIST_QUERY);
				// Dashboard Changes ends 07-01-2020

			}

			// Inward Remittance changes 23-12-2019 starts dashboard
			logger.info("Product code filter==>"
					+ userVo.getProductCodeFilter());
			if (userVo.getIsTiTransFlag().equalsIgnoreCase("Y")
					&& userVo.getProductCodeFilter().equalsIgnoreCase("CPCI")) {
				logger.info("Entering if condition in CPCI");

				// Dashboard Changes starts 07-01-2020
				/*
				 * transactionList = aDBHelper.getTransactionListFromDB(
				 * userVo.getRequestIdFilter(), userVo.getProductCodeFilter(),
				 * userVo.getEventCodeFilter(), userVo.getStepFilter(),
				 * userVo.getStatusFilter(), userVo.getIsQueriedFilter(),
				 * userVo.getIsTiTransFlag(), userVo.getFromDateFilter(),
				 * userVo.getToDateFilter(),
				 * ActionConstants.GETTFBOTITRANSLISTCPCI_QUERY);
				 */

				transactionList = aDBHelper.getTransactionListFromDB(
						userVo.getRequestIdFilter(),
						userVo.getProductCodeFilter(),
						userVo.getEventCodeFilter(), userVo.getStepFilter(),
						userVo.getStatusFilter(), userVo.getIsQueriedFilter(),
						userVo.getIsTiTransFlag(), userVo.getFromDateFilter(),
						userVo.getToDateFilter(), userVo.getSubProductFilter(),
						userVo.getTiReferenceFilter(),
						ActionConstants.GETTFBOTITRANSLISTCPCI_QUERY);

				// Dashboard Changes ends 07-01-2020
			}

			// Inward Remittance changes 23-12-2019 ends

			if (fromDateFlag.equals("Y"))
				userVo.setFromDateFilter("");
			if (toDateFlag.equals("Y"))
				userVo.setToDateFilter("");
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		logger.info(ActionConstants.EXITING_METHOD + "transactionList size-->"
				+ transactionList.size());
		return transactionList;
	}

	// karthika 08012020 ends

	public String getProductNameFromDB(String requestId) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		DBHelper aDBHelper = new DBHelper();
		String productName = "";
		try {
			productName = aDBHelper.getValueFromDB(requestId,
					ActionConstants.GETTFBOTRANSPRODUCTNAME_QUERY);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		logger.info(ActionConstants.EXITING_METHOD);
		return productName;
	}

	public String getProductCodeFromDB(String productName) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		DBHelper aDBHelper = new DBHelper();
		String productCode = "";
		try {
			productCode = aDBHelper.getValueFromDB(productName,
					ActionConstants.GETTFBOTRANSPRODUCTCODE_QUERY);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		logger.info(ActionConstants.EXITING_METHOD);
		return productCode;
	}

	public String getEventCodeFromDB(String productCode, String eventName)
			throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		DBHelper aDBHelper = new DBHelper();
		String eventCode = "";
		try {
			eventCode = aDBHelper.getValueFromDB(productCode, eventName,
					ActionConstants.GETTFBOTRANSEVENTCODE_QUERY);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		logger.info(ActionConstants.EXITING_METHOD);
		return eventCode;
	}

	public String getEventNameFromDB(String requestId) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		DBHelper aDBHelper = new DBHelper();
		String eventName = "";
		try {
			eventName = aDBHelper.getValueFromDB(requestId,
					ActionConstants.GETTFBOTRANSEVENTNAME_QUERY);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		logger.info(ActionConstants.EXITING_METHOD);
		return eventName;
	}

	public void updateTFBOEventTable(UserTransactionVO userVo) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		try {
			if (userVo.getProductCode().equalsIgnoreCase("ILC")) {
				if (userVo.getEventCode().equalsIgnoreCase("ISI")) {
					updateTFBOIlcIssue(userVo.getSolID(),
							userVo.getCustomeCif(), userVo.getAmount(),
							userVo.getCurrency(), userVo.getRequestId(),
							userVo.getLcType(), userVo.getUsancePeriod());
				}
				if (userVo.getEventCode().equalsIgnoreCase("NAMI")) {
					updateTFBOIlcAmend(userVo.getTiReferanceNo(),
							userVo.getSolID(), userVo.getCustomeCif(),
							userVo.getAmount(), userVo.getCurrency(),
							userVo.getLcType(), userVo.getRequestId());
				}
				if (userVo.getEventCode().equalsIgnoreCase("CRC")) {
					updateTFBOIlcClaimRvd(userVo.getTiReferanceNo(),
							userVo.getSolID(), userVo.getCustomeCif(),
							userVo.getBillAmount(), userVo.getCurrency(),
							userVo.getLcType(), userVo.getRequestId(),
							userVo.getBillUsancePeriod());
				}
				if (userVo.getEventCode().equalsIgnoreCase("POCA")) {
					updateTFBOIlcOutstandingClmAcc(userVo.getTiReferanceNo(),
							userVo.getSolID(), userVo.getCustomeCif(),
							userVo.getClaimAmount(), userVo.getCurrency(),
							userVo.getLcType(), userVo.getRequestId(),
							userVo.isPartAmount(), userVo.getPayType(),
							userVo.getBillReference());
				}
				if (userVo.getEventCode().equalsIgnoreCase("POCP")) {
					updateTFBOIlcOutstandingClmPay(userVo.getTiReferanceNo(),
							userVo.getSolID(), userVo.getCustomeCif(),
							userVo.getClaimAmount(), userVo.getCurrency(),
							userVo.getLcType(), userVo.getRequestId(),
							userVo.isPartAmount(), userVo.getPayType(),
							userVo.getRateTaken(), userVo.getToken(),
							userVo.getValueK(), userVo.getRate(),
							userVo.getBillReference());
				}
				// karthik 13012020 starts
				/*
				 * if (userVo.getEventCode().equalsIgnoreCase("COI")) {
				 * UpdateTFBOIlcCorrespondence(userVo.tiReferanceNo,
				 * userVo.getSolID(), userVo.getCustomeCif(),
				 * userVo.getCustomeName(), userVo.getAmount(),
				 * userVo.getCurrency(), userVo.getLcType(),
				 * userVo.getUserRemark(), userVo.getRequestId());
				 * 
				 * }
				 */
				if (userVo.getEventCode().equalsIgnoreCase("COI")) {
					UpdateTFBOIlcCorrespondence(userVo.tiReferanceNo,
							userVo.getSolID(), userVo.getCustomeCif(),
							userVo.getCustomeName(), userVo.getAmount(),
							userVo.getCurrency(), userVo.getLcType(),
							userVo.getUserRemark(), userVo.getRequestId());

				}
				// karthik 13012020 ends
				if (userVo.getEventCode().equalsIgnoreCase("POCD")) {

					updateTFBOIlcOutstandingClmDevolmentCase(
							userVo.getTiReferanceNo(), userVo.getSolID(),
							userVo.getCustomeCif(),
							userVo.getDevolvementAmount(),
							userVo.getCurrency(), userVo.getLcType(),
							userVo.getRequestId(), userVo.getRateTaken(),
							userVo.getToken(), userVo.getValueK(),
							userVo.getRate(), userVo.getBillReference());

				}
				// Expiry,closure,cancellation Changes Starts
				if (userVo.getEventCode().equalsIgnoreCase("EXI")) {

					updateTFBOIlcExpiry(userVo.getTiReferanceNo(),
							userVo.getSolID(), userVo.getCustomeCif(),
							userVo.getAmount(), userVo.getCurrency(),
							userVo.getRequestId(), userVo.getLcType(),
							userVo.getUsancePeriod());

					updateTFBOTiRefInTransTable(userVo.getTiReferanceNo(),
							userVo.getRequestId());

				}
				// Expiry,closure,cancellation Changes Ends
			}
			// Miscellanous changes starts 08-01-2020
			if (userVo.getProductCode().equalsIgnoreCase("COR")) {
				if (userVo.getEventCode().equalsIgnoreCase("CRCR")) {
					logger.info("Entering updateTFBOEventTable method for miscellanous==>");
					updateTFBOMiscellanousCreate(userVo.getRequestId(),
							userVo.getSolID(), userVo.getCustomeCif(),
							userVo.getAmount(), userVo.getCurrency(),
							userVo.getRateTaken(), userVo.getToken(),
							userVo.getRateTakenK(), userVo.getRate(),
							userVo.getSubProductCode(),
							userVo.getOdiSubProductType(),
							userVo.getTiReferanceNo(), userVo.getRemarks(),
							userVo.getMasReferanceNo());
					updateTFBOMISCTiRefInTransTable(userVo.getTiReferanceNo(),
							userVo.getRequestId());
				}
			}

			// Miscellanous changes ends 08-01-2020
			// Inward Remittance changes 23-12-2019 starts
			if (userVo.getProductCode().equalsIgnoreCase("CPCI")) {
				if (userVo.getEventCode().equalsIgnoreCase("PCIC")) {
					updateTFBOInwardRemittanceCreate(userVo.getSolID(),
							userVo.getCustomeCif(), userVo.getAmount(),
							userVo.getCurrency(), userVo.getRequestId(),
							userVo.getSubProductCode(),
							userVo.getPreshipAccSetteld(),
							userVo.getDummyIrex(), userVo.getRateTaken(),
							userVo.getToken(), userVo.getRateTakenK(),
							userVo.getRate());
				}
			}
			// Inward Remittance changes 23-12-2019 ends
			// Outward Remittance Changes 23/12/2019 start

			if (userVo.getProductCode().equalsIgnoreCase("CPCO")) {
				if (userVo.getEventCode().equalsIgnoreCase("PCOC")) {
					updateTFBOCpcoCreate(userVo.getRequestId(),
							userVo.getTiReferanceNo(), userVo.getCustomeCif(),
							userVo.getCustomeName(), userVo.getAmount(),
							userVo.getCurrency(), userVo.getSolID(),
							userVo.getBankpayment(), userVo.getRateTaken(),
							userVo.getSubProductCode(), userVo.getToken(),
							userVo.getValueK(), userVo.getRate());
				}
			}
			// Outward Remittance Changes 23/12/2019 end
			// Rate taken Fix Offshore Team 06012020 STARTS

			if (userVo.getProductCode().equalsIgnoreCase("ODC")) {
				if (userVo.getEventCode().equalsIgnoreCase("CRE")) {

					/*
					 * updateTFBOOdcCreate(userVo.getSolID(),
					 * userVo.getCustomeCif(), userVo.getAmount(),
					 * userVo.getCurrency(), userVo.getRequestId(),
					 * userVo.getUsancePeriod(), userVo.getDirect(),
					 * userVo.getMtReceived(), userVo.getPartPayment(),
					 * userVo.getSubProductCode(),
					 * userVo.getPreshipAccSetteld(),
					 * userVo.getDocumentDispatch(), userVo.getFinanceSameDay(),
					 * userVo.getRateTaken(), userVo.getToken(),
					 * userVo.getRateTakenK(), userVo.getRate());
					 */
					updateTFBOOdcCreate(userVo.getSolID(),
							userVo.getCustomeCif(), userVo.getAmount(),
							userVo.getCurrency(), userVo.getRequestId(),
							userVo.getUsancePeriod(), userVo.getDirect(),
							userVo.getMtReceived(), userVo.getPartPayment(),
							userVo.getSubProductCode(),
							userVo.getPreshipAccSetteld(),
							userVo.getDocumentDispatch(),
							userVo.getFinanceSameDay(), userVo.getRateTaken(),
							userVo.getToken(), userVo.getRateTakenK(),
							userVo.getRate(), userVo.getIrexRefNo(),
							userVo.getFncAmount(), userVo.getFinCurrency());
					/*
					 * updateCustomerName(userVo.getCustomeName(),
					 * userVo.getRequestId(), userVo.getEventCode());
					 */

					updateTFBOOdcFlow(userVo.getRequestId(),
							userVo.getDirect(), userVo.getMtReceived(),
							userVo.getPartPayment(),
							userVo.getSubProductCode(),
							userVo.getFinanceSameDay());
				}
				// karthik 13012020 starts
				/*
				 * if (userVo.getEventCode().equalsIgnoreCase("CCO")) {
				 * updateTFBOOdcCco(userVo.tiReferanceNo, userVo.getSolID(),
				 * userVo.getCustomeCif(), userVo.getCustomeName(),
				 * userVo.getAmount(), userVo.getCurrency(),
				 * userVo.getUserRemark(), userVo.getRequestId()); }
				 */
				if (userVo.getEventCode().equalsIgnoreCase("CCO")) {
					updateTFBOOdcCco(userVo.tiReferanceNo, userVo.getSolID(),
							userVo.getCustomeCif(), userVo.getCustomeName(),
							userVo.getAmount(), userVo.getCurrency(),
							userVo.getUserRemark(), userVo.getRequestId());
				}
				// karthik 13012020 ends
				if (userVo.getEventCode().equalsIgnoreCase("CLP")) {
					/*
					 * updateTFBOOdcPayment(userVo.getSolID(),
					 * userVo.getCustomeCif(), userVo.getAmount(),
					 * userVo.getCurrency(), userVo.getRequestId(),
					 * userVo.getUsancePeriod(), userVo.getDirect(),
					 * userVo.getSubProductCode(),
					 * userVo.getPreshipAccSetteld(),
					 * userVo.getDocumentDispatch(), userVo.getRateTaken(),
					 * userVo.getToken(), userVo.getRateTakenK(),
					 * userVo.getRate(), userVo.getFinalPayment(),
					 * userVo.getTiReferanceNo());
					 */
					updateTFBOOdcPayment(userVo.getSolID(),
							userVo.getCustomeCif(), userVo.getAmount(),
							userVo.getCurrency(), userVo.getRequestId(),
							userVo.getUsancePeriod(), userVo.getDirect(),
							userVo.getMtReceived(), userVo.getPartPayment(),
							userVo.getSubProductCode(),
							userVo.getPreshipAccSetteld(),
							userVo.getDocumentDispatch(),
							userVo.getRateTaken(), userVo.getToken(),
							userVo.getRateTakenK(), userVo.getRate(),
							userVo.getFinalPayment(), userVo.getIrexRefNo(),
							userVo.getTiReferanceNo(), userVo.getSenderRefno(),
							userVo.getFinanceSameDay());
					/*
					 * updateCustomerName(userVo.getCustomeName(),
					 * userVo.getRequestId(), userVo.getEventCode());
					 */
				}
				// CHANGES FOR ODC CAC 08012020 NY SAI STARTS HERE
				if (userVo.getEventCode().equalsIgnoreCase("CAC")) {
					/*
					 * updateTFBOOdcAccept(userVo.getSolID(),
					 * userVo.getCustomeCif(), userVo.getAmount(),
					 * userVo.getCurrency(), userVo.getRequestId(),
					 * userVo.getUsancePeriod(), userVo.getDirect(),
					 * userVo.getMtReceived(), userVo.getPartPayment(),
					 * userVo.getSubProductCode(),
					 * userVo.getPreshipAccSetteld(),
					 * userVo.getDocumentDispatch(), userVo.getFinanceSameDay(),
					 * userVo.getRateTaken(), userVo.getToken(),
					 * userVo.getRateTakenK(), userVo.getRate(),
					 * userVo.getTiReferanceNo());
					 */

					updateTFBOOdcAccept(userVo.getRequestId(),
							userVo.getSolID(), userVo.getTiReferanceNo(),
							userVo.getCustomeCif(), userVo.getCurrency(),
							userVo.getAcceptBillAmt(),
							userVo.getUsancePeriod(),
							userVo.getSubProductCode(), userVo.getCustomeName());

				}
				// CHANGES FOR ODC CAC 08012020 NY SAI ENDS HERE
			}
			// Rate taken Fix Offshore Team 06012020 ends
			// FOC- CRE
			if (userVo.getProductCode().equalsIgnoreCase("FOC")) {
				if (userVo.getEventCode().equalsIgnoreCase("CSA1")) {
					updateTFBOFocCreate(userVo.getSolID(),
							userVo.getCustomeCif(), userVo.getAmount(),
							userVo.getFinanceAmount(), userVo.getCurrency(),
							userVo.getRequestId(), userVo.getUsancePeriod(),
							userVo.getSubProductCode(),
							userVo.getPreshipAccSetteld(),
							userVo.getRateTaken(), userVo.getToken(),
							userVo.getRateTakenK(), userVo.getRate(),
							userVo.getTiReferanceNo());
				}
				if (userVo.getEventCode().equalsIgnoreCase("JSA1")) {
					System.out.println("Inside JSA1");
					updateTFBOFocAdjust(userVo.getSolID(),
							userVo.getCustomeCif(), userVo.getFinanceAmount(),
							userVo.getCurrency(), userVo.getRequestId(),
							userVo.getUsancePeriod(),
							userVo.getSubProductCode(),
							userVo.getMaturityDate(), userVo.getTiReferanceNo());
				}
				// karthik 13012020 starts
				/*
				 * if (userVo.getEventCode().equalsIgnoreCase("PSA1")) {
				 * updateTFBOFocPsa1(userVo.tiReferanceNo, userVo.getSolID(),
				 * userVo.getCustomeCif(), userVo.getCustomeName(),
				 * userVo.getAmount(), userVo.getCurrency(),
				 * userVo.getUserRemark(), userVo.getRequestId()); }
				 */
				if (userVo.getEventCode().equalsIgnoreCase("PSA1")) {
					updateTFBOFocPsa1(userVo.tiReferanceNo, userVo.getSolID(),
							userVo.getCustomeCif(), userVo.getCustomeName(),
							userVo.getAmount(), userVo.getCurrency(),
							userVo.getUserRemark(), userVo.getRequestId());
				}
				// karthik 13012020 ends
				if (userVo.getEventCode().equalsIgnoreCase("RSA1")) {
					updateTFBOFocRepay(userVo.getSolID(),
							userVo.getCustomeCif(), userVo.getFinanceAmount(),
							userVo.getCurrency(), userVo.getRequestId(),
							userVo.getUsancePeriod(),
							userVo.getSubProductCode(),
							userVo.getFinalPayment(), userVo.getRateTaken(),
							userVo.getToken(), userVo.getRateTakenK(),
							userVo.getRate(), userVo.getTiReferanceNo(),
							userVo.getPreshipAccSetteld());
				}
				if (userVo.getEventCode().equalsIgnoreCase("CRYST")) {
					updateTFBOFocCryst(userVo.getSolID(),
							userVo.getCustomeCif(), userVo.getFinanceAmount(),
							userVo.getCurrency(), userVo.getRequestId(),
							userVo.getUsancePeriod(),
							userVo.getSubProductCode(), userVo.getRateTaken(),
							userVo.getToken(), userVo.getRateTakenK(),
							userVo.getRate(), userVo.getTiReferanceNo());
				}
			}
			// FOC-CRE
			if (userVo.getProductCode().equalsIgnoreCase("FSA")) {
				if (userVo.getEventCode().equalsIgnoreCase("CSA")) {
					updateTFBOFsaCreate(userVo.getSolID(),
							userVo.getCustomeCif(), userVo.getAmount(),
							userVo.getCurrency(), userVo.getRequestId(),
							userVo.getUsancePeriod(),
							userVo.getSubProductCode(), userVo.getRateTaken(),
							userVo.getToken(), userVo.getRateTakenK(),
							userVo.getRate(), userVo.getTiReferanceNo());
				}
				if (userVo.getEventCode().equalsIgnoreCase("JSA")) {
					System.out.println("Inside JSA1");
					updateTFBOFsaAdjust(userVo.getSolID(),
							userVo.getCustomeCif(), userVo.getAmount(),
							userVo.getCurrency(), userVo.getRequestId(),
							userVo.getUsancePeriod(),
							userVo.getSubProductCode(),
							userVo.getMaturityDate(), userVo.getTiReferanceNo());
				}
				if (userVo.getEventCode().equalsIgnoreCase("RSA")) {
					updateTFBOFsaRepay(userVo.getSolID(),
							userVo.getCustomeCif(), userVo.getAmount(),
							userVo.getCurrency(), userVo.getRequestId(),
							userVo.getUsancePeriod(),
							userVo.getSubProductCode(), userVo.getRateTaken(),
							userVo.getToken(), userVo.getRateTakenK(),
							userVo.getRate(), userVo.getPartliqu(),
							userVo.getPcAmount(), userVo.getTiReferanceNo());
				}

			}
			if (userVo.getProductCode().equalsIgnoreCase("ELC")) {
				if (userVo.getEventCode().equalsIgnoreCase("ADE")) {
					updateTFBOElcAdv(userVo.getSolID(), userVo.getCustomeCif(),
							userVo.getCustomeName(), userVo.getAmount(),
							userVo.getCurrency(), userVo.getLcReceivedSWIFT(),
							userVo.getSenderRefno(), userVo.getRequestId(),
							userVo.getLcType(), userVo.getUsancePeriod());
				}
				if (userVo.getEventCode().equalsIgnoreCase("NAME")) {
					logger.info("Entering for updating ELC amend==> ");
					updateTFBOElcAmend(userVo.getTiReferanceNo(),
							userVo.getSolID(), userVo.getCustomeCif(),
							userVo.getAmount(), userVo.getCurrency(),
							userVo.getLcType(), userVo.getSenderRefno(),
							userVo.getUsancePeriod(), userVo.getRequestId());
				}
				// ELC DOP Issue Fix 20-12-2019 starts
				logger.info("Getting event code (DOP) ==> "
						+ userVo.getEventCode());
				if (userVo.getEventCode().equalsIgnoreCase("DOP")) {
					logger.info("Entering for updating ELC DOP==> ");
					updateTFBOElcDOP(userVo.getTiReferanceNo(),
							userVo.getSolID(), userVo.getRequestId(),
							userVo.getPreshipAccSetteld(), userVo.getAmount(),
							userVo.getCurrency(), userVo.getUsancePeriod(),
							userVo.getLcType(), userVo.getCustomeCif(),
							userVo.getFinanceSameDay(), userVo.getRateTaken(),
							userVo.getToken(), userVo.getRateTakenK(),
							userVo.getRate());

					updateTFBOELCFlow(userVo.getRequestId(),
							userVo.getFinanceSameDay(),
							userVo.getSubProductCode());

				}
				// karthik 13012020 starts
				/*
				 * if (userVo.getEventCode().equalsIgnoreCase("COE")) {
				 * UpdateTFBOIEcCorrespondence(userVo.tiReferanceNo,
				 * userVo.getSolID(), userVo.getCustomeCif(),
				 * userVo.getCustomeName(), userVo.getAmount(),
				 * userVo.getCurrency(), userVo.getLcType(),
				 * userVo.getUserRemark(), userVo.getRequestId());
				 * 
				 * }
				 */
				if (userVo.getEventCode().equalsIgnoreCase("COE")) {
					UpdateTFBOIEcCorrespondence(userVo.tiReferanceNo,
							userVo.getSolID(), userVo.getCustomeCif(),
							userVo.getCustomeName(), userVo.getAmount(),
							userVo.getCurrency(), userVo.getLcType(),
							userVo.getUserRemark(), userVo.getRequestId());

				}
				// karthik 13012020 ends
				// Expiry,closure,cancellation Changes Starts
				if (userVo.getEventCode().equalsIgnoreCase("EXP")) {

					updateTFBOElcExpiry(userVo.getTiReferanceNo(),
							userVo.getSolID(), userVo.getCustomeCif(),
							userVo.getAmount(), userVo.getCurrency(),
							userVo.getRequestId(), userVo.getLcType(),
							userVo.getUsancePeriod());

					updateTFBOTiRefInTransTable(userVo.getTiReferanceNo(),
							userVo.getRequestId());

				}
				// Expiry,closure,cancellation Changes Ends
				// Changes for ELC and IGT Starts 25-12-2019
				if (userVo.getEventCode().equalsIgnoreCase("PODA")) {

					updateTFBOELCPODA(userVo.getTiReferanceNo(),
							userVo.getSolID(), userVo.getCustomeCif(),
							userVo.getCustomeName(),
							userVo.getAcceptanceAmount(), userVo.getLcType(),
							userVo.getCurrency(), userVo.getRequestId(),
							userVo.getBillReference(),
							userVo.getSubProductCode());
				}
				if (userVo.getEventCode().equalsIgnoreCase("PODP")) {
					logger.info("Entering ELC PODP if case >>");

					updateTFBOELCPODP(userVo.getTiReferanceNo(),
							userVo.getSolID(), userVo.getCustomeCif(),
							userVo.getCustomeName(),
							userVo.getAcceptanceAmount(), userVo.getLcType(),
							userVo.getCurrency(), userVo.getRequestId(),
							userVo.getBillReference(),
							userVo.getSubProductCode(), userVo.getRateTaken(),
							userVo.getToken(), userVo.getValueK(),
							userVo.getRate());
				}
				// Changes for ELC and IGT ends 25-12-2019
			}
			// Changes for ELC and IGT starts 25-12-2019
			if (userVo.getProductCode().equalsIgnoreCase("IGT")) {
				if (userVo.getEventCode().equalsIgnoreCase("IIG")) {
					updateTFBOIGTIIG(userVo.getTiReferanceNo(),
							userVo.getSolID(), userVo.getCustomeCif(),
							userVo.getCustomeName(), userVo.getAmount(),
							userVo.getCurrency(), userVo.getRequestId(),
							userVo.getSubProductCode(), userVo.getTenure(),
							userVo.getExpiryDate());
				}
				if (userVo.getEventCode().equalsIgnoreCase("XIG")) {

					updateTFBOIgtExpire(userVo.getTiReferanceNo(),
							userVo.getSolID(), userVo.getCustomeCif(),
							userVo.getCustomeName(), userVo.getAmount(),
							userVo.getCurrency(), userVo.tenure,
							userVo.getRequestId());

					updateTFBOTiRefInTransTable(userVo.getTiReferanceNo(),
							userVo.getRequestId());

				}
				if (userVo.getEventCode().equalsIgnoreCase("NAIG")) {
					updateTFBOIGTNAIG(userVo.getTiReferanceNo(),
							userVo.getSolID(), userVo.getCustomeCif(),
							userVo.getCustomeName(), userVo.getAmount(),
							userVo.getCurrency(), userVo.getRequestId(),
							userVo.getSubProductCode(), userVo.getTenure());
				}
				if (userVo.getEventCode().equalsIgnoreCase("LIG")) {
					updateTFBOIGTLIG(userVo.getTiReferanceNo(),
							userVo.getSolID(), userVo.getCustomeCif(),
							userVo.getCustomeName(), userVo.getAmount(),
							userVo.getCurrency(), userVo.getRequestId(),
							userVo.getSubProductCode(), userVo.getTenure(),
							userVo.getPartInvocation(),
							userVo.getGuarnteeAmtPrevInv(),
							userVo.getReqInvAmt());
				}
				/* changes for rate taken starts 010120 */
				if (userVo.getEventCode().equalsIgnoreCase("OIG")) {
					updateTFBOIGTOIG(userVo.getTiReferanceNo(),
							userVo.getSolID(), userVo.getCustomeCif(),
							userVo.getCustomeName(), userVo.getAmount(),
							userVo.getCurrency(), userVo.getRequestId(),
							userVo.getSubProductCode(), userVo.getTenure(),
							userVo.getPartInvocation(),
							userVo.getGuarnteeAmtPrevInv(),
							userVo.getReqInvAmt(), userVo.getRateTaken(),
							userVo.getValueK(), userVo.getToken(),
							userVo.getRate(), userVo.getBillReference());
				}
				/* changes for rate taken starts 010120 */
				// Expiry,closure,cancellation Changes Starts
				if (userVo.getEventCode().equalsIgnoreCase("NIG")) {

					updateTFBOIgtCancel(userVo.getTiReferanceNo(),
							userVo.getSolID(), userVo.getCustomeCif(),
							userVo.getAmount(), userVo.getCurrency(),
							userVo.getRequestId(), userVo.getTenure());

					updateTFBOTiRefInTransTable(userVo.getTiReferanceNo(),
							userVo.getRequestId());

				}

				if (userVo.getEventCode().equalsIgnoreCase("KIG")) {

					updateTFBOIgtClosure(userVo.getTiReferanceNo(),
							userVo.getSolID(), userVo.getCustomeCif(),
							userVo.getAmount(), userVo.getCurrency(),
							userVo.getRequestId(), userVo.getTenure());

					updateTFBOTiRefInTransTable(userVo.getTiReferanceNo(),
							userVo.getRequestId());

				}
				// Expiry,closure,cancellation Changes Ends
			}
			// Changes for ELC and IGT ends 25-12-2019
			if (userVo.getProductCode().equalsIgnoreCase("IDC")) {
				// FREEZING(SCENARIO) off shore team starts 31122019
				CommonMethods aCommonMethods = new CommonMethods();

				// FREEZING(SCENARIO) off shore team ends 31122019
				if (userVo.getEventCode().equalsIgnoreCase("CRE")) {

					if (aCommonMethods.isValueAvailable(userVo.getDirect())
							&& userVo.getDirect().equals("false")) {
						userVo.setRateTaken("false");
						userVo.setToken("");
						userVo.setRate("");
						userVo.setValueK("");
					}

					updateTFBOIdcCreate(userVo.getRequestId(), userVo
							.getTiReferanceNo().trim(), userVo.getCustomeCif()
							.trim(), userVo.getCustomeName().trim(), userVo
							.getBillAmount().trim(), userVo.getCurrency()
							.trim(), userVo.getDirect().trim(), userVo
							.getPartpay().trim(), userVo.getSubProductCode()
							.trim(), userVo.getSolID().trim(), userVo
							.getBillUsancePeriod().trim(), userVo
							.getRateTaken().trim(), userVo.getToken().trim(),
							userVo.getValueK().trim(), userVo.getRate().trim());

					updateTFBOIdcFlow(userVo.getRequestId(),
							userVo.getDirect(), userVo.getSubProductCode());

				}
				// karthik 13012020 starts
				/*
				 * if (userVo.getEventCode().equalsIgnoreCase("CCO")) {
				 * updateTFBOIdcCco(userVo.tiReferanceNo, userVo.getSolID(),
				 * userVo.getCustomeCif(), userVo.getCustomeName(),
				 * userVo.getAmount(), userVo.getCurrency(),
				 * userVo.getUserRemark(), userVo.getRequestId());
				 * 
				 * }
				 */
				if (userVo.getEventCode().equalsIgnoreCase("CCO")) {
					updateTFBOIdcCco(userVo.tiReferanceNo, userVo.getSolID(),
							userVo.getCustomeCif(), userVo.getCustomeName(),
							userVo.getAmount(), userVo.getCurrency(),
							userVo.getUserRemark(), userVo.getRequestId());

				}
				// karthik 13012020 ends
				if (userVo.getEventCode().equalsIgnoreCase("CAC")) {

					updateTFBOIdcAccept(userVo.getRequestId(),
							userVo.getSolID(), userVo.getTiReferanceNo(),
							userVo.getCustomeCif(), userVo.getCurrency(),
							userVo.getAcceptBillAmt(),
							userVo.getBillUsancePeriod(),
							userVo.getSubProductCode(), userVo.getCustomeName());
				}
				/*
				 * updateTFBOIdcPayment(userVo.getRequestId(),
				 * userVo.getSolID(), userVo.getTiReferanceNo(),
				 * userVo.getBillAmount(), userVo.getRateTaken(),
				 * userVo.getPartpay(), userVo.getSubProductCode(),
				 * userVo.getRate(), userVo.getValueK());
				 */
				// FREEZING(SCENARIO) off shore team STARTS 31122019
				System.out.println("Getting part amount in if condition==>"
						+ userVo.getPartpay());
				if (userVo.getEventCode().equalsIgnoreCase("CLP")) {
					System.out.println("RATE TAKEN >>--> "
							+ userVo.getRateTaken());
					System.out.println("RATE >>--> " + userVo.getRate());
					System.out.println("TOKEN >>--> " + userVo.getToken());
					System.out.println("K VALUE>>--> " + userVo.getValueK());
					// FREEZING(SCENARIO) off shore team starts 06012020
					if (aCommonMethods.isValueAvailable(userVo
							.getDirectCREEvent())
							&& userVo.getDirectCREEvent().trim()
									.equalsIgnoreCase("true")) {
						System.out.println("entering direct condition");
						userVo.setRateTaken("true");
					}
					if (aCommonMethods.isValueAvailable(userVo.getRateTaken())
							&& userVo.getRateTaken().equalsIgnoreCase("false")) {
						System.out.println("entering arte taken condition");
						userVo.setToken("");
						userVo.setRate("");
						userVo.setValueK("");
						userVo.setDirect("false");
					}
					System.out.println("RATE TAKEN >>--> "
							+ userVo.getRateTaken());
					System.out.println("RATE >>--> " + userVo.getRate());
					System.out.println("TOKEN >>--> " + userVo.getToken());
					System.out.println("K VALUE>>--> " + userVo.getValueK());
					updateTFBOIdcPayment(userVo.getRequestId(),
							userVo.getSolID(), userVo.getTiReferanceNo(),
							userVo.getBillAmount(), userVo.getRateTaken(),
							userVo.getPartpay(), userVo.getSubProductCode(),
							userVo.getRate(), userVo.getValueK(),
							userVo.getCustomeCif(), userVo.getCustomeName(),
							userVo.getToken(), userVo.getCurrency(),
							userVo.getDirectCREEvent(), userVo.getDirect());

					// FREEZING(SCENARIO) off shore team ends 31122019
				}
			}
			if (userVo.getProductCode().equalsIgnoreCase("FEL")) {
				if (userVo.getEventCode().equalsIgnoreCase("CSA4")) {
					updateTFBOFelCreate(userVo.getSolID(),
							userVo.getLcRefNum(), userVo.getAmount(),
							userVo.getBillReferenceNo(), userVo.getRequestId(),
							userVo.getFncAmount(), userVo.getBillTenure(),
							userVo.getPreshipAccSetteld(),
							userVo.getRateTaken(), userVo.getSubProductCode(),
							userVo.getToken(), userVo.getRateTakenK(),
							userVo.getRate(), userVo.getCurrency(),
							userVo.getCustomeCif(), userVo.getCustomeName(),
							userVo.getPreshipAccSetteld());
				}
				// karthik 13012020 starts
				/*
				 * if (userVo.getEventCode().equalsIgnoreCase("PSA4")) {
				 * updateTFBOFelPSA4(userVo.tiReferanceNo, userVo.getSolID(),
				 * userVo.getCustomeCif(), userVo.getCustomeName(),
				 * userVo.getAmount(), userVo.getCurrency(), userVo.getLcType(),
				 * userVo.getUserRemark(), userVo.getRequestId()); }
				 */
				if (userVo.getEventCode().equalsIgnoreCase("PSA4")) {
					updateTFBOFelPSA4(userVo.getLcRefNum(), userVo.getSolID(),
							userVo.getCustomeCif(), userVo.getCustomeName(),
							userVo.getAmount(), userVo.getCurrency(),
							userVo.getLcType(), userVo.getUserRemark(),
							userVo.getRequestId());
				}
				// karthik 13012020 ends
				if (userVo.getEventCode().equalsIgnoreCase("JSA4")) {
					updateTFBOFelAdjust(userVo.getSolID(),
							userVo.getLcRefNum(), userVo.getCurrency(),
							userVo.getMaturityDate(), userVo.getRequestId(),
							userVo.getFncAmount(), userVo.getBillTenure(),
							userVo.getCustomeCif(), userVo.getCustomeName(),
							userVo.getSubProductCode());
				}
				if (userVo.getEventCode().equalsIgnoreCase("CRYST")) {
					updateTFBOFelCrystalization(userVo.getSolID(),
							userVo.getLcRefNum(), userVo.getCurrency(),
							userVo.getAmount(), userVo.getRequestId(),
							userVo.getFncAmount(), userVo.getBillTenure(),
							userVo.getCustomeCif(), userVo.getCustomeName(),
							userVo.getSubProductCode(),
							userVo.getFinalPayment(), userVo.getRateTaken(),
							userVo.getToken(), userVo.getRateTakenK(),
							userVo.getRate());
				}
				if (userVo.getEventCode().equalsIgnoreCase("RSA4")) {
					updateTFBOFelRepay(userVo.getSolID(), userVo.getLcRefNum(),
							userVo.getCurrency(), userVo.getAmount(),
							userVo.getRequestId(), userVo.getFncAmount(),
							userVo.getBillTenure(), userVo.getCustomeCif(),
							userVo.getCustomeName(),
							userVo.getSubProductCode(),
							userVo.getFinalPayment(), userVo.getRateTaken(),
							userVo.getToken(), userVo.getRateTakenK(),
							userVo.getRate(), userVo.getPreshipAccSetteld());
				}
			}

			// SBLC 251219
			if (userVo.getProductCode().equalsIgnoreCase("ISB")) {
				if (userVo.getEventCode().equalsIgnoreCase("IIS")) {

					updateTFBOIsbIssue(userVo.getRequestId(),
							userVo.getSolID(), userVo.getTiReferanceNo(),
							userVo.getCustomeCif(), userVo.getCustomeName(),
							userVo.getAmount(), userVo.getCurrency(),
							userVo.getRateTaken(),
							userVo.getBillUsancePeriod(),
							userVo.getBillrefno(), userVo.getBgRefNo(),
							userVo.getSubProductCode());

				}
				if (userVo.getEventCode().equalsIgnoreCase("NJIS")) {

					updateTFBOIsbAdjust(userVo.getRequestId(),
							userVo.getSolID(), userVo.getTiReferanceNo(),
							userVo.getCustomeCif(), userVo.getCustomeName(),
							userVo.getAmount(), userVo.getCurrency(),
							userVo.getBillUsancePeriod(),
							userVo.getBillrefno(), userVo.getBgRefNo(),
							userVo.getSubProductCode());

				}
				if (userVo.getEventCode().equalsIgnoreCase("NAIS")) {

					updateTFBOIsbAmend(userVo.getRequestId(),
							userVo.getSolID(), userVo.getTiReferanceNo(),
							userVo.getCustomeCif(), userVo.getCustomeName(),
							userVo.getAmount(), userVo.getCurrency(),
							userVo.getBillUsancePeriod(),
							userVo.getBillrefno(), userVo.getBgRefNo(),
							userVo.getSubProductCode());

				}

				if (userVo.getEventCode().equalsIgnoreCase("LIS")) {

					updateTFBOIsbClaimReceived(userVo.getRequestId(),
							userVo.getSolID(), userVo.getTiReferanceNo(),
							userVo.getCustomeCif(), userVo.getCustomeName(),
							userVo.getAmount(), userVo.getCurrency(),
							userVo.getBillUsancePeriod(),
							userVo.getBillrefno(), userVo.getBgRefNo(),
							userVo.getSubProductCode());

				}
				if (userVo.getEventCode().equalsIgnoreCase("KIS")) {
					updateTFBOIsbclosuer(userVo.getRequestId(),
							userVo.getSolID(), userVo.getTiReferanceNo(),
							userVo.getCustomeCif(), userVo.getCustomeName(),
							userVo.getTenure(), userVo.getAmount(),
							userVo.getCurrency(), userVo.getSubProductCode());

				}
				if (userVo.getEventCode().equalsIgnoreCase("NIS")) {
					updateTFBOIsbcance(userVo.getRequestId(),
							userVo.getSolID(), userVo.getTiReferanceNo(),
							userVo.getCustomeCif(), userVo.getCustomeName(),
							userVo.getTenure(), userVo.getAmount(),
							userVo.getCurrency(), userVo.getSubProductCode());
				}

				if (userVo.getEventCode().equalsIgnoreCase("OIS")) {

					updateTFBOIsbOutStdClaim(userVo.getRequestId(),
							userVo.getSolID(), userVo.getTiReferanceNo(),
							userVo.getConBillRef(), userVo.getCustomeCif(),
							userVo.getCustomeName(), userVo.getAmount(),
							userVo.getCurrency(), userVo.getBillUsancePeriod(),
							userVo.getBillrefno(), userVo.getBgRefNo(),
							userVo.getSubProductCode(),
							userVo.getBillReference(), userVo.getRateTaken(),
							userVo.getToken(), userVo.getValueK(),
							userVo.getRate());

				}

			}
			// SBLC 251219_END

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		logger.info(ActionConstants.EXITING_METHOD);
	}

	// SBLC_251219

	private void updateTFBOIsbOutStdClaim(String requestId, String solID,
			String tiReferanceNo, String conBillRef, String customeCif,
			String customeName, String amount, String currency,
			String billUsancePeriod, String billrefno, String bgRefNo,
			String subProduct, String billref, String rateToken, String token,
			String valueK, String rate) throws Exception {

		System.out.println(ActionConstants.ENTERING_METHOD);
		DBHelper aDBHelper = new DBHelper();

		aDBHelper.setValueInDB(tiReferanceNo, requestId,
				ActionConstants.GETUPDATETIREFERANCE_QUERY);
		// ADDED BY CHANDRU
		if (rateToken != null && !rateToken.trim().equals("")) {
			if (rateToken.equals("true")) {
				rateToken = "Y";
			} else {
				rateToken = "N";
			}
		}
		// ADDED BY CHANDRU
		aDBHelper.setISBOISInDB(requestId, solID, tiReferanceNo, conBillRef,
				customeCif, customeName, amount, currency, billUsancePeriod,
				billrefno, bgRefNo, subProduct, billref, rateToken, token,
				valueK, rate, ActionConstants.GETUPDATETFBOISBOIS_QUERY);
		System.out.println(ActionConstants.EXITING_METHOD);

	}

	private void updateTFBOIsbClaimReceived(String requestId, String solID,
			String tiReferanceNo, String customeCif, String customeName,
			String amount, String currency, String billUsancePeriod,
			String billrefno, String bgRefNo, String subProduct)
			throws Exception {

		System.out.println(ActionConstants.ENTERING_METHOD);
		DBHelper aDBHelper = new DBHelper();

		aDBHelper.setValueInDB(tiReferanceNo, requestId,
				ActionConstants.GETUPDATETIREFERANCE_QUERY);

		aDBHelper.setISB_AJ_AD_CR_InDB(requestId, solID, tiReferanceNo,
				customeCif, customeName, amount, currency, billUsancePeriod,
				billrefno, bgRefNo, subProduct,
				ActionConstants.GETUPDATETFBOISBLIS_QUERY);
		System.out.println(ActionConstants.EXITING_METHOD);

	}

	private void updateTFBOIsbAmend(String requestId, String solID,
			String tiReferanceNo, String customeCif, String customeName,
			String amount, String currency, String billUsancePeriod,
			String billrefno, String bgRefNo, String subProduct)
			throws Exception {

		System.out.println(ActionConstants.ENTERING_METHOD);
		DBHelper aDBHelper = new DBHelper();

		aDBHelper.setValueInDB(tiReferanceNo, requestId,
				ActionConstants.GETUPDATETIREFERANCE_QUERY);

		aDBHelper.setISB_AJ_AD_CR_InDB(requestId, solID, tiReferanceNo,
				customeCif, customeName, amount, currency, billUsancePeriod,
				billrefno, bgRefNo, subProduct,
				ActionConstants.GETUPDATETFBOISBNAIS_QUERY);
		System.out.println(ActionConstants.EXITING_METHOD);

	}

	private void updateTFBOIsbAdjust(String requestId, String solID,
			String tiReferanceNo, String customeCif, String customeName,
			String amount, String currency, String billUsancePeriod,
			String billrefno, String bgRefNo, String subProduct)
			throws Exception {

		System.out.println(ActionConstants.ENTERING_METHOD);
		DBHelper aDBHelper = new DBHelper();

		aDBHelper.setValueInDB(tiReferanceNo, requestId,
				ActionConstants.GETUPDATETIREFERANCE_QUERY);

		aDBHelper.setISB_AJ_AD_CR_InDB(requestId, solID, tiReferanceNo,
				customeCif, customeName, amount, currency, billUsancePeriod,
				billrefno, bgRefNo, subProduct,
				ActionConstants.GETUPDATETFBOISBNJIS_QUERY);
		System.out.println(ActionConstants.EXITING_METHOD);

	}

	private void updateTFBOIsbIssue(String requestId, String solID,
			String tiReferanceNo, String customeCif, String customeName,
			String amount, String currency, String rateTaken,
			String billUsancePeriod, String billrefno, String bgRefNo,
			String subProduct) throws Exception {
		System.out.println(ActionConstants.ENTERING_METHOD);
		DBHelper aDBHelper = new DBHelper();

		// CHANGED BY CHANDRU
		if (rateTaken.equals("false")) {
			rateTaken = "N";
		} else {
			rateTaken = "Y";
		}
		// ENDS

		aDBHelper.setISBIISSInDB(requestId, solID, customeCif, customeName,
				amount, currency, rateTaken, billUsancePeriod, billrefno,
				bgRefNo, subProduct, ActionConstants.GETUPDATETFBOISBISS_QUERY);
		System.out.println(ActionConstants.EXITING_METHOD);

	}

	// SBLC_251219END

	public void updateTFBOFocCreate(String solId, String customerCif,
			String amount, String finAmount, String currency, String requestId,
			String usancePeriod, String prodTypeFOC, String preshipAccSetteld,
			String rateTaken, String token, String rateK, String rate,
			String tiReferanceNo) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		DBHelper aDBHelper = new DBHelper();
		System.out.println("updateTFBOFocCreate prodTypeFOC-->" + prodTypeFOC);
		aDBHelper.setValueInDB(tiReferanceNo, requestId,
				ActionConstants.GETUPDATETIREFERANCE_QUERY);

		// CHANGED BY CHANDRU
		if (rateTaken.equals("false")) {
			rateTaken = "N";
		} else {
			rateTaken = "Y";
		}
		// ENDS

		aDBHelper.setValueFOCCREInDB(solId, customerCif, amount, finAmount,
				currency, usancePeriod, preshipAccSetteld, prodTypeFOC,
				rateTaken, token, rateK, rate, requestId,
				ActionConstants.GETUPDATETFBOFOCCREATENEW_QUERY);
		logger.info(ActionConstants.EXITING_METHOD);
	}

	public void updateTFBOFsaAdjust(String solId, String customerCif,
			String amount, String currency, String requestId,
			String usancePeriod, String prodType, String maturityDate,
			String tiReferanceNo) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		DBHelper aDBHelper = new DBHelper();
		// System.out.println("updateTFBOFocCreate prodTypeFOC-->" + prodType);
		// System.out.println("updateTFBOFocCreate maturityDate-->" +
		// maturityDate);
		aDBHelper.setValueInDB(tiReferanceNo, requestId,
				ActionConstants.GETUPDATETIREFERANCE_QUERY);
		aDBHelper.setValueFOCADJInDB(solId, customerCif, amount, currency,
				usancePeriod, prodType, maturityDate, requestId,
				ActionConstants.GETUPDATETFBOFSAADJUSTNEW_QUERY);
		logger.info(ActionConstants.EXITING_METHOD);
	}

	public void updateTFBOFsaRepay(String solId, String customerCif,
			String amount, String currency, String requestId,
			String usancePeriod, String prodType, String rateTaken,
			String token, String rateK, String rate, String partLiq,
			String pcAmount, String tiReferanceNo) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		DBHelper aDBHelper = new DBHelper();
		System.out.println("updateTFBOFocCreate prodTypeFOC-->" + prodType);
		aDBHelper.setValueInDB(tiReferanceNo, requestId,
				ActionConstants.GETUPDATETIREFERANCE_QUERY);
		aDBHelper.setValueInFSAREPAYDB(solId, customerCif, amount, currency,
				usancePeriod, prodType, rateTaken, token, rateK, rate, partLiq,
				pcAmount, requestId,
				ActionConstants.GETUPDATETFBOFSAREPAYNEW_QUERY);
		logger.info(ActionConstants.EXITING_METHOD);
	}

	public void updateTFBOFsaCreate(String solId, String customerCif,
			String amount, String currency, String requestId,
			String usancePeriod, String prodType, String rateTaken,
			String token, String rateK, String rate, String tiReferanceNo)
			throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		DBHelper aDBHelper = new DBHelper();
		System.out.println("updateTFBOFocCreate prodTypeFOC-->" + prodType);
		aDBHelper.setValueInDB(tiReferanceNo, requestId,
				ActionConstants.GETUPDATETIREFERANCE_QUERY);

		aDBHelper.setValueInDB(solId, customerCif, amount, currency,
				usancePeriod, prodType, rateTaken, token, rateK, rate,
				requestId, ActionConstants.GETUPDATETFBOFSACREATENEW_QUERY);
		logger.info(ActionConstants.EXITING_METHOD);
	}

	public void updateTFBOEventTableInScrutinizer(UserTransactionVO userVo)
			throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		DBHelper aDBHelper = new DBHelper();
		CommonMethods aCommonMethods = new CommonMethods();
		String rate = "";
		try {
			if (userVo.getProductCode().equalsIgnoreCase("ILC")) {
				if (userVo.getEventCode().equalsIgnoreCase("POCP")) {

					rate = userVo.getRateTaken();
					if (rate.equals("true")) {
						rate = "Y";
					} else {
						rate = "N";
					}
					aDBHelper.setValueInDB(rate, userVo.getRate(),
							userVo.getValueK(), userVo.getRequestId(),
							ActionConstants.GETUPDATETFBOILCOSCLMPAYSCRU_QUERY);
				}
				if (userVo.getEventCode().equalsIgnoreCase("POCD")) {
					aDBHelper.setValueInDB(rate, userVo.getRate(),
							userVo.getValueK(), userVo.getRequestId(),
							ActionConstants.GETUPDATETFBOILCOSCLMDEVSCRU_QUERY);
				}
			}
			// Inward Remittance changes 23-12-2019 starts

			if (userVo.getProductCode().equalsIgnoreCase("CPCI")) {
				if (userVo.getEventCode().equalsIgnoreCase("PCIC")) {

					// rate taken null checking 31122019
					if (aCommonMethods.isValueAvailable(userVo.getRateTaken())) {
						rate = userVo.getRateTaken().trim();

						if (rate.equalsIgnoreCase("true")) {
							userVo.setRateTaken("Y");
						} else {
							userVo.setRateTaken("N");
						}
					}

					aDBHelper.setValueInDB(userVo.getToken(),
							userVo.getRateTaken(), userVo.getRate(),
							userVo.getRateTakenK(), userVo.getRequestId(),
							ActionConstants.GETUPDATETFBOCPCICRESCRU_QUERY);
				}
			}

			// Inward Remittance changes 23-12-2019 ends

			// Issue Fix Offshore Team 30122019 starts

			// Outward Remittance changes starts

			if (userVo.getProductCode().equalsIgnoreCase("CPCO")) {
				if (userVo.getEventCode().equalsIgnoreCase("PCOC")) {

					// rate taken null checking 31122019
					if (aCommonMethods.isValueAvailable(userVo.getRateTaken())) {
						rate = userVo.getRateTaken().trim();
						if (rate.equalsIgnoreCase("true")) {
							userVo.setRateTaken("Y");
						} else {
							userVo.setRateTaken("N");
						}
					}

					aDBHelper.setValueInDB(userVo.getToken(),
							userVo.getRateTaken(), userVo.getRate(),
							userVo.getValueK(), userVo.getRequestId(),
							ActionConstants.GETUPDATETFBOCPCOCRESCRU_QUERY);
				}
			}

			// Outward Remittance changes ends

			// Issue Fix Offshore Team 30122019 ends

			if (userVo.getProductCode().equalsIgnoreCase("ODC")) {
				logger.info("entering ODC RateTaken >>-->"
						+ userVo.getRateTaken());
				if (aCommonMethods.isValueAvailable(userVo.getRateTaken())) {
					rate = userVo.getRateTaken();
					if (rate.equalsIgnoreCase("true")) {
						rate = "Y";
					} else {
						rate = "N";
					}
				}
				// RATE_TAKEN=?,TOKEN=?,RATE_TAKEN_K=?,RATE=?
				System.out.println("rate >>-->" + rate);
				if (userVo.getEventCode().equalsIgnoreCase("CRE")) {
					// CHANGED BY CHANDRU
					aDBHelper.setValueInDB(rate, userVo.getToken(),
							userVo.getRateTakenK(), userVo.getRate(),
							userVo.getRequestId(),
							ActionConstants.GETUPDATETFBOODCCREATESCRU_QUERY);

					updateTFBOOdcFlow(userVo.getRequestId(),
							userVo.getDirect(), userVo.getMtReceived(),
							userVo.getPartPayment(),
							userVo.getSubProductCode(),
							userVo.getFinanceSameDay());

				}
				if (userVo.getEventCode().equalsIgnoreCase("CLP")) {
					aDBHelper.setValueInDB(rate, userVo.getToken(),
							userVo.getRateTakenK(), userVo.getRate(),
							userVo.getRequestId(),
							ActionConstants.GETUPDATETFBOODCPAYMENTSCRU_QUERY);
					aDBHelper.setODCPAYUpdate(userVo.getFinalPayment(),
							userVo.getSenderRefno(), userVo.getRequestId(),
							ActionConstants.GETUPDATETFBOODCPAYMENT_QUERY);

				}
			}
			if (userVo.getProductCode().equalsIgnoreCase("IDC")) {
				if (userVo.getEventCode().equalsIgnoreCase("CRE")) {
					if (aCommonMethods.isValueAvailable(userVo.getRateTaken())
							&& userVo.getRateTaken().equalsIgnoreCase("false")) {
						userVo.setToken("");
						userVo.setRate("");
						userVo.setValueK("");
						userVo.setDirect("false");
					}
					rate = userVo.getRateTaken().trim();
					// CHANGED BY CHANDRU
					if (rate.equals("false")) {
						rate = "N";
					} else {
						rate = "Y";
					}
					// ENDS
					aDBHelper.setValueInDB(userVo.getToken(), rate.trim(),
							userVo.getRate(), userVo.getValueK(),
							userVo.getRequestId(),
							ActionConstants.GETUPDATETFBOIDCCRESCRU_QUERY);

					updateTFBOIdcFlow(userVo.getRequestId(),
							userVo.getDirect(), userVo.getSubProductCode());

				}

				if (userVo.getEventCode().equalsIgnoreCase("CLP")) {
					if (aCommonMethods.isValueAvailable(userVo.getRateTaken())
							&& userVo.getRateTaken().equalsIgnoreCase("false")) {
						userVo.setToken("");
						userVo.setRate("");
						userVo.setValueK("");
						userVo.setDirect("false");
					}
					// CHANGED BY CHANDRU
					rate = userVo.getRateTaken();
					if (rate.equals("false")) {
						rate = "N";
					} else {
						rate = "Y";
					}
					// ENDS
					aDBHelper.setValueInDB(userVo.getDirect(),
							userVo.getToken(), rate.trim(), userVo.getRate(),
							userVo.getValueK(), userVo.getRequestId(),
							ActionConstants.GETUPDATETFBOIDCCLPSCRU_QUERY);
					// FREEZING(SCENARIO) off shore team ends 31122019
				}
			}
			if (userVo.getProductCode().equalsIgnoreCase("FEL")) {
				if (userVo.getEventCode().equalsIgnoreCase("CSA4")) {
					rate = userVo.getRateTaken().trim();
					// CHANGED BY CHANDRU
					rate = userVo.getRateTaken();
					if (rate.equals("false")) {
						rate = "N";
					} else {
						rate = "Y";
					}
					// ENDS

					aDBHelper.setValueInDB(rate, userVo.getRate(),
							userVo.getRateTakenK(), userVo.getToken(),
							userVo.getRequestId(),
							ActionConstants.GETUPDATETFBOFELCRESCRU_QUERY);
				}
				if (userVo.getEventCode().equalsIgnoreCase("CRYST")) {
					// CHANGED BY CHANDRU
					rate = userVo.getRateTaken();
					if (rate.equals("false")) {
						rate = "N";
					} else {
						rate = "Y";
					}
					// ENDS

					aDBHelper.setValueInDB(rate, userVo.getRate(),
							userVo.getRateTakenK(), userVo.getToken(),
							userVo.getRequestId(),
							ActionConstants.GETUPDATETFBOFELCRYSTSCRU_QUERY);
				}
				if (userVo.getEventCode().equalsIgnoreCase("RSA4")) {
					rate = userVo.getRateTaken();
					if (rate.equals("false")) {
						rate = "N";
					} else {
						rate = "Y";
					}
					// ENDS

					String preshipAcc = userVo.getPreshipAccSetteld();
					if (preshipAcc.equals("true")) {
						preshipAcc = "Y";
					} else {
						preshipAcc = "N";
					}
					// ENDS

					aDBHelper.setValueInDB(rate, userVo.getRate(),
							userVo.getRateTakenK(), preshipAcc,
							userVo.getSenderRefno(), userVo.getToken(),
							userVo.getRequestId(),
							ActionConstants.GETUPDATETFBOFELRPYSCRU_QUERY);
				}
			}

			if (userVo.getProductCode().equalsIgnoreCase("ISB")) {
				if (userVo.getEventCode().equalsIgnoreCase("OIS")) {
					if (userVo.getRateTaken() != null
							&& !userVo.getRateTaken().trim().equals("")) {
						rate = userVo.getRateTaken().trim();
						// CHANGED BY CHANDRU
						if (rate.equals("true")) {
							rate = "Y";
						} else {
							rate = "N";
						}
						// ENDS
					}
					aDBHelper.setValueInDB(rate, userVo.getToken(),
							userVo.getValueK(), userVo.getRate(),
							userVo.getRequestId(),
							ActionConstants.GETUPDATETFBOISBOISSCRU_QUERY);

				}
			}

			if (userVo.getProductCode().equalsIgnoreCase("IGT")) {
				if (userVo.getEventCode().equalsIgnoreCase("OIG")) {
					if (userVo.getRateTaken() != null
							&& !userVo.getRateTaken().trim().equals("")) {
						rate = userVo.getRateTaken().trim();
						// CHANGED BY CHANDRU
						if (rate.equals("true")) {
							rate = "Y";
						} else {
							rate = "N";
						}
						// ENDS
					}
					aDBHelper.setValueInDB(rate, userVo.getToken(),
							userVo.getValueK(), userVo.getRate(),
							userVo.getRequestId(),
							ActionConstants.GETUPDATETFBOIGTOIGSCRU_QUERY);

				}
			}

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		logger.info(ActionConstants.EXITING_METHOD);
	}

	public void updateTFBOFocAdjust(String solId, String customerCif,
			String finAmount, String currency, String requestId,
			String usancePeriod, String prodTypeFOC, String maturityDate,
			String tiReferanceNo) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		DBHelper aDBHelper = new DBHelper();

		aDBHelper.setValueInDB(tiReferanceNo, requestId,
				ActionConstants.GETUPDATETIREFERANCE_QUERY);
		aDBHelper.setValueFOCADJInDB(solId, customerCif, finAmount, currency,
				usancePeriod, prodTypeFOC, maturityDate, requestId,
				ActionConstants.GETUPDATETFBOFOCADJUSTNEW_QUERY);
		logger.info(ActionConstants.EXITING_METHOD);
	}

	public void updateTFBOFocRepay(String solId, String customerCif,
			String finAmount, String currency, String requestId,
			String usancePeriod, String prodTypeFOC, String finalRepay,
			String rateTaken, String token, String rateTakenk, String rate,
			String tiReferanceNo, String preShipAcc) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		DBHelper aDBHelper = new DBHelper();

		aDBHelper.setValueInDB(tiReferanceNo, requestId,
				ActionConstants.GETUPDATETIREFERANCE_QUERY);

		// CHANGED BY CHANDRU
		if (rateTaken.equals("false")) {
			rateTaken = "N";
		} else {
			rateTaken = "Y";
		}
		// ENDS

		aDBHelper.setFOCCREValueInDB(solId, customerCif, finAmount, currency,
				usancePeriod, prodTypeFOC, finalRepay, rateTaken, token,
				rateTakenk, rate, preShipAcc, requestId,
				ActionConstants.GETUPDATETFBOFOCREPAYNEW_QUERY);
		logger.info(ActionConstants.EXITING_METHOD);
	}

	public void updateTFBOFocCryst(String solId, String customerCif,
			String finAmount, String currency, String requestId,
			String usancePeriod, String prodTypeFOC, String rateTaken,
			String token, String rateTakenk, String rate, String tiReferanceNo)
			throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		DBHelper aDBHelper = new DBHelper();

		aDBHelper.setValueInDB(tiReferanceNo, requestId,
				ActionConstants.GETUPDATETIREFERANCE_QUERY);

		// CHANGED BY CHANDRU
		if (rateTaken.equals("false")) {
			rateTaken = "N";
		} else {
			rateTaken = "Y";
		}
		// ENDS

		aDBHelper.setValueInDB(solId, customerCif, finAmount, currency,
				usancePeriod, prodTypeFOC, rateTaken, token, rateTakenk, rate,
				requestId, ActionConstants.GETUPDATETFBOFOCCRYSTNEW_QUERY);
		logger.info(ActionConstants.EXITING_METHOD);
	}

	/*
	 * @SuppressWarnings("unused") private void updateTFBOFelCreate(String
	 * solID, String lcRefNum, String amount, String billReferenceNo, String
	 * requestId, String fncAmount, String billTenure, String preshipAcc, String
	 * rateTaken, String subProductCode, String token, String rateTakenK, String
	 * rate) throws Exception {
	 * System.out.println(ActionConstants.ENTERING_METHOD); DBHelper aDBHelper =
	 * new DBHelper(); aDBHelper.setValueFelCreInDB(solID, lcRefNum, amount,
	 * billReferenceNo, requestId, fncAmount, billTenure, preshipAcc, rateTaken,
	 * subProductCode, token, rateTakenK, rate,
	 * ActionConstants.GETUPDATETFBOFELCRENEW_QUERY);
	 * 
	 * 
	 * 
	 * System.out.println(ActionConstants.EXITING_METHOD);
	 * 
	 * }
	 */

	private void updateTFBOElcAdv(String solId, String customeCif,
			String customeName, String amount, String currency,
			String lCreceivedSWIFT, String senderRefno, String requestId,
			String lcType, String usancePeriod) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		DBHelper aDBHelper = new DBHelper();
		aDBHelper.setValueInDB(solId, customeCif, customeName, amount,
				currency, lCreceivedSWIFT, senderRefno, lcType, usancePeriod,
				requestId, ActionConstants.GETUPDATETFBOELCADVNEW_QUERY);
		logger.info(ActionConstants.EXITING_METHOD);

	}

	private void updateTFBOElcAmend(String tiReferenceNo, String solID,
			String custCif, String amount, String currency, String lcType,
			String senderRefno, String usancePeriod, String requestId)
			throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD + ">> updateTFBOElcAmend");
		DBHelper aDBHelper = new DBHelper();
		logger.info("Getting TI ReferenceNo==>" + tiReferenceNo);
		logger.info("Getting solID==>" + solID);
		logger.info("Getting customer cif==>" + custCif);
		logger.info("Getting amount==>" + amount);
		logger.info("Getting currency==>" + currency);
		logger.info("Getting lc Type==>" + lcType);
		logger.info("Getting sender Ref no==>" + senderRefno);
		logger.info("Getting requestId==>" + requestId);
		aDBHelper.setValueInDB(tiReferenceNo, requestId,
				ActionConstants.GETUPDATETIREFERANCE_QUERY);
		aDBHelper.setValueInELCAMDDB(solID, custCif, amount, currency, lcType,
				senderRefno, usancePeriod, requestId,
				ActionConstants.GETUPDATETFBOELCAMDNEW_QUERY);
		logger.info(ActionConstants.EXITING_METHOD + ">> updateTFBOElcAmend");

	}

	public void updateTFBOIlcIssue(String solId, String customerCif,
			String amount, String currency, String requestId, String lcType,
			String usancePeriod) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		DBHelper aDBHelper = new DBHelper();
		aDBHelper.setValueInDB(solId, customerCif, amount, currency, lcType,
				usancePeriod, requestId,
				ActionConstants.GETUPDATETFBOILCISSNEW_QUERY);
		logger.info(ActionConstants.EXITING_METHOD);
	}

	public void updateTFBOIlcAmend(String tiReferanceNo, String solId,
			String customerCif, String amount, String currency, String lcType,
			String requestId) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		DBHelper aDBHelper = new DBHelper();
		aDBHelper.setValueInDB(tiReferanceNo, requestId,
				ActionConstants.GETUPDATETIREFERANCE_QUERY);
		aDBHelper.setValueInDB(solId, customerCif, amount, currency, lcType,
				requestId, ActionConstants.GETUPDATETFBOILCAMDNEW_QUERY);
		logger.info(ActionConstants.EXITING_METHOD);
	}

	public void updateTFBOIlcOutstandingClmPay(String tiReferanceNo,
			String solId, String customerCif, String claimAmount,
			String currency, String lcType, String requestId,
			boolean partAmount, String payType, String rateTaken, String token,
			String KPlus, String rate, String billref) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		DBHelper aDBHelper = new DBHelper();
		aDBHelper.setValueInDB(tiReferanceNo, requestId,
				ActionConstants.GETUPDATETIREFERANCE_QUERY);
		aDBHelper.setValueInDB(solId, customerCif, claimAmount, currency,
				lcType, partAmount, payType, rateTaken, token, KPlus, rate,
				requestId, ActionConstants.GETUPDATETFBOILCOSCLMPAYNEW_QUERY);
		aDBHelper.setValueInDB(billref, requestId,
				ActionConstants.GETUPDATEBILLREFERENCEOSP);
		logger.info(ActionConstants.EXITING_METHOD);
	}

	public void updateTFBOIlcOutstandingClmDevolmentCase(String tiReferanceNo,
			String solId, String customerCif, String devolmentAmount,
			String currency, String lcType, String requestId, String rateTaken,
			String token, String KPlus, String rate, String billref)
			throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		DBHelper aDBHelper = new DBHelper();
		aDBHelper.setValueInDB(tiReferanceNo, requestId,
				ActionConstants.GETUPDATETIREFERANCE_QUERY);
		aDBHelper.setValueInDBILCPOCD(solId, customerCif, devolmentAmount,
				currency, lcType, rateTaken, token, KPlus, rate, requestId,
				ActionConstants.GETUPDATETFBOILCOSCLMDEVNEW_QUERY);
		aDBHelper.setValueInDB(billref, requestId,
				ActionConstants.GETUPDATEBILLREFERENCEOSD);
		logger.info(ActionConstants.EXITING_METHOD);
	}

	private void updateTFBOFelCreate(String solID, String lcRefNum,
			String amount, String billReferenceNo, String requestId,
			String fncAmount, String billTenure, String preshipAcc,
			String rateTaken, String subProductCode, String token,
			String rateTakenK, String rate, String Currency, String customerId,
			String custName, String preShipAccId) throws Exception {
		System.out.println(ActionConstants.ENTERING_METHOD);
		DBHelper aDBHelper = new DBHelper();

		aDBHelper.setValueInDB(lcRefNum, requestId,
				ActionConstants.GETUPDATETIREFERANCE_QUERY);

		// CHANGED BY CHANDRU
		if (rateTaken.equals("false")) {
			rateTaken = "N";
		} else {
			rateTaken = "Y";
		}
		// ENDS
		if (preshipAcc.equals("false")) {
			preshipAcc = "N";
		} else {
			preshipAcc = "Y";
		}

		aDBHelper.setValuesInDB(solID, lcRefNum, amount, billReferenceNo,
				requestId, fncAmount, billTenure, preshipAcc, rateTaken,
				subProductCode, token, rateTakenK, rate, Currency, customerId,
				custName, preShipAccId,
				ActionConstants.GETUPDATETFBOFELCRENEW_QUERY);
		System.out.println(ActionConstants.EXITING_METHOD);

	}

	private void updateTFBOFelAdjust(String solID, String lcRefNum,
			String Currency, String maturityDate, String requestId,
			String fncAmount, String billTenure, String customeCif,
			String customeName, String subProductCode) throws Exception {
		System.out.println(ActionConstants.ENTERING_METHOD);
		DBHelper aDBHelper = new DBHelper();

		aDBHelper.setValueInDB(lcRefNum, requestId,
				ActionConstants.GETUPDATETIREFERANCE_QUERY);

		aDBHelper.setValueInDB(solID, lcRefNum, Currency, maturityDate,
				fncAmount, billTenure, customeCif, customeName, subProductCode,
				requestId, ActionConstants.GETUPDATETFBOFELADJNEW_QUERY);
		System.out.println(ActionConstants.EXITING_METHOD);

	}

	private void updateTFBOFelCrystalization(String solID, String lcRefNum,
			String Currency, String amount, String requestId, String fncAmount,
			String billTenure, String customeCif, String customeName,
			String subProductCode, String finalPayment, String getRateTaken,
			String token, String getRateTakenK, String rate) throws Exception {
		System.out.println(ActionConstants.ENTERING_METHOD);
		DBHelper aDBHelper = new DBHelper();

		// CHANGED BY CHANDRU

		aDBHelper.setValueInDB(lcRefNum, requestId,
				ActionConstants.GETUPDATETIREFERANCE_QUERY);

		if (getRateTaken.equals("false")) {
			getRateTaken = "N";
		} else {
			getRateTaken = "Y";
		}
		// ENDS

		aDBHelper.setValueInDB(solID, lcRefNum, Currency, amount, fncAmount,
				billTenure, customeCif, customeName, subProductCode,
				finalPayment, getRateTaken, token, getRateTakenK, rate,
				requestId, ActionConstants.GETUPDATETFBOFELCRYSTNEW_QUERY);
		System.out.println(ActionConstants.EXITING_METHOD);

	}

	private void updateTFBOFelRepay(String solID, String lcRefNum,
			String Currency, String amount, String requestId, String fncAmount,
			String billTenure, String customeCif, String customeName,
			String subProductCode, String finalPayment, String getRateTaken,
			String token, String getRateTakenK, String rate, String preShipAccId)
			throws Exception {
		System.out.println(ActionConstants.ENTERING_METHOD);
		DBHelper aDBHelper = new DBHelper();

		// CHANGED BY CHANDRU
		CommonMethods aCommonMethods = new CommonMethods();
		if (aCommonMethods.isValueAvailable(getRateTaken)) {
			if (getRateTaken.equals("false")) {
				getRateTaken = "N";
			} else {
				getRateTaken = "Y";
			}
		}
		// ENDS
		if (aCommonMethods.isValueAvailable(preShipAccId))
			if (preShipAccId.equals("false")) {
				preShipAccId = "N";
			} else {
				preShipAccId = "Y";
			}

		aDBHelper.setValueInDB(lcRefNum, requestId,
				ActionConstants.GETUPDATETIREFERANCE_QUERY);

		aDBHelper.setValueInDB(solID, lcRefNum, Currency, amount, fncAmount,
				billTenure, customeCif, customeName, subProductCode,
				finalPayment, getRateTaken, token, getRateTakenK, rate,
				requestId, preShipAccId,
				ActionConstants.GETUPDATETFBOFELRPYNEW_QUERY);
		System.out.println(ActionConstants.EXITING_METHOD);

	}

	/*
	 * // Added by divya for ODC starts public void updateTFBOOdcCreate(String
	 * solId, String customerCif, String amount, String currency, String
	 * requestId, String usancePeriod, String direct, String mtReceived, String
	 * partPayment, String prodTypeIDC, String preshipAccSetteld, String
	 * documentDispatch, String finSameDay, String rateTaken, String token,
	 * String rateK, String rate) throws Exception {
	 * logger.info(ActionConstants.ENTERING_METHOD); DBHelper aDBHelper = new
	 * DBHelper(); aDBHelper.setValueODCCREInDB(solId, customerCif, amount,
	 * currency, usancePeriod, direct, mtReceived, partPayment, prodTypeIDC,
	 * preshipAccSetteld, documentDispatch, finSameDay, rateTaken, token, rateK,
	 * rate, requestId, ActionConstants.GETUPDATETFBOODCCREATENEW_QUERY);
	 * logger.info(ActionConstants.EXITING_METHOD); }
	 * 
	 * public void updateTFBOOdcPayment(String solId, String customerCif, String
	 * amount, String currency, String requestId, String usancePeriod, String
	 * direct, String prodTypeIDC, String preshipAccSetteld, String
	 * documentDispatch, String rateTaken, String token, String rateK, String
	 * rate, String finalPayment, String tiReferanceNo) throws Exception {
	 * logger.info(ActionConstants.ENTERING_METHOD); DBHelper aDBHelper = new
	 * DBHelper(); aDBHelper.setValueInDB(tiReferanceNo, requestId,
	 * ActionConstants.GETUPDATETIREFERANCE_QUERY);
	 * aDBHelper.setValueODCPAYInDB(solId, customerCif, amount, currency,
	 * usancePeriod, direct, preshipAccSetteld, prodTypeIDC, documentDispatch,
	 * rateTaken, token, rateK, rate, finalPayment, requestId,
	 * ActionConstants.GETUPDATETFBOODCPAYMENTNEW_QUERY);
	 * logger.info(ActionConstants.EXITING_METHOD); }
	 * 
	 * // Added by divya for ODC ends
	 */
	// Rate taken Fix Offshore Team 06012020 starts
	public void updateTFBOOdcCreate(String solId, String customerCif,
			String amount, String currency, String requestId,
			String usancePeriod, String direct, String mtReceived,
			String partPayment, String prodTypeIDC, String preshipAccSetteld,
			String documentDispatch, String finSameDay, String rateTaken,
			String token, String rateK, String rate, String irexRefNo,String finAmount, String finCurrency)
			throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		DBHelper aDBHelper = new DBHelper();

		// CHANGED BY CHANDRU
		if (rateTaken.equals("false")) {
			rateTaken = "N";
		} else {
			rateTaken = "Y";
		}
		// ENDS
		System.out.println("solId >>-->" + solId);
		System.out.println("customerCif >>-->" + customerCif);
		System.out.println("amount >>-->" + amount);
		System.out.println("currency >>-->" + currency);
		System.out.println("requestId >>-->" + requestId);
		System.out.println("usancePeriod >>-->" + usancePeriod);
		System.out.println("direct >>-->" + direct);
		System.out.println("mtReceived >>-->" + mtReceived);
		System.out.println("partPayment >>-->" + partPayment);
		System.out.println("prodTypeIDC >>-->" + prodTypeIDC);
		System.out.println("preshipAccSetteld >>-->" + preshipAccSetteld);
		System.out.println("documentDispatch >>-->" + documentDispatch);
		System.out.println("finSameDay >>-->" + finSameDay);
		System.out.println("rateTaken >>-->" + rateTaken);
		System.out.println("token >>-->" + token);
		System.out.println("rateK >>-->" + rateK);
		System.out.println("rate >>-->" + rate);
		System.out.println("irexRefNo >>-->" + irexRefNo);

		aDBHelper.setValueODCCREInDB(solId, customerCif, amount, currency,
				usancePeriod, direct, mtReceived, partPayment, prodTypeIDC,
				preshipAccSetteld, documentDispatch, finSameDay, rateTaken,
				token, rateK, rate, irexRefNo, finAmount, finCurrency, requestId,
				ActionConstants.GETUPDATETFBOODCCREATENEW_QUERY);
		logger.info(ActionConstants.EXITING_METHOD);
	}

	public void updateTFBOOdcPayment(String solId, String customerCif,
			String amount, String currency, String requestId,
			String usancePeriod, String direct, String mtReceived,
			String partPayment, String prodTypeIDC, String preshipAccSetteld,
			String documentDispatch, String rateTaken, String token,
			String rateK, String rate, String finalPayment, String irexRefNo,
			String tiReferanceNo, String senderRefno, String financeSameDay)
			throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		DBHelper aDBHelper = new DBHelper();
		CommonMethods aCommonMethods = new CommonMethods();
		aDBHelper.setValueInDB(tiReferanceNo, requestId,
				ActionConstants.GETUPDATETIREFERANCE_QUERY);
		if (aCommonMethods.isValueAvailable(rateTaken)) {
			// CHANGED BY CHANDRU
			if (rateTaken.trim().equals("false")) {
				rateTaken = "N";
			} else {
				rateTaken = "Y";
			}
		}
		// ENDS

		aDBHelper.setValueODCPAYInDB(solId, customerCif, amount, currency,
				usancePeriod, direct, mtReceived, partPayment,
				preshipAccSetteld, prodTypeIDC, documentDispatch, rateTaken,
				token, rateK, rate, finalPayment, irexRefNo, financeSameDay,
				requestId, ActionConstants.GETUPDATETFBOODCPAYMENTNEW_QUERY);
		logger.info(ActionConstants.EXITING_METHOD);
	}

	public void updateCustomerName(String custname, String requestId,
			String eventCode) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		DBHelper aDBHelper = new DBHelper();
		if (eventCode.equals("CRE")) {
			System.out.println("custname >>--> " + custname
					+ "requestId >>--> " + requestId + "eventCode >>--> "
					+ eventCode);
			aDBHelper.setUpdateCustomerName(custname, requestId,
					ActionConstants.GETUPDATECUSTNAMECRE_QUERY);
		}
		if (eventCode.equals("CLP")) {
			/*
			 * aDBHelper.setUpdateCustomerName(custname, requestId,
			 * ActionConstants.GETUPDATECUSTNAMECLP_QUERY);
			 */
			aDBHelper.setUpdateCustomerName(custname, requestId,
					ActionConstants.GETUPDATECUSTNAMECRE_QUERY);
		}
		logger.info(ActionConstants.EXITING_METHOD);
	}

	// Rate taken Fix Offshore Team 06012020 ends

	public void updateTFBOIlcClaimRvd(String tiReferanceNo, String solId,
			String customerCif, String billAmount, String currency,
			String lcType, String requestId, String billUsancePeriod)
			throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		DBHelper aDBHelper = new DBHelper();
		aDBHelper.setValueInDB(tiReferanceNo, requestId,
				ActionConstants.GETUPDATETIREFERANCE_QUERY);
		aDBHelper.setValueInDB(solId, customerCif, billAmount, currency,
				lcType, billUsancePeriod, requestId,
				ActionConstants.GETUPDATETFBOILCCLMRVDNEW_QUERY);
		logger.info(ActionConstants.EXITING_METHOD);
	}

	public void updateTFBOIlcOutstandingClmAcc(String tiReferanceNo,
			String solId, String customerCif, String claimAmount,
			String currency, String lcType, String requestId,
			boolean partAmount, String payType, String billref)
			throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		DBHelper aDBHelper = new DBHelper();
		aDBHelper.setValueInDB(tiReferanceNo, requestId,
				ActionConstants.GETUPDATETIREFERANCE_QUERY);
		aDBHelper.setValueInDB(solId, customerCif, claimAmount, currency,
				lcType, partAmount, payType, requestId,
				ActionConstants.GETUPDATETFBOILCOSCLMACCNEW_QUERY);
		aDBHelper.setValueInDB(billref, requestId,
				ActionConstants.GETUPDATEBILLREFERENCEOSA);
		logger.info(ActionConstants.EXITING_METHOD);
	}

	// changes for IDC starts here
	private void updateTFBOIdcCreate(String requestId, String tiReferanceNo,
			String customeCif, String customeName, String billAmount,
			String currency, String direct, String partpay, String prdType,
			String solID, String billUsancePeriod, String rateTaken,
			String token, String valueK, String rate) throws Exception {

		System.out.println(ActionConstants.ENTERING_METHOD);
		DBHelper aDBHelper = new DBHelper();

		// CHANGED BY CHANDRU
		if (rateTaken.equals("false")) {
			rateTaken = "N";
		} else {
			rateTaken = "Y";
		}
		// ENDS

		aDBHelper.setValueInDB(customeCif, customeName, billAmount, currency,
				direct, partpay, prdType, solID, billUsancePeriod, rateTaken,
				token, valueK, rate, requestId,
				ActionConstants.GETUPDATETFBOIDCCRENEW_QUERY);
		System.out.println(ActionConstants.EXITING_METHOD);

	}

	private void updateTFBOIdcAccept(String requestId, String solID,
			String tiReferanceNo, String customeCif, String currency,
			String acceptBillAmt, String billUsancePeriod, String prdType,
			String customeName) throws Exception {

		System.out.println(ActionConstants.ENTERING_METHOD);
		DBHelper aDBHelper = new DBHelper();

		aDBHelper.setValueInDB(tiReferanceNo, requestId,
				ActionConstants.GETUPDATETIREFERANCE_QUERY);
		System.out.println("requestId >>-->" + requestId);
		System.out.println("solID >>-->" + solID);
		System.out.println("tiReferanceNo >-->" + tiReferanceNo);
		System.out.println("customeCif >>-->" + customeCif);
		System.out.println("currency >>-->" + currency);
		System.out.println("acceptBillAmt >>-->" + acceptBillAmt);
		System.out.println("billUsancePeriod >>-->" + billUsancePeriod);
		System.out.println("prdType >>-->" + prdType);
		System.out.println("customeName >>-->" + customeName);
		aDBHelper.setValueInDB(requestId, solID, customeCif, currency,
				acceptBillAmt, billUsancePeriod, prdType, customeName,
				ActionConstants.GETUPDATETFBOIDCCAC_QUERY);
		System.out.println(ActionConstants.EXITING_METHOD);

	}

	private void updateTFBOIdcPayment(String requestId, String solID,
			String tiReferanceNo, String billAmount, String rateTaken,
			String partpay, String prdType, String rate, String valueK,
			String customerCif, String customerName, String Token,
			String currency, String directFlagCreateEvent, String direct)
			throws Exception {
		DBHelper aDBHelper = new DBHelper();
		// FREEZING(SCENARIO) off shore team starts 31122019
		/*
		 * aDBHelper.setValueIdcPayInDB(requestId, solID, billAmount, rateTaken,
		 * partpay, prdType, rate, valueK,
		 * ActionConstants.GETUPDATETFBOIDCCLP_QUERY);
		 */
		System.out.println("RATE TAKEN >>--> " + rateTaken);
		System.out.println("RATE >>--> " + rate);
		System.out.println("TOKEN >>--> " + Token);
		System.out.println("K VALUE>>--> " + valueK);
		aDBHelper.setValueInDB(tiReferanceNo, requestId,
				ActionConstants.GETUPDATETIREFERANCE_QUERY);
		System.out.println("Getting part amount in if calling funcation==>"
				+ partpay);
		System.out.println("Getting rateTaken==>" + rateTaken);

		// CHANGED BY CHANDRU
		if (rateTaken.equals("false")) {
			rateTaken = "N";
		} else {
			rateTaken = "Y";
		}
		// ENDS

		aDBHelper.setValueIdcPayInDB(requestId, solID, billAmount, rateTaken,
				partpay, prdType, rate, valueK, customerCif, customerName,
				Token, currency, directFlagCreateEvent, direct,
				ActionConstants.GETUPDATETFBOIDCCLP_QUERY);

		// FREEZING(SCENARIO) off shore team ends 31122019
	}

	// changes for IDC End here

	public void updateTFBOIlcOutstandingClmAcc(String tiReferanceNo,
			String solId, String customerCif, String claimAmount,
			String currency, String lcType, String requestId,
			boolean partAmount, String payType) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		DBHelper aDBHelper = new DBHelper();
		aDBHelper.setValueInDB(tiReferanceNo, requestId,
				ActionConstants.GETUPDATETIREFERANCE_QUERY);
		aDBHelper.setValueInDB(solId, customerCif, claimAmount, currency,
				lcType, partAmount, payType, requestId,
				ActionConstants.GETUPDATETFBOILCOSCLMACCNEW_QUERY);
		logger.info(ActionConstants.EXITING_METHOD);
	}

	public void updateTFBOIlcOutstandingClmPay(String tiReferanceNo,
			String solId, String customerCif, String claimAmount,
			String currency, String lcType, String requestId,
			boolean partAmount, String payType, String rateTaken, String token,
			String KPlus, String rate) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		DBHelper aDBHelper = new DBHelper();
		aDBHelper.setValueInDB(tiReferanceNo, requestId,
				ActionConstants.GETUPDATETIREFERANCE_QUERY);
		aDBHelper.setValueInDB(solId, customerCif, claimAmount, currency,
				lcType, partAmount, payType, rateTaken, token, KPlus, rate,
				requestId, ActionConstants.GETUPDATETFBOILCOSCLMPAYNEW_QUERY);
		logger.info(ActionConstants.EXITING_METHOD);
	}

	public void updateTFBOIlcOutstandingClmDevolmentCase(String tiReferanceNo,
			String solId, String customerCif, String devolmentAmount,
			String currency, String lcType, String requestId, String rateTaken,
			String token, String KPlus, String rate) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		DBHelper aDBHelper = new DBHelper();
		aDBHelper.setValueInDB(tiReferanceNo, requestId,
				ActionConstants.GETUPDATETIREFERANCE_QUERY);
		aDBHelper.setValueInDB(solId, customerCif, devolmentAmount, currency,
				lcType, rateTaken, token, KPlus, rate, requestId,
				ActionConstants.GETUPDATETFBOILCOSCLMDEVNEW_QUERY);
		logger.info(ActionConstants.EXITING_METHOD);
	}

	public void updateTFBOTransChecklist(List<TFBOChecklistVO> aTFBOChecklist,
			String requestId) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		DBHelper aDBHelper = new DBHelper();
		CommonMethods aCommonMethods = new CommonMethods();
		String checklistId = "";
		String makerChecklistDetails = "";
		String checklistValue = "";
		String makerChecklistRemarks = "";
		for (TFBOChecklistVO aTFBOChecklistVO : aTFBOChecklist) {
			checklistId = aTFBOChecklistVO.getChecklistId();
			makerChecklistDetails = aTFBOChecklistVO.getChecklistDetails();
			checklistValue = aTFBOChecklistVO.getChecklistValue();
			makerChecklistRemarks = aTFBOChecklistVO.getChecklistRemarks();
			logger.info("checklistId-->" + checklistId);
			logger.info("makerChecklistDetails-->" + makerChecklistDetails);
			logger.info("checklistValue-->" + checklistValue);
			logger.info("makerChecklistRemarks-->" + makerChecklistRemarks);
			if (!aCommonMethods.isValueAvailable(checklistValue)) {
				checklistValue = "";
			}
			aDBHelper.setValueInDB(checklistValue, makerChecklistRemarks,
					requestId, checklistId,
					ActionConstants.GETUPDATETFBOTRANSCHECKLIST_QUERY);
		}
		logger.info(ActionConstants.EXITING_METHOD);
	}

	public void updateTFBOTransUser(String stepName, String userName,
			String requestId) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);

		if (stepName.trim().equals(ActionConstants.INPUT)) {
			updateTFBOTransUserInDB(userName, requestId,
					ActionConstants.GETUPDATETFBOTRANSINPUTUSER_QUERY);
			logger.info(ActionConstants.ENTERING_METHOD + ">> isValidUser");
		}
		if (stepName.trim().equals(ActionConstants.REVIEW)) {
			updateTFBOTransUserInDB(userName, requestId,
					ActionConstants.GETUPDATETFBOTRANSREVIEWUSER_QUERY);
			logger.info(ActionConstants.ENTERING_METHOD + ">> isValidUser");
		}
		if (stepName.trim().equals(ActionConstants.AUTHORIZE)) {
			updateTFBOTransUserInDB(userName, requestId,
					ActionConstants.GETUPDATETFBOTRANSAUTHUSER_QUERY);
			logger.info(ActionConstants.ENTERING_METHOD + ">> isValidUser");
		}
		logger.info(ActionConstants.EXITING_METHOD);
	}

	public void updateTFBOTransUserInDB(String userName, String requestId,
			String query) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		DBHelper aDBHelper = new DBHelper();
		aDBHelper.setValueInDB(userName, requestId, query);
		logger.info(ActionConstants.EXITING_METHOD);
	}

	public void clearTFBOTransUserInDB(String requestId, String query)
			throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		DBHelper aDBHelper = new DBHelper();
		aDBHelper.setValueInDB(requestId, query);
		logger.info(ActionConstants.EXITING_METHOD);
	}

	public void updateTFBOTransQueried(String isQueried, String requestId)
			throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		DBHelper aDBHelper = new DBHelper();
		aDBHelper.setValueInDB(isQueried, requestId,
				ActionConstants.GETUPDATETFBOTRANSQUERIED_QUERY);
		logger.info(ActionConstants.EXITING_METHOD);
	}

	/* Dashboard changes 23012020 starts */
	/*
	 * public void updateTFBOTransStatus(String stepName, String assignStatus,
	 * String requestId) throws Exception {
	 * logger.info(ActionConstants.ENTERING_METHOD); DBHelper aDBHelper = new
	 * DBHelper(); aDBHelper.setValueInDB(stepName, assignStatus, requestId,
	 * ActionConstants.GETUPDATETFBOTRANSSTATUS_QUERY);
	 * logger.info(ActionConstants.EXITING_METHOD); }
	 */
	
	//done by karthick on 11 mar 20
	
	/*public void updateTFBOTransStatus(String stepName, String assignStatus,
			String requestId) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		DBHelper aDBHelper = new DBHelper();
		String modifiedUser = getSessionUser();
		if(stepName.trim() == "FBO maker") 
		{
		aDBHelper.setValueInDB(stepName, assignStatus, modifiedUser,modifiedUser,requestId,
				ActionConstants.GETUPDATETFBOTRANSSTATUS_FBO_MAKER_QUERY);
		}
		else 
		{
			aDBHelper.setValueInDB(stepName, assignStatus, modifiedUser,modifiedUser,requestId,
					ActionConstants.GETUPDATETFBOTRANSSTATUS_FBO_CHECKER_QUERY);
		}
		logger.info(ActionConstants.EXITING_METHOD);
		logger.info(ActionConstants.EXITING_METHOD);
	}*/

	
	public void updateTFBOTransStatus(String stepName, String assignStatus,
			String requestId) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		DBHelper aDBHelper = new DBHelper();
		String modifiedUser = getSessionUser();
		if(stepName.trim().equalsIgnoreCase("FBO maker")) 
		{
		aDBHelper.setValueInDB(stepName, assignStatus, modifiedUser,modifiedUser,requestId,
				ActionConstants.GETUPDATETFBOTRANSSTATUS_FBO_MAKER_QUERY);
		}
		if(stepName.trim().equalsIgnoreCase("FBO checker"))
		{
			aDBHelper.setValueInDB(stepName, assignStatus, modifiedUser,modifiedUser,requestId,
					ActionConstants.GETUPDATETFBOTRANSSTATUS_FBO_CHECKER_QUERY);
		}else{
			aDBHelper.setValueInDB(stepName, assignStatus, modifiedUser, requestId,
					ActionConstants.GETUPDATETFBOTRANSSTATUS_QUERY);
		}
		
		logger.info(ActionConstants.EXITING_METHOD);
		logger.info(ActionConstants.EXITING_METHOD);
	}
	
	
	/* Dashboard changes 23012020 ends */

	public void updateSubProductInTFBOTrans(String subProductCode,
			String requestId) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		DBHelper aDBHelper = new DBHelper();
		aDBHelper.setValueInDB(subProductCode, requestId,
				ActionConstants.GETUPDATETFBOTRANSSUBPRODUCT_QUERY);
		logger.info(ActionConstants.EXITING_METHOD);
	}

	public void setTFBOUserComments(String requestId, String commentDetails,
			String stepName, String userName) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		DBHelper aDBHelper = new DBHelper();
		aDBHelper.setValueInDB(requestId, commentDetails, stepName, userName,
				ActionConstants.GETINSERTTFBOUSERCOMMENT_QUERY);
		logger.info(ActionConstants.EXITING_METHOD);
	}

	public void setTFBOCustomerComments(String requestId,
			String commentDetails, String stepName, String userName)
			throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		DBHelper aDBHelper = new DBHelper();
		System.out.println("commentDetails >>-->" + commentDetails);
		aDBHelper.setValueInDB(requestId, commentDetails, stepName, userName,
				ActionConstants.GETINSERTTFBOCUSTOMERCOMMENT_QUERY);
		// REQUESTID,CUST_COMMENTDETAILS,STEP,COMMENTUSER,DATETIME
		logger.info(ActionConstants.EXITING_METHOD);
	}

	public String insertIntoTFBOEventTable(String returnPage, String requestID,
			String productCode, String eventCode) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		if (productCode.equalsIgnoreCase("ILC")) {
			if (eventCode.equalsIgnoreCase("ISI")) {
				insertIntoTFBOIlcIssue(requestID);
				returnPage = "viewer" + productCode.trim() + eventCode.trim();
			}
			if (eventCode.equalsIgnoreCase("NAMI")) {
				insertIntoTFBOIlcAmend(requestID);
				returnPage = "viewer" + productCode.trim() + eventCode.trim();
			}
			if (eventCode.equalsIgnoreCase("CRC")) {
				logger.info(">>-->CRC Entering<--<<");
				insertIntoTFBOIlcClaimRvd(requestID);
				returnPage = "Viewer" + productCode.trim() + eventCode.trim();
			}
			if (eventCode.equalsIgnoreCase("POCA")) {
				insertIntoTFBOIlcOutstandingClaimAccept(requestID);
				returnPage = "Viewer" + productCode.trim() + eventCode.trim();
			}
			if (eventCode.equalsIgnoreCase("POCP")) {
				insertIntoTFBOIlcOutstandingClaimPay(requestID);
				returnPage = "Viewer" + productCode.trim() + eventCode.trim();
			}
			if (eventCode.equalsIgnoreCase("POCD")) {
				insertIntoTFBOIlcOutstandingClaimDevolmentCase(requestID);
				returnPage = "Viewer" + productCode.trim() + eventCode.trim();
			}
			// Expiry,closure,cancellation Changes Starts
			if (eventCode.equalsIgnoreCase("EXI")) {
				insertIntoTFBOIlcExpiry(requestID);
				returnPage = "viewer" + productCode.trim() + eventCode.trim();
			}
			// Expiry,closure,cancellation Changes Ends
			// Karthik 13012020 starts
			/*
			 * if (eventCode.equalsIgnoreCase("COI")) {
			 * inssertIntoTFBOIlcCorrespondence(requestID); returnPage =
			 * "Viewer" + productCode.trim() + eventCode.trim(); }
			 */
			if (eventCode.equalsIgnoreCase("COI")) {
				inssertIntoTFBOIlcCorrespondence(requestID);
				returnPage = "Viewer" + productCode.trim() + eventCode.trim();
			}
			// Karthik 13012020 ends
		}
		// Miscellanous changes starts 08-01-2020
		if (productCode.equalsIgnoreCase("COR")) {
			if (eventCode.equalsIgnoreCase("CRCR")) {
				logger.info("Entering insertIntoTFBOEventTable method for miscellanous==>");
				insertIntoTFBOMiscellanousCreate(requestID);
				returnPage = "viewer" + productCode.trim() + eventCode.trim();
			}
		}
		// Miscellanous changes ends 08-01-2020

		// Inward Remittance changes 23-12-2019 starts
		if (productCode.equalsIgnoreCase("CPCI")) {
			if (eventCode.equalsIgnoreCase("PCIC")) {
				insertIntoTFBOInwardRemittanceCreate(requestID);
				returnPage = "viewer" + productCode.trim() + eventCode.trim();
			}
		}
		// Inward Remittance changes 23-12-2019 ends

		// Outward Remittance Changes 23/12/2019 start

		if (productCode.equalsIgnoreCase("CPCO")) {
			if (eventCode.equalsIgnoreCase("PCOC")) {
				insertIntoTFBOcpcoCreate(requestID);
				returnPage = "viewer" + productCode.trim() + eventCode.trim();
			}
		}
		// Outward Remittance Changes 23/12/2019 end

		// Added by divya for ODC starts
		if (productCode.equalsIgnoreCase("ODC")) {
			if (eventCode.equalsIgnoreCase("CRE")) {
				insertIntoTFBOIlcOdcCreate(requestID);
				insertIntoTFBOIDCODCFlow(requestID, "ODC", "CRE");
				returnPage = "viewer" + productCode.trim() + eventCode.trim();
			}
			if (eventCode.equalsIgnoreCase("CLP")) {
				insertIntoTFBOIlcOdcPayment(requestID);
				returnPage = "viewer" + productCode.trim() + eventCode.trim();
			}
			// CHANGES FOR ODC CAC 08012020 NY SAI STARTS HERE
			if (eventCode.equalsIgnoreCase("CAC")) {
				insertIntoTFBOIlcOdcAccept(requestID);
				returnPage = "viewer" + productCode.trim() + eventCode.trim();
			}
			// CHANGES FOR ODC CAC 08012020 NY SAI ENDS HERE
			// Karthik 13012020 starts
			/*
			 * if (eventCode.equalsIgnoreCase("CCO")) {
			 * insertIntoTFBOIlcOdcCco(requestID); returnPage = "viewer" +
			 * productCode.trim() + eventCode.trim();
			 * 
			 * }
			 */
			if (eventCode.equalsIgnoreCase("CCO")) {
				insertIntoTFBOIlcOdcCco(requestID);
				returnPage = "viewer" + productCode.trim() + eventCode.trim();

			}
			// Karthik 13012020 ends
		}
		// Added by divya for ODC ends
		// Added by divya for FOC-CRE starts
		if (productCode.equalsIgnoreCase("FOC")) {
			if (eventCode.equalsIgnoreCase("CSA1")) {
				insertIntoTFBOIlcFocCreate(requestID);
				returnPage = "viewer" + productCode.trim() + eventCode.trim();

			}
			// Karthik 13012020 starts
			/*
			 * if (eventCode.equalsIgnoreCase("PSA1")) {
			 * insertIntoTFBOIlcFocPsa1(requestID); returnPage = "viewer" +
			 * productCode.trim() + eventCode.trim(); }
			 */
			if (eventCode.equalsIgnoreCase("PSA1")) {
				insertIntoTFBOIlcFocPsa1(requestID);
				returnPage = "viewer" + productCode.trim() + eventCode.trim();
			}
			// Karthik 13012020 ends
			if (eventCode.equalsIgnoreCase("JSA1")) {
				insertIntoTFBOIlcFocAdjust(requestID);
				returnPage = "viewer" + productCode.trim() + eventCode.trim();

			}
			if (eventCode.equalsIgnoreCase("RSA1")) {
				insertIntoTFBOIlcFocRepay(requestID);
				returnPage = "viewer" + productCode.trim() + eventCode.trim();

			}
			if (eventCode.equalsIgnoreCase("CRYST")) {
				insertIntoTFBOIlcFocCryst(requestID);
				returnPage = "viewer" + productCode.trim() + eventCode.trim();

			}
		}

		if (productCode.equalsIgnoreCase("FSA")) {
			if (eventCode.equalsIgnoreCase("CSA")) {
				insertIntoTFBOIlcFsaCreate(requestID);
				returnPage = "viewer" + productCode.trim() + eventCode.trim();

			}
			if (eventCode.equalsIgnoreCase("JSA")) {
				insertIntoTFBOIlcFsaAdjust(requestID);
				returnPage = "viewer" + productCode.trim() + eventCode.trim();

			}
			if (eventCode.equalsIgnoreCase("RSA")) {
				insertIntoTFBOIlcFsaRepay(requestID);
				returnPage = "viewer" + productCode.trim() + eventCode.trim();

			}
		}

		// Added by divya for FOC-CRE ends
		if (productCode.equalsIgnoreCase("ELC")) {
			if (eventCode.equalsIgnoreCase("ADE")) {
				insertIntoTFBOElcAdv(requestID);
				returnPage = "viewer" + productCode.trim() + eventCode.trim();

			}
			// Karthik 13012020 starts
			/*
			 * if (eventCode.equalsIgnoreCase("COE")) {
			 * insertintoTFBOElcCOI(requestID); returnPage = "viewer" +
			 * productCode.trim() + eventCode.trim(); }
			 */
			if (eventCode.equalsIgnoreCase("COE")) {
				insertintoTFBOElcCOI(requestID);
				returnPage = "viewer" + productCode.trim() + eventCode.trim();
			}
			// Karthik 13012020 ends
			if (eventCode.equalsIgnoreCase("NAME")) {
				insertintoTFBOElcAmd(requestID);
				returnPage = "viewer" + productCode.trim() + eventCode.trim();
			}
			// Expiry,closure,cancellation Changes Starts
			if (eventCode.equalsIgnoreCase("EXP")) {
				insertIntoTFBOElcExpiry(requestID);
				returnPage = "viewer" + productCode.trim() + eventCode.trim();
			}
			// Expiry,closure,cancellation Changes Ends
			// ELC DOP Issue Fix 20-12-2019 starts
			if (eventCode.equalsIgnoreCase("DOP")) {
				logger.info("Entering for insertion of ELC DOP event table");
				insertintoTFBOElcDOP(requestID);
				insertIntoTFBOIDCODCFlow(requestID, "ELC", "DOP");
				returnPage = "viewer" + productCode.trim() + eventCode.trim();
			}
			// ELC DOP Issue Fix 20-12-2019 ends
			// Changes for ELC and IGT Starts 25-12-2019
			if (eventCode.equalsIgnoreCase("PODA")) {
				insertintoTFBOElcPODA(requestID);
				returnPage = "viewer" + productCode.trim() + eventCode.trim();
			}
			if (eventCode.equalsIgnoreCase("PODP")) {
				insertintoTFBOElcPODP(requestID);
				returnPage = "viewer" + productCode.trim() + eventCode.trim();
			}
			// Changes for ELC and IGT ends 25-12-2019
		}
		// Changes for ELC and IGT Starts 25-12-2019
		if (productCode.equalsIgnoreCase("IGT")) {
			if (eventCode.equalsIgnoreCase("IIG")) {
				System.out.println(">>-->IGT-IIG Entering<--<<");
				insertIntoTFBOIgtIssue(requestID);
				returnPage = "viewer" + productCode.trim() + eventCode.trim();
			}
			if (eventCode.equalsIgnoreCase("NAIG")) {
				insertIntoTFBOIgtAmend(requestID);
				returnPage = "viewer" + productCode.trim() + eventCode.trim();
			}
			if (eventCode.equalsIgnoreCase("XIG")) {
				insertIntoTFBOIgtExpire(requestID);
				returnPage = "viewer" + productCode.trim() + eventCode.trim();
			}

			if (eventCode.equalsIgnoreCase("LIG")) {
				insertIntoTFBOIgtClaim(requestID);
				returnPage = "viewer" + productCode.trim() + eventCode.trim();
			}
			if (eventCode.equalsIgnoreCase("OIG")) {
				insertIntoTFBOIgtPayment(requestID);
				returnPage = "viewer" + productCode.trim() + eventCode.trim();
			}
			// Expiry,closure,cancellation Changes Starts
			if (eventCode.equalsIgnoreCase("NIG")) {
				insertIntoTFBOIgtCancel(requestID);
				returnPage = "viewer" + productCode.trim() + eventCode.trim();
			}

			if (eventCode.equalsIgnoreCase("KIG")) {
				insertIntoTFBOIgtClosure(requestID);
				returnPage = "viewer" + productCode.trim() + eventCode.trim();
			}
			// Expiry,closure,cancellation Changes Ends
		}
		// Changes for ELC and IGT ends 25-12-2019
		if (productCode.equalsIgnoreCase("IDC")) {
			if (eventCode.equalsIgnoreCase("CRE")) {
				System.out.println(">>-->IDC-CRE Entering<--<<");
				insertIntoTFBOIdcCreate(requestID);
				insertIntoTFBOIDCODCFlow(requestID, "IDC", "CRE");
				returnPage = "viewer" + productCode.trim() + eventCode.trim();
			}
			if (eventCode.equalsIgnoreCase("CAC")) {
				System.out.println(">>-->IDC-CAC Entering<--<<");
				insertIntoTFBOIdcAccept(requestID);
				returnPage = "viewer" + productCode.trim() + eventCode.trim();
			}
			// karthik 13012020 starts
			/*
			 * if (eventCode.equalsIgnoreCase("CCO")) {
			 * System.out.println(">>----IDC-CCO Entering-------<<");
			 * insertIntoTFBOIdCco(requestID); returnPage = "viewer" +
			 * productCode.trim() + eventCode.trim(); }
			 */
			if (eventCode.equalsIgnoreCase("CCO")) {
				System.out.println(">>----IDC-CCO Entering-------<<");
				insertIntoTFBOIdCco(requestID);
				returnPage = "viewer" + productCode.trim() + eventCode.trim();
			}
			// karthik 13012020 ends
			if (eventCode.equalsIgnoreCase("CLP")) {

				System.out.println(">>-->IDC-CLP Entering<--<<");
				insertIntoTFBOIdcPay(requestID);
				returnPage = "viewer" + productCode.trim() + eventCode.trim();

			}
		}
		if (productCode.equalsIgnoreCase("FEL")) {
			if (eventCode.equalsIgnoreCase("CSA4")) {
				insertIntoTFBOFELCreate(requestID);
				returnPage = "viewer" + productCode.trim() + eventCode.trim();
			}
			// karthik 13012020 starts
			// if (eventCode.equalsIgnoreCase("PSA4")) {
			// insertIntoTFBOFELPSA4(requestID);
			// returnPage = "viewer" + productCode.trim() + eventCode.trim();
			//
			// }
			if (eventCode.equalsIgnoreCase("PSA4")) {
				insertIntoTFBOFELPSA4(requestID);
				returnPage = "viewer" + productCode.trim() + eventCode.trim();

			}
			// karthik 13012020 ends
			if (eventCode.equalsIgnoreCase("JSA4")) {
				insertIntoTFBOFELAdjust(requestID);
				returnPage = "viewer" + productCode.trim() + eventCode.trim();
			}
			if (eventCode.equalsIgnoreCase("CRYST")) {
				insertIntoTFBOFELCrystalization(requestID);
				returnPage = "viewer" + productCode.trim() + eventCode.trim();
			}
			if (eventCode.equalsIgnoreCase("RSA4")) {
				insertIntoTFBOFELRepay(requestID);
				returnPage = "viewer" + productCode.trim() + eventCode.trim();
			}
		}

		// SBLC 251219
		if (productCode.equalsIgnoreCase("ISB")) {
			if (eventCode.equalsIgnoreCase("KIS")) {
				insertIntoTFBOISBClosure(requestID);
				returnPage = "viewer" + productCode.trim() + eventCode.trim();
			}
			if (eventCode.equalsIgnoreCase("NIS")) {
				insertIntoTFBOISBCancel(requestID);
				returnPage = "viewer" + productCode.trim() + eventCode.trim();

			}
			if (eventCode.equalsIgnoreCase("IIS")) {
				insertIntoTFBOISBIssue(requestID);
				returnPage = "viewer" + productCode.trim() + eventCode.trim();

			}
			if (eventCode.equalsIgnoreCase("LIS")) {
				insertIntoTFBOClaimReceived(requestID);
				returnPage = "viewer" + productCode.trim() + eventCode.trim();

			}
			if (eventCode.equalsIgnoreCase("OIS")) {
				insertIntoTFBOOutstdClaim(requestID);
				returnPage = "viewer" + productCode.trim() + eventCode.trim();

			}
			if (eventCode.equalsIgnoreCase("NJIS")) {
				insertIntoTFBOISBAdjust(requestID);
				returnPage = "viewer" + productCode.trim() + eventCode.trim();

			}
			if (eventCode.equalsIgnoreCase("NAIS")) {
				insertIntoTFBOISBAmend(requestID);
				returnPage = "viewer" + productCode.trim() + eventCode.trim();

			}

		}

		logger.info(ActionConstants.EXITING_METHOD);
		return returnPage;
	}

	private void insertIntoTFBOISBIssue(String requestID) throws Exception {
		System.out.println(ActionConstants.ENTERING_METHOD);
		DBHelper aDBHelper = new DBHelper();
		aDBHelper.setValueInDB(requestID,
				ActionConstants.GETINSERTTFBOISBISS_QUERY);
		System.out.println(ActionConstants.EXITING_METHOD);

	}

	private void insertIntoTFBOISBAdjust(String requestID) throws Exception {
		System.out.println(ActionConstants.ENTERING_METHOD);
		DBHelper aDBHelper = new DBHelper();
		aDBHelper.setValueInDB(requestID,
				ActionConstants.GETINSERTTFBOISBNJIS_QUERY);
		System.out.println(ActionConstants.EXITING_METHOD);

	}

	private void insertIntoTFBOISBAmend(String requestID) throws Exception {
		System.out.println(ActionConstants.ENTERING_METHOD);
		DBHelper aDBHelper = new DBHelper();
		aDBHelper.setValueInDB(requestID,
				ActionConstants.GETINSERTTFBOISBNAIS_QUERY);
		System.out.println(ActionConstants.EXITING_METHOD);

	}

	private void insertIntoTFBOClaimReceived(String requestID) throws Exception {
		System.out.println(ActionConstants.ENTERING_METHOD);
		DBHelper aDBHelper = new DBHelper();
		aDBHelper.setValueInDB(requestID,
				ActionConstants.GETINSERTTFBOISBLIS_QUERY);
		System.out.println(ActionConstants.EXITING_METHOD);

	}

	private void insertIntoTFBOOutstdClaim(String requestID) throws Exception {
		System.out.println(ActionConstants.ENTERING_METHOD);
		DBHelper aDBHelper = new DBHelper();
		aDBHelper.setValueInDB(requestID,
				ActionConstants.GETINSERTTFBOISBOIS_QUERY);
		System.out.println(ActionConstants.EXITING_METHOD);
	}

	// SBLC 251219_END

	// ODC-Create
	public void insertIntoTFBOIlcFocCreate(String requestId) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		DBHelper aDBHelper = new DBHelper();
		aDBHelper.setValueInDB(requestId,
				ActionConstants.GETINSERTTFBOFOCCREATE_QUERY);
		logger.info(ActionConstants.EXITING_METHOD);
	}

	// ODC-Adjust
	public void insertIntoTFBOIlcFocAdjust(String requestId) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		DBHelper aDBHelper = new DBHelper();
		aDBHelper.setValueInDB(requestId,
				ActionConstants.GETINSERTTFBOFOCADJUST_QUERY);
		logger.info(ActionConstants.EXITING_METHOD);
	}

	public void insertIntoTFBOIlcFocRepay(String requestId) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		DBHelper aDBHelper = new DBHelper();
		aDBHelper.setValueInDB(requestId,
				ActionConstants.GETINSERTTFBOFOCREPAY_QUERY);
		logger.info(ActionConstants.EXITING_METHOD);
	}

	public void insertIntoTFBOIlcFocCryst(String requestId) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		DBHelper aDBHelper = new DBHelper();
		aDBHelper.setValueInDB(requestId,
				ActionConstants.GETINSERTTFBOFOCCRYST_QUERY);
		logger.info(ActionConstants.EXITING_METHOD);
	}

	public void insertIntoTFBOIlcFsaCreate(String requestId) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		DBHelper aDBHelper = new DBHelper();
		aDBHelper.setValueInDB(requestId,
				ActionConstants.GETINSERTTFBOFSACRE_QUERY);
		logger.info(ActionConstants.EXITING_METHOD);
	}

	public void insertIntoTFBOIlcFsaRepay(String requestId) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		DBHelper aDBHelper = new DBHelper();
		aDBHelper.setValueInDB(requestId,
				ActionConstants.GETINSERTTFBOFSAREPAY_QUERY);
		logger.info(ActionConstants.EXITING_METHOD);
	}

	public void insertIntoTFBOIlcFsaAdjust(String requestId) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		DBHelper aDBHelper = new DBHelper();
		aDBHelper.setValueInDB(requestId,
				ActionConstants.GETINSERTTFBOFSAADJUST_QUERY);
		logger.info(ActionConstants.EXITING_METHOD);
	}

	// Added by divya for ODC ends
	private void insertIntoTFBOIdcCreate(String requestID) throws Exception {
		System.out.println(ActionConstants.ENTERING_METHOD);
		DBHelper aDBHelper = new DBHelper();
		aDBHelper.setValueInDB(requestID,
				ActionConstants.GETINSERTTFBOIDCCRE_QUERY);
		System.out.println(ActionConstants.EXITING_METHOD);

	}

	private void insertIntoTFBOIdcAccept(String requestID) throws Exception {
		System.out.println(ActionConstants.ENTERING_METHOD);
		DBHelper aDBHelper = new DBHelper();
		aDBHelper.setValueInDB(requestID,
				ActionConstants.GETINSERTTFBOIDCCAC_QUERY);
		System.out.println(ActionConstants.EXITING_METHOD);

	}

	private void insertIntoTFBOIdcPay(String requestID) throws Exception {
		System.out.println(ActionConstants.ENTERING_METHOD);
		DBHelper aDBHelper = new DBHelper();
		aDBHelper.setValueInDB(requestID,
				ActionConstants.GETINSERTTFBOIDCCLP_QUERY);
		System.out.println(ActionConstants.EXITING_METHOD);

	}

	private void insertIntoTFBOFELCreate(String requestID) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		DBHelper aDBHelper = new DBHelper();
		logger.info("--------insert cc------");
		aDBHelper.setValueInDB(requestID,
				ActionConstants.GETINSERTTFBOFELCRE_QUERY);
		logger.info(ActionConstants.EXITING_METHOD);
	}

	private void insertIntoTFBOFELAdjust(String requestID) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		DBHelper aDBHelper = new DBHelper();
		logger.info("--------insert cc------");
		aDBHelper.setValueInDB(requestID,
				ActionConstants.GETINSERTTFBOFELADJ_QUERY);
		logger.info(ActionConstants.EXITING_METHOD);
	}

	private void insertIntoTFBOFELCrystalization(String requestID)
			throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		DBHelper aDBHelper = new DBHelper();
		logger.info("--------insert cc------");
		aDBHelper.setValueInDB(requestID,
				ActionConstants.GETINSERTTFBOFELCRYST_QUERY);
		logger.info(ActionConstants.EXITING_METHOD);
	}

	private void insertIntoTFBOFELRepay(String requestID) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		DBHelper aDBHelper = new DBHelper();
		logger.info("--------insert cc------");
		aDBHelper.setValueInDB(requestID,
				ActionConstants.GETINSERTTFBOFELRPY_QUERY);
		logger.info(ActionConstants.EXITING_METHOD);
	}

	/*
	 * private void inssertIntoTFBOIlcCorrespondence(String requestID) throws
	 * Exception { System.out.println(ActionConstants.ENTERING_METHOD); DBHelper
	 * aDBHelper = new DBHelper(); aDBHelper.setValueInDB(requestID,
	 * ActionConstants.GETINSERTTFBOILCCOI);
	 * System.out.println(ActionConstants.ENTERING_METHOD);
	 * 
	 * }
	 */
	private void inssertIntoTFBOIlcCorrespondence(String requestID)
			throws Exception {
		System.out.println(ActionConstants.ENTERING_METHOD);
		DBHelper aDBHelper = new DBHelper();
		aDBHelper.setValueInDB(requestID, ActionConstants.GETINSERTTFBOILCCOI);
		System.out.println(ActionConstants.ENTERING_METHOD);

	}

	/*
	 * private void insertIntoTFBOIlcOdcCco(String requestID) throws Exception {
	 * System.out.println(ActionConstants.ENTERING_METHOD); DBHelper aDBDbHelper
	 * = new DBHelper(); aDBDbHelper.setValueInDB(requestID,
	 * ActionConstants.GETINSERTODCCCO);
	 * System.out.println(ActionConstants.ENTERING_METHOD);
	 * 
	 * }
	 */
	private void insertIntoTFBOIlcOdcCco(String requestID) throws Exception {
		System.out.println(ActionConstants.ENTERING_METHOD);
		DBHelper aDBDbHelper = new DBHelper();
		aDBDbHelper.setValueInDB(requestID, ActionConstants.GETINSERTODCCCO);
		System.out.println(ActionConstants.ENTERING_METHOD);

	}

	/*
	 * private void insertIntoTFBOIlcFocPsa1(String requestID) throws Exception
	 * { System.out.println(ActionConstants.ENTERING_METHOD); DBHelper
	 * aDBDbHelper = new DBHelper(); aDBDbHelper.setValueInDB(requestID,
	 * ActionConstants.GETINSERTTFBOFOCPSA1);
	 * System.out.println(ActionConstants.ENTERING_METHOD); }
	 */
	private void insertIntoTFBOIlcFocPsa1(String requestID) throws Exception {
		System.out.println(ActionConstants.ENTERING_METHOD);
		DBHelper aDBDbHelper = new DBHelper();
		aDBDbHelper.setValueInDB(requestID,
				ActionConstants.GETINSERTTFBOFOCPSA1);
		System.out.println(ActionConstants.ENTERING_METHOD);
	}

	/*
	 * private void insertintoTFBOElcCOI(String requestID) throws Exception {
	 * System.out.println(ActionConstants.ENTERING_METHOD); DBHelper aDBDbHelper
	 * = new DBHelper(); aDBDbHelper .setValueInDB(requestID,
	 * ActionConstants.GETINSERTTFBOELCCOE);
	 * System.out.println(ActionConstants.ENTERING_METHOD); }
	 */

	private void insertintoTFBOElcCOI(String requestID) throws Exception {
		System.out.println(ActionConstants.ENTERING_METHOD);
		DBHelper aDBDbHelper = new DBHelper();
		aDBDbHelper
				.setValueInDB(requestID, ActionConstants.GETINSERTTFBOELCCOE);
		System.out.println(ActionConstants.ENTERING_METHOD);
	}

	/*
	 * private void insertIntoTFBOIdCco(String requestID) throws Exception {
	 * System.out.println(ActionConstants.ENTERING_METHOD); DBHelper aDBDbHelper
	 * = new DBHelper(); aDBDbHelper.setValueInDB(requestID,
	 * ActionConstants.GETINSERTIDCCCO);
	 * System.out.println(ActionConstants.ENTERING_METHOD);
	 * 
	 * }
	 */
	private void insertIntoTFBOIdCco(String requestID) throws Exception {
		System.out.println(ActionConstants.ENTERING_METHOD);
		DBHelper aDBDbHelper = new DBHelper();
		aDBDbHelper.setValueInDB(requestID, ActionConstants.GETINSERTIDCCCO);
		System.out.println(ActionConstants.ENTERING_METHOD);

	}

	/*
	 * private void insertIntoTFBOFELPSA4(String requestID) throws Exception {
	 * System.out.println(ActionConstants.ENTERING_METHOD); DBHelper aDBDbHelper
	 * = new DBHelper(); aDBDbHelper.setValueInDB(requestID,
	 * ActionConstants.GETINSERTTFBOFELPSA4);
	 * System.out.println(ActionConstants.ENTERING_METHOD); }
	 */

	private void insertIntoTFBOFELPSA4(String requestID) throws Exception {
		System.out.println(ActionConstants.ENTERING_METHOD);
		DBHelper aDBDbHelper = new DBHelper();
		aDBDbHelper.setValueInDB(requestID,
				ActionConstants.GETINSERTTFBOFELPSA4);
		System.out.println(ActionConstants.ENTERING_METHOD);
	}

	private void insertIntoTFBOIlcOutstandingClaimDevolmentCase(String requestID)
			throws Exception {

		logger.info(ActionConstants.ENTERING_METHOD);
		DBHelper aDBHelper = new DBHelper();
		aDBHelper.setValueInDB(requestID,
				ActionConstants.GETINSERTTFBOILCPOCD_QUERY);
		logger.info(ActionConstants.EXITING_METHOD);
	}

	// ELC insert Id
	private void insertIntoTFBOElcAdv(String requestID) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		DBHelper aDBHelper = new DBHelper();
		logger.info("--------insert cc------");
		aDBHelper.setValueInDB(requestID,
				ActionConstants.GETINSERTTFBOELCADV_QUERY);
		logger.info(ActionConstants.EXITING_METHOD);

	}

	public void insertintoTFBOElcAmd(String requestID) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		DBHelper aDBHelper = new DBHelper();
		aDBHelper.setValueInDB(requestID,
				ActionConstants.GETINSERTTFBOELCAMD_QUERY);
		logger.info(ActionConstants.EXITING_METHOD);
	}

	private void insertIntoTFBOIlcOutstandingClaimPay(String requestId)
			throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		DBHelper aDBHelper = new DBHelper();
		aDBHelper.setValueInDB(requestId,
				ActionConstants.GETINSERTTFBOILCPOCP_QUERY);
		logger.info(ActionConstants.EXITING_METHOD);
	}

	private void insertIntoTFBOIlcOutstandingClaimAccept(String requestId)
			throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		DBHelper aDBHelper = new DBHelper();
		aDBHelper.setValueInDB(requestId,
				ActionConstants.GETINSERTTFBOILCPOCA_QUERY);
		logger.info(ActionConstants.EXITING_METHOD);
	}

	private void insertIntoTFBOIlcClaimRvd(String requestId) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		DBHelper aDBHelper = new DBHelper();
		aDBHelper.setValueInDB(requestId,
				ActionConstants.GETINSERTTFBOILCCRC_QUERY);
		logger.info(ActionConstants.EXITING_METHOD);
	}

	public void insertIntoTFBOIlcAmend(String requestId) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		DBHelper aDBHelper = new DBHelper();
		aDBHelper.setValueInDB(requestId,
				ActionConstants.GETINSERTTFBOILCAMD_QUERY);
		logger.info(ActionConstants.EXITING_METHOD);
	}

	public void insertIntoTFBOIlcOdcCreate(String requestId) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		DBHelper aDBHelper = new DBHelper();
		aDBHelper.setValueInDB(requestId,
				ActionConstants.GETINSERTTFBOODCCREATE_QUERY);
		logger.info(ActionConstants.EXITING_METHOD);
	}

	public void insertIntoTFBOIlcOdcPayment(String requestId) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		DBHelper aDBHelper = new DBHelper();
		aDBHelper.setValueInDB(requestId,
				ActionConstants.GETINSERTTFBOODCPAYMENT_QUERY);
		logger.info(ActionConstants.EXITING_METHOD);
	}

	public void insertIntoTFBOIlcIssue(String requestId) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		DBHelper aDBHelper = new DBHelper();
		aDBHelper.setValueInDB(requestId,
				ActionConstants.GETINSERTTFBOILCISS_QUERY);
		logger.info(ActionConstants.EXITING_METHOD);
	}

	public void deleteTFBOTransChecklist(String requestId, String productCode,
			String eventCode) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		DBHelper aDBHelper = new DBHelper();
		try {
			aDBHelper.deleteTFBOTransChecklist(requestId, productCode,
					eventCode, ActionConstants.GETDELETETFBOCHECKLIST_QUERY);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		logger.info(ActionConstants.EXITING_METHOD);
	}

	public void insertIntoTFBOTransChecklist(String requestId,
			String productCode, String eventCode, String subProductCode)
			throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		DBHelper aDBHelper = new DBHelper();
		try {
			String makerTeam = ActionConstants.MAKER;
			String checkerTeam = ActionConstants.FBOSCRUTINIZER;
			logger.info("productCode-->" + productCode);
			logger.info("eventCode-->" + eventCode);
			aDBHelper.insertTFBOTransChecklist(requestId, productCode,
					eventCode, subProductCode, makerTeam,
					ActionConstants.GETINSERTTFBOTRANSCHECKLIST_QUERY);
			aDBHelper.insertTFBOTransChecklist(requestId, productCode,
					eventCode, subProductCode, checkerTeam,
					ActionConstants.GETINSERTTFBOTRANSCHECKLIST_QUERY);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		logger.info(ActionConstants.EXITING_METHOD);
	}

	// Pandi IDC DIRECT Checklist Starts here
	public void insertIntoTFBOTransChecklist_IDC_DIRECT(String requestId,
			String productCode, String eventCode, String subProductCode,
			String direct) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		DBHelper aDBHelper = new DBHelper();
		try {
			String makerTeam = ActionConstants.MAKER;
			String checkerTeam = ActionConstants.FBOSCRUTINIZER;
			logger.info("productCode-->" + productCode);
			logger.info("eventCode-->" + eventCode);
			logger.info("direct-->" + direct);
			System.out.println("productCode-->" + productCode);
			System.out.println("eventCode-->" + eventCode);
			System.out.println("eventCode-->" + subProductCode);
			System.out.println("eventCode-->" + makerTeam);
			System.out.println("direct-->" + direct);
			aDBHelper
					.insertTFBOTransChecklist_Direct(
							requestId,
							productCode,
							eventCode,
							subProductCode,
							makerTeam,
							direct,
							ActionConstants.GETINSERTTFBOTRANSCHECKLIST_QUERY_IDC_DIRECT);
			aDBHelper
					.insertTFBOTransChecklist_Direct(
							requestId,
							productCode,
							eventCode,
							subProductCode,
							checkerTeam,
							direct,
							ActionConstants.GETINSERTTFBOTRANSCHECKLIST_QUERY_IDC_DIRECT);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		logger.info(ActionConstants.EXITING_METHOD);
	}

	// Pandi IDC Direct Checklist Ends Here

	public String getCurrentStepFromDB(String requestId) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		DBHelper aDBHelper = new DBHelper();
		String stepName = "";
		try {
			stepName = aDBHelper.getValueFromDB(requestId,
					ActionConstants.GETCURRENTSTEPNAME_QUERY);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		logger.info(ActionConstants.EXITING_METHOD + ">>" + stepName);
		return stepName;
	}

	public void insertIntoTFBOStepHist(String stepName, String stepStatus,
			String requestID, String userName) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		DBHelper aDBHelper = new DBHelper();
		aDBHelper.setValueInDB(stepName, stepStatus, requestID, userName,
				ActionConstants.GETINSERTTFBOSTEPHIST_QUERY);
		logger.info(ActionConstants.EXITING_METHOD);
	}

	public void insertIntoTFBOTrans(String productCode, String eventCode,
			String subProductCode, String stepName, String stepStatus,
			String requestID, String userName) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		DBHelper aDBHelper = new DBHelper();
		insertIntoTFBOStepHist(stepName, stepStatus, requestID, userName);
		aDBHelper.setValueInDB(requestID, productCode, eventCode, stepName,
				stepStatus, ActionConstants.GETINSERTTFBOTRANS_QUERY);
		logger.info(ActionConstants.EXITING_METHOD);
	}

	public Boolean isUserDonePreviousStep(String requestID, String userName)
			throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		DBHelper aDBHelper = new DBHelper();
		CommonMethods aCommonMethods = new CommonMethods();
		String inputUser = "";
		if (!aCommonMethods.isValueAvailable(requestID)) {
			logger.info(ActionConstants.EXITING_METHOD);
			return false;
		}
		inputUser = aDBHelper.getValueFromDB(requestID,
				ActionConstants.GETINPUTUSER_QUERY);
		if (aCommonMethods.isValueAvailable(inputUser)) {
			if (userName.trim().equals(inputUser.trim())) {
				logger.info(ActionConstants.EXITING_METHOD);
				return true;
			}
		}
		String reviewUser = "";
		reviewUser = aDBHelper.getValueFromDB(requestID,
				ActionConstants.GETREVIEWUSER_QUERY);
		if (aCommonMethods.isValueAvailable(reviewUser)) {
			if (userName.trim().equals(reviewUser.trim())) {
				logger.info(ActionConstants.EXITING_METHOD);
				return true;
			}
		}
		String authUser = "";
		authUser = aDBHelper.getValueFromDB(requestID,
				ActionConstants.GETAUTHUSER_QUERY);
		if (aCommonMethods.isValueAvailable(authUser)) {
			if (userName.trim().equals(authUser.trim())) {
				logger.info(ActionConstants.EXITING_METHOD);
				return true;
			}
		}
		logger.info(ActionConstants.EXITING_METHOD);
		return false;
	}

	public List<String> getUserTeam(String userName) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		DBHelper aDBHelper = new DBHelper();
		List<String> userTeamList = null;
		try {
			
			userTeamList = aDBHelper.getListFromDB(userName,
					ActionConstants.GETUSERTEAM_QUERY);
			

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		logger.info(ActionConstants.EXITING_METHOD);
		return userTeamList;
	}

	public Boolean isUserMaker(String userName) {
		logger.info(ActionConstants.ENTERING_METHOD + ">> isUserMaker");
		List<String> userTeamList = null;
		try {
			userTeamList = getUserTeam(userName);
			for (int teamCount = 0; teamCount < userTeamList.size(); teamCount++) {
				if (userTeamList.get(teamCount).trim()
						.equals(ActionConstants.MAKER)) {
					logger.info(ActionConstants.EXITING_METHOD
							+ ">> isUserMaker");
					return true;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		logger.info(ActionConstants.EXITING_METHOD + ">> isUserMaker");
		return false;
	}

	public Boolean isUserFbo(UserTransactionVO userVo) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD + ">> isUserMaker");
		List<String> userTeamList = null;
		userVo.setUserFBOMaker("NO");
		userVo.setUserFBOChecker("NO");
		userTeamList = getUserTeam(userVo.getSessionUserName());
		for (int teamCount = 0; teamCount < userTeamList.size(); teamCount++) {
			if (userTeamList.get(teamCount).trim()
					.equals(ActionConstants.FBOSCRUTINIZER)
					|| userTeamList.get(teamCount).trim()
							.equals(ActionConstants.ILCSCRUTINIZER)
					|| userTeamList.get(teamCount).trim()
							.equals(ActionConstants.ELCSCRUTINIZER)
					|| userTeamList.get(teamCount).trim()
							.equals(ActionConstants.IDCSCRUTINIZER)
					|| userTeamList.get(teamCount).trim()
							.equals(ActionConstants.ODCSCRUTINIZER)
					|| userTeamList.get(teamCount).trim()
							.equals(ActionConstants.FSASCRUTINIZER)
					|| userTeamList.get(teamCount).trim()
							.equals(ActionConstants.IRSCRUTINIZER)
					|| userTeamList.get(teamCount).trim()
							.equals(ActionConstants.ORSCRUTINIZER)
					// Changes for IGT FBOMAKER on 02/01/20
					|| userTeamList.get(teamCount).trim()
							.equals(ActionConstants.IGTSCRUTINIZER)) {
				logger.info(ActionConstants.EXITING_METHOD + ">> isUserMaker");
				return true;
			}
			if (userTeamList.get(teamCount).trim()
					.equals(ActionConstants.FBOCHECKER)
					|| userTeamList.get(teamCount).trim()
							.equals(ActionConstants.ILCCHECKER)
					|| userTeamList.get(teamCount).trim()
							.equals(ActionConstants.ELCCHECKER)
					|| userTeamList.get(teamCount).trim()
							.equals(ActionConstants.IDCCHECKER)
					|| userTeamList.get(teamCount).trim()
							.equals(ActionConstants.ODCCHECKER)
					|| userTeamList.get(teamCount).trim()
							.equals(ActionConstants.FSACHECKER)
					|| userTeamList.get(teamCount).trim()
							.equals(ActionConstants.IRCHECKER)
					|| userTeamList.get(teamCount).trim()
							.equals(ActionConstants.ORCHECKER)
					|| userTeamList.get(teamCount).trim()
							.equals(ActionConstants.IGTCHECKER)
					|| userTeamList.get(teamCount).trim()
							.equals(ActionConstants.SBLCCHECKER)) {
				userVo.setUserFBOChecker("YES");
				logger.info(ActionConstants.EXITING_METHOD + ">> isUserMaker");
				return true;
			}
			if (userTeamList.get(teamCount).trim()
					.equals(ActionConstants.FBOMAKER)
					|| userTeamList.get(teamCount).trim()
							.equals(ActionConstants.ILCMAKER)
					|| userTeamList.get(teamCount).trim()
							.equals(ActionConstants.ELCMAKER)
					|| userTeamList.get(teamCount).trim()
							.equals(ActionConstants.IDCMAKER)
					|| userTeamList.get(teamCount).trim()
							.equals(ActionConstants.ODCMAKER)
					|| userTeamList.get(teamCount).trim()
							.equals(ActionConstants.FSAMAKER)
					|| userTeamList.get(teamCount).trim()
							.equals(ActionConstants.IRMAKER)
					|| userTeamList.get(teamCount).trim()
							.equals(ActionConstants.ORMAKER)
					|| userTeamList.get(teamCount).trim()
							.equals(ActionConstants.IGTMAKER)
					|| userTeamList.get(teamCount).trim()
							.equals(ActionConstants.SBLCMAKER)) {
				userVo.setUserFBOMaker("YES");
				logger.info(ActionConstants.EXITING_METHOD + ">> isUserMaker");
				return true;
			}
		}
		logger.info(ActionConstants.EXITING_METHOD + ">> isUserMaker");
		return false;
	}

	public Boolean isUserAllowed(String userName, String requestID,
			String stepName) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD + ">> isUserAllowed");
		TFBOWorkflow aTFBOWorkflow = new TFBOWorkflow();
		List<String> userTeamList = null;
		String stepTeam = "";
		stepTeam = aTFBOWorkflow.getStepTeam(stepName);
		userTeamList = getUserTeam(userName);
		for (int teamCount = 0; teamCount < userTeamList.size(); teamCount++) {
			if (stepTeam.contains(",")) {
				String[] stepTeamValues = stepTeam.split(",");
				for (int stepTeamCount = 0; stepTeamCount < stepTeamValues.length; stepTeamCount++) {
					if (userTeamList.get(teamCount).trim()
							.equals(stepTeamValues[stepTeamCount].trim())) {
						if (!isUserDonePreviousStep(requestID, userName)) {
							logger.info(ActionConstants.EXITING_METHOD
									+ ">> isUserAllowed");
							return true;
						}
					}
				}
			}
			if (userTeamList.get(teamCount).trim().equals(stepTeam.trim())) {
				if (!isUserDonePreviousStep(requestID, userName)) {
					logger.info(ActionConstants.EXITING_METHOD
							+ ">> isUserAllowed");
					return true;
				}
			}
		}
		logger.info(ActionConstants.EXITING_METHOD + ">> isUserAllowed");
		return false;
	}

	public String getTIDate() throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		DBHelper aDBHelper = new DBHelper();
		String tiDate = null;
		tiDate = aDBHelper.getValueFromDB(ActionConstants.GETTIDATE_QUERY);
		logger.info(ActionConstants.ENTERING_METHOD);
		return tiDate;
	}

	public String generateRequestID(String productCode) {
		DBHelper aDBHelper = new DBHelper();
		String requestId = "";
		String finalSequenceNo = "";
		try {
			SimpleDateFormat aSimpleDateFormat = new SimpleDateFormat(
					"yyyyMMdd");
			Date aDate = new Date();
			String todayDate = aSimpleDateFormat.format(aDate);
			logger.info("Getting Today Date===>" + todayDate);
			String sequenceNo = aDBHelper
					.getValueFromDB(ActionConstants.GETREQUESTID_QUERY);
			while (sequenceNo.length() < 4) {
				sequenceNo = "0" + sequenceNo;
				logger.info("Sequence No in while loop ===>" + finalSequenceNo);
			}
			finalSequenceNo = sequenceNo;
			logger.info("Final Sequence No===>" + finalSequenceNo);
			requestId = productCode + todayDate + finalSequenceNo;
			logger.info("Getting requestId==> " + requestId);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return requestId;
	}

	public List<String> getCurrencyList() throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		DBHelper aDBHelper = new DBHelper();
		List<String> currencyList = null;
		currencyList = aDBHelper
				.getListFromDB(ActionConstants.GETCURRENCY_QUERY);
		logger.info(ActionConstants.ENTERING_METHOD);
		return currencyList;
	}

	public List<String> getSubProduct(UserTransactionVO userVo)
			throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		DBHelper aDBHelper = new DBHelper();
		List<String> subProduct = null;
		logger.info("ProductCode in getSubproduct method"
				+ userVo.getProductCode());
		logger.info("EventCode in getSubproduct method" + userVo.getEventCode());
		subProduct = aDBHelper.getListFromDB(userVo.getProductCode(),
				userVo.getEventCode(), ActionConstants.GETSUBPRODUCT_QUERY);
		logger.info(ActionConstants.ENTERING_METHOD);
		return subProduct;
	}

	public List<String> getProductListFromDB() throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		DBHelper aDBHelper = new DBHelper();
		List<String> productList = null;
		productList = aDBHelper
				.getListFromDB(ActionConstants.GETPRODUCTLIST_QUERY);
		logger.info(ActionConstants.ENTERING_METHOD);
		return productList;
	}

	public List<String> getEventListFromDB(String productCode) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		DBHelper aDBHelper = new DBHelper();
		List<String> eventDetailsList = null;
		try {
			eventDetailsList = aDBHelper.getListFromDB(productCode,
					ActionConstants.GETEVENTLIST_QUERY);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		logger.info(ActionConstants.ENTERING_METHOD);
		return eventDetailsList;
	}

	public List<String> getBillReference(UserTransactionVO userVo,
			String tiReference) {
		logger.info(ActionConstants.ENTERING_METHOD);
		List<String> billReference = new ArrayList<String>();
		try {
			logger.info(ActionConstants.ENTERING_METHOD);
			DBHelper aDBHelper = new DBHelper();
			if (userVo.getProductCode().equalsIgnoreCase("FEL")
					&& userVo.getEventCode().equalsIgnoreCase("CSA4")) {
				if (tiReference != null && !tiReference.trim().equals("")) {
					billReference = aDBHelper.getBillReferenceFromDB(
							tiReference, "FEL");
				} else {
					billReference = aDBHelper.getBillReferenceFromDB(
							userVo.getLcRefNum(), "FEL");
				}

				logger.info("bill reference in TFBOHomeDAO>>-->"
						+ billReference);
			}
			if (userVo.getProductCode().equalsIgnoreCase("ILC")
					&& (userVo.getEventCode().equalsIgnoreCase("POCA")
							|| userVo.getEventCode().equalsIgnoreCase("POCD") || userVo
							.getEventCode().equalsIgnoreCase("POCP"))) {
				billReference = aDBHelper.getBillReferenceFromDB(tiReference,
						"ILC");
				logger.info("bill reference in TFBOHomeDAO>>-->"
						+ billReference);
			}
			// if(on monday)

			if (userVo.getProductCode().equalsIgnoreCase("ELC")
					&& (userVo.getEventCode().equalsIgnoreCase("PODA") || userVo
							.getEventCode().equalsIgnoreCase("PODP"))) {
				billReference = aDBHelper.getBillReferenceFromDB(tiReference,
						"ELC");
				logger.info("bill reference in TFBOHomeDAO>>-->"
						+ billReference);
			}

			// SBLC_251219
			if (userVo.getProductCode().equalsIgnoreCase("ISB")
					&& userVo.getEventCode().equalsIgnoreCase("OIS")) {
				billReference = aDBHelper.getBillReferenceFromDB(tiReference,
						"ISB");
				logger.info("bill reference in TFBOHomeDAO>>-->"
						+ billReference);

			}
			System.out.println("product code >>-->" + userVo.getProductCode());
			System.out.println("event code >>-->" + userVo.getEventCode());
			if (userVo.getProductCode().equalsIgnoreCase("IGT")
					&& userVo.getEventCode().equalsIgnoreCase("OIG")) {
				billReference = aDBHelper.getBillReferenceFromDB(tiReference,
						"IGT");
				logger.info("bill reference in TFBOHomeDAO>>-->"
						+ billReference);

			}

			logger.info(ActionConstants.ENTERING_METHOD);

		} catch (Exception e) {
		}
		logger.info(ActionConstants.EXITING_METHOD);
		return billReference;
	}

	public UserTransactionVO getLCDetailsFromDB(UserTransactionVO userVo,
			String tiReferenceNo) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		DBHelper aDBHelper = new DBHelper();
		List<TFBOFinanceExportLcVO> financeExportLCVOList = new LinkedList<TFBOFinanceExportLcVO>();
		if (userVo.getProductCode().equalsIgnoreCase("FEL")
				&& userVo.getEventCode().equalsIgnoreCase("CSA4")) {
			financeExportLCVOList = aDBHelper.getTFBOIFELCREFromDB(
					tiReferenceNo,
					ActionConstants.GETTIREFNOTRANSDETAILES_FELCRE_QUERY);
			userVo.setFinanceExportLCList(financeExportLCVOList);
			setTransactionValuesInVO(userVo);
		}
		logger.info(ActionConstants.EXITING_METHOD);
		return userVo;
	}

	public void fetchDevolmentAmount(UserTransactionVO userVo) {
		logger.info(ActionConstants.ENTERING_METHOD);
		DBHelper aDBHelper = new DBHelper();
		String billAmount = "";
		try {
			billAmount = aDBHelper.getDevolmentAmount(
					userVo.getBillReference(), userVo.getTiReferanceNo(),
					ActionConstants.GETDEVOLMENTAMOUNT_ILC_POC_QUERY, userVo);
			userVo.setBillReferenceList(getBillReference(userVo,
					userVo.getTiReferanceNo()));
			if (billAmount.equals("")) {
				logger.info("error since billamount null");
			}
		} catch (Exception e) {

			e.printStackTrace();
		}
	}

	// ELC DOP Issue Fix 20-12-2019 starts
	private void updateTFBOElcDOP(String tiReferenceNo, String solID,
			String requestId, String preshipAccSettled, String amount,
			String currency, String usancePeriod, String lcType,
			String custCif, String finSameDay,String rateTaken, String token,
			String rateK, String rate) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD + ">> updateTFBOElcDOP");
		DBHelper aDBHelper = new DBHelper();
		logger.info("Getting tiReferenceNo==> " + tiReferenceNo);
		logger.info("Getting solID==> " + solID);
		logger.info("Getting requestId==> " + requestId);
		logger.info("Getting preshipAccSetteld==> " + preshipAccSettled);
		logger.info("Getting amount==> " + amount);
		logger.info("Getting currency==> " + currency);
		logger.info("Getting usancePeriod==> " + usancePeriod);
		logger.info("Getting lcType==> " + lcType);
		logger.info("Getting custCif==> " + custCif);

		if (preshipAccSettled.trim().equals("true")) {
			preshipAccSettled = "Yes";
		} else {
			preshipAccSettled = "No";
		}

		if (finSameDay.trim().equals("Yes")) {
			finSameDay = "Y";
		} else {
			finSameDay = "N";
		}
		if (rateTaken.trim().equals("true")) {
			rateTaken = "Y";
		} else {
			rateTaken = "N";
		}
		logger.info("After setting yes or no in Preship account to be settled==> "
				+ preshipAccSettled);
		aDBHelper.setValueInDB(tiReferenceNo, requestId,
				ActionConstants.GETUPDATETIREFERANCE_QUERY);
		aDBHelper.setValueInDBELCDOP(solID, preshipAccSettled, amount,currency, usancePeriod,
				lcType, custCif, requestId, finSameDay,rateTaken,
				token, rateK, rate,
				ActionConstants.GETUPDATETFBOELCDOPNEW_QUERY);
		logger.info(ActionConstants.EXITING_METHOD + ">> updateTFBOElcDOP");

	}

	// ELC DOP Issue Fix 20-12-2019 ends

	/*
	 * private void UpdateTFBOIlcCorrespondence(String tiReferanceNo, String
	 * solID, String customeCif, String customeName, String amount, String
	 * currency, String lcType, String userRemark, String requestId) throws
	 * Exception { System.out.println(ActionConstants.ENTERING_METHOD); DBHelper
	 * aDBHelper = new DBHelper(); aDBHelper.setValueInDB(tiReferanceNo,
	 * requestId, ActionConstants.GETUPDATETIREFERANCE_QUERY);
	 * aDBHelper.setValueInLILCCOIDB(solID, customeCif, customeName, amount,
	 * currency, lcType, userRemark, requestId,
	 * ActionConstants.GETUPDATETFBOILCCOI_QUERY);
	 * 
	 * }
	 */
	private void UpdateTFBOIlcCorrespondence(String tiReferanceNo,
			String solID, String customeCif, String customeName, String amount,
			String currency, String lcType, String userRemark, String requestId)
			throws Exception {
		System.out.println(ActionConstants.ENTERING_METHOD);
		DBHelper aDBHelper = new DBHelper();
		aDBHelper.setValueInDB(tiReferanceNo, requestId,
				ActionConstants.GETUPDATETIREFERANCE_QUERY);
		aDBHelper.setValueInLILCCOIDB(solID, customeCif, customeName, amount,
				currency, lcType, userRemark, requestId,
				ActionConstants.GETUPDATETFBOILCCOI_QUERY);

	}

	/*
	 * private void UpdateTFBOIEcCorrespondence(String tiReferanceNo, String
	 * solID, String customeCif, String customeName, String amount, String
	 * currency, String lcType, String userRemark, String requestId) throws
	 * Exception { System.out.println(ActionConstants.ENTERING_METHOD); DBHelper
	 * aDBHelper = new DBHelper(); aDBHelper.setValueInDB(tiReferanceNo,
	 * requestId, ActionConstants.GETUPDATETIREFERANCE_QUERY);
	 * aDBHelper.setValueInLILCCOIDB(solID, customeCif, customeName, amount,
	 * currency, lcType, userRemark, requestId,
	 * ActionConstants.GETUPDATETFBOELCCOE_QUERY);
	 * 
	 * }
	 */
	private void UpdateTFBOIEcCorrespondence(String tiReferanceNo,
			String solID, String customeCif, String customeName, String amount,
			String currency, String lcType, String userRemark, String requestId)
			throws Exception {
		System.out.println(ActionConstants.ENTERING_METHOD);
		DBHelper aDBHelper = new DBHelper();
		aDBHelper.setValueInDB(tiReferanceNo, requestId,
				ActionConstants.GETUPDATETIREFERANCE_QUERY);
		aDBHelper.setValueInLILCCOIDB(solID, customeCif, customeName, amount,
				currency, lcType, userRemark, requestId,
				ActionConstants.GETUPDATETFBOELCCOE_QUERY);

	}

	// ELC DOP Issue Fix 20-12-2019 starts
	public void insertintoTFBOElcDOP(String requestID) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		DBHelper aDBHelper = new DBHelper();
		aDBHelper.setValueInDB(requestID,
				ActionConstants.GETINSERTTFBOELCDOP_QUERY);
		logger.info(ActionConstants.EXITING_METHOD);
	}

	// ELC DOP Issue Fix 20-12-2019 ends

	// Inward Remittance changes 23-12-2019 starts
	public void updateTFBOInwardRemittanceCreate(String solId,
			String customerCif, String amount, String currency,
			String requestId, String prodType, String preshipAccSetteld,
			String dummyIrex, String rateTaken, String token, String rateK,
			String rate) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		DBHelper aDBHelper = new DBHelper();
		if (dummyIrex.trim().equals("true")) {
			dummyIrex = "Yes";
		} else {
			dummyIrex = "No";
		}
		if (preshipAccSetteld.trim().equals("true")) {
			preshipAccSetteld = "Yes";
		} else {
			preshipAccSetteld = "No";
		}
		if (rateTaken.trim().equals("true")) {
			rateTaken = "Y";
		} else {
			rateTaken = "N";
		}
		aDBHelper.setValueInwardRemittanceInDB(solId, customerCif, amount,
				currency, dummyIrex, prodType, preshipAccSetteld, rateTaken,
				token, rateK, rate, requestId,
				ActionConstants.GETUPDATETFBOINWARDREMITTANCECREATENEW_QUERY);
		logger.info(ActionConstants.EXITING_METHOD);
	}

	// Inward Remittance changes 23-12-2019 ends

	// Inward Remittance changes 23-12-2019 starts
	public void insertIntoTFBOInwardRemittanceCreate(String requestId)
			throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		DBHelper aDBHelper = new DBHelper();
		aDBHelper.setValueInDB(requestId,
				ActionConstants.GETINSERTTFBOINWARDREMITTANCECREATE_QUERY);
		logger.info(ActionConstants.EXITING_METHOD);
	}

	// Inward Remittance changes 23-12-2019 ends

	// Outward Remittance Changes 23/12/2019 start

	private void updateTFBOCpcoCreate(String requestId, String tiReferanceNo,
			String customeCif, String customeName, String amount,
			String currency, String solID, String bankPay, String rateTaken,
			String subProductCode, String token, String valueK, String rate)
			throws Exception {

		System.out.println(ActionConstants.ENTERING_METHOD);
		DBHelper aDBHelper = new DBHelper();

		aDBHelper.setValueInDB(tiReferanceNo, requestId,
				ActionConstants.GETUPDATETIREFERANCE_QUERY);

		aDBHelper.setValueInDBCpcoCreate(solID, tiReferanceNo, amount,
				customeCif, customeName, currency, bankPay, rateTaken,
				subProductCode, token, valueK, rate, requestId,
				ActionConstants.GETUPDATETFBOCPCPCRE_QUERY);
		System.out.println(ActionConstants.EXITING_METHOD);

	}

	// Outward Remittance Changes 23/12/2019 end
	// Outward Remittance Changes 23/12/2019 start

	public void insertIntoTFBOcpcoCreate(String requestId) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		DBHelper aDBHelper = new DBHelper();
		aDBHelper.setValueInDB(requestId,
				ActionConstants.GETINSERTTFBOCPCOCRE_QUERY);
		logger.info(ActionConstants.EXITING_METHOD);
	}

	// Outward Remittance Changes 23/12/2019 end
	// Changes for ELC and IGT Starts 25-12-2019
	public void insertintoTFBOElcPODA(String requestID) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		DBHelper aDBHelper = new DBHelper();
		aDBHelper.setValueInDB(requestID,
				ActionConstants.GETINSERTTFBOELCPODA_QUERY);
		logger.info(ActionConstants.EXITING_METHOD);
	}

	public void insertintoTFBOElcPODP(String requestID) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		DBHelper aDBHelper = new DBHelper();
		aDBHelper.setValueInDB(requestID,
				ActionConstants.GETINSERTTFBOELCPODP_QUERY);
		logger.info(ActionConstants.EXITING_METHOD);
	}

	public void insertIntoTFBOIgtIssue(String requestID) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		DBHelper aDBHelper = new DBHelper();
		aDBHelper.setValueInDB(requestID,
				ActionConstants.GETINSERTTFBOIGTIIG_QUERY);
		logger.info(ActionConstants.EXITING_METHOD);
	}

	public void insertIntoTFBOIgtAmend(String requestID) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		DBHelper aDBHelper = new DBHelper();
		aDBHelper.setValueInDB(requestID,
				ActionConstants.GETINSERTTFBOIGTNAIG_QUERY);
		logger.info(ActionConstants.EXITING_METHOD);
	}

	private void insertIntoTFBOIgtExpire(String requestID) throws Exception {
		System.out.println(ActionConstants.ENTERING_METHOD);
		DBHelper aDBHelper = new DBHelper();
		aDBHelper.setValueInDB(requestID,
				ActionConstants.GETINSERTTFBOIGTXIG_QUERY);
		System.out.println(ActionConstants.EXITING_METHOD);

	}

	public void insertIntoTFBOIgtClaim(String requestID) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		DBHelper aDBHelper = new DBHelper();
		aDBHelper.setValueInDB(requestID,
				ActionConstants.GETINSERTTFBOIGTLIG_QUERY);
		logger.info(ActionConstants.EXITING_METHOD);
	}

	public void insertIntoTFBOIgtPayment(String requestID) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		DBHelper aDBHelper = new DBHelper();
		aDBHelper.setValueInDB(requestID,
				ActionConstants.GETINSERTTFBOIGTOIG_QUERY);
		logger.info(ActionConstants.EXITING_METHOD);
	}

	private String getGuaranteeAmount(String tiReferenceNo,String billReference) throws Exception {

		DBHelper aDBHelper = new DBHelper();
		String guaranteeAmt = "";
		guaranteeAmt = aDBHelper.getGuaranteeAmt(tiReferenceNo,billReference,
				ActionConstants.GETGUARANTEEAMT_QUERY);
		return guaranteeAmt;
	}

	private void updateTFBOELCPODA(String tiReferanceNo, String solID,
			String custCif, String customeName, String acceptanceAmount,
			String lcType, String currency, String requestId,
			String billReference, String subprodtype) throws Exception {

		System.out.println(ActionConstants.ENTERING_METHOD);
		DBHelper aDBHelper = new DBHelper();
		aDBHelper.setValueInDB(tiReferanceNo, requestId,
				ActionConstants.GETUPDATETIREFERANCE_QUERY);
		aDBHelper.setValueInDBELCPODA(tiReferanceNo, solID, custCif,
				customeName, acceptanceAmount, lcType, currency, billReference,
				subprodtype, requestId,
				ActionConstants.GETUPDATETFBOELCPODANEW_QUERY);
		System.out.println(ActionConstants.EXITING_METHOD);

	}

	private void updateTFBOELCPODP(String tiReferanceNo, String solID,
			String custCif, String customeName, String acceptanceAmount,
			String lcType, String currency, String requestId,
			String billReference, String subprodtype, String rateTaken,
			String token, String K, String rate) throws Exception {

		System.out.println(ActionConstants.ENTERING_METHOD);
		DBHelper aDBHelper = new DBHelper();
		aDBHelper.setValueInDB(tiReferanceNo, requestId,
				ActionConstants.GETUPDATETIREFERANCE_QUERY);
		aDBHelper.setValueInDBELCPODP(tiReferanceNo, solID, custCif,
				customeName, acceptanceAmount, lcType, currency, billReference,
				subprodtype, rateTaken, token, K, rate, requestId,
				ActionConstants.GETUPDATETFBOELCPODPNEW_QUERY);
		System.out.println(ActionConstants.EXITING_METHOD);

	}

	private void updateTFBOIGTIIG(String tiReferanceNo, String solID,
			String customeCif, String customeName, String amount,
			String currency, String requestId, String subProductCode,
			String tenure, String expiryDate) throws Exception {

		System.out.println(ActionConstants.ENTERING_METHOD);
		DBHelper aDBHelper = new DBHelper();
		aDBHelper.setValueInDB(tiReferanceNo, requestId,
				ActionConstants.GETUPDATETIREFERANCE_QUERY);
		aDBHelper.setValueInDBIGTIIG(tiReferanceNo, solID, customeCif,
				customeName, amount, currency, subProductCode, tenure,
				requestId, expiryDate,
				ActionConstants.GETUPDATETFBOIGTIIGNEW_QUERY);

	}

	private void updateTFBOIgtExpire(String tiReferanceNo, String solID,
			String customeCif, String customeName, String tenure,
			String amount, String currency, String requestId) throws Exception {
		System.out.println(ActionConstants.ENTERING_METHOD);
		DBHelper aDBHelper = new DBHelper();

		aDBHelper.setValueInDB(tiReferanceNo, requestId,
				ActionConstants.GETUPDATETIREFERANCE_QUERY);

		aDBHelper.setValuesIGTExpire(requestId, solID, tiReferanceNo,
				customeCif, customeName, tenure, amount, currency,
				ActionConstants.GETUPDATEIGTXIG_QUERY);
	}

	private void updateTFBOIGTNAIG(String tiReferanceNo, String solID,
			String customeCif, String customeName, String amount,
			String currency, String requestId, String subProductCode,
			String tenure) throws Exception {

		System.out.println(ActionConstants.ENTERING_METHOD);
		DBHelper aDBHelper = new DBHelper();
		aDBHelper.setValueInDB(tiReferanceNo, requestId,
				ActionConstants.GETUPDATETIREFERANCE_QUERY);
		aDBHelper.setValueInDBIGTNAIG(tiReferanceNo, solID, customeCif,
				customeName, amount, currency, subProductCode, tenure,
				requestId, ActionConstants.GETUPDATETFBOIGTNAIGNEW_QUERY);

	}

	private void updateTFBOIGTLIG(String tiReferanceNo, String solID,
			String customeCif, String customeName, String amount,
			String currency, String requestId, String subProductCode,
			String tenure, String partInvocation, String guarnteeAmtPrevInv,
			String reqInvAmt) throws Exception {

		System.out.println(ActionConstants.ENTERING_METHOD);
		DBHelper aDBHelper = new DBHelper();

		aDBHelper.setValueInDB(tiReferanceNo, requestId,
				ActionConstants.GETUPDATETIREFERANCE_QUERY);
		if (partInvocation.equals("false")) {
			partInvocation = "N";
		} else {
			partInvocation = "Y";
		}
		aDBHelper.setValueInDBIGTLIG(tiReferanceNo, solID, customeCif,
				customeName, amount, currency, subProductCode, tenure,
				partInvocation, requestId, guarnteeAmtPrevInv, reqInvAmt,
				ActionConstants.GETUPDATETFBOIGTLIGNEW_QUERY);
	}

	/* changes for rate taken starts 010120 */
	private void updateTFBOIGTOIG(String tiReferanceNo, String solID,
			String customeCif, String customeName, String amount,
			String currency, String requestId, String subProductCode,
			String tenure, String partInvocation, String guarnteeAmtPrevInv,
			String reqInvAmt, String rateTaken, String valuek, String token,
			String rate, String billref) throws Exception {

		System.out.println(ActionConstants.ENTERING_METHOD);
		DBHelper aDBHelper = new DBHelper();
		aDBHelper.setValueInDB(tiReferanceNo, requestId,
				ActionConstants.GETUPDATETIREFERANCE_QUERY);
		aDBHelper.setValueInDBIGTOIG(tiReferanceNo, solID, customeCif,
				customeName, amount, currency, subProductCode, tenure,
				partInvocation, requestId, guarnteeAmtPrevInv, reqInvAmt,
				rateTaken, valuek, token, rate, billref,
				ActionConstants.GETUPDATETFBOIGTOIGNEW_QUERY);
	}

	/* changes for rate taken starts 010120 */
	/*
	 * public List<String> getBillReference(String tiReference, String
	 * eventCode, String productCode) {
	 * logger.info(ActionConstants.ENTERING_METHOD + ">> getBillReference ");
	 * List<String> billReference = new LinkedList<String>(); //
	 * List<TFBOImportLcVO> ilcIssue = new LinkedList<TFBOImportLcVO>(); //
	 * TFBOImportLcVO aTFBOIlcIssueVO = null; try {
	 * logger.info(ActionConstants.ENTERING_METHOD); DBHelper aDBHelper = new
	 * DBHelper(); logger.info("tiReference >>" + tiReference); String query =
	 * ""; // aTFBOIlcIssueVO=new TFBOImportLcVO(); if
	 * ((productCode.equals("ILC")) && (eventCode.equals("POCA") ||
	 * eventCode.equals("POCD") || eventCode .equals("POCP"))) { query =
	 * "Select Bev.Refno_Pfix||Lpad(Bev.Refno_Serl,3,0) As Event_Ref From Master Mas,Baseevent Bev,Lcpayment Lcp, Clmrecd clm WHERE MAS.KEY97    = BEV.MASTER_KEY And Bev.Refno_Pfix = 'CLM' And Bev.Key97 = Lcp.Key97 And  Bev.Key97 = Clm.Key97  and  Lcp.Nextout_Ev is null And Mas.Master_Ref = '"
	 * + tiReference.trim() + "'"; // query =
	 * ActionConstants.GETBILLREFERENCE_ILC_POC_QUERY; } else if
	 * (productCode.equals("IGT") && eventCode.equals("OIG")) { query =
	 * "Select Bev.Refno_Pfix||Lpad(Bev.Refno_Serl,3,0) As Event_Ref From Master Mas,Baseevent Bev,Lcpayment Lcp, Clmrecd clm WHERE MAS.KEY97    = BEV.MASTER_KEY And Bev.Refno_Pfix = 'CLM' And Bev.Key97 = Lcp.Key97 And  Bev.Key97 = Clm.Key97  and  Lcp.Nextout_Ev is null And Mas.Master_Ref = '"
	 * + tiReference.trim() + "'"; } else if (productCode.equals("ELC") &&
	 * (eventCode.equals("PODA") || eventCode.equals("PODP"))) {
	 * System.out.println("entering >> ELC PODA block"); query =
	 * "SELECT bev.refno_pfix || lpad(bev.refno_serl, 3, 0) AS event_ref FROM master      mas, baseevent   bev,lcpayment   lcp,docSPRE DOC WHERE mas.key97 = bev.master_key AND bev.refno_pfix = 'DPR' AND bev.key97 = lcp.key97 AND BEV.KEY97=DOC.KEY97  AND lcp.nextout_ev IS NULL AND mas.master_ref = '"
	 * + tiReference.trim() + "'"; // query =
	 * ActionConstants.GETBILLREFERENCE_ELC_POD_QUERY; }
	 * 
	 * billReference = aDBHelper .getBillReferenceFromDB(tiReference, query);
	 * 
	 * logger.info("billReference.size() >>-->" + billReference.size());
	 * logger.info(ActionConstants.ENTERING_METHOD); //
	 * aTFBOIlcIssueVO.setBillReferenceList(billReference); //
	 * ilcIssue.add(aTFBOIlcIssueVO); } catch (Exception e) { }
	 * logger.info(ActionConstants.EXITING_METHOD); return billReference;
	 * 
	 * }
	 */

	// Changes for ELC and IGT ends 25-12-2019

	// Changes for ELC and IGT Starts 25-12-2019

	// Changed by onsite team 26122019 starts
	/*
	 * public void fetchExpiryDate(UserTransactionVO userVo) throws Exception {
	 * logger.info(ActionConstants.ENTERING_METHOD); String expiryDate = "";
	 * String tenure = userVo.getTenure(); if (tenure != null) { try { LocalDate
	 * expDat = LocalDate.now().plusDays(Integer.parseInt(tenure)); expiryDate =
	 * expDat.toString(); userVo.setExpiryDate(expiryDate);
	 * logger.info("Expiry date >>--> " + userVo.getExpiryDate()); } catch
	 * (Exception e) { }
	 * 
	 * } else { userVo.setExpiryDate(expiryDate); } }
	 */

	public void fetchExpiryDate(UserTransactionVO userVo) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		String expiryDate = "";
		String tenure = userVo.getTenure();
		if (tenure != null) {
			try {
				/*
				 * LocalDate expDat =
				 * LocalDate.now().plusDays(Integer.parseInt(tenure));
				 */
				SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
				Date expDat = new Date();
				Calendar c = Calendar.getInstance();
				c.setTime(expDat);
				c.add(Calendar.DAY_OF_MONTH, (Integer.parseInt(tenure)));
				expiryDate = sdf.format(c.getTime());
				userVo.setExpiryDate(expiryDate);
				logger.info("Expiry date >>--> " + userVo.getExpiryDate());
			} catch (Exception e) {

				e.printStackTrace();
			}
		} else {
			userVo.setExpiryDate(expiryDate);
		}
	}

	// Changed by onsite team 26122019 ends

	// Changes for ELC and IGT ends 25-12-2019

	// code changes for checklist by pandi starts 06012020
	public void insertIntoTFBOTransChecklist_pocp(String requestId,
			String productCode, String eventCode, String subProductCode,
			String lcType) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		DBHelper aDBHelper = new DBHelper();
		try {
			String makerTeam = ActionConstants.MAKER;
			String checkerTeam = ActionConstants.FBOSCRUTINIZER;
			logger.info("productCode-->" + productCode);
			logger.info("eventCode-->" + eventCode);
			aDBHelper.insertTFBOTransChecklist_pocp(requestId, productCode,
					eventCode, subProductCode, makerTeam, lcType,
					ActionConstants.GETINSERTTFBOTRANSCHECKLIST_QUERY_POCP);
			aDBHelper.insertTFBOTransChecklist_pocp(requestId, productCode,
					eventCode, subProductCode, checkerTeam, lcType,
					ActionConstants.GETINSERTTFBOTRANSCHECKLIST_QUERY_POCP);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		logger.info(ActionConstants.EXITING_METHOD);
	}

	// code changes for checklist by pandi ends 06012020

	// Changes for acceptance amount fetch starts 08012020
	public void fetchAcceptanceAmount(UserTransactionVO userVo)
			throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		DBHelper aDBHelper = new DBHelper();
		userVo.setAcceptanceAmount(aDBHelper.getAcceptanceAmount(userVo));
		userVo.setBillReferenceList(getBillReference(userVo,
				userVo.getTiReferanceNo()));
	}
	
	public void fetchIGTBillAmount(UserTransactionVO userVo)
			throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		userVo.setGuarnteeAmtPrevInv(getGuaranteeAmount(userVo.getTiReferanceNo(),userVo.getBillReference()));
		userVo.setBillReferenceList(getBillReference(userVo,
				userVo.getTiReferanceNo()));
	}

	// Changes for acceptance amount fetch ends 08012020
	// CHANGES FOR ODC CAC 08012020 NY SAI STARTS HERE
	public void insertIntoTFBOIlcOdcAccept(String requestId) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		DBHelper aDBHelper = new DBHelper();
		aDBHelper.setValueInDB(requestId,
				ActionConstants.GETINSERTTFBOODCACCEPT_QUERY);
		logger.info(ActionConstants.EXITING_METHOD);
	}

	public void updateTFBOOdcAccept(String requestId, String solId,
			String tiReferanceNo, String customerCif, String currency,
			String acceptAmt, String usancePeriod, String prodType,
			String custName) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		DBHelper aDBHelper = new DBHelper();
		aDBHelper.setValueInDB(tiReferanceNo, requestId,
				ActionConstants.GETUPDATETIREFERANCE_QUERY);

		aDBHelper.setValueODCACCEPTInDB(solId, customerCif, currency.trim(),
				acceptAmt, usancePeriod, prodType, custName, requestId,
				ActionConstants.GETUPDATETFBOODCACCEPTNEW_QUERY);
		logger.info(ActionConstants.EXITING_METHOD);
		logger.info(ActionConstants.EXITING_METHOD);
	}

	// CHANGES FOR ODC CAC 08012020 NY SAI ENDS HERE

	// CHANGES BY CHANDRU 10012020 STARTS
	// public List<TFBOTransVO> getTFBOTransListFromDBFilter(
	// UserTransactionVO userVo) throws Exception {
	// logger.info(ActionConstants.ENTERING_METHOD);
	// DBHelper aDBHelper = new DBHelper();
	// List<TFBOTransVO> transactionList = null;
	// CommonMethods aCommonMethods = new CommonMethods();
	// try {
	//
	// // Sub product type drop down filter changes starts 21012020
	// String productFilter = userVo.getSubProductFilter();
	// if (aCommonMethods.isValueAvailable(productFilter)) {
	// productFilter = getSubProductCodeFromDB(userVo
	// .getSubProductFilter());
	// }
	// // Sub product type drop down filter changes ends 21012020
	//
	// // Transaction status drop down filter changes starts 20012020
	// userVo.setIsTiTransFlag("");
	// String statusFilter = userVo.getStatusFilter();
	// String stepFilter = userVo.getStepFilter();
	// if (aCommonMethods.isValueAvailable(userVo.getStatusFilter())) {
	//
	// logger.info("Getting status filter in getTFBOTransListFromDBFilter==> "
	// + userVo.getStatusFilter());
	//
	// if (userVo.getStatusFilter().equalsIgnoreCase(
	// "Transaction Pending for Entry in FBTI")) {
	// stepFilter = "a1";
	// statusFilter = "i";
	// userVo.setIsTiTransFlag("Y");
	// }
	//
	// if (userVo.getStatusFilter().equalsIgnoreCase(
	// "Transaction Pending for Approval in FBTI")) {
	// stepFilter = "i";
	// statusFilter = "i";
	// userVo.setIsTiTransFlag("Y");
	// }
	//
	// if (userVo.getStatusFilter().equalsIgnoreCase(
	// "Approved-Completed in FBTI")) {
	// statusFilter = "c";
	// userVo.setIsTiTransFlag("Y");
	// }
	//
	// }
	// // Transaction status drop down filter changes ends 20012020
	//
	// if (!aCommonMethods.isValueAvailable(userVo.getIsTiTransFlag()))
	// userVo.setIsTiTransFlag("N");
	// String fromDateFlag = "N";
	// String toDateFlag = "N";
	// String requestId = userVo.getRequestIdFilter();
	// String productCode = userVo.getProductCodeFilter();
	// String eventCode = userVo.getEventCodeFilter();
	//
	// // Transaction status drop down filter changes starts 20012020
	// String stepFilter = userVo.getStepFilter();
	// // Transaction status drop down filter changes ends 20012020
	//
	// // Transaction status drop down filter changes starts 20012020
	// String statusFilter = userVo.getStatusFilter();
	// // Transaction status drop down filter changes ends 20012020
	//
	// String queriedFilter = userVo.getIsQueriedFilter();
	// String fromDateFilter = userVo.getFromDateFilter();
	// String toDateFilter = userVo.getToDateFilter();
	//
	// // Sub product type drop down filter changes starts 21012020
	// String productFilter = userVo.getSubProductFilter();
	// // Sub product type drop down filter changes ends 21012020
	//
	// String referenceFilter = userVo.getTiReferenceFilter();
	// String query = "";
	//
	// if (userVo.getIsTiTransFlag().equalsIgnoreCase("N")) {
	// System.out.println("getIsTiTransFlag is N (if condition)==>");
	//
	// query = ActionConstants.GETTFBOTRANSLIST_TIREF_QUERY_MOD;
	// if (requestId != null && !requestId.equals("")) {
	// query = query + " AND TXN.REQUESTID LIKE '%" + requestId
	// + "%'";
	// }
	// if (productCode != null && !productCode.equals("")) {
	// query = query + " AND TXN.PRODUCTCODE LIKE '%"
	// + productCode + "%'";
	// }
	// if (eventCode != null && !eventCode.equals("")) {
	// query = query + " AND TXN.EVENTCODE LIKE '%" + eventCode
	// + "%'";
	// }
	// if (stepFilter != null && !stepFilter.equals("")) {
	// query = query + " AND TXN.STEP LIKE '%" + stepFilter + "%'";
	// }
	// if (statusFilter != null && !statusFilter.equals("")) {
	// query = query + " AND TXN.STEPSTATUS LIKE '%"
	// + statusFilter + "%'";
	// }
	// if (queriedFilter != null && !queriedFilter.equals("")) {
	// query = query + " AND TXN.ISQUERIEDTRANS LIKE '%"
	// + queriedFilter + "%'";
	// }
	// if (fromDateFilter != null && !fromDateFilter.equals("")
	// && toDateFilter != null && !toDateFilter.equals("")) {
	// query = query
	// + " AND TO_DATE(TRUNC(TXN.TRANS_CREATED),'DD-MM-YY') "
	// + " BETWEEN TO_DATE('" + fromDateFilter
	// + "','DD-MM-YY') " + " AND TO_DATE('"
	// + toDateFilter + "','DD-MM-YY') ";
	// }
	// if (productFilter != null && !productFilter.equals("")) {
	// query = query + " AND TXN.SUBPRODUCTCODE LIKE '%"
	// + productFilter + "%'";
	// }
	// if (referenceFilter != null && !referenceFilter.equals("")) {
	// query = query + " AND TXN.TIREFERANCE LIKE '%"
	// + referenceFilter + "%'";
	// }
	// query = query
	// + " ORDER BY TXN.REQUESTID DESC FETCH FIRST 20 ROW ONLY";
	// System.out.println("GENERAL QUERY--->" + query);
	// transactionList = aDBHelper
	// .getTransactionListFromDBFilter(query);
	// }
	//
	// if (userVo.getIsTiTransFlag().equalsIgnoreCase("Y")
	// && !userVo.getProductCodeFilter().equalsIgnoreCase("CPCI")) {
	// System.out.println("getIsTiTransFlag is Y (if condition)==>");
	//
	// query = ActionConstants.GETTFBOTITRANSLIST_QUERY_MOD;
	// if (requestId != null && !requestId.equals("")) {
	// query = query + " AND TFB.REQUESTID LIKE '%" + requestId
	// + "%'";
	// }
	// if (productCode != null && !productCode.equals("")) {
	// query = query + " AND TRIM(PRD.CODE79) = '" + productCode
	// + "'";
	// }
	// if (eventCode != null && !eventCode.equals("")) {
	// query = query + " AND TRIM(EVT.CODE79) = '" + eventCode
	// + "'";
	// }
	// if (statusFilter != null && !statusFilter.equals("")) {
	// query = query + " AND TRIM(BEV.STATUS) = '" + statusFilter
	// + "'";
	// }
	// if (stepFilter != null && !stepFilter.equals("")) {
	// query = query + " AND TRIM(STEP.TYPE) <> '" + stepFilter
	// + "'";
	// }
	// if (queriedFilter != null && !queriedFilter.equals("")) {
	// query = query + " AND TFB.ISQUERIEDTRANS LIKE '%"
	// + queriedFilter + "%'";
	// }
	// if (fromDateFilter != null && !fromDateFilter.equals("")
	// && toDateFilter != null && !toDateFilter.equals("")) {
	// query = query
	// + " AND TO_DATE(TRUNC(TXN.TRANS_CREATED),'DD-MM-YY') "
	// + " BETWEEN TO_DATE('" + fromDateFilter
	// + "','DD-MM-YY') " + " AND TO_DATE('"
	// + toDateFilter + "','DD-MM-YY') ";
	// }
	// if (productFilter != null && !productFilter.equals("")) {
	// query = query + " AND TFB.SUBPRODUCTCODE LIKE '%"
	// + productFilter + "%'";
	// }
	// if (referenceFilter != null && !referenceFilter.equals("")) {
	// query = query + " AND TFB.TIREFERANCE LIKE '%"
	// + referenceFilter + "%'";
	// }
	// query = query
	// + " ORDER BY TFB.REQUESTID DESC FETCH FIRST 20 ROW ONLY";
	// System.out.println("WITHOUT CPCI QUERY--->" + query);
	// transactionList = aDBHelper
	// .getTransactionListFromDBFilter(query);
	//
	// }
	//
	// logger.info("Product code filter==>"
	// + userVo.getProductCodeFilter());
	// if (userVo.getIsTiTransFlag().equalsIgnoreCase("Y")
	// && userVo.getProductCodeFilter().equalsIgnoreCase("CPCI")) {
	// logger.info("Entering if condition in CPCI");
	// query = ActionConstants.GETTFBOTITRANSLISTCPCI_QUERY_MOD;
	// if (requestId != null && !requestId.equals("")) {
	// query = query + " AND TFB.REQUESTID LIKE '%" + requestId
	// + "%'";
	// }
	// if (productCode != null && !productCode.equals("")) {
	// query = query + " AND (TRIM(PRD.CODE79) = '" + productCode
	// + "' OR TRIM(TFB.SUBPRODUCTCODE) LIKE ('IBP')) ";
	// }
	// if (eventCode != null && !eventCode.equals("")) {
	// query = query + " AND TRIM(EVT.CODE79) = '" + eventCode
	// + "'";
	// }
	// if (statusFilter != null && !statusFilter.equals("")) {
	// query = query + " AND TRIM(BEV.STATUS) = '" + statusFilter
	// + "'";
	// }
	// if (stepFilter != null && !stepFilter.equals("")) {
	// query = query + " AND TRIM(STEP.TYPE) <> '" + stepFilter
	// + "'";
	// }
	// if (queriedFilter != null && !queriedFilter.equals("")) {
	// query = query + " AND TFB.ISQUERIEDTRANS LIKE '%"
	// + queriedFilter + "%'";
	// }
	// if (fromDateFilter != null && !fromDateFilter.equals("")
	// && toDateFilter != null && !toDateFilter.equals("")) {
	// query = query
	// + " AND TO_DATE(TRUNC(TXN.TRANS_CREATED),'DD-MM-YY') "
	// + " BETWEEN TO_DATE('" + fromDateFilter
	// + "','DD-MM-YY') " + " AND TO_DATE('"
	// + toDateFilter + "','DD-MM-YY') ";
	// }
	// if (productFilter != null && !productFilter.equals("")) {
	// query = query + " AND TFB.SUBPRODUCTCODE LIKE '%"
	// + productFilter + "%'";
	// }
	// if (referenceFilter != null && !referenceFilter.equals("")) {
	// query = query + " AND TFB.TIREFERANCE LIKE '%"
	// + referenceFilter + "%'";
	// }
	// query = query
	// + " ORDER BY TFB.REQUESTID DESC FETCH FIRST 20 ROW ONLY";
	// System.out.println("WITH CPCI QUERY--->" + query);
	// transactionList = aDBHelper
	// .getTransactionListFromDBFilter(query);
	// }
	//
	// if (fromDateFlag.equals("Y"))
	// userVo.setFromDateFilter("");
	// if (toDateFlag.equals("Y"))
	// userVo.setToDateFilter("");
	// } catch (Exception e) {
	// e.printStackTrace();
	// throw e;
	// }
	// logger.info(ActionConstants.EXITING_METHOD + "transactionList size-->"
	// + transactionList.size());
	// return transactionList;
	// }

	/*ADDED BY CHANDRU FOR FILTER PURPOSE ON 17032020*/
	public List<TFBOTransVO> getTFBOTransListFromDBFilterForFilter(
			UserTransactionVO userVo) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		DBHelper aDBHelper = new DBHelper();
		List<TFBOTransVO> transactionList = null;
		CommonMethods aCommonMethods = new CommonMethods();
		try {
			String productFilter = userVo.getSubProductFilter();
			if (aCommonMethods.isValueAvailable(productFilter)) {
				productFilter = getSubProductCodeFromDB(userVo
						.getSubProductFilter());
			}
			userVo.setIsTiTransFlag("");
			String statusFilter = userVo.getStatusFilter();
			String stepFilter = userVo.getStepFilter();
			String stepFilterReject = "";
			
			
			
			if (aCommonMethods.isValueAvailable(userVo.getStatusFilter())) {

				logger.info("Getting status filter in getTFBOTransListFromDBFilter==> "
						+ userVo.getStatusFilter());

				if (userVo.getStatusFilter().equalsIgnoreCase(
						"Transaction With FBO maker")) {
					userVo.setIsTiTransFlag("Y");
				}

				if (userVo.getStatusFilter().equalsIgnoreCase(
						"Transaction With FBO checker")) {
					userVo.setIsTiTransFlag("Y");
				}

				if (userVo.getStatusFilter().equalsIgnoreCase(
						"Authrorized-Completed in Baroda Insta")) {
					userVo.setIsTiTransFlag("Y");
				}

				if (userVo.getStatusFilter().equalsIgnoreCase(
						"Transaction With Branch maker")) {
					stepFilter = "Branch maker";
					userVo.setIsTiTransFlag("N");
				}
				if (userVo.getStatusFilter().equalsIgnoreCase("FBO Rejected")) {
					userVo.setIsTiTransFlag("N");
				}
				if (userVo.getStatusFilter()
						.equalsIgnoreCase("Branch Rejected")) {
					stepFilter = "Branch checker";
					stepFilterReject = "Branch maker";
					userVo.setIsTiTransFlag("N");
				}
				if (userVo.getStatusFilter().equalsIgnoreCase(
						"Authrorize by Scrutinizer")) {
					stepFilter = "Release";
					userVo.setIsTiTransFlag("N");
				}
				if (userVo.getStatusFilter().equalsIgnoreCase(
						"Transaction With Branch checker")) {
					stepFilter = "Branch checker";
					userVo.setIsTiTransFlag("N");
				}
				if (userVo.getStatusFilter().equalsIgnoreCase(
						"Transaction With FBO Scrutinizer")) {
					stepFilter = "FBO Scrutinizer";
					userVo.setIsTiTransFlag("N");
				}
			}

			if (!aCommonMethods.isValueAvailable(userVo.getIsTiTransFlag()))
				userVo.setIsTiTransFlag("N");
			String fromDateFlag = "N";
			String toDateFlag = "N";
			String requestId = userVo.getRequestIdFilter();
			String productCode = userVo.getProductCodeFilter();
			String eventCode = userVo.getEventCodeFilter();

			String queriedFilter = userVo.getIsQueriedFilter();
			String fromDateFilter = userVo.getFromDateFilter();
			String toDateFilter = userVo.getToDateFilter();

			String referenceFilter = userVo.getTiReferenceFilter();

			String solIdFilter = userVo.getSolIdFilter();
			String customerNameFilter = userVo.getCustomerNameFilter();
			String senderRefnoFilter = userVo.getSenderRefNo();// pandi for sender ref no
			String query = "";

			if (userVo.getIsTiTransFlag().equalsIgnoreCase("N")
					&& userVo.getProductCodeFilter() != null 
					&& !userVo.getProductCodeFilter().trim().equals("")
					&& !(userVo.getProductCodeFilter().equalsIgnoreCase("ODC") || userVo
							.getProductCodeFilter().equalsIgnoreCase("ELC"))) {
				System.out.println("getIsTiTransFlag is N (if condition)==>");
				query = ActionConstants.GETTFBOTRANSLIST_TIREF_QUERY_MOD;
				if (requestId != null && !requestId.equals("")) {
					query = query + " AND TXN.REQUESTID LIKE '%" + requestId
							+ "%'";
				}
				if (productCode != null && !productCode.equals("")) {
					query = query + " AND TXN.PRODUCTCODE LIKE '%"
							+ productCode + "%'";
				}
				if (eventCode != null && !eventCode.equals("")) {
					query = query + " AND TXN.EVENTCODE LIKE '%" + eventCode
							+ "%'";
				}
				if ((stepFilter != null && !stepFilter.equals(""))
						&& statusFilter.equals("Branch Rejected")) {
					query = query + " AND TXN.STEP IN ('" + stepFilter + "','"
							+ stepFilterReject + "')";
				} else if (stepFilter != null && !stepFilter.equals("")) {
					query = query + " AND TXN.STEP LIKE '%" + stepFilter + "%'";
				}
				if (statusFilter != null && !statusFilter.equals("")) {
					query = query + " AND TXN.STEPSTATUS LIKE '%"
							+ statusFilter + "%'";
				}
				if (queriedFilter != null && !queriedFilter.equals("")) {
					query = query + " AND TXN.ISQUERIEDTRANS LIKE '%"
							+ queriedFilter + "%'";
				}
				if (fromDateFilter != null && !fromDateFilter.equals("")
						&& toDateFilter != null && !toDateFilter.equals("")) {
					query = query
							+ " AND TO_DATE(TRUNC(TXN.TRANS_CREATED),'DD-MM-YY') "
							+ " BETWEEN TO_DATE('" + fromDateFilter
							+ "','DD-MM-YY') " + " AND TO_DATE('"
							+ toDateFilter + "','DD-MM-YY') ";
				}
				if (productFilter != null && !productFilter.equals("")) {
					query = query + " AND TXN.SUBPRODUCTCODE LIKE '%"
							+ productFilter + "%'";
				}
				if (referenceFilter != null && !referenceFilter.equals("")) {
					query = query + " AND TXN.TIREFERANCE LIKE '%"
							+ referenceFilter + "%'";
				}
				if (solIdFilter != null && !solIdFilter.equals("")) {

					String[] solIdSplit = solIdFilter.split(",");
					String finalSolIdFilter = "";
					for (int solIdIndex = 0; solIdIndex < solIdSplit.length; solIdIndex++) {
						finalSolIdFilter = finalSolIdFilter + "'"
								+ solIdSplit[solIdIndex] + "'";
					}
					finalSolIdFilter = finalSolIdFilter.replace("''", "','");
					query = query + " AND TXN.SOLID IN (" + finalSolIdFilter
							+ ")";
				}

				if (customerNameFilter != null
						&& !customerNameFilter.equals("")) {
					query = query + " AND TXN.CUSTOMERNAME LIKE '%"
							+ customerNameFilter + "%'";
				}

				if (senderRefnoFilter != null && !senderRefnoFilter.equals("")) {
								query = query + " AND TEA.SENDERREFNO LIKE '%"
										+ senderRefnoFilter + "%'";
							}
				query = query + " ORDER BY TXN.REQUESTID DESC ";
				System.out.println("GENERAL QUERY--->" + query);
				transactionList = aDBHelper
						.getTransactionListFromDBFilter(query);
			}

			
			if (userVo.getIsTiTransFlag().equalsIgnoreCase("N")
					&& userVo.getProductCodeFilter() != null
					&& !userVo.getProductCodeFilter().trim().equals("")
					&& (userVo.getProductCodeFilter().equalsIgnoreCase("ODC")
							||userVo.getProductCodeFilter().equalsIgnoreCase("ELC"))) {
				System.out.println("getIsTiTransFlag is N (if condition)==>");

				query = ActionConstants.GETTFBOTRANSLIST_TIREF_QUERY_MOD;
				if (requestId != null && !requestId.equals("")) {
					query = query + " AND TXN.REQUESTID LIKE '%" + requestId
							+ "%'";
				}
				if (productCode != null && !productCode.equals("")) {
					query = query + " AND TXN.PRODUCTCODE LIKE '%"
							+ productCode + "%'";
				}
				if (eventCode != null && !eventCode.equals("")) {
					query = query + " AND TXN.EVENTCODE LIKE '%" + eventCode
							+ "%'";
				}
				if ((stepFilter != null && !stepFilter.equals(""))
						&& statusFilter.equals("Branch Rejected")) {
					query = query + " AND TXN.STEP IN ('" + stepFilter + "','"
							+ stepFilterReject + "')";
				} else if (stepFilter != null && !stepFilter.equals("")) {
					query = query + " AND TXN.STEP LIKE '%" + stepFilter + "%'";
				}
				if (statusFilter != null && !statusFilter.equals("")) {
					query = query + " AND TXN.STEPSTATUS LIKE '%"
							+ statusFilter + "%'";
				}
				if (queriedFilter != null && !queriedFilter.equals("")) {
					query = query + " AND TXN.ISQUERIEDTRANS LIKE '%"
							+ queriedFilter + "%'";
				}
				if (fromDateFilter != null && !fromDateFilter.equals("")
						&& toDateFilter != null && !toDateFilter.equals("")) {
					query = query
							+ " AND TO_DATE(TRUNC(TXN.TRANS_CREATED),'DD-MM-YY') "
							+ " BETWEEN TO_DATE('" + fromDateFilter
							+ "','DD-MM-YY') " + " AND TO_DATE('"
							+ toDateFilter + "','DD-MM-YY') ";
				}
				if (productFilter != null && !productFilter.equals("")) {
					query = query + " AND TXN.SUBPRODUCTCODE LIKE '%"
							+ productFilter + "%'";
				}
				if (referenceFilter != null && !referenceFilter.equals("")) {
					query = query + " AND TXN.TIREFERANCE LIKE '%"
							+ referenceFilter + "%'";
				}
				if (solIdFilter != null && !solIdFilter.equals("")) {

					String[] solIdSplit = solIdFilter.split(",");
					String finalSolIdFilter = "";
					for (int solIdIndex = 0; solIdIndex < solIdSplit.length; solIdIndex++) {
						finalSolIdFilter = finalSolIdFilter + "'"
								+ solIdSplit[solIdIndex] + "'";
					}
					finalSolIdFilter = finalSolIdFilter.replace("''", "','");
					query = query + " AND TXN.SOLID IN (" + finalSolIdFilter
							+ ")";
				}

				if (customerNameFilter != null
						&& !customerNameFilter.equals("")) {
					query = query + " AND TXN.CUSTOMERNAME LIKE '%"
							+ customerNameFilter + "%'";
				}
				if (senderRefnoFilter != null && !senderRefnoFilter.equals("")) {
					query = query + " AND TEA.SENDERREFNO LIKE '%"
							+ senderRefnoFilter + "%'";
				}
				query = query + " ORDER BY TXN.REQUESTID DESC ";
				System.out.println("ELC 2 QUERY-test1-->" + query);
				transactionList = aDBHelper
						.getTransactionListFromDBFilter(query);
			}
			
			if (userVo.getIsTiTransFlag().equalsIgnoreCase("Y")
					&& userVo.getProductCodeFilter() != null
					&& !userVo.getProductCodeFilter().trim().equals("")
					&& !(userVo.getProductCodeFilter().equalsIgnoreCase("CPCI"))) {

				System.out.println("getIsTiTransFlag is Y (if condition)==>");

				query = ActionConstants.GETTFBOTITRANSLIST_QUERY_MOD;
				if (requestId != null && !requestId.equals("")) {
					query = query + " AND TFB.REQUESTID LIKE '%" + requestId
							+ "%'";
				}
				if (productCode != null && !productCode.equals("")) {
					query = query + " AND TRIM(TFB.PRODUCTCODE) = '" + productCode
							+ "'";
				}
				if (eventCode != null && !eventCode.equals("")) {
					query = query + " AND TRIM(TFB.EVENTCODE) = '" + eventCode
							+ "'";
				}
				if (statusFilter != null && !statusFilter.equals("")) {
					query = query + " AND TRIM(TFB.STEPSTATUS) = '" + statusFilter
							+ "'";
				}
				if (queriedFilter != null && !queriedFilter.equals("")) {
					query = query + " AND TFB.ISQUERIEDTRANS LIKE '%"
							+ queriedFilter + "%'";
				}
				if (fromDateFilter != null && !fromDateFilter.equals("")
						&& toDateFilter != null && !toDateFilter.equals("")) {
					query = query
							+ " AND TO_DATE(TRUNC(TXN.TRANS_CREATED),'DD-MM-YY') "
							+ " BETWEEN TO_DATE('" + fromDateFilter
							+ "','DD-MM-YY') " + " AND TO_DATE('"
							+ toDateFilter + "','DD-MM-YY') ";
				}
				if (productFilter != null && !productFilter.equals("")) {
					query = query + " AND TFB.SUBPRODUCTCODE LIKE '%"
							+ productFilter + "%'";
				}
				if (referenceFilter != null && !referenceFilter.equals("")) {
					query = query + " AND TFB.TIREFERANCE LIKE '%"
							+ referenceFilter + "%'";
				}
				if (solIdFilter != null && !solIdFilter.equals("")) {

					String[] solIdSplit = solIdFilter.split(",");
					String finalSolIdFilter = "";
					for (int solIdIndex = 0; solIdIndex < solIdSplit.length; solIdIndex++) {
						finalSolIdFilter = finalSolIdFilter + "'"
								+ solIdSplit[solIdIndex] + "'";
					}
					finalSolIdFilter = finalSolIdFilter.replace("''", "','");
					query = query + " AND TXN.SOLID IN (" + finalSolIdFilter
							+ ")";
				}

				if (customerNameFilter != null
						&& !customerNameFilter.equals("")) {
					query = query + " AND TXN.CUSTOMERNAME LIKE '%"
							+ customerNameFilter + "%'";
				}
				if (senderRefnoFilter != null && !senderRefnoFilter.equals("")) {
					query = query + " AND TEA.SENDERREFNO LIKE '%"
							+ senderRefnoFilter + "%'";
				}
				query = query + " ORDER BY TFB.REQUESTID DESC ";
				System.out.println("WITHOUT CPCI QUERY--->" + query);
				transactionList = aDBHelper
						.getTransactionListFromDBFilter(query);

			}

			logger.info("Product code filter==>"
					+ userVo.getProductCodeFilter());
			if (userVo.getIsTiTransFlag().equalsIgnoreCase("Y")
					&& userVo.getProductCodeFilter() != null
					&& !userVo.getProductCodeFilter().trim().equals("")
					&& userVo.getProductCodeFilter().equalsIgnoreCase("CPCI")) {
				logger.info("Entering if condition in CPCI");
				query = ActionConstants.GETTFBOTITRANSLISTCPCI_QUERY_MOD;
				if (requestId != null && !requestId.equals("")) {
					query = query + " AND TFB.REQUESTID LIKE '%" + requestId
							+ "%'";
				}
				if (productCode != null && !productCode.equals("")) {
					query = query + " AND (TRIM(TFB.PRODUCTCODE) = '" + productCode
							+ "' OR TRIM(TFB.SUBPRODUCTCODE) LIKE ('IBP')) ";
				}
				if (eventCode != null && !eventCode.equals("")) {
					query = query + " AND TRIM(EVT.CODE79) = '" + eventCode
							+ "'";
				}
				if (statusFilter != null && !statusFilter.equals("")) {
					query = query + " AND TRIM(TFB.STEPSTATUS) = '" + statusFilter
							+ "'";
				}
				if (queriedFilter != null && !queriedFilter.equals("")) {
					query = query + " AND TFB.ISQUERIEDTRANS LIKE '%"
							+ queriedFilter + "%'";
				}
				if (fromDateFilter != null && !fromDateFilter.equals("")
						&& toDateFilter != null && !toDateFilter.equals("")) {
					query = query
							+ " AND TO_DATE(TRUNC(TXN.TRANS_CREATED),'DD-MM-YY') "
							+ " BETWEEN TO_DATE('" + fromDateFilter
							+ "','DD-MM-YY') " + " AND TO_DATE('"
							+ toDateFilter + "','DD-MM-YY') ";
				}
				if (productFilter != null && !productFilter.equals("")) {
					query = query + " AND TFB.SUBPRODUCTCODE LIKE '%"
							+ productFilter + "%'";
				}
				if (referenceFilter != null && !referenceFilter.equals("")) {
					query = query + " AND TFB.TIREFERANCE LIKE '%"
							+ referenceFilter + "%'";
				}
				if (solIdFilter != null && !solIdFilter.equals("")) {

					String[] solIdSplit = solIdFilter.split(",");
					String finalSolIdFilter = "";
					for (int solIdIndex = 0; solIdIndex < solIdSplit.length; solIdIndex++) {
						finalSolIdFilter = finalSolIdFilter + "'"
								+ solIdSplit[solIdIndex] + "'";
					}
					finalSolIdFilter = finalSolIdFilter.replace("''", "','");
					query = query + " AND TXN.SOLID IN (" + finalSolIdFilter
							+ ")";
				}

				if (customerNameFilter != null
						&& !customerNameFilter.equals("")) {
					query = query + " AND TXN.CUSTOMERNAME LIKE '%"
							+ customerNameFilter + "%'";
				}

				query = query + " ORDER BY TFB.REQUESTID DESC ";
				System.out.println("WITH CPCI QUERY--->" + query);
				transactionList = aDBHelper
						.getTransactionListFromDBFilter(query);
			}

			if (userVo.getIsTiTransFlag().equalsIgnoreCase("Y")
					&& userVo.getProductCodeFilter() != null
					&& !userVo.getProductCodeFilter().trim().equals("")
					&& userVo.getProductCodeFilter().equalsIgnoreCase("COR")) {
				logger.info("Entering if condition in CPCI");
				if (statusFilter.equals("i") && stepFilter.equals("a1")) {
					query = ActionConstants.GETTFBOTITRANSLISTCOR_QUERY_MOD_INP;
				} else if (statusFilter.equals("i") && stepFilter.equals("i")) {
					query = ActionConstants.GETTFBOTITRANSLISTCOR_QUERY_MOD_AUT;
				} else if (statusFilter.equals("c")) {
					query = ActionConstants.GETTFBOTITRANSLISTCOR_QUERY_MOD_COMP;
				}
				if (requestId != null && !requestId.equals("")) {
					query = query + " AND TFB.REQUESTID LIKE '%" + requestId
							+ "%'";
				}
				if (eventCode != null && !eventCode.equals("")) {
					query = query + " AND TRIM(TFB.EVENTCODE) = '" + eventCode
							+ "'";
				}
				if (statusFilter != null && !statusFilter.equals("")) {
					query = query + " AND TRIM(TFB.BEV_STATUS) = '"
							+ statusFilter + "'";
				}
				if (stepFilter != null && !stepFilter.equals("")) {
					query = query + " AND TRIM(TFB.STEP_TYPE) <> '"
							+ stepFilter + "'";
				}
				if (queriedFilter != null && !queriedFilter.equals("")) {
					query = query + " AND TFB.ISQUERIEDTRANS LIKE '%"
							+ queriedFilter + "%'";
				}
				if (fromDateFilter != null && !fromDateFilter.equals("")
						&& toDateFilter != null && !toDateFilter.equals("")) {
					query = query
							+ " AND TO_DATE(TRUNC(TFB.TRANS_CREATED),'DD-MM-YY') "
							+ " BETWEEN TO_DATE('" + fromDateFilter
							+ "','DD-MM-YY') " + " AND TO_DATE('"
							+ toDateFilter + "','DD-MM-YY') ";
				}
				if (productFilter != null && !productFilter.equals("")) {
					query = query + " AND TFB.SUBPRODUCTCODE LIKE '%"
							+ productFilter + "%'";
				}
				if (referenceFilter != null && !referenceFilter.equals("")) {
					query = query + " AND TFB.TIREFERANCE LIKE '%"
							+ referenceFilter + "%'";
				}
				if (solIdFilter != null && !solIdFilter.equals("")) {

					String[] solIdSplit = solIdFilter.split(",");
					String finalSolIdFilter = "";
					for (int solIdIndex = 0; solIdIndex < solIdSplit.length; solIdIndex++) {
						finalSolIdFilter = finalSolIdFilter + "'"
								+ solIdSplit[solIdIndex] + "'";
					}
					finalSolIdFilter = finalSolIdFilter.replace("''", "','");
					query = query + " AND TFB.SOLID IN (" + finalSolIdFilter
							+ ")";
				}

				if (customerNameFilter != null
						&& !customerNameFilter.equals("")) {
					query = query + " AND TFB.CUSTOMERNAME LIKE '%"
							+ customerNameFilter + "%'";
				}

				query = query + " ORDER BY TFB.REQUESTID DESC ";
				transactionList = aDBHelper
						.getTransactionListFromDBFilter(query);
			}
			
			
			if (userVo.getProductCodeFilter() == null
					|| userVo.getProductCodeFilter().equalsIgnoreCase("")) {
				System.out.println("getIsTiTransFlag is N (if condition)==>");
				if (userVo.getIsTiTransFlag().equalsIgnoreCase("Y"))
					query = ActionConstants.GETTFBOTITRANSLIST_QUERY_MOD;
				if (userVo.getIsTiTransFlag().equalsIgnoreCase("N"))
					query = ActionConstants.GETTFBOTRANSLIST_TIREF_QUERY_MOD;
				if (requestId != null && !requestId.equals("")) {
					query = query + " AND TXN.REQUESTID LIKE '%" + requestId
							+ "%'";
				}
				if (eventCode != null && !eventCode.equals("")) {
					query = query + " AND TXN.EVENTCODE LIKE '%" + eventCode
							+ "%'";
				}
				if ((stepFilter != null && !stepFilter.equals(""))
						&& statusFilter.equals("Branch Rejected")) {
					query = query + " AND TXN.STEP IN ('" + stepFilter + "','"
							+ stepFilterReject + "')";
				} else if (stepFilter != null && !stepFilter.equals("")) {
					query = query + " AND TXN.STEP LIKE '%" + stepFilter + "%'";
				}
				if (statusFilter != null && !statusFilter.equals("")) {
					query = query + " AND TXN.STEPSTATUS LIKE '%"
							+ statusFilter + "%'";
				}
				if (queriedFilter != null && !queriedFilter.equals("")) {
					query = query + " AND TXN.ISQUERIEDTRANS LIKE '%"
							+ queriedFilter + "%'";
				}
				if (fromDateFilter != null && !fromDateFilter.equals("")
						&& toDateFilter != null && !toDateFilter.equals("")) {
					query = query
							+ " AND TO_DATE(TRUNC(TXN.TRANS_CREATED),'DD-MM-YY') "
							+ " BETWEEN TO_DATE('" + fromDateFilter
							+ "','DD-MM-YY') " + " AND TO_DATE('"
							+ toDateFilter + "','DD-MM-YY') ";
				}
				if (productFilter != null && !productFilter.equals("")) {
					query = query + " AND TXN.SUBPRODUCTCODE LIKE '%"
							+ productFilter + "%'";
				}
				if (referenceFilter != null && !referenceFilter.equals("")) {
					query = query + " AND TXN.TIREFERANCE LIKE '%"
							+ referenceFilter + "%'";
				}
				if (solIdFilter != null && !solIdFilter.equals("")) {

					String[] solIdSplit = solIdFilter.split(",");
					String finalSolIdFilter = "";
					for (int solIdIndex = 0; solIdIndex < solIdSplit.length; solIdIndex++) {
						finalSolIdFilter = finalSolIdFilter + "'"
								+ solIdSplit[solIdIndex] + "'";
					}
					finalSolIdFilter = finalSolIdFilter.replace("''", "','");
					query = query + " AND TXN.SOLID IN (" + finalSolIdFilter
							+ ")";
				}

				if (customerNameFilter != null
						&& !customerNameFilter.equals("")) {
					query = query + " AND TXN.CUSTOMERNAME LIKE '%"
							+ customerNameFilter + "%'";
				}

				if (senderRefnoFilter != null && !senderRefnoFilter.equals("")) {
					query = query + " AND TEA.SENDERREFNO LIKE '%"
							+ senderRefnoFilter + "%'";
				}
				query = query + " ORDER BY TXN.REQUESTID DESC ";
				System.out.println("GENERAL QUERY--->" + query);
				transactionList = aDBHelper
						.getTransactionListFromDBFilter(query);
			}
			

			if (fromDateFlag.equals("Y"))
				userVo.setFromDateFilter("");
			if (toDateFlag.equals("Y"))
				userVo.setToDateFilter("");
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		return transactionList;
	}
	
	/*ENDS :- ADDED BY CHANDRU FOR FILTER PURPOSE ON 17032020*/
	
	public List<TFBOTransVO> getTFBOTransListFromDBFilter(
			UserTransactionVO userVo) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		DBHelper aDBHelper = new DBHelper();
		List<TFBOTransVO> transactionList = null;
		CommonMethods aCommonMethods = new CommonMethods();
		try {

			// Sub product type drop down filter changes starts 21012020
			String productFilter = userVo.getSubProductFilter();
			if (aCommonMethods.isValueAvailable(productFilter)) {
				productFilter = getSubProductCodeFromDB(userVo
						.getSubProductFilter());
			}
			// Sub product type drop down filter changes ends 21012020

			// Transaction status drop down filter changes starts 20012020
//			userVo.setIsTiTransFlag("");
			String statusFilter = userVo.getStatusFilter();
			String stepFilter = userVo.getStepFilter();
			String stepFilterReject = "";
			String bevstepphase = userVo.getBevStatus();
			
			
//			if (aCommonMethods.isValueAvailable(userVo.getStatusFilter())) {
//
//				logger.info("Getting status filter in getTFBOTransListFromDBFilter==> "
//						+ userVo.getStatusFilter());
//
//				if (userVo.getStatusFilter().equalsIgnoreCase(
//						"Transaction With FBO maker")) {
//					bevstepphase = "D";
////					stepFilter = "a1";
////					statusFilter = "i";
//					userVo.setIsTiTransFlag("Y");
//				}
//
//				if (userVo.getStatusFilter().equalsIgnoreCase(
//						"Transaction With FBO checker")) {
//					bevstepphase = "V";
////					stepFilter = "i";
////					statusFilter = "i";
//					userVo.setIsTiTransFlag("Y");
//				}
//
//				if (userVo.getStatusFilter().equalsIgnoreCase(
//						"Authrorized-Completed in Baroda Insta")) {
////					statusFilter = "c";
//					userVo.setIsTiTransFlag("Y");
//				}
//
//				// changes for dashbord 05022020 starts
//
//				if (userVo.getStatusFilter().equalsIgnoreCase(
//						"Transaction With Branch maker")) {
//					stepFilter = "Branch maker";
//					// statusFilter = "i";
//					userVo.setIsTiTransFlag("N");
//				}
//				if (userVo.getStatusFilter().equalsIgnoreCase("FBO Rejected")) {
//					//stepFilter = "FBO Maker";//pandi for FBO Auto rejected
//					// statusFilter = "i";
//					userVo.setIsTiTransFlag("N");
//				}
//				if (userVo.getStatusFilter()
//						.equalsIgnoreCase("Branch Rejected")) {
//					stepFilter = "Branch checker";
//					stepFilterReject = "Branch maker";
//					// statusFilter = "i";
//					userVo.setIsTiTransFlag("N");
//				}
//				if (userVo.getStatusFilter().equalsIgnoreCase(
//						"Authrorize by Scrutinizer")) {
//					stepFilter = "Release";
//					// statusFilter = "i";
//					userVo.setIsTiTransFlag("N");
//				}
//				if (userVo.getStatusFilter().equalsIgnoreCase(
//						"Transaction With Branch checker")) {
//					stepFilter = "Branch checker";
//					// statusFilter = "i";
//					userVo.setIsTiTransFlag("N");
//				}
//				if (userVo.getStatusFilter().equalsIgnoreCase(
//						"Transaction With FBO Scrutinizer")) {
//					stepFilter = "FBO Scrutinizer";
//					// statusFilter = "i";
//					userVo.setIsTiTransFlag("N");
//				}
//
//				// changes fro dashboard 05022020 ends
//
//			}
			// Transaction status drop down filter changes ends 20012020

			if (!aCommonMethods.isValueAvailable(userVo.getIsTiTransFlag()))
				userVo.setIsTiTransFlag("N");
			String fromDateFlag = "N";
			String toDateFlag = "N";
			String requestId = userVo.getRequestIdFilter();
			String productCode = userVo.getProductCodeFilter();
			String eventCode = userVo.getEventCodeFilter();

			// Transaction status drop down filter changes starts 20012020
			/* String stepFilter = userVo.getStepFilter(); */
			// Transaction status drop down filter changes ends 20012020

			// Transaction status drop down filter changes starts 20012020
			/* String statusFilter = userVo.getStatusFilter(); */
			// Transaction status drop down filter changes ends 20012020

			String queriedFilter = userVo.getIsQueriedFilter();
			String fromDateFilter = userVo.getFromDateFilter();
			String toDateFilter = userVo.getToDateFilter();

			// Sub product type drop down filter changes starts 21012020
			/* String productFilter = userVo.getSubProductFilter(); */
			// Sub product type drop down filter changes ends 21012020

			String referenceFilter = userVo.getTiReferenceFilter();
			// ADDED BY CHANDRU FOR IDC DIRECT PAYMENTS STARTS
			String directOption = userVo.getDirectOption();
			// ADDED BY CHANDRU FOR IDC DIRECT PAYMENTS ENDS
			/* Dashboard changes 23012020 starts */

			String solIdFilter = userVo.getSolIdFilter();
			String customerNameFilter = userVo.getCustomerNameFilter();
			/* Dashboard changes 23012020 ends */
			String idenOdcType = userVo.getIdenOdcType();
			String directCompFlag = userVo.getDirectCompFlag();
			String amount =userVo.getAmount(); 
		    String currency=userVo.getCurrency();
			String mtReceived = "";
			String finSameDay = "";
			String subProdCode = "";
			String senderRefnoFilter = userVo.getSenderRefNo();// pandi for sender ref no
			String query = "";

			if (aCommonMethods.isValueAvailable(idenOdcType)) {
				if (idenOdcType.trim().equals("MTF")) {
					mtReceived = "Full Amount";
					finSameDay = "";
				} else if (idenOdcType.trim().equals("MTPN")) {
					mtReceived = "Part Amount,None";
					finSameDay = "";
				} else if (idenOdcType.trim().equals("FINSY")) {
					mtReceived = "Part Amount,None";
					finSameDay = "Yes";
				} else if (idenOdcType.trim().equals("FINSN")) {
					mtReceived = "Part Amount,None";
					finSameDay = "No";
				} else if (idenOdcType.trim().equals("ODCIND")) {
					mtReceived = "";
					finSameDay = "";
				} else if (idenOdcType.trim().equals("ADV")) {
					mtReceived = "";
					finSameDay = "";
					subProdCode = "FBA";
				} else if (idenOdcType.trim().equals("ELCFINY")) {
					finSameDay = "Yes";
				} else if (idenOdcType.trim().equals("ELCFINN")) {
					finSameDay = "No";
				}
			}

			if (userVo.getIsTiTransFlag().equalsIgnoreCase("N")
					&& !(userVo.getProductCodeFilter().equalsIgnoreCase("ODC")
							||userVo.getProductCodeFilter().equalsIgnoreCase("ELC"))
					&& !finSameDay.equals("Yes")) {
				System.out.println("getIsTiTransFlag is N (if condition)==>");

				query = ActionConstants.GETTFBOTRANSLIST_TIREF_QUERY_MOD;
				if (requestId != null && !requestId.equals("")) {
					query = query + " AND TXN.REQUESTID LIKE '%" + requestId
							+ "%'";
				}
				if (productCode != null && !productCode.equals("")) {
					query = query + " AND TXN.PRODUCTCODE LIKE '%"
							+ productCode + "%'";
				}
				if (eventCode != null && !eventCode.equals("")) {
					query = query + " AND TXN.EVENTCODE LIKE '%" + eventCode
							+ "%'";
				}
				if ((stepFilter != null && !stepFilter.equals(""))
						&& statusFilter.equals("Branch Rejected")) {
					query = query + " AND TXN.STEP IN ('" + stepFilter + "','"
							+ stepFilterReject + "')";
				} else if (stepFilter != null && !stepFilter.equals("")) {
					query = query + " AND TXN.STEP LIKE '%" + stepFilter + "%'";
				}
				if (statusFilter != null && !statusFilter.equals("")) {
					query = query + " AND TXN.STEPSTATUS LIKE '%"
							+ statusFilter + "%'";
				}
				if (queriedFilter != null && !queriedFilter.equals("")) {
					query = query + " AND TXN.ISQUERIEDTRANS LIKE '%"
							+ queriedFilter + "%'";
				}
				if (fromDateFilter != null && !fromDateFilter.equals("")
						&& toDateFilter != null && !toDateFilter.equals("")) {
					query = query
							+ " AND TO_DATE(TRUNC(TXN.TRANS_CREATED),'DD-MM-YY') "
							+ " BETWEEN TO_DATE('" + fromDateFilter
							+ "','DD-MM-YY') " + " AND TO_DATE('"
							+ toDateFilter + "','DD-MM-YY') ";
				}
				if (productFilter != null && !productFilter.equals("")) {
					query = query + " AND TXN.SUBPRODUCTCODE LIKE '%"
							+ productFilter + "%'";
				}
				if (referenceFilter != null && !referenceFilter.equals("")) {
					query = query + " AND TXN.TIREFERANCE LIKE '%"
							+ referenceFilter + "%'";
				}

				/* Dashboard changes 23012020 starts */
				if (solIdFilter != null && !solIdFilter.equals("")) {

					String[] solIdSplit = solIdFilter.split(",");
					String finalSolIdFilter = "";
					for (int solIdIndex = 0; solIdIndex < solIdSplit.length; solIdIndex++) {
						finalSolIdFilter = finalSolIdFilter + "'"
								+ solIdSplit[solIdIndex] + "'";
					}
					finalSolIdFilter = finalSolIdFilter.replace("''", "','");
					query = query + " AND TXN.SOLID IN (" + finalSolIdFilter
							+ ")";
				}

				if (customerNameFilter != null
						&& !customerNameFilter.equals("")) {
					query = query + " AND TXN.CUSTOMERNAME LIKE '%"
							+ customerNameFilter + "%'";
				}
				/* Dashboard changes 23012020 ends */
				//pandi for sender ref search filter

				if (senderRefnoFilter != null && !senderRefnoFilter.equals("")) {
								query = query + " AND TEA.SENDERREFNO LIKE '%"
										+ senderRefnoFilter + "%'";
							}
				//pandi for sender ref search filter				

				/*
				 * // ADDED BY CHANDRU FOR FILTER if (productCode.equals("IDC"))
				 * { if (directOption != null && !directOption.equals("") &&
				 * directOption.equals("Y")) { query = query +
				 * " AND TXN.DIRECT = 'true' "; } else { query = query +
				 * " AND (TXN.DIRECT       = 'false' OR TXN.DIRECT IS NULL) "; }
				 * }
				 * 
				 * // ENDS
				 */

				// ADDED BY CHANDRU FOR FILTER
				if (productCode.equals("IDC") || productCode.equals("ODC")) {
					if (directOption != null && !directOption.equals("")
							&& directOption.equals("Y")) {
						query = query + " AND COLL.DIRECT = 'true' ";
					} else {
						query = query
								+ " AND (COLL.DIRECT = 'false' OR COLL.DIRECT IS NULL) ";
					}
				}

				if (productCode.equals("ODC")) {
					if (mtReceived != null && !mtReceived.equals("")
							&& mtReceived.equals("Full Amount")) {
						query = query + " AND COLL.MTRECEIVED = 'Full Amount' ";
					} else {
						query = query
								+ " AND (COLL.MTRECEIVED <> 'Full Amount' OR COLL.MTRECEIVED IS NULL)";
					}
				}

				if (productCode.equals("ODC")) {
					if (finSameDay != null && !finSameDay.equals("")
							&& finSameDay.equals("Yes")) {
						query = query + " AND COLL.FINSAMEDAY = 'Yes' ";
					} else {
						query = query
								+ " AND (COLL.FINSAMEDAY <> 'Yes' OR COLL.FINSAMEDAY IS NULL)";
					}
				}

				if (productCode.equals("ODC")) {
					if (subProdCode != null && !subProdCode.equals("")
							&& subProdCode.equals("FBA")) {
						query = query + " AND COLL.SUBPRODUCT = 'FBA' ";
					} else {
						query = query
								+ " AND (COLL.SUBPRODUCT <> 'FBA' OR COLL.SUBPRODUCT IS NULL)";
					}
				}

				// ENDS
				query = query + " ORDER BY TXN.REQUESTID DESC ";
				System.out.println("GENERAL QUERY--->" + query);
				transactionList = aDBHelper
						.getTransactionListFromDBFilter(query);
			}

			if (userVo.getIsTiTransFlag().equalsIgnoreCase("N")
					&& (userVo.getProductCodeFilter().equalsIgnoreCase("ODC") || userVo
							.getProductCodeFilter().equalsIgnoreCase("ELC"))
					&& finSameDay != null && finSameDay.equals("Yes")) {
				System.out.println("getIsTiTransFlag is N (if condition)==>");

				query = ActionConstants.GETTFBOTRANSLIST_TIREF_QUERY_MOD;
				if (requestId != null && !requestId.equals("")) {
					query = query + " AND TXN.REQUESTID LIKE '%" + requestId
							+ "%'";
				}
				if (productCode != null && !productCode.equals("")) {
					query = query + " AND TXN.PRODUCTCODE LIKE '%"
							+ productCode + "%'";
				}
				if (eventCode != null && !eventCode.equals("")) {
					query = query + " AND TXN.EVENTCODE LIKE '%" + eventCode
							+ "%'";
				}
				if ((stepFilter != null && !stepFilter.equals(""))
						&& statusFilter.equals("Branch Rejected")) {
					query = query + " AND TXN.STEP IN ('" + stepFilter + "','"
							+ stepFilterReject + "')";
				} else if (stepFilter != null && !stepFilter.equals("")) {
					query = query + " AND TXN.STEP LIKE '%" + stepFilter + "%'";
				}
				if (statusFilter != null && !statusFilter.equals("")) {
					query = query + " AND TXN.STEPSTATUS LIKE '%"
							+ statusFilter + "%'";
				}
				if (queriedFilter != null && !queriedFilter.equals("")) {
					query = query + " AND TXN.ISQUERIEDTRANS LIKE '%"
							+ queriedFilter + "%'";
				}
				if (fromDateFilter != null && !fromDateFilter.equals("")
						&& toDateFilter != null && !toDateFilter.equals("")) {
					query = query
							+ " AND TO_DATE(TRUNC(TXN.TRANS_CREATED),'DD-MM-YY') "
							+ " BETWEEN TO_DATE('" + fromDateFilter
							+ "','DD-MM-YY') " + " AND TO_DATE('"
							+ toDateFilter + "','DD-MM-YY') ";
				}
				if (productFilter != null && !productFilter.equals("")) {
					query = query + " AND TXN.SUBPRODUCTCODE LIKE '%"
							+ productFilter + "%'";
				}
				if (referenceFilter != null && !referenceFilter.equals("")) {
					query = query + " AND TXN.TIREFERANCE LIKE '%"
							+ referenceFilter + "%'";
				}

				/* Dashboard changes 23012020 starts */
				if (solIdFilter != null && !solIdFilter.equals("")) {

					String[] solIdSplit = solIdFilter.split(",");
					String finalSolIdFilter = "";
					for (int solIdIndex = 0; solIdIndex < solIdSplit.length; solIdIndex++) {
						finalSolIdFilter = finalSolIdFilter + "'"
								+ solIdSplit[solIdIndex] + "'";
					}
					finalSolIdFilter = finalSolIdFilter.replace("''", "','");
					query = query + " AND TXN.SOLID IN (" + finalSolIdFilter
							+ ")";
				}

				if (customerNameFilter != null
						&& !customerNameFilter.equals("")) {
					query = query + " AND TXN.CUSTOMERNAME LIKE '%"
							+ customerNameFilter + "%'";
				}

				if (productCode.equals("ODC")) {
					if (mtReceived != null && !mtReceived.equals("")
							&& mtReceived.equals("Full Amount")) {
						query = query + " AND COLL.MTRECEIVED = 'Full Amount' ";
					} else {
						query = query
								+ " AND (COLL.MTRECEIVED <> 'Full Amount' OR COLL.MTRECEIVED IS NULL)";
					}
				}

				// if (productCode.equals("ODC")) {
				if (finSameDay != null && !finSameDay.equals("")
						&& finSameDay.equals("Yes")) {
					query = query + " AND COLL.FINSAMEDAY = 'Yes' ";
				} else {
					query = query
							+ " AND (COLL.FINSAMEDAY <> 'Yes' OR COLL.FINSAMEDAY IS NULL)";
				}
				// }

				if (productCode.equals("ODC")) {
					if (subProdCode != null && !subProdCode.equals("")
							&& subProdCode.equals("FBA")) {
						query = query + " AND COLL.SUBPRODUCT = 'FBA' ";
					} else {
						query = query
								+ " AND (COLL.SUBPRODUCT <> 'FBA' OR COLL.SUBPRODUCT IS NULL)";
					}
				}
				//pandi
				if (senderRefnoFilter != null && !senderRefnoFilter.equals("")) {
					query = query + " AND TEA.SENDERREFNO LIKE '%"
							+ senderRefnoFilter + "%'";
				}
				//pandi
				// ENDS
				query = query + " ORDER BY TXN.REQUESTID DESC ";
				System.out.println("GENERAL QUERY--->" + query);
				transactionList = aDBHelper
						.getTransactionListFromDBFilter(query);
			}

			
			if (userVo.getIsTiTransFlag().equalsIgnoreCase("N")
					&& (userVo.getProductCodeFilter().equalsIgnoreCase("ODC")
							||userVo.getProductCodeFilter().equalsIgnoreCase("ELC"))
					&& finSameDay != null && !finSameDay.equals("Yes")) {
				System.out.println("getIsTiTransFlag is N (if condition)==>");

				query = ActionConstants.GETTFBOTRANSLIST_TIREF_QUERY_MOD;
				if (requestId != null && !requestId.equals("")) {
					query = query + " AND TXN.REQUESTID LIKE '%" + requestId
							+ "%'";
				}
				if (productCode != null && !productCode.equals("")) {
					query = query + " AND TXN.PRODUCTCODE LIKE '%"
							+ productCode + "%'";
				}
				if (eventCode != null && !eventCode.equals("")) {
					query = query + " AND TXN.EVENTCODE LIKE '%" + eventCode
							+ "%'";
				}
				if ((stepFilter != null && !stepFilter.equals(""))
						&& statusFilter.equals("Branch Rejected")) {
					query = query + " AND TXN.STEP IN ('" + stepFilter + "','"
							+ stepFilterReject + "')";
				} else if (stepFilter != null && !stepFilter.equals("")) {
					query = query + " AND TXN.STEP LIKE '%" + stepFilter + "%'";
				}
				if (statusFilter != null && !statusFilter.equals("")) {
					query = query + " AND TXN.STEPSTATUS LIKE '%"
							+ statusFilter + "%'";
				}
				if (queriedFilter != null && !queriedFilter.equals("")) {
					query = query + " AND TXN.ISQUERIEDTRANS LIKE '%"
							+ queriedFilter + "%'";
				}
				if (fromDateFilter != null && !fromDateFilter.equals("")
						&& toDateFilter != null && !toDateFilter.equals("")) {
					query = query
							+ " AND TO_DATE(TRUNC(TXN.TRANS_CREATED),'DD-MM-YY') "
							+ " BETWEEN TO_DATE('" + fromDateFilter
							+ "','DD-MM-YY') " + " AND TO_DATE('"
							+ toDateFilter + "','DD-MM-YY') ";
				}
				if (productFilter != null && !productFilter.equals("")) {
					query = query + " AND TXN.SUBPRODUCTCODE LIKE '%"
							+ productFilter + "%'";
				}
				if (referenceFilter != null && !referenceFilter.equals("")) {
					query = query + " AND TXN.TIREFERANCE LIKE '%"
							+ referenceFilter + "%'";
				}

				/* Dashboard changes 23012020 starts */
				if (solIdFilter != null && !solIdFilter.equals("")) {

					String[] solIdSplit = solIdFilter.split(",");
					String finalSolIdFilter = "";
					for (int solIdIndex = 0; solIdIndex < solIdSplit.length; solIdIndex++) {
						finalSolIdFilter = finalSolIdFilter + "'"
								+ solIdSplit[solIdIndex] + "'";
					}
					finalSolIdFilter = finalSolIdFilter.replace("''", "','");
					query = query + " AND TXN.SOLID IN (" + finalSolIdFilter
							+ ")";
				}

				if (customerNameFilter != null
						&& !customerNameFilter.equals("")) {
					query = query + " AND TXN.CUSTOMERNAME LIKE '%"
							+ customerNameFilter + "%'";
				}


				if (productCode.equals("ODC")) {
					if (mtReceived != null && !mtReceived.equals("")
							&& mtReceived.equals("Full Amount")) {
						query = query + " AND COLL.MTRECEIVED = 'Full Amount' ";
					} else {
						query = query
								+ " AND (COLL.MTRECEIVED <> 'Full Amount' OR COLL.MTRECEIVED IS NULL)";
					}
				}

				// if (productCode.equals("ODC")) {
				if (finSameDay != null && !finSameDay.equals("")
						&& finSameDay.equals("Yes")) {
					query = query + " AND COLL.FINSAMEDAY = 'Yes' ";
				} else {
					query = query
							+ " AND (COLL.FINSAMEDAY <> 'Yes' OR COLL.FINSAMEDAY IS NULL)";
				}
				// }

				if (productCode.equals("ODC")) {
					if (subProdCode != null && !subProdCode.equals("")
							&& subProdCode.equals("FBA")) {
						query = query + " AND COLL.SUBPRODUCT = 'FBA' ";
					} else {
						query = query
								+ " AND (COLL.SUBPRODUCT <> 'FBA' OR COLL.SUBPRODUCT IS NULL)";
					}
				}
				
				//pandi
				if (senderRefnoFilter != null && !senderRefnoFilter.equals("")) {
					query = query + " AND TEA.SENDERREFNO LIKE '%"
							+ senderRefnoFilter + "%'";
				}
				//pandi

				// ENDS
				query = query + " ORDER BY TXN.REQUESTID DESC ";
				System.out.println("ELC 2 QUERY--test2->" + query);
				transactionList = aDBHelper
						.getTransactionListFromDBFilter(query);
			}
			
			
			if (userVo.getIsTiTransFlag().equalsIgnoreCase("Y")
					&& (userVo.getProductCodeFilter().equalsIgnoreCase("IDC") || userVo
							.getProductCodeFilter().equalsIgnoreCase("ODC"))
					&& finSameDay != null && !finSameDay.equals("Yes")) {
				if (directOption != null && directOption.trim().equals("Y")) {
					query = ActionConstants.idcDummyDirectDetail;

					if (productCode != null && !productCode.equals("")) {
						query = query + " AND TRIM(IDC.PRODUCTCODE) = '"
								+ productCode + "'";
					}
					
								
					if (statusFilter != null && !statusFilter.equals("")) {
						query = query + " AND (TRIM(IDC.STEPSTATUS) = '"
								+ statusFilter + "' OR (BEV.STEPPHASE  = '"+bevstepphase+ "') )";
					}
//					if (stepFilter != null && !stepFilter.equals("")) {
//						query = query + " AND TRIM(STEP.TYPE) <> '"
//								+ stepFilter + "'";
//					}
					if (directCompFlag != null && directCompFlag.equals("Y")) {
						query = query
								+ " AND BEV.REFNO_PFIX = 'CRE' AND NOT EXISTS (SELECT 'x' FROM BOBZONE.BASEEVENT bev1 WHERE BEV1.REFNO_PFIX = 'PAY' AND bev1.MASTER_KEY   = BEV.MASTER_KEY AND bev1.status IN ('i','c')) ";
					}

					if (directOption != null && !directOption.equals("")
							&& directOption.equals("Y")) {
						query = query + " AND COLL.DIRECT = 'true' ";
					} else {
						query = query
								+ " AND (COLL.DIRECT = 'false' OR COLL.DIRECT IS NULL) ";
					}

					if (productCode.equals("ODC")) {
						if (mtReceived != null && !mtReceived.equals("")
								&& mtReceived.equals("Full Amount")) {
							query = query
									+ " AND COLL.MTRECEIVED = 'Full Amount' ";
						} else {
							query = query
									+ " AND (COLL.MTRECEIVED <> 'Full Amount' OR COLL.MTRECEIVED IS NULL)";
						}
					}

					if (productCode.equals("ODC")) {
						if (finSameDay != null && !finSameDay.equals("")
								&& finSameDay.equals("Yes")) {
							query = query + " AND COLL.FINSAMEDAY = 'Yes' ";
						} else {
							query = query
									+ " AND (COLL.FINSAMEDAY <> 'Yes' OR COLL.FINSAMEDAY IS NULL)";
						}
					}

					/*
					 * if (productCode.equals("ODC")) { if (subProdCode != null
					 * && !subProdCode.equals("") && subProdCode.equals("FBA"))
					 * { query = query + " AND COLL.SUBPRODUCT = 'FBA' "; } else
					 * { query = query +
					 * " AND (COLL.SUBPRODUCT <> 'FBA' OR COLL.SUBPRODUCT IS NULL)"
					 * ; } }
					 */
					query = query + " ORDER BY COLL.REQUESTID DESC ";
					System.out.println("IDC Direct Query--->" + query);
					transactionList = aDBHelper
							.getTransactionListFromDBFilter(query);
				} else if ((directOption == null || directOption.trim().equals(
						"N"))
						&& subProdCode != null
						&& subProdCode.trim().equals("FBA")
						&& userVo.getProductCodeFilter()
								.equalsIgnoreCase("ODC")) {
					query = ActionConstants.idcDummyDirectDetail;

					if (productCode != null && !productCode.equals("")) {
						query = query + " AND TRIM(IDC.PRODUCTCODE) = '"
								+ productCode + "'";
					}
					if (statusFilter != null && !statusFilter.equals("")) {
						query = query + " AND (TRIM(IDC.STEPSTATUS) = '"
								+ statusFilter + "' OR (BEV.STEPPHASE  = '"+bevstepphase+ "') )";
					}
//					if (stepFilter != null && !stepFilter.equals("")) {
//						query = query + " AND TRIM(STEP.TYPE) <> '"
//								+ stepFilter + "'";
//					}
					if (directCompFlag != null && directCompFlag.equals("Y")) {
						query = query
								+ " AND BEV.REFNO_PFIX = 'CRE' AND NOT EXISTS (SELECT 'x' FROM BOBZONE.BASEEVENT bev1 WHERE BEV1.REFNO_PFIX = 'PAY' AND bev1.MASTER_KEY   = BEV.MASTER_KEY AND bev1.status IN ('i','c')) ";
					}
					if (directOption != null && !directOption.equals("")
							&& directOption.equals("Y")) {
						query = query + " AND COLL.DIRECT = 'true' ";
					} else {
						query = query
								+ " AND (COLL.DIRECT = 'false' OR COLL.DIRECT IS NULL) ";
					}
					query = query + " AND TRIM(COLL.SUBPRODUCT) = 'FBA'";
					query = query + " ORDER BY COLL.REQUESTID DESC ";
					System.out.println("ODC Direct Query--->" + query);
					transactionList = aDBHelper
							.getTransactionListFromDBFilter(query);
				}
			}

			/*
			 * if (userVo.getIsTiTransFlag().equalsIgnoreCase("Y") &&
			 * !userVo.getProductCodeFilter().equalsIgnoreCase("CPCI")) {
			 */

			/*
			 * if (userVo.getIsTiTransFlag().equalsIgnoreCase("Y") &&
			 * !userVo.getProductCodeFilter().equalsIgnoreCase("CPCI") &&
			 * !(directOption != null && directOption.trim() .equals("Y"))) {
			 */

			if (!subProdCode.trim().equals("FBA")
					&& userVo.getProductCodeFilter().equals("ODC")
					&& finSameDay != null && !finSameDay.equals("")
					&& finSameDay.equals("Yes")
					&& userVo.getIsTiTransFlag().equalsIgnoreCase("Y")) {

				query = ActionConstants.idcDummyDirectDetail;

				if (productCode != null && !productCode.equals("")) {
					query = query + " AND TRIM(PRD.CODE79) = '" + productCode
							+ "'";
				}
				if (statusFilter != null && !statusFilter.equals("")) {
					query = query + " AND (TRIM(IDC.STEPSTATUS) = '"
							+ statusFilter + "' OR (BEV.STEPPHASE  = '"+bevstepphase+ "') )";
				}
				if (stepFilter != null && !stepFilter.equals("")) {
					query = query + " AND TRIM(STEP.TYPE) <> '" + stepFilter
							+ "'";
				}
				if (directCompFlag != null && directCompFlag.equals("Y")) {
					query = query
							+ " AND BEV.REFNO_PFIX = 'CRE' AND NOT EXISTS (SELECT 'x' FROM BOBZONE.BASEEVENT bev1 WHERE BEV1.REFNO_PFIX = 'FEC' AND bev1.MASTER_KEY   = BEV.MASTER_KEY AND bev1.status IN ('i','c')) ";
				}

				// if (directOption != null && !directOption.equals("")
				// && directOption.equals("Y")) {
				// query = query + " AND COLL.DIRECT = 'true' ";
				// } else {
				// query = query
				// + " AND (COLL.DIRECT = 'false' OR COLL.DIRECT IS NULL) ";
				// }

				// if (productCode.equals("ODC")) {
				// if (mtReceived != null && !mtReceived.equals("")
				// && mtReceived.equals("Full Amount")) {
				// query = query
				// + " AND COLL.MTRECEIVED = 'Full Amount' ";
				// } else {
				// query = query
				// +
				// " AND (COLL.MTRECEIVED <> 'Full Amount' OR COLL.MTRECEIVED IS NULL)";
				// }
				// }

				if (productCode.equals("ODC")) {
					if (finSameDay != null && !finSameDay.equals("")
							&& finSameDay.equals("Yes")) {
						query = query + " AND COLL.FINSAMEDAY = 'Yes' ";
					} else {
						query = query
								+ " AND (COLL.FINSAMEDAY <> 'Yes' OR COLL.FINSAMEDAY IS NULL)";
					}
				}

				/*
				 * if (productCode.equals("ODC")) { if (subProdCode != null &&
				 * !subProdCode.equals("") && subProdCode.equals("FBA")) { query
				 * = query + " AND COLL.SUBPRODUCT = 'FBA' "; } else { query =
				 * query +
				 * " AND (COLL.SUBPRODUCT <> 'FBA' OR COLL.SUBPRODUCT IS NULL)"
				 * ; } }
				 */
				query = query + " ORDER BY COLL.REQUESTID DESC ";
				System.out.println("ODC Direct-N Query--->" + query);
				transactionList = aDBHelper
						.getTransactionListFromDBFilter(query);
			}

			if (userVo.getProductCodeFilter().equals("ELC")
					&& finSameDay != null && !finSameDay.equals("")
					&& finSameDay.equals("Yes")
					&& userVo.getIsTiTransFlag().equalsIgnoreCase("Y")) {

				query = ActionConstants.elcDummyDirectDetail;

				if (productCode != null && !productCode.equals("")) {
					query = query + " AND TRIM(PRD.CODE79) = '" + productCode
							+ "'";
				}
//				if (statusFilter != null && !statusFilter.equals("")) {
//					query = query + " AND TRIM(BEV.STATUS) = '" + statusFilter
//							+ "'";
//				}
				
				if (statusFilter != null && !statusFilter.equals("")) {
					query = query + " AND (TRIM(IDC.STEPSTATUS) = '"
							+ statusFilter + "' OR (BEV.STEPPHASE  = '"+bevstepphase+ "') )";
				}
				
				
				if (stepFilter != null && !stepFilter.equals("")) {
					query = query + " AND TRIM(STEP.TYPE) <> '" + stepFilter
							+ "'";
				}
				if (directCompFlag != null && directCompFlag.equals("Y")) {
					query = query
							+ "AND BEV.REFNO_PFIX  = 'DPR' AND NOT EXISTS (SELECT 'x' FROM LCPAYMENT LCM,BASEEVENT BEV1,DOCSPRE O WHERE BEV.KEY97  = LCM.OR_PAY_EV AND LCM.KEY97  =  BEV1.KEY97 AND BEV1.KEY97 = O.KEY97 AND BEV1.REFNO_PFIX = 'POD' AND O.PAYSTSCODE = 'FN')";
				}
				if (finSameDay != null && !finSameDay.equals("")
						&& finSameDay.equals("Yes")) {
					query = query + " AND COLL.FINSAMEDAY = 'Yes' ";
				} else {
					query = query
							+ " AND (COLL.FINSAMEDAY <> 'Yes' OR COLL.FINSAMEDAY IS NULL)";
				}

				/*
				 * if (productCode.equals("ODC")) { if (subProdCode != null &&
				 * !subProdCode.equals("") && subProdCode.equals("FBA")) { query
				 * = query + " AND COLL.SUBPRODUCT = 'FBA' "; } else { query =
				 * query +
				 * " AND (COLL.SUBPRODUCT <> 'FBA' OR COLL.SUBPRODUCT IS NULL)"
				 * ; } }
				 */
				query = query + " ORDER BY COLL.REQUESTID DESC ";
				System.out.println("ELC 1 Query--->" + query);
				transactionList = aDBHelper
						.getTransactionListFromDBFilter(query);
			}

			/*
			 * if (userVo.getIsTiTransFlag().equalsIgnoreCase("Y") &&
			 * !(userVo.getProductCodeFilter().equalsIgnoreCase("CPCI")) &&
			 * !(directOption != null && directOption.trim() .equals("Y")) &&
			 * !(subProdCode != null && subProdCode.trim() .equals("FBA"))) {
			 */

			if (userVo.getIsTiTransFlag().equalsIgnoreCase("Y")
					&& !(userVo.getProductCodeFilter().equalsIgnoreCase("CPCI"))
					&& !(directOption != null && directOption.trim()
							.equals("Y"))
					&& !(subProdCode != null && subProdCode.trim()
							.equals("FBA"))
					&& !(finSameDay != null && finSameDay.trim().equals("Yes"))) {

				System.out.println("getIsTiTransFlag is Y (if condition)==>");

				query = ActionConstants.GETTFBOTITRANSLIST_QUERY_MOD;
				if (requestId != null && !requestId.equals("")) {
					query = query + " AND TFB.REQUESTID LIKE '%" + requestId
							+ "%'";
				}
				if (productCode != null && !productCode.equals("")) {
					query = query + " AND TRIM(TFB.PRODUCTCODE) = '" + productCode
							+ "'";
				}
				if (eventCode != null && !eventCode.equals("")) {
					query = query + " AND TRIM(TFB.EVENTCODE) = '" + eventCode
							+ "'";
				}
				if (statusFilter != null && !statusFilter.equals("")) {
					query = query + " AND TRIM(TFB.STEPSTATUS) = '" + statusFilter + "'";
				}
//				if (statusFilter != null && !statusFilter.equals("")) {
//					query = query + " AND (TRIM(TFB.STEPSTATUS) = '"
//							+ statusFilter + "' OR (BEV.STEPPHASE  = '"+bevstepphase+ "') )";
//				}
//				if (stepFilter != null && !stepFilter.equals("")) {
//					query = query + " AND TRIM(TFB.STEP) <> '" + stepFilter
//							+ "'";
//				}
				if (queriedFilter != null && !queriedFilter.equals("")) {
					query = query + " AND TFB.ISQUERIEDTRANS LIKE '%"
							+ queriedFilter + "%'";
				}
				if (fromDateFilter != null && !fromDateFilter.equals("")
						&& toDateFilter != null && !toDateFilter.equals("")) {
					query = query
							+ " AND TO_DATE(TRUNC(TXN.TRANS_CREATED),'DD-MM-YY') "
							+ " BETWEEN TO_DATE('" + fromDateFilter
							+ "','DD-MM-YY') " + " AND TO_DATE('"
							+ toDateFilter + "','DD-MM-YY') ";
				}
				if (productFilter != null && !productFilter.equals("")) {
					query = query + " AND TFB.SUBPRODUCTCODE LIKE '%"
							+ productFilter + "%'";
				}
				if (referenceFilter != null && !referenceFilter.equals("")) {
					query = query + " AND TFB.TIREFERANCE LIKE '%"
							+ referenceFilter + "%'";
				}

				/* Dashboard changes 23012020 starts */
				if (solIdFilter != null && !solIdFilter.equals("")) {

					String[] solIdSplit = solIdFilter.split(",");
					String finalSolIdFilter = "";
					for (int solIdIndex = 0; solIdIndex < solIdSplit.length; solIdIndex++) {
						finalSolIdFilter = finalSolIdFilter + "'"
								+ solIdSplit[solIdIndex] + "'";
					}
					finalSolIdFilter = finalSolIdFilter.replace("''", "','");
					query = query + " AND TXN.SOLID IN (" + finalSolIdFilter
							+ ")";
				}

				if (customerNameFilter != null
						&& !customerNameFilter.equals("")) {
					query = query + " AND TXN.CUSTOMERNAME LIKE '%"
							+ customerNameFilter + "%'";
				}
				/* Dashboard changes 23012020 ends */

				/*
				 * // ADDED BY CHANDRU FOR FILTER if (productCode.equals("IDC"))
				 * { if (directOption != null && !directOption.equals("") &&
				 * directOption.equals("Y")) { query = query +
				 * " AND TFB.DIRECT = 'true' "; } else { query = query +
				 * " AND (TFB.DIRECT       = 'false' OR TFB.DIRECT IS NULL) "; }
				 * } // ENDS
				 */

				// ADDED BY CHANDRU FOR FILTER
				if (productCode.equals("IDC") || productCode.equals("ODC")) {
					if (directOption != null && !directOption.equals("")
							&& directOption.equals("Y")) {
						query = query + " AND COLL.DIRECT = 'true' ";
					} else {
						query = query
								+ " AND (COLL.DIRECT       = 'false' OR COLL.DIRECT IS NULL) ";
					}
				}

				if (productCode.equals("ELC")) {
					if (finSameDay != null && !finSameDay.equals("")
							&& finSameDay.equals("Yes")) {
						query = query + " AND COLL.FINSAMEDAY = 'Yes' ";
					} else {
						query = query
								+ " AND (COLL.FINSAMEDAY <> 'Yes' OR COLL.FINSAMEDAY IS NULL)";
					}

				}
				
				//pandi
				if (senderRefnoFilter != null && !senderRefnoFilter.equals("")) {
					query = query + " AND TEA.SENDERREFNO LIKE '%"
							+ senderRefnoFilter + "%'";
				}
				//pandi
				
				// ENDS
				query = query + " ORDER BY TFB.REQUESTID DESC ";
				System.out.println("WITHOUT CPCI QUERY--->" + query);
				transactionList = aDBHelper
						.getTransactionListFromDBFilter(query);
			}

			logger.info("Product code filter==>"
					+ userVo.getProductCodeFilter());
			if (userVo.getIsTiTransFlag().equalsIgnoreCase("Y")
					&& userVo.getProductCodeFilter().equalsIgnoreCase("CPCI")) {
				logger.info("Entering if condition in CPCI");
				query = ActionConstants.GETTFBOTITRANSLISTCPCI_QUERY_MOD;
				if (requestId != null && !requestId.equals("")) {
					query = query + " AND TFB.REQUESTID LIKE '%" + requestId
							+ "%'";
				}
				if (productCode != null && !productCode.equals("")) {
					query = query + " AND (TRIM(TFB.PRODUCTCODE) = '" + productCode
							+ "' OR TRIM(TFB.SUBPRODUCTCODE) LIKE ('IBP')) ";
				}
				if (eventCode != null && !eventCode.equals("")) {
					query = query + " AND TRIM(EVT.CODE79) = '" + eventCode
							+ "'";
				}
				if (statusFilter != null && !statusFilter.equals("")) {
					query = query + " AND TRIM(TFB.STEPSTATUS) = '" + statusFilter
							+ "'";
				}
//				if (stepFilter != null && !stepFilter.equals("")) {
//					query = query + " AND TRIM(STEP.TYPE) <> '" + stepFilter
//							+ "'";
//				}
				if (queriedFilter != null && !queriedFilter.equals("")) {
					query = query + " AND TFB.ISQUERIEDTRANS LIKE '%"
							+ queriedFilter + "%'";
				}
				if (fromDateFilter != null && !fromDateFilter.equals("")
						&& toDateFilter != null && !toDateFilter.equals("")) {
					query = query
							+ " AND TO_DATE(TRUNC(TXN.TRANS_CREATED),'DD-MM-YY') "
							+ " BETWEEN TO_DATE('" + fromDateFilter
							+ "','DD-MM-YY') " + " AND TO_DATE('"
							+ toDateFilter + "','DD-MM-YY') ";
				}
				if (productFilter != null && !productFilter.equals("")) {
					query = query + " AND TFB.SUBPRODUCTCODE LIKE '%"
							+ productFilter + "%'";
				}
				if (referenceFilter != null && !referenceFilter.equals("")) {
					query = query + " AND TFB.TIREFERANCE LIKE '%"
							+ referenceFilter + "%'";
				}

				/* Dashboard changes 23012020 starts */
				if (solIdFilter != null && !solIdFilter.equals("")) {

					String[] solIdSplit = solIdFilter.split(",");
					String finalSolIdFilter = "";
					for (int solIdIndex = 0; solIdIndex < solIdSplit.length; solIdIndex++) {
						finalSolIdFilter = finalSolIdFilter + "'"
								+ solIdSplit[solIdIndex] + "'";
					}
					finalSolIdFilter = finalSolIdFilter.replace("''", "','");
					query = query + " AND TXN.SOLID IN (" + finalSolIdFilter
							+ ")";
				}

				if (customerNameFilter != null
						&& !customerNameFilter.equals("")) {
					query = query + " AND TXN.CUSTOMERNAME LIKE '%"
							+ customerNameFilter + "%'";
				}
				/* Dashboard changes 23012020 ends */

				query = query + " ORDER BY TFB.REQUESTID DESC ";
				System.out.println("WITH CPCI QUERY--->" + query);
				transactionList = aDBHelper
						.getTransactionListFromDBFilter(query);
			}

			if (userVo.getIsTiTransFlag().equalsIgnoreCase("Y")
					&& userVo.getProductCodeFilter().equalsIgnoreCase("COR")) {
				logger.info("Entering if condition in CPCI");
				if (bevstepphase.equals("D")) {
					query = ActionConstants.GETTFBOTITRANSLISTCOR_QUERY_MOD_INP;
					stepFilter = "a1";
					statusFilter = "i";
				} else if (bevstepphase.equals("V")) {
					query = ActionConstants.GETTFBOTITRANSLISTCOR_QUERY_MOD_AUT;
					stepFilter = "i";
					statusFilter = "i";
				} else if (bevstepphase.equals("R")) {
					query = ActionConstants.GETTFBOTITRANSLISTCOR_QUERY_MOD_COMP;
					statusFilter = "c";
				}
				if (requestId != null && !requestId.equals("")) {
					query = query + " AND TFB.REQUESTID LIKE '%" + requestId
							+ "%'";
				}
				if (eventCode != null && !eventCode.equals("")) {
					query = query + " AND TRIM(TFB.EVENTCODE) = '" + eventCode
							+ "'";
				}
				if (statusFilter != null && !statusFilter.equals("")) {
					query = query + " AND TRIM(TFB.BEV_STATUS) = '"
							+ statusFilter + "'";
				}
				if (stepFilter != null && !stepFilter.equals("")) {
					query = query + " AND TRIM(TFB.STEP_TYPE) <> '"
							+ stepFilter + "'";
				}
				if (queriedFilter != null && !queriedFilter.equals("")) {
					query = query + " AND TFB.ISQUERIEDTRANS LIKE '%"
							+ queriedFilter + "%'";
				}
				if (fromDateFilter != null && !fromDateFilter.equals("")
						&& toDateFilter != null && !toDateFilter.equals("")) {
					query = query
							+ " AND TO_DATE(TRUNC(TFB.TRANS_CREATED),'DD-MM-YY') "
							+ " BETWEEN TO_DATE('" + fromDateFilter
							+ "','DD-MM-YY') " + " AND TO_DATE('"
							+ toDateFilter + "','DD-MM-YY') ";
				}
				if (productFilter != null && !productFilter.equals("")) {
					query = query + " AND TFB.SUBPRODUCTCODE LIKE '%"
							+ productFilter + "%'";
				}
				if (referenceFilter != null && !referenceFilter.equals("")) {
					query = query + " AND TFB.TIREFERANCE LIKE '%"
							+ referenceFilter + "%'";
				}

				/* Dashboard changes 23012020 starts */
				if (solIdFilter != null && !solIdFilter.equals("")) {

					String[] solIdSplit = solIdFilter.split(",");
					String finalSolIdFilter = "";
					for (int solIdIndex = 0; solIdIndex < solIdSplit.length; solIdIndex++) {
						finalSolIdFilter = finalSolIdFilter + "'"
								+ solIdSplit[solIdIndex] + "'";
					}
					finalSolIdFilter = finalSolIdFilter.replace("''", "','");
					query = query + " AND TFB.SOLID IN (" + finalSolIdFilter
							+ ")";
				}

				if (customerNameFilter != null
						&& !customerNameFilter.equals("")) {
					query = query + " AND TFB.CUSTOMERNAME LIKE '%"
							+ customerNameFilter + "%'";
				}
				/* Dashboard changes 23012020 ends */

				query = query + " ORDER BY TFB.REQUESTID DESC ";
				System.out.println("WITH CPCI QUERY--->" + query);
				transactionList = aDBHelper
						.getTransactionListFromDBFilter(query);
			}

			if (fromDateFlag.equals("Y"))
				userVo.setFromDateFilter("");
			if (toDateFlag.equals("Y"))
				userVo.setToDateFilter("");
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		return transactionList;
	}

	public List<TFBOTransVO> getTFBOTransListFromDBFilterForCount(
			UserTransactionVO userVo) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		DBHelper aDBHelper = new DBHelper();
		List<TFBOTransVO> transactionList = null;
		CommonMethods aCommonMethods = new CommonMethods();
		try {
			String productFilter = userVo.getSubProductFilter();
			if (aCommonMethods.isValueAvailable(productFilter)) {
				productFilter = getSubProductCodeFromDB(userVo
						.getSubProductFilter());
			}
			userVo.setIsTiTransFlag("");
			String statusFilter = userVo.getStatusFilter();
			String stepFilter = userVo.getStepFilter();
			String stepFilterReject = "";
			if (aCommonMethods.isValueAvailable(userVo.getStatusFilter())) {

				logger.info("Getting status filter in getTFBOTransListFromDBFilter==> "
						+ userVo.getStatusFilter());

				if (userVo.getStatusFilter().equalsIgnoreCase(
						"Transaction Pending for Entry in FBTI")) {
					stepFilter = "a1";
					statusFilter = "i";
					userVo.setIsTiTransFlag("Y");
				}

				if (userVo.getStatusFilter().equalsIgnoreCase(
						"Transaction Pending for Approval in FBTI")) {
					stepFilter = "i";
					statusFilter = "i";
					userVo.setIsTiTransFlag("Y");
				}

				if (userVo.getStatusFilter().equalsIgnoreCase(
						"Approved-Completed in FBTI")) {
					statusFilter = "c";
					userVo.setIsTiTransFlag("Y");
				}

				if (userVo.getStatusFilter().equalsIgnoreCase(
						"Transaction With Branch maker")) {
					stepFilter = "Branch maker";
					userVo.setIsTiTransFlag("N");
				}
				if (userVo.getStatusFilter().equalsIgnoreCase("FBO Rejected")) {
					stepFilter = "FBO Scrutinizer";
					userVo.setIsTiTransFlag("N");
				}
				if (userVo.getStatusFilter()
						.equalsIgnoreCase("Branch Rejected")) {
					stepFilter = "Branch checker";
					stepFilterReject = "Branch maker";
					userVo.setIsTiTransFlag("N");
				}
				if (userVo.getStatusFilter().equalsIgnoreCase(
						"Authrorize by Scrutinizer")) {
					stepFilter = "Release";
					userVo.setIsTiTransFlag("N");
				}
				if (userVo.getStatusFilter().equalsIgnoreCase(
						"Transaction With Branch checker")) {
					stepFilter = "Branch checker";
					userVo.setIsTiTransFlag("N");
				}
				if (userVo.getStatusFilter().equalsIgnoreCase(
						"Transaction With FBO Scrutinizer")) {
					stepFilter = "FBO Scrutinizer";
					userVo.setIsTiTransFlag("N");
				}

			}

			if (!aCommonMethods.isValueAvailable(userVo.getIsTiTransFlag()))
				userVo.setIsTiTransFlag("N");
			String fromDateFlag = "N";
			String toDateFlag = "N";
			String requestId = userVo.getRequestIdFilter();
			String productCode = userVo.getProductCodeFilter();
			String eventCode = userVo.getEventCodeFilter();

			String queriedFilter = userVo.getIsQueriedFilter();
			String fromDateFilter = userVo.getFromDateFilter();
			String toDateFilter = userVo.getToDateFilter();

			String referenceFilter = userVo.getTiReferenceFilter();
			String directOption = userVo.getDirectOption();

			String solIdFilter = userVo.getSolIdFilter();
			String customerNameFilter = userVo.getCustomerNameFilter();
			String idenOdcType = userVo.getIdenOdcType();
			String directCompFlag = userVo.getDirectCompFlag();
			String mtReceived = "";
			String finSameDay = "";
			String subProdCode = "";

			String query = "";

			if (aCommonMethods.isValueAvailable(idenOdcType)) {
				if (idenOdcType.trim().equals("MTF")) {
					mtReceived = "Full Amount";
					finSameDay = "";
				} else if (idenOdcType.trim().equals("MTPN")) {
					mtReceived = "Part Amount,None";
					finSameDay = "";
				} else if (idenOdcType.trim().equals("FINSY")) {
					mtReceived = "Part Amount,None";
					finSameDay = "Yes";
				} else if (idenOdcType.trim().equals("FINSN")) {
					mtReceived = "Part Amount,None";
					finSameDay = "No";
				} else if (idenOdcType.trim().equals("ODCIND")) {
					mtReceived = "";
					finSameDay = "";
				} else if (idenOdcType.trim().equals("ADV")) {
					mtReceived = "";
					finSameDay = "";
					subProdCode = "FBA";
				}
			}

			if (userVo.getIsTiTransFlag().equalsIgnoreCase("N")) {
				System.out.println("getIsTiTransFlag is N (if condition)==>");

				query = ActionConstants.GETTFBOTRANSLIST_TIREF_QUERY_MOD;
				if (requestId != null && !requestId.equals("")) {
					query = query + " AND TXN.REQUESTID = '" + requestId + "'";
				}
				if (productCode != null && !productCode.equals("")) {
					query = query + " AND TXN.PRODUCTCODE = '" + productCode
							+ "'";
				}
				if (eventCode != null && !eventCode.equals("")) {
					query = query + " AND TXN.EVENTCODE = '" + eventCode + "'";
				}
				if ((stepFilter != null && !stepFilter.equals(""))
						&& statusFilter.equals("Branch Rejected")) {
					query = query + " AND TXN.STEP IN ('" + stepFilter + "','"
							+ stepFilterReject + "')";
				} else if (stepFilter != null && !stepFilter.equals("")) {
					query = query + " AND TXN.STEP = '" + stepFilter + "'";
				}
				if (statusFilter != null && !statusFilter.equals("")) {
					query = query + " AND TXN.STEPSTATUS = '" + statusFilter
							+ "'";
				}
				if (queriedFilter != null && !queriedFilter.equals("")) {
					query = query + " AND TXN.ISQUERIEDTRANS = '"
							+ queriedFilter + "'";
				}
				if (fromDateFilter != null && !fromDateFilter.equals("")
						&& toDateFilter != null && !toDateFilter.equals("")) {
					query = query
							+ " AND TO_DATE(TRUNC(TXN.TRANS_CREATED),'DD-MM-YY') "
							+ " BETWEEN TO_DATE('" + fromDateFilter
							+ "','DD-MM-YY') " + " AND TO_DATE('"
							+ toDateFilter + "','DD-MM-YY') ";
				}
				if (productFilter != null && !productFilter.equals("")) {
					query = query + " AND TXN.SUBPRODUCTCODE = '"
							+ productFilter + "'";
				}
				if (referenceFilter != null && !referenceFilter.equals("")) {
					query = query + " AND TXN.TIREFERANCE = '"
							+ referenceFilter + "'";
				}

				if (solIdFilter != null && !solIdFilter.equals("")) {

					String[] solIdSplit = solIdFilter.split(",");
					String finalSolIdFilter = "";
					for (int solIdIndex = 0; solIdIndex < solIdSplit.length; solIdIndex++) {
						finalSolIdFilter = finalSolIdFilter + "'"
								+ solIdSplit[solIdIndex] + "'";
					}
					finalSolIdFilter = finalSolIdFilter.replace("''", "','");
					query = query + " AND TXN.SOLID IN (" + finalSolIdFilter
							+ ")";
				}

				if (customerNameFilter != null
						&& !customerNameFilter.equals("")) {
					query = query + " AND TXN.CUSTOMERNAME = '"
							+ customerNameFilter + "'";
				}
				if (productCode.equals("IDC") || productCode.equals("ODC")) {
					if (directOption != null && !directOption.equals("")
							&& directOption.equals("Y")) {
						query = query + " AND COLL.DIRECT = 'true' ";
					} else {
						query = query
								+ " AND (COLL.DIRECT = 'false' OR COLL.DIRECT IS NULL) ";
					}
				}

				if (productCode.equals("ODC")) {
					if (mtReceived != null && !mtReceived.equals("")
							&& mtReceived.equals("Full Amount")) {
						query = query + " AND COLL.MTRECEIVED = 'Full Amount' ";
					} else {
						query = query
								+ " AND (COLL.MTRECEIVED <> 'Full Amount' OR COLL.MTRECEIVED IS NULL)";
					}
				}

				if (productCode.equals("ODC")) {
					if (finSameDay != null && !finSameDay.equals("")
							&& finSameDay.equals("Yes")) {
						query = query + " AND COLL.FINSAMEDAY = 'Yes' ";
					} else {
						query = query
								+ " AND (COLL.FINSAMEDAY <> 'Yes' OR COLL.FINSAMEDAY IS NULL)";
					}
				}

				if (productCode.equals("ODC")) {
					if (subProdCode != null && !subProdCode.equals("")
							&& subProdCode.equals("FBA")) {
						query = query + " AND COLL.SUBPRODUCT = 'FBA' ";
					} else {
						query = query
								+ " AND (COLL.SUBPRODUCT <> 'FBA' OR COLL.SUBPRODUCT IS NULL)";
					}
				}
				query = query + " ORDER BY TXN.REQUESTID DESC ";
				System.out.println("GENERAL QUERY--->" + query);
				transactionList = aDBHelper
						.getTransactionListFromDBFilter(query);
			}

			if (userVo.getIsTiTransFlag().equalsIgnoreCase("N")
					&& userVo.getProductCodeFilter().equalsIgnoreCase("ODC")
					&& finSameDay != null && finSameDay.equals("Yes")) {
				System.out.println("getIsTiTransFlag is N (if condition)==>");

				query = ActionConstants.GETTFBOTRANSLIST_TIREF_QUERY_MOD;
				if (requestId != null && !requestId.equals("")) {
					query = query + " AND TXN.REQUESTID = '" + requestId + "'";
				}
				if (productCode != null && !productCode.equals("")) {
					query = query + " AND TXN.PRODUCTCODE = '" + productCode
							+ "'";
				}
				if (eventCode != null && !eventCode.equals("")) {
					query = query + " AND TXN.EVENTCODE = '" + eventCode + "'";
				}
				if ((stepFilter != null && !stepFilter.equals(""))
						&& statusFilter.equals("Branch Rejected")) {
					query = query + " AND TXN.STEP IN ('" + stepFilter + "','"
							+ stepFilterReject + "')";
				} else if (stepFilter != null && !stepFilter.equals("")) {
					query = query + " AND TXN.STEP = '" + stepFilter + "'";
				}
				if (statusFilter != null && !statusFilter.equals("")) {
					query = query + " AND TXN.STEPSTATUS = '" + statusFilter
							+ "'";
				}
				if (queriedFilter != null && !queriedFilter.equals("")) {
					query = query + " AND TXN.ISQUERIEDTRANS = '"
							+ queriedFilter + "'";
				}
				if (fromDateFilter != null && !fromDateFilter.equals("")
						&& toDateFilter != null && !toDateFilter.equals("")) {
					query = query
							+ " AND TO_DATE(TRUNC(TXN.TRANS_CREATED),'DD-MM-YY') "
							+ " BETWEEN TO_DATE('" + fromDateFilter
							+ "','DD-MM-YY') " + " AND TO_DATE('"
							+ toDateFilter + "','DD-MM-YY') ";
				}
				if (productFilter != null && !productFilter.equals("")) {
					query = query + " AND TXN.SUBPRODUCTCODE = '"
							+ productFilter + "'";
				}
				if (referenceFilter != null && !referenceFilter.equals("")) {
					query = query + " AND TXN.TIREFERANCE = '"
							+ referenceFilter + "'";
				}

				if (solIdFilter != null && !solIdFilter.equals("")) {

					String[] solIdSplit = solIdFilter.split(",");
					String finalSolIdFilter = "";
					for (int solIdIndex = 0; solIdIndex < solIdSplit.length; solIdIndex++) {
						finalSolIdFilter = finalSolIdFilter + "'"
								+ solIdSplit[solIdIndex] + "'";
					}
					finalSolIdFilter = finalSolIdFilter.replace("''", "','");
					query = query + " AND TXN.SOLID IN (" + finalSolIdFilter
							+ ")";
				}

				if (customerNameFilter != null
						&& !customerNameFilter.equals("")) {
					query = query + " AND TXN.CUSTOMERNAME = '"
							+ customerNameFilter + "'";
				}

				if (productCode.equals("ODC")) {
					if (mtReceived != null && !mtReceived.equals("")
							&& mtReceived.equals("Full Amount")) {
						query = query + " AND COLL.MTRECEIVED = 'Full Amount' ";
					} else {
						query = query
								+ " AND (COLL.MTRECEIVED <> 'Full Amount' OR COLL.MTRECEIVED IS NULL)";
					}
				}

				if (productCode.equals("ODC")) {
					if (finSameDay != null && !finSameDay.equals("")
							&& finSameDay.equals("Yes")) {
						query = query + " AND COLL.FINSAMEDAY = 'Yes' ";
					} else {
						query = query
								+ " AND (COLL.FINSAMEDAY <> 'Yes' OR COLL.FINSAMEDAY IS NULL)";
					}
				}

				if (productCode.equals("ODC")) {
					if (subProdCode != null && !subProdCode.equals("")
							&& subProdCode.equals("FBA")) {
						query = query + " AND COLL.SUBPRODUCT = 'FBA' ";
					} else {
						query = query
								+ " AND (COLL.SUBPRODUCT <> 'FBA' OR COLL.SUBPRODUCT IS NULL)";
					}
				}

				query = query + " ORDER BY TXN.REQUESTID DESC ";
				System.out.println("GENERAL QUERY1--->" + query);
				transactionList = aDBHelper
						.getTransactionListFromDBFilter(query);
			}

			if (userVo.getIsTiTransFlag().equalsIgnoreCase("Y")
					&& (userVo.getProductCodeFilter().equalsIgnoreCase("IDC") || userVo
							.getProductCodeFilter().equalsIgnoreCase("ODC"))
					&& finSameDay != null && !finSameDay.equals("Yes")) {
				if (directOption != null && directOption.trim().equals("Y")) {
					query = ActionConstants.idcDummyDirectDetail;

					if (productCode != null && !productCode.equals("")) {
						query = query + " AND TRIM(PRD.CODE79) = '"
								+ productCode + "'";
					}
					if (statusFilter != null && !statusFilter.equals("")) {
						query = query + " AND TRIM(BEV.STATUS) = '"
								+ statusFilter + "'";
					}
					if (stepFilter != null && !stepFilter.equals("")) {
						query = query + " AND TRIM(STEP.TYPE) <> '"
								+ stepFilter + "'";
					}
					if (directCompFlag != null && directCompFlag.equals("Y")) {
						query = query
								+ " AND BEV.REFNO_PFIX = 'CRE' AND NOT EXISTS (SELECT 'x' FROM BOBZONE.BASEEVENT bev1 WHERE BEV1.REFNO_PFIX = 'PAY' AND bev1.MASTER_KEY   = BEV.MASTER_KEY AND bev1.status IN ('i','c')) ";
					}

					if (directOption != null && !directOption.equals("")
							&& directOption.equals("Y")) {
						query = query + " AND COLL.DIRECT = 'true' ";
					} else {
						query = query
								+ " AND (COLL.DIRECT = 'false' OR COLL.DIRECT IS NULL) ";
					}

					if (productCode.equals("ODC")) {
						if (mtReceived != null && !mtReceived.equals("")
								&& mtReceived.equals("Full Amount")) {
							query = query
									+ " AND COLL.MTRECEIVED = 'Full Amount' ";
						} else {
							query = query
									+ " AND (COLL.MTRECEIVED <> 'Full Amount' OR COLL.MTRECEIVED IS NULL)";
						}
					}

					if (productCode.equals("ODC")) {
						if (finSameDay != null && !finSameDay.equals("")
								&& finSameDay.equals("Yes")) {
							query = query + " AND COLL.FINSAMEDAY = 'Yes' ";
						} else {
							query = query
									+ " AND (COLL.FINSAMEDAY <> 'Yes' OR COLL.FINSAMEDAY IS NULL)";
						}
					}

					System.out.println("IDC Direct Query--->" + query);
					transactionList = aDBHelper
							.getTransactionListFromDBFilter(query);
				} else if ((directOption == null || directOption.trim().equals(
						"N"))
						&& subProdCode != null
						&& subProdCode.trim().equals("FBA")
						&& userVo.getProductCodeFilter()
								.equalsIgnoreCase("ODC")) {
					query = ActionConstants.idcDummyDirectDetail;

					if (productCode != null && !productCode.equals("")) {
						query = query + " AND TRIM(PRD.CODE79) = '"
								+ productCode + "'";
					}
					if (statusFilter != null && !statusFilter.equals("")) {
						query = query + " AND TRIM(BEV.STATUS) = '"
								+ statusFilter + "'";
					}
					if (stepFilter != null && !stepFilter.equals("")) {
						query = query + " AND TRIM(STEP.TYPE) <> '"
								+ stepFilter + "'";
					}
					if (directCompFlag != null && directCompFlag.equals("Y")) {
						query = query
								+ " AND BEV.REFNO_PFIX = 'CRE' AND NOT EXISTS (SELECT 'x' FROM BOBZONE.BASEEVENT bev1 WHERE BEV1.REFNO_PFIX = 'PAY' AND bev1.MASTER_KEY   = BEV.MASTER_KEY AND bev1.status IN ('i','c')) ";
					}
					if (directOption != null && !directOption.equals("")
							&& directOption.equals("Y")) {
						query = query + " AND COLL.DIRECT = 'true' ";
					} else {
						query = query
								+ " AND (COLL.DIRECT = 'false' OR COLL.DIRECT IS NULL) ";
					}
					query = query + " AND TRIM(COLL.SUBPRODUCT) = 'FBA'";
					System.out.println("ODC Direct Query--->" + query);
					transactionList = aDBHelper
							.getTransactionListFromDBFilter(query);
				}
			}
			if (!subProdCode.trim().equals("FBA")
					&& userVo.getProductCodeFilter().equals("ODC")
					&& finSameDay != null && !finSameDay.equals("")
					&& finSameDay.equals("Yes")
					&& userVo.getIsTiTransFlag().equalsIgnoreCase("Y")) {

				query = ActionConstants.idcDummyDirectDetail;

				if (productCode != null && !productCode.equals("")) {
					query = query + " AND TRIM(PRD.CODE79) = '" + productCode
							+ "'";
				}
				if (statusFilter != null && !statusFilter.equals("")) {
					query = query + " AND TRIM(IDC.STEPSTATUS) = '" + statusFilter
							+ "'";
				}
				if (stepFilter != null && !stepFilter.equals("")) {
					query = query + " AND TRIM(STEP.TYPE) <> '" + stepFilter
							+ "'";
				}
				if (directCompFlag != null && directCompFlag.equals("Y")) {
					query = query
							+ " AND BEV.REFNO_PFIX = 'CRE' AND NOT EXISTS (SELECT 'x' FROM BOBZONE.BASEEVENT bev1 WHERE BEV1.REFNO_PFIX = 'PAY' AND bev1.MASTER_KEY   = BEV.MASTER_KEY AND bev1.status IN ('i','c')) ";
				}

				if (productCode.equals("ODC")) {
					if (finSameDay != null && !finSameDay.equals("")
							&& finSameDay.equals("Yes")) {
						query = query + " AND COLL.FINSAMEDAY = 'Yes' ";
					} else {
						query = query
								+ " AND (COLL.FINSAMEDAY <> 'Yes' OR COLL.FINSAMEDAY IS NULL)";
					}
				}
				System.out.println("ODC Direct-N Query--->" + query);
				transactionList = aDBHelper
						.getTransactionListFromDBFilter(query);
			}

			if (userVo.getIsTiTransFlag().equalsIgnoreCase("Y")
					&& !(userVo.getProductCodeFilter().equalsIgnoreCase("CPCI"))
					&& !(directOption != null && directOption.trim()
							.equals("Y"))
					&& !(subProdCode != null && subProdCode.trim()
							.equals("FBA"))
					&& !(finSameDay != null && finSameDay.trim().equals("Yes"))) {

				System.out.println("getIsTiTransFlag is Y (if condition)==>");

				query = ActionConstants.GETTFBOTITRANSLIST_QUERY_MOD;
				if (requestId != null && !requestId.equals("")) {
					query = query + " AND TFB.REQUESTID = '" + requestId + "'";
				}
				if (productCode != null && !productCode.equals("")) {
					query = query + " AND TRIM(TFB.PRODUCTCODE) = '" + productCode
							+ "'";
				}
				if (eventCode != null && !eventCode.equals("")) {
					query = query + " AND TRIM(TFB.EVENTCODE) = '" + eventCode
							+ "'";
				}
				if (statusFilter != null && !statusFilter.equals("")) {
					query = query + " AND TRIM(TFB.STEPSTATUS) = '" + statusFilter
							+ "'";
				}
				if (stepFilter != null && !stepFilter.equals("")) {
					query = query + " AND TRIM(TFB.STEP) = '" + stepFilter
							+ "'";
				}
				if (queriedFilter != null && !queriedFilter.equals("")) {
					query = query + " AND TFB.ISQUERIEDTRANS = '"
							+ queriedFilter + "'";
				}
				if (fromDateFilter != null && !fromDateFilter.equals("")
						&& toDateFilter != null && !toDateFilter.equals("")) {
					query = query
							+ " AND TO_DATE(TRUNC(TXN.TRANS_CREATED),'DD-MM-YY') "
							+ " BETWEEN TO_DATE('" + fromDateFilter
							+ "','DD-MM-YY') " + " AND TO_DATE('"
							+ toDateFilter + "','DD-MM-YY') ";
				}
				if (productFilter != null && !productFilter.equals("")) {
					query = query + " AND TFB.SUBPRODUCTCODE = '"
							+ productFilter + "'";
				}
				if (referenceFilter != null && !referenceFilter.equals("")) {
					query = query + " AND TFB.TIREFERANCE = '"
							+ referenceFilter + "'";
				}
				if (solIdFilter != null && !solIdFilter.equals("")) {

					String[] solIdSplit = solIdFilter.split(",");
					String finalSolIdFilter = "";
					for (int solIdIndex = 0; solIdIndex < solIdSplit.length; solIdIndex++) {
						finalSolIdFilter = finalSolIdFilter + "'"
								+ solIdSplit[solIdIndex] + "'";
					}
					finalSolIdFilter = finalSolIdFilter.replace("''", "','");
					query = query + " AND TXN.SOLID IN (" + finalSolIdFilter
							+ ")";
				}

				if (customerNameFilter != null
						&& !customerNameFilter.equals("")) {
					query = query + " AND TXN.CUSTOMERNAME = '"
							+ customerNameFilter + "'";
				}
				if (productCode.equals("IDC") || productCode.equals("ODC")) {
					if (directOption != null && !directOption.equals("")
							&& directOption.equals("Y")) {
						query = query + " AND COLL.DIRECT = 'true' ";
					} else {
						query = query
								+ " AND (COLL.DIRECT       = 'false' OR COLL.DIRECT IS NULL) ";
					}
				}

				query = query + " ORDER BY TFB.REQUESTID DESC ";
				System.out.println("WITHOUT CPCI QUERY--->" + query);
				transactionList = aDBHelper
						.getTransactionListFromDBFilter(query);

			}

			logger.info("Product code filter==>"
					+ userVo.getProductCodeFilter());
			if (userVo.getIsTiTransFlag().equalsIgnoreCase("Y")
					&& userVo.getProductCodeFilter().equalsIgnoreCase("CPCI")) {
				logger.info("Entering if condition in CPCI");
				query = ActionConstants.GETTFBOTITRANSLISTCPCI_QUERY_MOD;
				if (requestId != null && !requestId.equals("")) {
					query = query + " AND TFB.REQUESTID = '" + requestId + "'";
				}
				if (productCode != null && !productCode.equals("")) {
					query = query + " AND (TRIM(TFB.PRODUCTCODE) = '" + productCode
							+ "' OR TRIM(TFB.SUBPRODUCTCODE) = ('IBP')) ";
				}
				if (eventCode != null && !eventCode.equals("")) {
					query = query + " AND TRIM(TFB.EVENTCODE) = '" + eventCode
							+ "'";
				}
				if (statusFilter != null && !statusFilter.equals("")) {
					query = query + " AND TRIM(TFB.STEPSTATUS) = '" + statusFilter
							+ "'";
				}
				if (stepFilter != null && !stepFilter.equals("")) {
					query = query + " AND TRIM(TFB.STEP) = '" + stepFilter
							+ "'";
				}
				if (queriedFilter != null && !queriedFilter.equals("")) {
					query = query + " AND TFB.ISQUERIEDTRANS = '"
							+ queriedFilter + "'";
				}
				if (fromDateFilter != null && !fromDateFilter.equals("")
						&& toDateFilter != null && !toDateFilter.equals("")) {
					query = query
							+ " AND TO_DATE(TRUNC(TXN.TRANS_CREATED),'DD-MM-YY') "
							+ " BETWEEN TO_DATE('" + fromDateFilter
							+ "','DD-MM-YY') " + " AND TO_DATE('"
							+ toDateFilter + "','DD-MM-YY') ";
				}
				if (productFilter != null && !productFilter.equals("")) {
					query = query + " AND TFB.SUBPRODUCTCODE = '"
							+ productFilter + "'";
				}
				if (referenceFilter != null && !referenceFilter.equals("")) {
					query = query + " AND TFB.TIREFERANCE = '"
							+ referenceFilter + "'";
				}

				if (solIdFilter != null && !solIdFilter.equals("")) {

					String[] solIdSplit = solIdFilter.split(",");
					String finalSolIdFilter = "";
					for (int solIdIndex = 0; solIdIndex < solIdSplit.length; solIdIndex++) {
						finalSolIdFilter = finalSolIdFilter + "'"
								+ solIdSplit[solIdIndex] + "'";
					}
					finalSolIdFilter = finalSolIdFilter.replace("''", "','");
					query = query + " AND TXN.SOLID IN (" + finalSolIdFilter
							+ ")";
				}

				if (customerNameFilter != null
						&& !customerNameFilter.equals("")) {
					query = query + " AND TXN.CUSTOMERNAME = '"
							+ customerNameFilter + "'";
				}

				query = query + " ORDER BY TFB.REQUESTID DESC ";
				System.out.println("WITH CPCI QUERY--->" + query);
				transactionList = aDBHelper
						.getTransactionListFromDBFilter(query);
			}

			if (userVo.getIsTiTransFlag().equalsIgnoreCase("Y")
					&& userVo.getProductCodeFilter().equalsIgnoreCase("COR")) {
				logger.info("Entering if condition in CPCI");
				if (statusFilter.equals("i") && stepFilter.equals("a1")) {
					query = ActionConstants.GETTFBOTITRANSLISTCOR_QUERY_MOD_INP;
				} else if (statusFilter.equals("i") && stepFilter.equals("i")) {
					query = ActionConstants.GETTFBOTITRANSLISTCOR_QUERY_MOD_AUT;
				} else if (statusFilter.equals("c")) {
					query = ActionConstants.GETTFBOTITRANSLISTCOR_QUERY_MOD_COMP;
				}
				if (requestId != null && !requestId.equals("")) {
					query = query + " AND TFB.REQUESTID = '" + requestId + "%'";
				}
				if (eventCode != null && !eventCode.equals("")) {
					query = query + " AND TRIM(TFB.EVENTCODE) = '" + eventCode
							+ "'";
				}
				if (statusFilter != null && !statusFilter.equals("")) {
					query = query + " AND TRIM(TFB.BEV_STATUS) = '"
							+ statusFilter + "'";
				}
				if (stepFilter != null && !stepFilter.equals("")) {
					query = query + " AND TRIM(TFB.STEP_TYPE) <> '"
							+ stepFilter + "'";
				}
				if (queriedFilter != null && !queriedFilter.equals("")) {
					query = query + " AND TFB.ISQUERIEDTRANS = '"
							+ queriedFilter + "'";
				}
				if (fromDateFilter != null && !fromDateFilter.equals("")
						&& toDateFilter != null && !toDateFilter.equals("")) {
					query = query
							+ " AND TO_DATE(TRUNC(TFB.TRANS_CREATED),'DD-MM-YY') "
							+ " BETWEEN TO_DATE('" + fromDateFilter
							+ "','DD-MM-YY') " + " AND TO_DATE('"
							+ toDateFilter + "','DD-MM-YY') ";
				}
				if (productFilter != null && !productFilter.equals("")) {
					query = query + " AND TFB.SUBPRODUCTCODE = '"
							+ productFilter + "'";
				}
				if (referenceFilter != null && !referenceFilter.equals("")) {
					query = query + " AND TFB.TIREFERANCE = '"
							+ referenceFilter + "'";
				}

				if (solIdFilter != null && !solIdFilter.equals("")) {

					String[] solIdSplit = solIdFilter.split(",");
					String finalSolIdFilter = "";
					for (int solIdIndex = 0; solIdIndex < solIdSplit.length; solIdIndex++) {
						finalSolIdFilter = finalSolIdFilter + "'"
								+ solIdSplit[solIdIndex] + "'";
					}
					finalSolIdFilter = finalSolIdFilter.replace("''", "','");
					query = query + " AND TFB.SOLID IN (" + finalSolIdFilter
							+ ")";
				}

				if (customerNameFilter != null
						&& !customerNameFilter.equals("")) {
					query = query + " AND TFB.CUSTOMERNAME = '"
							+ customerNameFilter + "'";
				}

				query = query + " ORDER BY TFB.REQUESTID DESC ";
				System.out.println("WITH CPCI QUERY1--->" + query);
				transactionList = aDBHelper
						.getTransactionListFromDBFilter(query);
			}

			if (fromDateFlag.equals("Y"))
				userVo.setFromDateFilter("");
			if (toDateFlag.equals("Y"))
				userVo.setToDateFilter("");
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		logger.info(ActionConstants.EXITING_METHOD + "transactionList size-->"
				+ transactionList.size());
		return transactionList;
	}

	private void updateTFBOIdcCco(String tiReferanceNo, String solID,
			String customeCif, String customeName, String amount,
			String currency, String userRemark, String requestId)
			throws Exception {
		System.out.println(ActionConstants.ENTERING_METHOD);
		DBHelper aDBHelper = new DBHelper();
		aDBHelper.setValueInDB(tiReferanceNo, requestId,
				ActionConstants.GETUPDATETIREFERANCE_QUERY);
		aDBHelper.setValueInDB(solID, customeCif, customeName, amount,
				currency, userRemark, requestId,
				ActionConstants.GETUPDATEIDCCCO_QUERY);

	}

	/*
	 * private void updateTFBOOdcCco(String tiReferanceNo, String solID, String
	 * customeCif, String customeName, String amount, String currency, String
	 * userRemark, String requestId) throws Exception {
	 * System.out.println(ActionConstants.ENTERING_METHOD); DBHelper aDBHelper =
	 * new DBHelper(); aDBHelper.setValueInDB(tiReferanceNo, requestId,
	 * ActionConstants.GETUPDATETIREFERANCE_QUERY);
	 * aDBHelper.setValueInDB(solID, customeCif, customeName, amount, currency,
	 * userRemark, requestId, ActionConstants.GETUPDATEODCCCO_QUERY);
	 * 
	 * }
	 */
	private void updateTFBOOdcCco(String tiReferanceNo, String solID,
			String customeCif, String customeName, String amount,
			String currency, String userRemark, String requestId)
			throws Exception {
		System.out.println(ActionConstants.ENTERING_METHOD);
		DBHelper aDBHelper = new DBHelper();
		aDBHelper.setValueInDB(tiReferanceNo, requestId,
				ActionConstants.GETUPDATETIREFERANCE_QUERY);
		aDBHelper.setValueInDB(solID, customeCif, customeName, amount,
				currency, userRemark, requestId,
				ActionConstants.GETUPDATEODCCCO_QUERY);

	}

	/*
	 * private void updateTFBOFocPsa1(String tiReferanceNo, String solID, String
	 * customeCif, String customeName, String amount, String currency, String
	 * userRemark, String requestId) throws Exception {
	 * System.out.println(ActionConstants.ENTERING_METHOD); DBHelper aDBHelper =
	 * new DBHelper(); aDBHelper.setValueInDB(tiReferanceNo, requestId,
	 * ActionConstants.GETUPDATETIREFERANCE_QUERY);
	 * aDBHelper.setValueInDB(solID, customeCif, customeName, amount, currency,
	 * userRemark, requestId, ActionConstants.GETUPDATEFOCPSA1_QUERY);
	 * 
	 * }
	 */
	private void updateTFBOFocPsa1(String tiReferanceNo, String solID,
			String customeCif, String customeName, String amount,
			String currency, String userRemark, String requestId)
			throws Exception {
		System.out.println(ActionConstants.ENTERING_METHOD);
		DBHelper aDBHelper = new DBHelper();
		aDBHelper.setValueInDB(tiReferanceNo, requestId,
				ActionConstants.GETUPDATETIREFERANCE_QUERY);
		aDBHelper.setValueInDB(solID, customeCif, customeName, amount,
				currency, userRemark, requestId,
				ActionConstants.GETUPDATEFOCPSA1_QUERY);

	}

	/*
	 * private void updateTFBOFelPSA4(String tiReferanceNo, String solID, String
	 * customeCif, String customeName, String amount, String currency, String
	 * lcType, String userRemark, String requestId) throws Exception {
	 * System.out.println(ActionConstants.ENTERING_METHOD); DBHelper aDBHelper =
	 * new DBHelper(); aDBHelper.setValueInDB(tiReferanceNo, requestId,
	 * ActionConstants.GETUPDATETIREFERANCE_QUERY);
	 * aDBHelper.setValueInLILCCOIDB(solID, customeCif, customeName, amount,
	 * currency, lcType, userRemark, requestId,
	 * ActionConstants.GETUPDATETFBOFELPSA4_QUERY); }
	 */
	private void updateTFBOFelPSA4(String lcRefNum, String solID,
			String customeCif, String customeName, String amount,
			String currency, String lcType, String userRemark, String requestId)
			throws Exception {
		System.out.println(ActionConstants.ENTERING_METHOD);
		DBHelper aDBHelper = new DBHelper();
		aDBHelper.setValueInDB(lcRefNum, requestId,
				ActionConstants.GETUPDATETIREFERANCE_QUERY);
		aDBHelper.setValueInLILCCOIDB(solID, customeCif, customeName, amount,
				currency, lcType, userRemark, requestId,
				ActionConstants.GETUPDATETFBOFELPSA4_QUERY);
	}

	// karthik 13012020 ends

	// Miscellanous changes starts 08-01-2020
	public void updateTFBOMiscellanousCreate(String requestId, String solId,
			String customerCif, String amount, String currency,
			String rateTaken, String token, String rateK, String rate,
			String subproductType, String odiSubProductType,
			String tireference, String remarks, String masReferanceNo)
			throws Exception {

		logger.info(ActionConstants.ENTERING_METHOD
				+ " <<updateTFBOMiscellanousCreate");

		DBHelper aDBHelper = new DBHelper();
		CommonMethods aCommonMethods = new CommonMethods();

		if (aCommonMethods.isValueAvailable(rateTaken)) {

			if (rateTaken.trim().equals("true")) {
				rateTaken = "Yes";
			} else {
				rateTaken = "No";
				token = "";
				rate = "";
				rateK = "";
			}
		}

		/*
		 * aDBHelper.setValueMiscellanousInDB(solId, customerCif, amount,
		 * currency, rateTaken, token, rateK, rate, subproductType,
		 * odiSubProductType, tireference, remarks, masReferanceNo, requestId,
		 * ActionConstants.GETUPDATETFBOMISCELLANOUSCREATENEW_QUERY);
		 */
		aDBHelper.setValueMiscellanousInDB(solId, customerCif, amount,
				currency, rateTaken, token, rateK, rate, subproductType,
				odiSubProductType, remarks, masReferanceNo, requestId,
				ActionConstants.GETUPDATETFBOMISCELLANOUSCREATENEW_QUERY);

		logger.info(ActionConstants.EXITING_METHOD
				+ " <<updateTFBOMiscellanousCreate");
	}

	public void updateTFBOMISCTiRefInTransTable(String tireference,
			String requestId) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD
				+ "<<updateTFBOMISCTiRefInTransTable");
		DBHelper aDBHelper = new DBHelper();
		aDBHelper.setValueInDB(tireference, requestId,
				ActionConstants.UPDATETFBOMASTERREF);
		logger.info(ActionConstants.EXITING_METHOD
				+ "<<updateTFBOMISCTiRefInTransTable");
	}

	// Miscellanous changes ends 08-01-2020
	// Miscellanous changes starts 08-01-2020
	public void insertIntoTFBOMiscellanousCreate(String requestId)
			throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD
				+ "<<insertIntoTFBOMiscellanousCreate");
		DBHelper aDBHelper = new DBHelper();
		aDBHelper.setValueInDB(requestId,
				ActionConstants.GETINSERTTFBOMISCELLANOUSCREATE_QUERY);
		logger.info(ActionConstants.EXITING_METHOD
				+ "<<insertIntoTFBOMiscellanousCreate");
	}

	// Miscellanous changes ends 08-01-2020
	// Miscellanous changes starts 08-01-2020
	public void updateRateTakenDetailsInDB(UserTransactionVO userVo)
			throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD
				+ "<<updateRateTakenDetailsInDB");

		DBHelper aDBHelper = new DBHelper();
		CommonMethods aCommonMethods = new CommonMethods();

		try {
			if (userVo.getProductCode().trim().equalsIgnoreCase("COR")) {
				if (userVo.getEventCode().trim().equalsIgnoreCase("CRCR")) {

					logger.info(ActionConstants.ENTERING_METHOD);

					if (aCommonMethods.isValueAvailable(userVo.getRateTaken())
							&& userVo.getRateTaken().equalsIgnoreCase("false")) {
						userVo.setToken("");
						userVo.setRate("");
						userVo.setRateTakenK("");
						userVo.setRateTaken("No");
					}

					if (aCommonMethods.isValueAvailable(userVo.getRateTaken())
							&& userVo.getRateTaken().equalsIgnoreCase("true")) {
						userVo.setRateTaken("Yes");
					}

					aDBHelper
							.setValueRateTakenLCInDB(
									userVo.getRateTaken(),
									userVo.getRate(),
									userVo.getToken(),
									userVo.getRateTakenK(),
									userVo.getRequestId(),
									ActionConstants.GETUPDATERATETAKENDETAILS_MISCRE_QUERY);
					logger.info(ActionConstants.EXITING_METHOD);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		logger.info(ActionConstants.EXITING_METHOD
				+ "<<updateRateTakenDetailsInDB");
	}

	// Miscellanous changes ends 08-01-2020
	// Changes for Tat Report starts

//	public void generateTATReport(UserTransactionVO userVo) throws Exception {
//		logger.info(ActionConstants.ENTERING_METHOD);
//
//		String fromDate = userVo.getTatfromDateFilter();
//		String toDate = userVo.getTattoDateFilter();
//
//		System.out.println("fromDate >>-->" + fromDate);
//		System.out.println("toDate >>-->" + toDate);
//
//		logger.info("From Date " + fromDate);
//		logger.info("To Date" + toDate);
//
//		try {
//
//			DBHelper aDBHelper = new DBHelper();
//
//			List<AlertMessagesVO> errorDetailList = new LinkedList<AlertMessagesVO>();
//			errorDetailList = isTatFieldFilled(userVo, errorDetailList);
//			userVo.setErrorDetailsList(errorDetailList);
//
//			if (errorDetailList.isEmpty()) {
//				aDBHelper.setTatReports(fromDate, toDate,
//						ActionConstants.GETTATREPORTSHEET1,
//						ActionConstants.GETTATREPORTSHEET2, userVo);
//			}
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//
//	}

	public List<AlertMessagesVO> isTatFieldFilled(UserTransactionVO userVo,
			List<AlertMessagesVO> errorDetailList) throws Exception {
		CommonMethods aCommonMethods = new CommonMethods();
		if (userVo.getTatfromDateFilter() == null
				|| userVo.getTatfromDateFilter().equalsIgnoreCase("")) {

			errorDetailList = aCommonMethods.setErrorInList(
					ActionConstants.FROMDATEFILTER, errorDetailList);

		}

		if (userVo.getTattoDateFilter() == null
				|| userVo.getTattoDateFilter().equalsIgnoreCase("")) {

			errorDetailList = aCommonMethods.setErrorInList(
					ActionConstants.TODATEFILTER, errorDetailList);

		}

		return errorDetailList;
	}

	// Changes for Tat Report ends

	/* Changes for branch profile 14012020 starts */

	public void branchMgmtmaker_Verify(ProfileManagementVO profileVo)
			throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		try {

			DBHelper aDBHelper = new DBHelper();
			String Sol_ID = profileVo.getSolID();
			String check = checkSOL_ID(Sol_ID);

			System.out.println("Sol_ID===" + Sol_ID);
			System.out.println("check===" + check);

			if (Sol_ID.equals(check)) {

				System.out
						.println("SOL_ID already in BRANCH_PROFILE table...So Updating values");
				aDBHelper.updateBranchProfile(
						ActionConstants.UPDATE_BRANCHPROFILE_QUERY, profileVo);
			} else {
				System.out
						.println("SOL_ID not in BRANCH_PROFILE table...So Inserting values");
				aDBHelper.insertBranchProfile(
						ActionConstants.INSERT_BRANCHPROFILE_QUERY, profileVo);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public String checkSOL_ID(String solid) throws Exception {
		System.out.println("Entering into checkSOL_ID method");
		DBHelper aDBHelper = new DBHelper();
		String branch = "";
		try {
			if (solid != null) {
				branch = aDBHelper.getBranchID(solid);
				System.out.println("branch in checkSOL_ID===" + branch);
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		System.out.println("Exiting checkSOL_ID method");
		return branch;
	}

	public ProfileManagementVO branchProfileVerify(
			ProfileManagementVO profileVo, String solid) throws Exception {

		logger.info(ActionConstants.ENTERING_METHOD);
		DBHelper aDBHelper = new DBHelper();
		/* List<BrabchProfileMgmt> bms=null; */
		List<BrabchProfileMgmt> branchProfileSolid = new LinkedList<BrabchProfileMgmt>();
		try {
			// query = ActionConstants.BRANCHPROFILE_MGMT_QUERY ;

			branchProfileSolid = aDBHelper
					.getBranchProfileListFromDBFilter(solid);
			profileVo.setBranchProfileSolid(branchProfileSolid);
			setTransactionValuesInVO(profileVo);

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		logger.info(ActionConstants.EXITING_METHOD + "branchProfileVerify---->");
		return profileVo;

	}

	public ProfileManagementVO setTransactionValuesInVO(
			ProfileManagementVO profileVo) throws Exception {

		if (profileVo.branchProfileSolid != null) {
			for (BrabchProfileMgmt branchsol : profileVo.branchProfileSolid) {

				profileVo.AlphaCode = branchsol.getAlphaCode();
				profileVo.BranchAddr = branchsol.getBranchAddr();
				profileVo.BRPhoneSTD = branchsol.getBRPhoneSTD();
				profileVo.SwiftCode = branchsol.getSwiftCode();
				profileVo.MobileNo = branchsol.getMobileNo();
			}
		}
		return profileVo;
	}

	/* Changes for branch profile 14012020 ends */

	public CustomerProfileManageVO fetchcustomerDetails(
			CustomerProfileManageVO custProfileVo) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		DBHelper aDBHelper = new DBHelper();
		List<CustomerProfileManageVO> custProfileList = new LinkedList<CustomerProfileManageVO>();
		try {
			String custID = custProfileVo.getCustID();
			if (custID != null && !custID.trim().equals("")) {
				boolean flag = aDBHelper
						.checkCustomerAvailable(ActionConstants.CHECKCUSTOMERDETAILS
								+ " WHERE TRIM(CUSTID) = '"
								+ custID.trim()
								+ "'");
				if (flag) {
					custProfileList = aDBHelper
							.fetchcustomerDetailsFromProfile(ActionConstants.FETCHCUSTOMERDETAILSFROMPROFILE
									+ " WHERE TRIM(CUSTID) = '"
									+ custID.trim()
									+ "'");
					for (CustomerProfileManageVO custProVO : custProfileList) {
						custProfileVo.custName = custProVO.getCustName();
						custProfileVo.emailID = custProVO.getEmailID();
						custProfileVo.mobileNo = custProVO.getMobileNo();
						custProfileVo.rateMarginFrom = custProVO
								.getRateMarginFrom();
						custProfileVo.rateMarginTo = custProVO
								.getRateMarginTo();
						custProfileVo.operAccNo = custProVO.getOperAccNo();
						custProfileVo.operSolID = custProVO.getOperSolID();
						custProfileVo.alphaCode = custProVO.getAlphaCode();
						custProfileVo.lineofActivity = custProVO
								.getLineofActivity();
						custProfileVo.flag = "TRUE";
					}
				} else {
					custProfileList = aDBHelper
							.fetchcustomerDetails(ActionConstants.FETCHCUSTOMERDETAILS
									+ " WHERE SXCUS1 = '" + custID + "'");
					for (CustomerProfileManageVO custProVO : custProfileList) {
						custProfileVo.custName = custProVO.getCustName();
						custProfileVo.emailID = custProVO.getEmailID();
						custProfileVo.flag = "FALSE";
						custProfileVo.mobileNo = "";
						custProfileVo.rateMarginFrom = "";
						custProfileVo.rateMarginTo = "";
						custProfileVo.operAccNo = "";
						custProfileVo.operSolID = "";
						custProfileVo.alphaCode = "";
						custProfileVo.lineofActivity = "";
					}
				}
			} else {
				custProfileVo.custName = "";
				custProfileVo.emailID = "";
				custProfileVo.mobileNo = "";
				custProfileVo.rateMarginFrom = "";
				custProfileVo.rateMarginTo = "";
				custProfileVo.operAccNo = "";
				custProfileVo.operSolID = "";
				custProfileVo.alphaCode = "";
				custProfileVo.lineofActivity = "";
				custProfileVo.flag = "";
			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();

		}
		return custProfileVo;
	}

	public int UpdateCustomerDtails(CustomerProfileManageVO custProfileVo,
			String userName) throws Exception {// //
		logger.info(ActionConstants.ENTERING_METHOD);
		DBHelper aDBHelper = new DBHelper();
		int resultValue = 0;
		try {
			if (custProfileVo.getCustID() != null
					&& !custProfileVo.getCustID().trim().equals("")) {
				if (custProfileVo.getFlag().equals("TRUE")) {
					resultValue = aDBHelper.UpdateCustomerDtails(custProfileVo,
							userName, ActionConstants.UPDATECUSTOMERDETAILS
									+ " WHERE CUSTID = '"
									+ custProfileVo.getCustID().trim() + "' ");
				} else {
					resultValue = aDBHelper.UpdateCustomerDtails(custProfileVo,
							userName, ActionConstants.INSERTCUSTOMERDETAILS);
				}
			}

		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();

		}
		return resultValue;
	}

	public CustomerProfileManageVO getBranchProfileDetails(String userName,
			String custSolid, CustomerProfileManageVO custProfileVo)
			throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		DBHelper aDBHelper = new DBHelper();
		List<CustomerProfileManageVO> custProfileList = new LinkedList<CustomerProfileManageVO>();
		try {
			// String solID = aDBHelper
			// .getBranchIDfromTI(ActionConstants.FETCHBRANCHFROMTI + " "
			// + " AND NAME85 = '" + userName.trim() + "' "
			// + " AND TEAM = 'BRANCHMAKER'");
			custProfileList = aDBHelper.getBranchProfileDetails(custSolid,
					custProfileVo, ActionConstants.FETCHBRANCHFROMPROFILE + " "
							+ " WHERE SOL_ID = '" + custSolid + "'");

			if (custProfileList != null) {
				for (CustomerProfileManageVO custProVO : custProfileList) {
					custProfileVo.branchAddress = custProVO.getBranchAddress();
					custProfileVo.branchalphaCode = custProVO
							.getBranchalphaCode();
					custProfileVo.branchMobileNo = custProVO
							.getBranchMobileNo();
					custProfileVo.branchPhone = custProVO.getBranchPhone();
					custProfileVo.branchsolID = custProVO.getBranchsolID();
					custProfileVo.branchswiftCode = custProVO
							.getBranchswiftCode();
				}
			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();

		}
		return custProfileVo;
	}

	public Boolean isUserChecker(String userName) {
		logger.info(ActionConstants.ENTERING_METHOD + ">> isUserMaker");
		List<String> userTeamList = null;
		try {
			userTeamList = getUserTeam(userName);
			for (int teamCount = 0; teamCount < userTeamList.size(); teamCount++) {
				if (userTeamList.get(teamCount).trim()
						.equals(ActionConstants.CHECKER)) {
					logger.info(ActionConstants.EXITING_METHOD
							+ ">> isUserMaker");
					return true;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		logger.info(ActionConstants.EXITING_METHOD + ">> isUserMaker");
		return false;
	}

	public Boolean isUserScrutinizer(String userName) {
		logger.info(ActionConstants.ENTERING_METHOD + ">> isUserMaker");
		List<String> userTeamList = null;
		try {
			userTeamList = getUserTeam(userName);
			for (int teamCount = 0; teamCount < userTeamList.size(); teamCount++) {
				if (userTeamList.get(teamCount).trim()
						.equals(ActionConstants.FBOSCRUTINIZER)
						|| userTeamList.get(teamCount).trim()
								.equals(ActionConstants.ILCSCRUTINIZER)
						|| userTeamList.get(teamCount).trim()
								.equals(ActionConstants.ELCSCRUTINIZER)
						|| userTeamList.get(teamCount).trim()
								.equals(ActionConstants.IDCSCRUTINIZER)
						|| userTeamList.get(teamCount).trim()
								.equals(ActionConstants.ODCSCRUTINIZER)
						|| userTeamList.get(teamCount).trim()
								.equals(ActionConstants.FSASCRUTINIZER)
						|| userTeamList.get(teamCount).trim()
								.equals(ActionConstants.IRSCRUTINIZER)
						|| userTeamList.get(teamCount).trim()
								.equals(ActionConstants.ORSCRUTINIZER)
						|| userTeamList.get(teamCount).trim()
								.equals(ActionConstants.IGTSCRUTINIZER)) {
					logger.info(ActionConstants.EXITING_METHOD
							+ ">> isUserMaker");
					return true;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		logger.info(ActionConstants.EXITING_METHOD + ">> isUserMaker");
		return false;
	}

	// Sub product type drop down filter changes starts 13012020

	public List<String> getSubProductListFromDB(String productCode)
			throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		DBHelper aDBHelper = new DBHelper();
		List<String> subProductDetailsList = null;
		try {
			subProductDetailsList = aDBHelper.getListFromDB(productCode,
					ActionConstants.GETSUBPRODUCTTYPE_QUERY);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		logger.info(ActionConstants.ENTERING_METHOD);
		return subProductDetailsList;
	}

	// Sub product type drop down filter changes starts 21012020
	public String getSubProductCodeFromDB(String subProductDescription)
			throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		DBHelper aDBHelper = new DBHelper();
		String subProductCode = "";
		try {
			subProductCode = aDBHelper.getValueFromDB(subProductDescription,
					ActionConstants.GETTFBOSUBPRODUCTCODE_QUERY);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		logger.info(ActionConstants.EXITING_METHOD);
		return subProductCode;
	}

	// Sub product type drop down filter changes ends 21012020

	// Sub product type drop down filter changes ends 13012020

	// Expiry,closure,cancellation Changes Starts

	public void updateTFBOTiRefInTransTable(String tireference, String requestId)
			throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD
				+ "<<updateTFBOTiRefInTransTable");
		DBHelper aDBHelper = new DBHelper();
		aDBHelper.setValueInDB(tireference, requestId,
				ActionConstants.UPDATETFBOMASTERREF);
		logger.info(ActionConstants.EXITING_METHOD
				+ "<<updateTFBOTiRefInTransTable");
	}

	public void updateTFBOIlcExpiry(String tiReferenceNo, String solId,
			String customerCif, String amount, String currency,
			String requestId, String lcType, String usancePeriod)
			throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		DBHelper aDBHelper = new DBHelper();
		aDBHelper.setValueInDB(tiReferenceNo, solId, customerCif, amount,
				currency, lcType, requestId,
				ActionConstants.GETUPDATETFBOILCEXPNEW_QUERY);
		logger.info(ActionConstants.EXITING_METHOD);
	}

	public void updateTFBOElcExpiry(String tireference, String solId,
			String customerCif, String amount, String currency,
			String requestId, String lcType, String usancePeriod)
			throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		DBHelper aDBHelper = new DBHelper();
		aDBHelper.setValueInDB(tireference, solId, customerCif, amount,
				currency, lcType, requestId,
				ActionConstants.GETUPDATETFBOELCEXPNEW_QUERY);
		logger.info(ActionConstants.EXITING_METHOD);
	}

	public void updateTFBOIgtCancel(String tireference, String solId,
			String customerCif, String amount, String currency,
			String requestId, String tenor) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		DBHelper aDBHelper = new DBHelper();
		aDBHelper.setValueInDB(tireference, solId, customerCif, amount,
				currency, tenor, requestId,
				ActionConstants.GETUPDATETFBOIGTCANNEW_QUERY);
		logger.info(ActionConstants.EXITING_METHOD);
	}

	public void updateTFBOIgtClosure(String tireference, String solId,
			String customerCif, String amount, String currency,
			String requestId, String tenor) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		DBHelper aDBHelper = new DBHelper();
		aDBHelper.setValueInDB(tireference, solId, customerCif, amount,
				currency, tenor, requestId,
				ActionConstants.GETUPDATETFBOIGTKIGNEW_QUERY);
		logger.info(ActionConstants.EXITING_METHOD);
	}

	// Expiry,closure,cancellation Changes Ends
	// Expiry,closure,cancellation Changes Starts
	public void insertIntoTFBOIlcExpiry(String requestId) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		DBHelper aDBHelper = new DBHelper();
		aDBHelper.setValueInDB(requestId,
				ActionConstants.GETINSERTTFBOILCEXP_QUERY);
		logger.info(ActionConstants.EXITING_METHOD);
	}

	public void insertIntoTFBOElcExpiry(String requestId) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		DBHelper aDBHelper = new DBHelper();
		aDBHelper.setValueInDB(requestId,
				ActionConstants.GETINSERTTFBOELCEXP_QUERY);
		logger.info(ActionConstants.EXITING_METHOD);
	}

	public void insertIntoTFBOIgtCancel(String requestId) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		DBHelper aDBHelper = new DBHelper();
		aDBHelper.setValueInDB(requestId,
				ActionConstants.GETINSERTTFBOIGTCAN_QUERY);
		logger.info(ActionConstants.EXITING_METHOD);
	}

	public void insertIntoTFBOIgtClosure(String requestId) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		DBHelper aDBHelper = new DBHelper();
		aDBHelper.setValueInDB(requestId,
				ActionConstants.GETINSERTTFBOIGTKIG_QUERY);
		logger.info(ActionConstants.EXITING_METHOD);
	}

	// Expiry,closure,cancellation Changes Ends

	public CustomerProfileManageVO fetchcustomerDetailsView(
			CustomerProfileManageVO custProfileVo) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		DBHelper aDBHelper = new DBHelper();
		List<CustomerProfileManageVO> custProfileList = new LinkedList<CustomerProfileManageVO>();
		try {
			String custID = "";
			if (custProfileVo.getFlag() != null
					&& custProfileVo.getFlag().equals("TRUE")) {
				custID = custProfileVo.getCustVerify();
			} else {
				custID = custProfileVo.getCustID();
			}
			if (custID != null && !custID.trim().equals("")) {
				custProfileList = aDBHelper
						.fetchcustomerDetailsFromProfile(ActionConstants.FETCHCUSTOMERDETAILSFROMPROFILE
								+ " WHERE TRIM(CUSTID) = '"
								+ custID.trim()
								+ "'");
				for (CustomerProfileManageVO custProVO : custProfileList) {
					custProfileVo.custID = custID;
					custProfileVo.custName = custProVO.getCustName();
					custProfileVo.emailID = custProVO.getEmailID();
					custProfileVo.mobileNo = custProVO.getMobileNo();
					custProfileVo.rateMarginFrom = custProVO
							.getRateMarginFrom();
					custProfileVo.rateMarginTo = custProVO.getRateMarginTo();
					custProfileVo.operAccNo = custProVO.getOperAccNo();
					custProfileVo.operSolID = custProVO.getOperSolID();
					custProfileVo.alphaCode = custProVO.getAlphaCode();
					custProfileVo.lineofActivity = custProVO
							.getLineofActivity();
					custProfileVo.custSolId = custProVO.getCustSolId();
				}
			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();

		}
		return custProfileVo;
	}

	public int updateCustomerVerify(String userName,
			CustomerProfileManageVO custProfileVo) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		DBHelper aDBHelper = new DBHelper();
		CommonMethods acommMethods = new CommonMethods();
		List<AlertMessagesVO> errorDetailList = new LinkedList<AlertMessagesVO>();
		int resultValue = 0;
		try {
			if (custProfileVo.getCustID() != null
					&& !custProfileVo.getCustID().trim().equals("")) {
				resultValue = aDBHelper.UpdateCustomerVerifyDtails(
						custProfileVo, ActionConstants.UPDATECUSTVERIFYLIST,
						userName);
				if (resultValue > 0) {
					custProfileVo.setErrorDetailsList(acommMethods
							.setErrorInList("Customer Verified Successfully",
									errorDetailList));
				}
			}

		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();

		}
		return resultValue;
	}

	/* Dashboard changes 23012020 starts */

	public void updateValuesInTFBOTrans(String productCode, String solId,
			String custmerCif, String customerName, String direct,
			String financeSameDay, String requestId,String amount,String currency, String rateTaken) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		DBHelper aDBHelper = new DBHelper();
		aDBHelper.setValueInDB_TRANS(productCode, solId, custmerCif, customerName,
				direct, financeSameDay,amount, currency, rateTaken, requestId,
				ActionConstants.GETUPDATETFBOTRANSVALUES_QUERY);
		logger.info(ActionConstants.EXITING_METHOD);
	}

	/* Dashboard changes 23012020 ends */

	// Report 23012020 starts

	public List<String> getProductCodeFromDB() throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		DBHelper aDBHelper = new DBHelper();
		List<String> productList = null;
		productList = aDBHelper
				.getCodeListFromDB(ActionConstants.GETPRODUCTCODELIST_QUERY);
		logger.info(ActionConstants.ENTERING_METHOD);
		return productList;
	}

	/*
	 * public List<String> getUserIdListFromDB() throws Exception {
	 * logger.info(ActionConstants.ENTERING_METHOD); DBHelper aDBHelper = new
	 * DBHelper(); List<String> userList = null; userList =
	 * aDBHelper.getUserIdListFromDB(ActionConstants.GETUSERIDNAME);
	 * logger.info(ActionConstants.ENTERING_METHOD); return userList; }
	 */
	public List<String> getUserIdListFromDB() throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD
				+ "<<getUserIdListFromDB DAO");
		DBHelper aDBHelper = new DBHelper();
		List<String> userList = null;
		userList = aDBHelper.getUserIdListFromDB(ActionConstants.GETUSERIDNAME);
		logger.info(ActionConstants.EXITING_METHOD
				+ "<<getUserIdListFromDB DAO");
		return userList;
	}

	/*
	 * public List<ReportVO> generateSummaryReportInGrid(ReportVO reportVo)
	 * throws Exception { logger.info(ActionConstants.ENTERING_METHOD +
	 * "<<generateSummaryReportInGrid DAO"); List<ReportVO> summaryList = null;
	 * 
	 * try {
	 * 
	 * CommonMethods aCommonMethods = new CommonMethods(); String query = "";
	 * 
	 * query = ActionConstants.GETSUMMARYRESULTS;
	 * 
	 * if (aCommonMethods.isValueAvailable(reportVo.getProductCodeList())) {
	 * query = query + " WHERE TRANSTYPE LIKE '%" +
	 * reportVo.getProductCodeList() + "%'"; }
	 * 
	 * if (aCommonMethods.isValueAvailable(reportVo.getSolID())) { query = query
	 * + " AND SOLID LIKE '%" + reportVo.getSolID() + "%'"; }
	 * 
	 * if (aCommonMethods.isValueAvailable(reportVo.getCurrency())) { query =
	 * query + " AND CURRENCY LIKE '%" + reportVo.getCurrency() + "%'"; }
	 * 
	 * if (aCommonMethods.isValueAvailable(reportVo.getRstatusFilter())) { query
	 * = query + " AND TRANS_STATUS LIKE '%" + reportVo.getRstatusFilter() +
	 * "%'"; }
	 * 
	 * if (aCommonMethods.isValueAvailable(reportVo.getUserIdList())) { query =
	 * query + " AND USERNAME LIKE '%" + reportVo.getUserIdList() + "%'"; }
	 * 
	 * if (aCommonMethods.isValueAvailable(reportVo.getFromDateFilter()) &&
	 * aCommonMethods.isValueAvailable(reportVo .getToDateFilter())) { query =
	 * query + " AND TRANSACTION_GENERATE_TIME BETWEEN '" +
	 * reportVo.getFromDateFilter() + "' AND '" + reportVo.getToDateFilter() +
	 * "'"; }
	 * 
	 * 
	 * // Uncomment after getting query from BOB starts
	 * 
	 * summaryList = aDBHelper.generateSummaryReportInGrid(query, reportVo);
	 * 
	 * // Uncomment after getting query from BOB ends
	 * 
	 * } catch (Exception e) { e.printStackTrace(); }
	 * logger.info(ActionConstants.EXITING_METHOD +
	 * "<<generateSummaryReportInGrid DAO"); return summaryList; }
	 */

	/*public List<ReportVO> generateSummaryReportInGrid(ReportVO reportVo)
			throws Exception {

		logger.info(ActionConstants.ENTERING_METHOD
				+ "<<generateSummaryReportInGrid DAO");

		List<ReportVO> summaryList = null;
		String summaryReportQuery = "";
		CommonMethods aCommonMethods = new CommonMethods();

		try {

			logger.info("Getting product name==> " + reportVo.getProductName());

			if (aCommonMethods.isValueAvailable(reportVo.getProductName())) {

				if (reportVo.getProductName().equalsIgnoreCase("ALL")) {

					reportVo.setProductCodeList("ALL");

				} else {

					reportVo.setProductCodeList(getProductCodeFromDB(reportVo
							.getProductName()));
				}
			}

			logger.info("Getting product code==> "
					+ reportVo.getProductCodeList());

			if (reportVo.getProductCodeList().equalsIgnoreCase("ILC")) {
				summaryReportQuery = ActionConstants.GETILCSUMMARYRESULTS;
				summaryList = generateGridSummaryReportQuery(reportVo,
						summaryReportQuery);
			}

			else if (reportVo.getProductCodeList().equalsIgnoreCase("ELC")) {
				summaryReportQuery = ActionConstants.GETELCSUMMARYRESULTS;
				summaryList = generateGridSummaryReportQuery(reportVo,
						summaryReportQuery);
			}

			else if (reportVo.getProductCodeList().equalsIgnoreCase("FOC")) {
				summaryReportQuery = ActionConstants.GETFOCSUMMARYRESULTS;
				summaryList = generateGridSummaryReportQuery(reportVo,
						summaryReportQuery);
			}

			else if (reportVo.getProductCodeList().equalsIgnoreCase("CPCI")) {
				summaryReportQuery = ActionConstants.GETCPCISUMMARYRESULTS;
				summaryList = generateGridSummaryReportQuery(reportVo,
						summaryReportQuery);
			}

			else if (reportVo.getProductCodeList().equalsIgnoreCase("ISB")) {
				summaryReportQuery = ActionConstants.GETISBSUMMARYRESULTS;
				summaryList = generateGridSummaryReportQuery(reportVo,
						summaryReportQuery);
			}

			else if (reportVo.getProductCodeList().equalsIgnoreCase("FSA")) {
				summaryReportQuery = ActionConstants.GETFSASUMMARYRESULTS;
				summaryList = generateGridSummaryReportQuery(reportVo,
						summaryReportQuery);
			}

			else if (reportVo.getProductCodeList().equalsIgnoreCase("IDC")) {
				summaryReportQuery = ActionConstants.GETIDCSUMMARYRESULTS;
				summaryList = generateGridSummaryReportQuery(reportVo,
						summaryReportQuery);
			}

			else if (reportVo.getProductCodeList().equalsIgnoreCase("ODC")) {
				summaryReportQuery = ActionConstants.GETODCSUMMARYRESULTS;
				summaryList = generateGridSummaryReportQuery(reportVo,
						summaryReportQuery);
			}

			else if (reportVo.getProductCodeList().equalsIgnoreCase("IGT")) {
				summaryReportQuery = ActionConstants.GETIGTSUMMARYRESULTS;
				summaryList = generateGridSummaryReportQuery(reportVo,
						summaryReportQuery);
			}

			else if (reportVo.getProductCodeList().equalsIgnoreCase("CPCO")) {
				summaryReportQuery = ActionConstants.GETCPCOSUMMARYRESULTS;
				summaryList = generateGridSummaryReportQuery(reportVo,
						summaryReportQuery);
			}

			else if (reportVo.getProductCodeList().equalsIgnoreCase("FEL")) {
				summaryReportQuery = ActionConstants.GETFELSUMMARYRESULTS;
				summaryList = generateGridSummaryReportQuery(reportVo,
						summaryReportQuery);
			}

			else if (reportVo.getProductCodeList().equalsIgnoreCase("COR")) {
				summaryReportQuery = ActionConstants.GETCORSUMMARYRESULTS;
				summaryList = generateGridSummaryReportQuery(reportVo,
						summaryReportQuery);
			}

			else if (reportVo.getProductCodeList().equalsIgnoreCase("ALL")) {
				summaryReportQuery = ActionConstants.GETALLSUMMARYRESULTS;
				summaryList = generateGridSummaryReportQuery(reportVo,
						summaryReportQuery);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		logger.info(ActionConstants.EXITING_METHOD
				+ "<<generateSummaryReportInGrid DAO");
		return summaryList;
	}*/
	
//	public List<ReportVO> generateSummaryReportInGrid(ReportVO reportVo)
//			throws Exception {
//
//		logger.info(ActionConstants.ENTERING_METHOD
//				+ "<<generateSummaryReportInGrid DAO");
//
//		List<ReportVO> summaryList = null;
//		String summaryReportQuery = "";
//		CommonMethods aCommonMethods = new CommonMethods();
//
//		try {
//
//			logger.info("Getting product name==> " + reportVo.getProductName());
//
//			if (aCommonMethods.isValueAvailable(reportVo.getProductName())) {
//
//				if (reportVo.getProductName().equalsIgnoreCase("ALL")) {
//
//					reportVo.setProductCodeList("ALL");
//
//				} else {
//
//					reportVo.setProductCodeList(getProductCodeFromDB(reportVo
//							.getProductName()));
//				}
//			}
//
//			logger.info("Getting product code==> "
//					+ reportVo.getProductCodeList());
//
//			if (reportVo.getProductCodeList().equalsIgnoreCase("ILC")) {
//			//	summaryReportQuery = ActionConstants.GETILCSUMMARYRESULTS;
//				
//				if(reportVo.getReportFrequency().equalsIgnoreCase("Hourly")){
//					summaryReportQuery = ActionConstants.GET_ILCSUMMARYRESULTS_HOURLY;
//					summaryList = generateGridSummaryReportQuery(reportVo,
//							summaryReportQuery);
//				}
//			     if(reportVo.getReportFrequency().equalsIgnoreCase("Daily")){
//					summaryReportQuery = ActionConstants.GET_ILCSUMMARYRESULTS_DAILY;
//					summaryList = generateGridSummaryReportQuery(reportVo,
//							summaryReportQuery);
//				}
//			     if(reportVo.getReportFrequency().equalsIgnoreCase("Weekly")){
//			    	 summaryReportQuery = ActionConstants.GET_ILCSUMMARYRESULTS_WEEKLY;
//			    	 summaryList = generateGridSummaryReportQuery(reportVo,
//								summaryReportQuery);	 
//			     }
//			     if(reportVo.getReportFrequency().equalsIgnoreCase("Monthly")){
//			    	 summaryReportQuery = ActionConstants.GET_ILCSUMMARYRESULTS_MONTHLY;
//			    	 summaryList = generateGridSummaryReportQuery(reportVo,
//								summaryReportQuery); 
//			     }
//				
//			}
//
//			else if (reportVo.getProductCodeList().equalsIgnoreCase("ELC")) {
//				System.out.println("--------"+reportVo.getReportFrequency());
//				if(reportVo.getReportFrequency().equalsIgnoreCase("Hourly")){
//					summaryReportQuery = ActionConstants.GET_ELCSUMMARYRESULTS_HOURLY;
//					summaryList = generateGridSummaryReportQuery(reportVo,
//							summaryReportQuery);
//				}
//			     if(reportVo.getReportFrequency().equalsIgnoreCase("Daily")){
//					summaryReportQuery = ActionConstants.GET_ELCSUMMARYRESULTS_DAILY;
//					summaryList = generateGridSummaryReportQuery(reportVo,
//							summaryReportQuery);
//				}
//			     if(reportVo.getReportFrequency().equalsIgnoreCase("Weekly")){
//			    	 summaryReportQuery = ActionConstants.GET_ELCSUMMARYRESULTS_WEEKLY;
//						summaryList = generateGridSummaryReportQuery(reportVo,
//								summaryReportQuery);	 
//			     }
//			     if(reportVo.getReportFrequency().equalsIgnoreCase("Monthly")){
//			    	 summaryReportQuery = ActionConstants.GET_ELCSUMMARYRESULTS_MONTHLY;
//						summaryList = generateGridSummaryReportQuery(reportVo,
//								summaryReportQuery);	 
//			     }
//			}
//
//			else if (reportVo.getProductCodeList().equalsIgnoreCase("FOC")) {
//				if(reportVo.getReportFrequency().equalsIgnoreCase("Hourly")){
//				summaryReportQuery = ActionConstants.GET_FOCSUMMARYRESULTS_HOURLY;
//				summaryList = generateGridSummaryReportQuery(reportVo,
//						summaryReportQuery);
//			}
//				if(reportVo.getReportFrequency().equalsIgnoreCase("Daily")){
//					summaryReportQuery = ActionConstants.GET_FOCSUMMARYRESULTS_DAILY;
//					summaryList = generateGridSummaryReportQuery(reportVo,
//							summaryReportQuery);
//				}
//				if(reportVo.getReportFrequency().equalsIgnoreCase("Weekly")){
//					summaryReportQuery = ActionConstants.GET_FOCSUMMARYRESULTS_WEEKLY;
//					summaryList = generateGridSummaryReportQuery(reportVo,
//							summaryReportQuery);
//				}
//				
//				if(reportVo.getReportFrequency().equalsIgnoreCase("Monthly")){
//					summaryReportQuery = ActionConstants.GET_FOCSUMMARYRESULTS_MONTHLY;
//					summaryList = generateGridSummaryReportQuery(reportVo,
//							summaryReportQuery);
//				}
//			}
//			else if (reportVo.getProductCodeList().equalsIgnoreCase("CPCI")) {
//				if(reportVo.getReportFrequency().equalsIgnoreCase("Hourly")){
//				summaryReportQuery = ActionConstants.GET_CPCISUMMARYRESULTS_HOURLY;
//				summaryList = generateGridSummaryReportQuery(reportVo,
//						summaryReportQuery);
//				}
//				if(reportVo.getReportFrequency().equalsIgnoreCase("Daily")){
//					summaryReportQuery = ActionConstants.GET_CPCISUMMARYRESULTS_DAILY;
//					summaryList = generateGridSummaryReportQuery(reportVo,
//							summaryReportQuery);
//					
//			}
//				if(reportVo.getReportFrequency().equalsIgnoreCase("Weekly")){
//					summaryReportQuery = ActionConstants.GET_CPCISUMMARYRESULTS_WEEKLY;
//					summaryList = generateGridSummaryReportQuery(reportVo,
//							summaryReportQuery);
//		      }
//				if(reportVo.getReportFrequency().equalsIgnoreCase("Monthly")){
//					summaryReportQuery = ActionConstants.GET_CPCISUMMARYRESULTS_MONTHLY;
//					summaryList = generateGridSummaryReportQuery(reportVo,
//							summaryReportQuery);
//		      }
//		}			
//			else if (reportVo.getProductCodeList().equalsIgnoreCase("ISB")) {
//				if(reportVo.getReportFrequency().equalsIgnoreCase("Hourly")){
//					summaryReportQuery = ActionConstants.GET_ISBSUMMARYRESULTS_HOURLY;
//					summaryList = generateGridSummaryReportQuery(reportVo,
//							summaryReportQuery);
//					}
//				if(reportVo.getReportFrequency().equalsIgnoreCase("Daily")){
//					summaryReportQuery = ActionConstants.GET_ISBSUMMARYRESULTS_DAILY;
//					summaryList = generateGridSummaryReportQuery(reportVo,
//							summaryReportQuery);
//					}
//				if(reportVo.getReportFrequency().equalsIgnoreCase("Weekly")){
//					summaryReportQuery = ActionConstants.GET_ISBSUMMARYRESULTS_WEEKLY;
//					summaryList = generateGridSummaryReportQuery(reportVo,
//							summaryReportQuery);
//					}
//				if(reportVo.getReportFrequency().equalsIgnoreCase("Monthly")){
//					summaryReportQuery = ActionConstants.GET_ISBSUMMARYRESULTS_MONTHLY;
//					summaryList = generateGridSummaryReportQuery(reportVo,
//							summaryReportQuery);
//					}
//		
//			}
//
//			else if (reportVo.getProductCodeList().equalsIgnoreCase("FSA")) {
//				/*summaryReportQuery = ActionConstants.GETFSASUMMARYRESULTS;
//				summaryList = generateGridSummaryReportQuery(reportVo,
//						summaryReportQuery);*/
//				   if(reportVo.getReportFrequency().equalsIgnoreCase("Hourly")){
//						summaryReportQuery = ActionConstants.GET_FSASUMMARYRESULTS_HOURLY;
//						summaryList = generateGridSummaryReportQuery(reportVo,
//								summaryReportQuery);
//						}
//					if(reportVo.getReportFrequency().equalsIgnoreCase("Daily")){
//						summaryReportQuery = ActionConstants.GET_FSASUMMARYRESULTS_DAILY;
//						summaryList = generateGridSummaryReportQuery(reportVo,
//								summaryReportQuery);
//						}
//					if(reportVo.getReportFrequency().equalsIgnoreCase("Weekly")){
//						summaryReportQuery = ActionConstants.GET_FSASUMMARYRESULTS_WEEKLY;
//						summaryList = generateGridSummaryReportQuery(reportVo,
//								summaryReportQuery);
//						}
//					if(reportVo.getReportFrequency().equalsIgnoreCase("Monthly")){
//						summaryReportQuery = ActionConstants.GET_FSASUMMARYRESULTS_MONTHLY;
//						summaryList = generateGridSummaryReportQuery(reportVo,
//								summaryReportQuery);
//						}
//			}
//
//			else if (reportVo.getProductCodeList().equalsIgnoreCase("IDC")) {
//				/*summaryReportQuery = ActionConstants.GETIDCSUMMARYRESULTS;
//				summaryList = generateGridSummaryReportQuery(reportVo,
//						summaryReportQuery);*/
//				 if(reportVo.getReportFrequency().equalsIgnoreCase("Hourly")){
//						summaryReportQuery = ActionConstants.GET_IDCSUMMARYRESULTS_HOURLY;
//						summaryList = generateGridSummaryReportQuery(reportVo,
//								summaryReportQuery);
//						}
//					if(reportVo.getReportFrequency().equalsIgnoreCase("Daily")){
//						summaryReportQuery = ActionConstants.GET_IDCSUMMARYRESULTS_DAILY;
//						summaryList = generateGridSummaryReportQuery(reportVo,
//								summaryReportQuery);
//						}
//					if(reportVo.getReportFrequency().equalsIgnoreCase("Weekly")){
//						summaryReportQuery = ActionConstants.GET_IDCSUMMARYRESULTS_WEEKLY;
//						summaryList = generateGridSummaryReportQuery(reportVo,
//								summaryReportQuery);
//						}
//					if(reportVo.getReportFrequency().equalsIgnoreCase("Monthly")){
//						summaryReportQuery = ActionConstants.GET_IDCSUMMARYRESULTS_MONTHLY;
//						summaryList = generateGridSummaryReportQuery(reportVo,
//								summaryReportQuery);
//						}
//			}
//
//			else if (reportVo.getProductCodeList().equalsIgnoreCase("ODC")) {
//				/*summaryReportQuery = ActionConstants.GETODCSUMMARYRESULTS;
//				summaryList = generateGridSummaryReportQuery(reportVo,
//						summaryReportQuery);*/
//				  if(reportVo.getReportFrequency().equalsIgnoreCase("Hourly")){
//						summaryReportQuery = ActionConstants.GET_ODCSUMMARYRESULTS_HOURLY;
//						summaryList = generateGridSummaryReportQuery(reportVo,
//								summaryReportQuery);
//						}
//					if(reportVo.getReportFrequency().equalsIgnoreCase("Daily")){
//						summaryReportQuery = ActionConstants.GET_ODCSUMMARYRESULTS_DAILY;
//						summaryList = generateGridSummaryReportQuery(reportVo,
//								summaryReportQuery);
//						}
//					if(reportVo.getReportFrequency().equalsIgnoreCase("Weekly")){
//						summaryReportQuery = ActionConstants.GET_ODCSUMMARYRESULTS_WEEKLY;
//						summaryList = generateGridSummaryReportQuery(reportVo,
//								summaryReportQuery);
//						}
//					if(reportVo.getReportFrequency().equalsIgnoreCase("Monthly")){
//						summaryReportQuery = ActionConstants.GET_ODCSUMMARYRESULTS_MONTHLY;
//						summaryList = generateGridSummaryReportQuery(reportVo,
//								summaryReportQuery);
//						}
//			}
//
//			else if (reportVo.getProductCodeList().equalsIgnoreCase("IGT")) {
//			/*	summaryReportQuery = ActionConstants.GETIGTSUMMARYRESULTS;
//				summaryList = generateGridSummaryReportQuery(reportVo,
//						summaryReportQuery);*/
//				 if(reportVo.getReportFrequency().equalsIgnoreCase("Hourly")){
//						summaryReportQuery = ActionConstants.GET_IGTSUMMARYRESULTS_HOURLY;
//						summaryList = generateGridSummaryReportQuery(reportVo,
//								summaryReportQuery);
//						}
//					if(reportVo.getReportFrequency().equalsIgnoreCase("Daily")){
//						summaryReportQuery = ActionConstants.GET_IGTSUMMARYRESULTS_DAILY;
//						summaryList = generateGridSummaryReportQuery(reportVo,
//								summaryReportQuery);
//						}
//					if(reportVo.getReportFrequency().equalsIgnoreCase("Weekly")){
//						summaryReportQuery = ActionConstants.GET_IGTSUMMARYRESULTS_WEEKLY;
//						summaryList = generateGridSummaryReportQuery(reportVo,
//								summaryReportQuery);
//						}
//					if(reportVo.getReportFrequency().equalsIgnoreCase("Monthly")){
//						summaryReportQuery = ActionConstants.GET_IGTSUMMARYRESULTS_MONTHLY;
//						summaryList = generateGridSummaryReportQuery(reportVo,
//								summaryReportQuery);
//						}
//			}
//
//			else if (reportVo.getProductCodeList().equalsIgnoreCase("CPCO")) {
//				/*summaryReportQuery = ActionConstants.GETCPCOSUMMARYRESULTS;
//				summaryList = generateGridSummaryReportQuery(reportVo,
//						summaryReportQuery);*/
//				if(reportVo.getReportFrequency().equalsIgnoreCase("Hourly")){
//					summaryReportQuery = ActionConstants.GET_CPCOSUMMARYRESULTS_HOURLY;
//					summaryList = generateGridSummaryReportQuery(reportVo,
//							summaryReportQuery);
//					}
//				if(reportVo.getReportFrequency().equalsIgnoreCase("Daily")){
//					summaryReportQuery = ActionConstants.GET_CPCOSUMMARYRESULTS_DAILY;
//					summaryList = generateGridSummaryReportQuery(reportVo,
//							summaryReportQuery);
//					}
//				if(reportVo.getReportFrequency().equalsIgnoreCase("Weekly")){
//					summaryReportQuery = ActionConstants.GET_CPCOSUMMARYRESULTS_WEEKLY;
//					summaryList = generateGridSummaryReportQuery(reportVo,
//							summaryReportQuery);
//					}
//				if(reportVo.getReportFrequency().equalsIgnoreCase("Monthly")){
//					summaryReportQuery = ActionConstants.GET_CPCOSUMMARYRESULTS_MONTHLY;
//					summaryList = generateGridSummaryReportQuery(reportVo,
//							summaryReportQuery);
//					}
//			}
//
//			else if (reportVo.getProductCodeList().equalsIgnoreCase("FEL")) {
//				/*summaryReportQuery = ActionConstants.GETFELSUMMARYRESULTS;
//				summaryList = generateGridSummaryReportQuery(reportVo,
//						summaryReportQuery);*/
//				  if(reportVo.getReportFrequency().equalsIgnoreCase("Hourly")){
//						summaryReportQuery = ActionConstants.GET_FELSUMMARYRESULTS_HOURLY;
//						summaryList = generateGridSummaryReportQuery(reportVo,
//								summaryReportQuery);
//						}
//					if(reportVo.getReportFrequency().equalsIgnoreCase("Daily")){
//						summaryReportQuery = ActionConstants.GET_FELSUMMARYRESULTS_DAILY;
//						summaryList = generateGridSummaryReportQuery(reportVo,
//								summaryReportQuery);
//						}
//					if(reportVo.getReportFrequency().equalsIgnoreCase("Weekly")){
//						summaryReportQuery = ActionConstants.GET_FELSUMMARYRESULTS_WEEKLY;
//						summaryList = generateGridSummaryReportQuery(reportVo,
//								summaryReportQuery);
//						}
//					if(reportVo.getReportFrequency().equalsIgnoreCase("Monthly")){
//						summaryReportQuery = ActionConstants.GET_FELSUMMARYRESULTS_MONTHLY;
//						summaryList = generateGridSummaryReportQuery(reportVo,
//								summaryReportQuery);
//						}
//			}
//
//			else if (reportVo.getProductCodeList().equalsIgnoreCase("COR")) {
//				/*summaryReportQuery = ActionConstants.GETCORSUMMARYRESULTS;
//				summaryList = generateGridSummaryReportQuery(reportVo,
//						summaryReportQuery);*/
//				 if(reportVo.getReportFrequency().equalsIgnoreCase("Hourly")){
//						summaryReportQuery = ActionConstants.GET_CORSUMMARYRESULTS_HOURLY;
//						summaryList = generateGridSummaryReportQuery(reportVo,
//								summaryReportQuery);
//						}
//					if(reportVo.getReportFrequency().equalsIgnoreCase("Daily")){
//						summaryReportQuery = ActionConstants.GET_CORSUMMARYRESULTS_DAILY;
//						summaryList = generateGridSummaryReportQuery(reportVo,
//								summaryReportQuery);
//						}
//					if(reportVo.getReportFrequency().equalsIgnoreCase("Weekly")){
//						summaryReportQuery = ActionConstants.GET_CORSUMMARYRESULTS_WEEKLY;
//						summaryList = generateGridSummaryReportQuery(reportVo,
//								summaryReportQuery);
//						}
//					if(reportVo.getReportFrequency().equalsIgnoreCase("Monthly")){
//						summaryReportQuery = ActionConstants.GET_CORSUMMARYRESULTS_MONTHLY;
//						summaryList = generateGridSummaryReportQuery(reportVo,
//								summaryReportQuery);
//						}
//			}
//
//			else if (reportVo.getProductCodeList().equalsIgnoreCase("ALL")) {
////				summaryReportQuery = ActionConstants.GETALLSUMMARYRESULTS;
////				summaryList = generateGridSummaryReportQuery(reportVo,
////						summaryReportQuery);
//				
//				
//				 if(reportVo.getReportFrequency().equalsIgnoreCase("Hourly")){
//						summaryReportQuery = ActionConstants.GETALLSUMMARYRESULTS_HOURLY;
//						summaryList = generateGridSummaryReportQuery(reportVo,
//								summaryReportQuery);
//						}
//					if(reportVo.getReportFrequency().equalsIgnoreCase("Daily")){
//						summaryReportQuery = ActionConstants.GETALLSUMMARYRESULTS_DAILY;
//						summaryList = generateGridSummaryReportQuery(reportVo,
//								summaryReportQuery);
//						}
//					if(reportVo.getReportFrequency().equalsIgnoreCase("Weekly")){
//						summaryReportQuery = ActionConstants.GETALLSUMMARYRESULTS_WEEKLY;
//						summaryList = generateGridSummaryReportQuery(reportVo,
//								summaryReportQuery);
//						}
//					if(reportVo.getReportFrequency().equalsIgnoreCase("Monthly")){
//						summaryReportQuery = ActionConstants.GETALLSUMMARYRESULTS_MONTHLY;
//						summaryList = generateGridSummaryReportQuery(reportVo,
//								summaryReportQuery);
//						}
//				
//			}
//
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//		logger.info(ActionConstants.EXITING_METHOD
//				+ "<<generateSummaryReportInGrid DAO");
//		return summaryList;
//	}

	/*
	 * public List<ReportVO> generateDetailedTableReport(ReportVO reportVo)
	 * throws Exception { logger.info(ActionConstants.ENTERING_METHOD +
	 * "<<generateDetailedTableReport DAO"); List<ReportVO> detailedList = null;
	 * 
	 * try {
	 * 
	 * DBHelper aDBHelper = new DBHelper(); CommonMethods aCommonMethods = new
	 * CommonMethods(); String query = "";
	 * 
	 * query = ActionConstants.GETDETAILEDRESULTS;
	 * 
	 * if (aCommonMethods.isValueAvailable(reportVo.getProductCodeList())) {
	 * query = query + " WHERE TRANSACTION_TYPE LIKE '%" +
	 * reportVo.getProductCodeList() + "%'"; }
	 * 
	 * if (aCommonMethods.isValueAvailable(reportVo.getSolID())) { query = query
	 * + " AND SOL_ID LIKE '%" + reportVo.getSolID() + "%'"; }
	 * 
	 * if (aCommonMethods.isValueAvailable(reportVo.getCurrency())) { query =
	 * query + " AND CURRENCY LIKE '%" + reportVo.getCurrency() + "%'"; }
	 * 
	 * if (aCommonMethods.isValueAvailable(reportVo.getRstatusFilter())) { query
	 * = query + " AND STATUS LIKE '%" + reportVo.getRstatusFilter() + "%'"; }
	 * 
	 * if (aCommonMethods.isValueAvailable(reportVo.getUserIdList())) { query =
	 * query + " AND STATUS_CHANGED_BY LIKE '%" +
	 * reportVo.getUserIdList().trim() + "%'"; } if
	 * (aCommonMethods.isValueAvailable(reportVo.getFromDateFilter()) &&
	 * aCommonMethods.isValueAvailable(reportVo .getToDateFilter())) { query =
	 * query + " AND TRANSACTION_GENERATE_TIME BETWEEN '" +
	 * reportVo.getFromDateFilter() + "' AND '" + reportVo.getToDateFilter() +
	 * "'";
	 * 
	 * }
	 * 
	 * if (!aCommonMethods.isValueAvailable(reportVo.getFromDateFilter()) &&
	 * aCommonMethods.isValueAvailable(reportVo .getToDateFilter())) { query =
	 * query + " AND TRANSACTION_GENERATE_TIME BETWEEN '01-01-2019'" + " AND '"
	 * + reportVo.getToDateFilter() + "'";
	 * reportVo.setFromDateFilter("01-01-2019"); }
	 * 
	 * if (aCommonMethods.isValueAvailable(reportVo.getFromDateFilter()) &&
	 * !aCommonMethods.isValueAvailable(reportVo .getToDateFilter())) { query =
	 * query + " AND TRANSACTION_GENERATE_TIME BETWEEN '" +
	 * reportVo.getFromDateFilter() + "' AND sysdate"; try {
	 * 
	 * SimpleDateFormat formatter = new SimpleDateFormat( "dd-MM-yyyy"); Date
	 * date = new Date(); System.out.println("date" + formatter.format(date));
	 * reportVo.setToDateFilter(formatter.format(date)); } catch (Exception e) {
	 * 
	 * }
	 * 
	 * } System.out.println("query" + query); detailedList =
	 * aDBHelper.generateDetailedTableReport(query, reportVo); } catch
	 * (Exception e) { e.printStackTrace(); }
	 * logger.info(ActionConstants.EXITING_METHOD +
	 * "<<generateDetailedTableReport DAO"); return detailedList; }
	 */

	/*
	 * public void generateReportInExcel(ReportVO reportVo) throws Exception {
	 * 
	 * logger.info(ActionConstants.ENTERING_METHOD +
	 * "<<generateReportInExcel DAO"); CommonMethods aCommonMethods = new
	 * CommonMethods(); try { if
	 * (reportVo.getProductCodeList().equalsIgnoreCase("ILC")) { if
	 * (aCommonMethods.isValueAvailable(reportVo .getReportCheckList()) &&
	 * reportVo.getReportCheckList().equalsIgnoreCase("D")) {
	 * 
	 * generateILCDetailedReportInExcel(reportVo); } else if
	 * (aCommonMethods.isValueAvailable(reportVo .getReportCheckList()) &&
	 * reportVo.getReportCheckList().equalsIgnoreCase("S")) {
	 * generateILCSummaryReportInExcel(reportVo); }
	 * 
	 * }
	 * 
	 * } catch (Exception e) { e.printStackTrace(); }
	 * logger.info(ActionConstants.EXITING_METHOD +
	 * "<<generateReportInExcel DAO"); }
	 */
	/*
	 * public void generateILCSummaryReportInExcel(ReportVO reportVo) throws
	 * Exception { logger.info(ActionConstants.ENTERING_METHOD +
	 * "<<generateILCSummaryReportInExcel DAO");
	 * 
	 * CommonMethods aCommonMethods = new CommonMethods(); try {
	 * 
	 * String query = ""; query = ActionConstants.GETSUMMARYRESULTS;
	 * 
	 * if (aCommonMethods.isValueAvailable(reportVo.getProductCodeList())) {
	 * query = query + " WHERE TRANSTYPE LIKE '%" +
	 * reportVo.getProductCodeList() + "%'"; }
	 * 
	 * if (aCommonMethods.isValueAvailable(reportVo.getSolID())) { query = query
	 * + " AND SOLID LIKE '%" + reportVo.getSolID() + "%'"; }
	 * 
	 * if (aCommonMethods.isValueAvailable(reportVo.getCurrency())) { query =
	 * query + " AND CURRENCY LIKE '%" + reportVo.getCurrency() + "%'"; }
	 * 
	 * if (aCommonMethods.isValueAvailable(reportVo.getRstatusFilter())) { query
	 * = query + " AND TRANS_STATUS LIKE '%" + reportVo.getRstatusFilter() +
	 * "%'"; }
	 * 
	 * if (aCommonMethods.isValueAvailable(reportVo.getUserIdList())) { query =
	 * query + " AND USERNAME LIKE '%" + reportVo.getUserIdList() + "%'"; }
	 * 
	 * if (aCommonMethods.isValueAvailable(reportVo.getFromDateFilter()) &&
	 * aCommonMethods.isValueAvailable(reportVo .getToDateFilter())) { query =
	 * query + " AND TRANSACTION_GENERATE_TIME BETWEEN '" +
	 * reportVo.getFromDateFilter() + "' AND '" + reportVo.getToDateFilter() +
	 * "'"; }
	 * 
	 * System.out.println("query------------" + query);
	 * 
	 * // Uncomment after getting query from BOB starts
	 * aDBHelper.generateSummaryReportInExcel(query); // Uncomment after getting
	 * query from BOB ends
	 * 
	 * } catch (Exception e) { e.printStackTrace(); }
	 * logger.info(ActionConstants.EXITING_METHOD +
	 * "<<generateILCSummaryReportInExcel DAO"); }
	 */

	/*
	 * public void generateILCDetailedReportInExcel(ReportVO reportVo) throws
	 * Exception { logger.info(ActionConstants.ENTERING_METHOD +
	 * "<<generateILCDetailedReportInExcel DAO"); DBHelper aDBHelper = new
	 * DBHelper(); CommonMethods aCommonMethods = new CommonMethods(); try {
	 * 
	 * String query = ""; query = ActionConstants.GETDETAILEDRESULTS;
	 * 
	 * if (aCommonMethods.isValueAvailable(reportVo.getProductCodeList())) {
	 * query = query + " WHERE TRANSACTION_TYPE LIKE '%" +
	 * reportVo.getProductCodeList() + "%'"; }
	 * 
	 * if (aCommonMethods.isValueAvailable(reportVo.getSolID())) { query = query
	 * + " AND SOL_ID LIKE '%" + reportVo.getSolID() + "%'"; }
	 * 
	 * if (aCommonMethods.isValueAvailable(reportVo.getCurrency())) { query =
	 * query + " AND CURRENCY LIKE '%" + reportVo.getCurrency() + "%'"; }
	 * 
	 * if (aCommonMethods.isValueAvailable(reportVo.getRstatusFilter())) { query
	 * = query + " AND STATUS LIKE '%" + reportVo.getRstatusFilter() + "%'"; }
	 * 
	 * if (aCommonMethods.isValueAvailable(reportVo.getUserIdList())) { query =
	 * query + " AND STATUS_CHANGED_BY LIKE '%" +
	 * reportVo.getUserIdList().trim() + "%'"; } if
	 * (aCommonMethods.isValueAvailable(reportVo.getFromDateFilter()) &&
	 * aCommonMethods.isValueAvailable(reportVo .getToDateFilter())) {
	 * 
	 * query = query + " AND TRANSACTION_GENERATE_TIME BETWEEN '" +
	 * reportVo.getFromDateFilter() + "' AND '" + reportVo.getToDateFilter() +
	 * "'"; } if (!aCommonMethods.isValueAvailable(reportVo.getFromDateFilter())
	 * && aCommonMethods.isValueAvailable(reportVo .getToDateFilter())) { query
	 * = query + " AND TRANSACTION_GENERATE_TIME BETWEEN '01-01-2019'" +
	 * " AND '" + reportVo.getToDateFilter() + "'";
	 * reportVo.setFromDateFilter("01-01-2019"); }
	 * 
	 * if (aCommonMethods.isValueAvailable(reportVo.getFromDateFilter()) &&
	 * !aCommonMethods.isValueAvailable(reportVo .getToDateFilter())) { query =
	 * query + " AND TRANSACTION_GENERATE_TIME BETWEEN '" +
	 * reportVo.getFromDateFilter() + "' AND sysdate"; try {
	 * 
	 * SimpleDateFormat formatter = new SimpleDateFormat( "dd-MM-yyyy"); Date
	 * date = new Date(); System.out.println("date" + formatter.format(date));
	 * reportVo.setToDateFilter(formatter.format(date)); } catch (Exception e) {
	 * 
	 * } } aDBHelper.generateDetailedReportInExcel(query);
	 * 
	 * } catch (Exception e) { e.printStackTrace(); }
	 * logger.info(ActionConstants.EXITING_METHOD +
	 * "<<generateILCDetailedReportInExcel DAO"); }
	 */
//	public void generateILCDetailedReportInExcel(ReportVO reportVo)
//			throws Exception {
//
//		logger.info(ActionConstants.ENTERING_METHOD
//				+ "<<generateILCDetailedReportInExcel DAO");
//
//		DBHelper aDBHelper = new DBHelper();
//		CommonMethods aCommonMethods = new CommonMethods();
//
//		try {
//
//			String ilcDetailedReportQuery = "";
//
//			ilcDetailedReportQuery = ActionConstants.GETILCDETAILEDRESULTS;
//
//			if (aCommonMethods.isValueAvailable(reportVo.getProductCodeList())) {
//				ilcDetailedReportQuery = ilcDetailedReportQuery
//						+ " WHERE TRANSACTION_TYPE LIKE '%"
//						+ reportVo.getProductCodeList().trim() + "%'";
//			}
//
//			if (aCommonMethods.isValueAvailable(reportVo.getSolID())) {
//				ilcDetailedReportQuery = ilcDetailedReportQuery
//						+ " AND SOL_ID LIKE '%" + reportVo.getSolID().trim()
//						+ "%'";
//			}
//
//			if (aCommonMethods.isValueAvailable(reportVo.getCurrency())) {
//				ilcDetailedReportQuery = ilcDetailedReportQuery
//						+ " AND CURRENCY LIKE '%"
//						+ reportVo.getCurrency().trim() + "%'";
//			}
//
//			if (aCommonMethods.isValueAvailable(reportVo.getRstatusFilter())) {
//				ilcDetailedReportQuery = ilcDetailedReportQuery
//						+ " AND STATUS LIKE '%"
//						+ reportVo.getRstatusFilter().trim() + "%'";
//			}
//
//			/*
//			 * if (aCommonMethods.isValueAvailable(reportVo.getUserIdList())) {
//			 * ilcDetailedReportQuery = ilcDetailedReportQuery +
//			 * " AND STATUS_CHANGED_BY LIKE '%" +
//			 * reportVo.getUserIdList().trim() + "%'"; }
//			 */
//
//			if (aCommonMethods.isValueAvailable(reportVo.getUserIdList())) {
//				ilcDetailedReportQuery = ilcDetailedReportQuery
//						+ " AND (INPUTUSER LIKE '%"
//						+ reportVo.getUserIdList().trim() + "%'"
//						+ " OR REVIEWUSER LIKE '%"
//						+ reportVo.getUserIdList().trim() + "%'"
//						+ " OR AUTHUSER LIKE '%"
//						+ reportVo.getUserIdList().trim() + "%'"
//						+ " OR FBOMAKER LIKE '%"
//						+ reportVo.getUserIdList().trim() + "%'"
//						+ " OR FBOCHECKER LIKE '%"
//						+ reportVo.getUserIdList().trim() + "%')";
//			}
//			if (aCommonMethods.isValueAvailable(reportVo.getFromDateFilter())
//					&& aCommonMethods.isValueAvailable(reportVo
//							.getToDateFilter())) {
//
//				ilcDetailedReportQuery = ilcDetailedReportQuery
//						+ " AND  trunc(TRANSACTION_GENERATE_TIME) BETWEEN "
//						+ "to_date('" + reportVo.getFromDateFilter()
//						+ "','dd-mm-yyyy') AND " + "to_date( '"
//						+ reportVo.getToDateFilter() + "','dd-mm-yyyy')";
//			}
//			if (!aCommonMethods.isValueAvailable(reportVo.getFromDateFilter())
//					&& aCommonMethods.isValueAvailable(reportVo
//							.getToDateFilter())) {
//				ilcDetailedReportQuery = ilcDetailedReportQuery
//						+ " AND trunc(TRANSACTION_GENERATE_TIME) BETWEEN '01-01-2019'"
//						+ " AND '" + reportVo.getToDateFilter() + "'";
//				reportVo.setFromDateFilter("01-01-2019");
//			}
//
//			if (aCommonMethods.isValueAvailable(reportVo.getFromDateFilter())
//					&& !aCommonMethods.isValueAvailable(reportVo
//							.getToDateFilter())) {
//				ilcDetailedReportQuery = ilcDetailedReportQuery
//						+ " AND trunc(TRANSACTION_GENERATE_TIME) BETWEEN '"
//						+ reportVo.getFromDateFilter() + "' AND sysdate";
//				try {
//
//					SimpleDateFormat aSimpleDateFormat = new SimpleDateFormat(
//							"dd-MM-yyyy");
//					Date aDate = new Date();
//					reportVo.setToDateFilter(aSimpleDateFormat.format(aDate));
//				} catch (Exception e) {
//					e.printStackTrace();
//				}
//			}
//
//			logger.info("Getting ILC Detailed Report Query (Excel) ==> "
//					+ ilcDetailedReportQuery);
//			aDBHelper.generateILCDetailedReportInExcel(ilcDetailedReportQuery);
//
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//		logger.info(ActionConstants.EXITING_METHOD
//				+ "<<generateILCDetailedReportInExcel DAO");
//	}

	// Report 23012020 ends

	/*
	 * public List<TFBOReminderVO> fetchReminderDetails(TFBOReminderVO
	 * reminderVo) throws Exception {
	 * 
	 * DBHelper aDBHelper = new DBHelper(); List<TFBOReminderVO> reminder = new
	 * LinkedList<TFBOReminderVO>(); try { reminder = aDBHelper
	 * .getTFBOIReminderDetailsFromDB(ActionConstants.GETREMINDERDETAILS_QUERY);
	 * reminderVo.setReminderList(reminder); //
	 * setReminderValuesInVO(reminderVo); System.out.println("-----size--11---"
	 * + reminder.size());
	 * 
	 * } catch (Exception e) { e.printStackTrace(); }
	 * 
	 * return reminder;
	 * 
	 * }
	 */
	public List<TFBOReminderVO> fetchReminderDetails(TFBOReminderVO reminderVo,
			UserTransactionVO userVo) throws Exception {

		DBHelper aDBHelper = new DBHelper();
		String productCode = userVo.getProductCode();

		List<TFBOReminderVO> reminder = new LinkedList<TFBOReminderVO>();
		try {
			reminder = aDBHelper.getTFBOIReminderDetailsFromDB(
					ActionConstants.GETREMINDERDETAILS_QUERY, productCode);
			reminderVo.setReminderList(reminder);
			// setReminderValuesInVO(reminderVo);
			System.out.println("-----size--11---" + reminder.size());

		} catch (Exception e) {
			e.printStackTrace();
		}

		return reminder;

	}

	public int sentMailtoReminder(TFBOReminderVO reminderVO) {
		TFBOEmailProcessDAO aTFBOEmailProcessDAO = new TFBOEmailProcessDAO();
		EmailProcessManager aEmailProcessManager = new EmailProcessManager();
		List<String> emaillist = new ArrayList<>();
		CommonMethods aCommonMethods = new CommonMethods();
		int value = 0;
		Properties aProperties;
		try {
			aProperties = PropertyUtil.getPropertiesValue();
			String emailUserId = "";
			String emailPassword = "";
			String mailBody = "";
			String mailSubject = "";
			String DefaultCustomerId = "";
			String emailAddresss = "";
			String[] toEmailId = null;
			// Object cusDetails = null;
			emailUserId = aProperties.getProperty("EmailUserId");
			emailPassword = aProperties.getProperty("EmailPassword");
			DefaultCustomerId = aProperties.getProperty("DefaultCustomerId");
			// emailAddresss = "tf.ops.bcc@bankofbaroda.co.in";
			emaillist.add("tf.ops.bcc@bankofbaroda.co.in");
			emaillist.add("cbt.tf.bcc@bankofbaroda.com");

			for (String email : emaillist) {
				toEmailId = email.split(",|\\;");
				logger.info("toEmailId-->" + toEmailId);

				mailSubject = aTFBOEmailProcessDAO
						.getMailSubjectToReminder(reminderVO);
				mailBody = aTFBOEmailProcessDAO
						.getMailBodyToReminder(reminderVO);
				aEmailProcessManager.sendMail(emailUserId, emailPassword,
						toEmailId, mailSubject, mailBody);
				logger.info("Mail body-->" + mailBody);

			}
			value = 1;
		} catch (Exception e) {

			e.printStackTrace();
			return value;
		}
		logger.info(ActionConstants.EXITING_METHOD);
		return value;
	}

	public List<TFBOReminderVO> getcustomerDetails(TFBOReminderVO reminderVo) {
		System.out.println("-------->Entering DB method<------");
		DBHelper aDBHelper = new DBHelper();
		List<TFBOReminderVO> reminderCust = new LinkedList<TFBOReminderVO>();
		try {
			if (reminderVo.getProductCode().equalsIgnoreCase("ILC")) {
				if ((reminderVo).getEventCode().equalsIgnoreCase("POCD")) {
					reminderCust = aDBHelper
							.getcusDetailsFromDB(
									reminderVo.requestId,
									ActionConstants.GETCUSTDETAILSREMINDERILC_POCD_QUERY);
					reminderVo.setReminderList(reminderCust);
				}
				if ((reminderVo).getEventCode().equalsIgnoreCase("NAMI")) {
					reminderCust = aDBHelper
							.getcusDetailsFromDB(
									reminderVo.requestId,
									ActionConstants.GETCUSTDETAILSREMINDERILC_NAMI_QUERY);
					reminderVo.setReminderList(reminderCust);
				}
				if ((reminderVo).getEventCode().equalsIgnoreCase("POCA")) {
					reminderCust = aDBHelper
							.getcusDetailsFromDB(
									reminderVo.requestId,
									ActionConstants.GETCUSTDETAILSREMINDERILC_POCA_QUERY);
					reminderVo.setReminderList(reminderCust);
				}
				if ((reminderVo).getEventCode().equalsIgnoreCase("CRC")) {
					reminderCust = aDBHelper
							.getcusDetailsFromDB(
									reminderVo.requestId,
									ActionConstants.GETCUSTDETAILSREMINDERILC_CRC_QUERY);
					reminderVo.setReminderList(reminderCust);
				}
				if ((reminderVo).getEventCode().equalsIgnoreCase("POCP")) {
					reminderCust = aDBHelper
							.getcusDetailsFromDB(
									reminderVo.requestId,
									ActionConstants.GETCUSTDETAILSREMINDERILC_POCP_QUERY);
					reminderVo.setReminderList(reminderCust);
				}
				if ((reminderVo).getEventCode().equalsIgnoreCase("ISI")) {
					reminderCust = aDBHelper
							.getcusDetailsFromDB(
									reminderVo.requestId,
									ActionConstants.GETCUSTDETAILSREMINDERILC_ISI_QUERY);
					reminderVo.setReminderList(reminderCust);
				}
				if ((reminderVo).getEventCode().equalsIgnoreCase("COI")) {
					reminderCust = aDBHelper
							.getcusDetailsFromDB(
									reminderVo.requestId,
									ActionConstants.GETCUSTDETAILSREMINDERILC_COI_QUERY);
					reminderVo.setReminderList(reminderCust);
				}

			}
			if (reminderVo.getProductCode().equalsIgnoreCase("ELC")) {
				if ((reminderVo).getEventCode().equalsIgnoreCase("COE")) {
					reminderCust = aDBHelper
							.getcusDetailsFromDB(
									reminderVo.requestId,
									ActionConstants.GETCUSTDETAILSREMINDERELC_COE_QUERY);
					reminderVo.setReminderList(reminderCust);
				}
				if ((reminderVo).getEventCode().equalsIgnoreCase("NAMI")) {
					reminderCust = aDBHelper
							.getcusDetailsFromDB(
									reminderVo.requestId,
									ActionConstants.GETCUSTDETAILSREMINDERELC_NAMI_QUERY);
					reminderVo.setReminderList(reminderCust);
				}
				if ((reminderVo).getEventCode().equalsIgnoreCase("NAME")) {
					reminderCust = aDBHelper
							.getcusDetailsFromDB(
									reminderVo.requestId,
									ActionConstants.GETCUSTDETAILSREMINDERELC_NAME_QUERY);
					reminderVo.setReminderList(reminderCust);
				}
				if ((reminderVo).getEventCode().equalsIgnoreCase("PODP")) {
					reminderCust = aDBHelper
							.getcusDetailsFromDB(
									reminderVo.requestId,
									ActionConstants.GETCUSTDETAILSREMINDERELC_PODP_QUERY);
					reminderVo.setReminderList(reminderCust);
				}
				if ((reminderVo).getEventCode().equalsIgnoreCase("PODA")) {
					reminderCust = aDBHelper
							.getcusDetailsFromDB(
									reminderVo.requestId,
									ActionConstants.GETCUSTDETAILSREMINDERELC_PODA_QUERY);
					reminderVo.setReminderList(reminderCust);
				}
				if ((reminderVo).getEventCode().equalsIgnoreCase("ADE")) {
					reminderCust = aDBHelper
							.getcusDetailsFromDB(
									reminderVo.requestId,
									ActionConstants.GETCUSTDETAILSREMINDERELC_ADE_QUERY);
					reminderVo.setReminderList(reminderCust);
				}
				if ((reminderVo).getEventCode().equalsIgnoreCase("DOP")) {
					reminderCust = aDBHelper
							.getcusDetailsFromDB(
									reminderVo.requestId,
									ActionConstants.GETCUSTDETAILSREMINDERELC_DOP_QUERY);
					reminderVo.setReminderList(reminderCust);
				}

			}
			if (reminderVo.getProductCode().equalsIgnoreCase("FEL")) {
				if ((reminderVo).getEventCode().equalsIgnoreCase("CRYST")) {
					reminderCust = aDBHelper
							.getcusDetailsFromDB(
									reminderVo.requestId,
									ActionConstants.GETCUSTDETAILSREMINDERFEL_CRYST_QUERY);
					reminderVo.setReminderList(reminderCust);
				}
				if ((reminderVo).getEventCode().equalsIgnoreCase("RSA4")) {
					reminderCust = aDBHelper
							.getcusDetailsFromDB(
									reminderVo.requestId,
									ActionConstants.GETCUSTDETAILSREMINDERFEL_RSA4_QUERY);
					reminderVo.setReminderList(reminderCust);
				}
				if ((reminderVo).getEventCode().equalsIgnoreCase("CSA4")) {
					reminderCust = aDBHelper
							.getcusDetailsFromDB(
									reminderVo.requestId,
									ActionConstants.GETCUSTDETAILSREMINDERFEL_CSA4_QUERY);
					reminderVo.setReminderList(reminderCust);
				}
				if ((reminderVo).getEventCode().equalsIgnoreCase("JSA4")) {
					reminderCust = aDBHelper
							.getcusDetailsFromDB(
									reminderVo.requestId,
									ActionConstants.GETCUSTDETAILSREMINDERFEL_JSA4_QUERY);
					reminderVo.setReminderList(reminderCust);
				}
				if ((reminderVo).getEventCode().equalsIgnoreCase("PSA4")) {
					reminderCust = aDBHelper
							.getcusDetailsFromDB(
									reminderVo.requestId,
									ActionConstants.GETCUSTDETAILSREMINDERFEL_PSA4_QUERY);
					reminderVo.setReminderList(reminderCust);
				}

			}
			if (reminderVo.getProductCode().equalsIgnoreCase("FOC")) {
				if ((reminderVo).getEventCode().equalsIgnoreCase("CSA1")) {
					reminderCust = aDBHelper
							.getcusDetailsFromDB(
									reminderVo.requestId,
									ActionConstants.GETCUSTDETAILSREMINDERFOC_CSAI1_QUERY);
					reminderVo.setReminderList(reminderCust);
				}
				if ((reminderVo).getEventCode().equalsIgnoreCase("PSA1")) {
					reminderCust = aDBHelper
							.getcusDetailsFromDB(
									reminderVo.requestId,
									ActionConstants.GETCUSTDETAILSREMINDERFOC_PSA1_QUERY);
					reminderVo.setReminderList(reminderCust);
				}
				if ((reminderVo).getEventCode().equalsIgnoreCase("RSA1")) {
					reminderCust = aDBHelper
							.getcusDetailsFromDB(
									reminderVo.requestId,
									ActionConstants.GETCUSTDETAILSREMINDERFOC_RSA1_QUERY);
					reminderVo.setReminderList(reminderCust);
				}
				if ((reminderVo).getEventCode().equalsIgnoreCase("CRYST")) {
					reminderCust = aDBHelper
							.getcusDetailsFromDB(
									reminderVo.requestId,
									ActionConstants.GETCUSTDETAILSREMINDERFOC_CRYST_QUERY);
					reminderVo.setReminderList(reminderCust);
				}
				if ((reminderVo).getEventCode().equalsIgnoreCase("JSA1")) {
					reminderCust = aDBHelper
							.getcusDetailsFromDB(
									reminderVo.requestId,
									ActionConstants.GETCUSTDETAILSREMINDERFOC_JSA1_QUERY);
					reminderVo.setReminderList(reminderCust);
				}

			}
			if (reminderVo.getProductCode().equalsIgnoreCase("FSA")) {
				if ((reminderVo).getEventCode().equalsIgnoreCase("JSA")) {
					reminderCust = aDBHelper
							.getcusDetailsFromDB(
									reminderVo.requestId,
									ActionConstants.GETCUSTDETAILSREMINDERFSA_JSA_QUERY);
					reminderVo.setReminderList(reminderCust);
				}
				if ((reminderVo).getEventCode().equalsIgnoreCase("CSA")) {
					reminderCust = aDBHelper
							.getcusDetailsFromDB(
									reminderVo.requestId,
									ActionConstants.GETCUSTDETAILSREMINDERFSA_CSA_QUERY);
					reminderVo.setReminderList(reminderCust);
				}
				if ((reminderVo).getEventCode().equalsIgnoreCase("RSA")) {
					reminderCust = aDBHelper
							.getcusDetailsFromDB(
									reminderVo.requestId,
									ActionConstants.GETCUSTDETAILSREMINDERFSA_RSA_QUERY);
					reminderVo.setReminderList(reminderCust);
				}
			}
			if (reminderVo.getProductCode().equalsIgnoreCase("IDC")) {
				if ((reminderVo).getEventCode().equalsIgnoreCase("CRE")) {
					reminderCust = aDBHelper
							.getcusDetailsFromDB(
									reminderVo.requestId,
									ActionConstants.GETCUSTDETAILSREMINDERIDC_CRE_QUERY);
					reminderVo.setReminderList(reminderCust);
				}
				if ((reminderVo).getEventCode().equalsIgnoreCase("CAC")) {
					reminderCust = aDBHelper
							.getcusDetailsFromDB(
									reminderVo.requestId,
									ActionConstants.GETCUSTDETAILSREMINDERIDC_CAC_QUERY);
					reminderVo.setReminderList(reminderCust);
				}
				if ((reminderVo).getEventCode().equalsIgnoreCase("CLP")) {
					reminderCust = aDBHelper
							.getcusDetailsFromDB(
									reminderVo.requestId,
									ActionConstants.GETCUSTDETAILSREMINDERIDC_CLP_QUERY);
					reminderVo.setReminderList(reminderCust);
				}
				if ((reminderVo).getEventCode().equalsIgnoreCase("CCO")) {
					reminderCust = aDBHelper
							.getcusDetailsFromDB(
									reminderVo.requestId,
									ActionConstants.GETCUSTDETAILSREMINDERIDC_CCO_QUERY);
					reminderVo.setReminderList(reminderCust);
				}
			}
			if (reminderVo.getProductCode().equalsIgnoreCase("IGT")) {
				if ((reminderVo).getEventCode().equalsIgnoreCase("OIG")) {
					reminderCust = aDBHelper
							.getcusDetailsFromDB(
									reminderVo.requestId,
									ActionConstants.GETCUSTDETAILSREMINDERIGT_OIG_QUERY);
					reminderVo.setReminderList(reminderCust);
				}
				if ((reminderVo).getEventCode().equalsIgnoreCase("LIG")) {
					reminderCust = aDBHelper
							.getcusDetailsFromDB(
									reminderVo.requestId,
									ActionConstants.GETCUSTDETAILSREMINDERIGT_LIG_QUERY);
					reminderVo.setReminderList(reminderCust);
				}
				if ((reminderVo).getEventCode().equalsIgnoreCase("NAIG")) {
					reminderCust = aDBHelper
							.getcusDetailsFromDB(
									reminderVo.requestId,
									ActionConstants.GETCUSTDETAILSREMINDERIGT_NAIG_QUERY);
					reminderVo.setReminderList(reminderCust);
				}
				if ((reminderVo).getEventCode().equalsIgnoreCase("IIG")) {
					reminderCust = aDBHelper
							.getcusDetailsFromDB(
									reminderVo.requestId,
									ActionConstants.GETCUSTDETAILSREMINDERIGT_IIG_QUERY);
					reminderVo.setReminderList(reminderCust);
				}
			}
			if (reminderVo.getProductCode().equalsIgnoreCase("ISB")) {
				if ((reminderVo).getEventCode().equalsIgnoreCase("NJIS")) {
					reminderCust = aDBHelper
							.getcusDetailsFromDB(
									reminderVo.requestId,
									ActionConstants.GETCUSTDETAILSREMINDERISB_NJIS_QUERY);
					reminderVo.setReminderList(reminderCust);
				}
				if ((reminderVo).getEventCode().equalsIgnoreCase("IIS")) {
					reminderCust = aDBHelper
							.getcusDetailsFromDB(
									reminderVo.requestId,
									ActionConstants.GETCUSTDETAILSREMINDERISB_IIS_QUERY);
					reminderVo.setReminderList(reminderCust);
				}
				if ((reminderVo).getEventCode().equalsIgnoreCase("LIS")) {
					reminderCust = aDBHelper
							.getcusDetailsFromDB(
									reminderVo.requestId,
									ActionConstants.GETCUSTDETAILSREMINDERISB_LIS_QUERY);
					reminderVo.setReminderList(reminderCust);
				}
				if ((reminderVo).getEventCode().equalsIgnoreCase("OIS")) {
					reminderCust = aDBHelper
							.getcusDetailsFromDB(
									reminderVo.requestId,
									ActionConstants.GETCUSTDETAILSREMINDERISB_OIS_QUERY);
					reminderVo.setReminderList(reminderCust);
				}
				if ((reminderVo).getEventCode().equalsIgnoreCase("NAIS")) {
					reminderCust = aDBHelper
							.getcusDetailsFromDB(
									reminderVo.requestId,
									ActionConstants.GETCUSTDETAILSREMINDERISB_NAIS_QUERY);
					reminderVo.setReminderList(reminderCust);
				}
			}
			if (reminderVo.getProductCode().equalsIgnoreCase("ODC")) {
				System.out.println("Entering into ODC-------->");
				if ((reminderVo).getEventCode().equalsIgnoreCase("CAC")) {
					reminderCust = aDBHelper
							.getcusDetailsFromDB(
									reminderVo.requestId,
									ActionConstants.GETCUSTDETAILSREMINDERODC_CAC_QUERY);
					reminderVo.setReminderList(reminderCust);
				}
				if ((reminderVo).getEventCode().equalsIgnoreCase("CRE")) {
					reminderCust = aDBHelper
							.getcusDetailsFromDB(
									reminderVo.requestId,
									ActionConstants.GETCUSTDETAILSREMINDERODC_CRE_QUERY);
					reminderVo.setReminderList(reminderCust);
				}
				if ((reminderVo).getEventCode().equalsIgnoreCase("CCO")) {
					reminderCust = aDBHelper
							.getcusDetailsFromDB(
									reminderVo.requestId,
									ActionConstants.GETCUSTDETAILSREMINDERODC_CCO_QUERY);
					reminderVo.setReminderList(reminderCust);
				}
				if ((reminderVo).getEventCode().equalsIgnoreCase("CLP")) {
					System.out.println("Entering into CLP-------->");

					System.out.println("-----re ID------"
							+ reminderVo.requestId);
					reminderCust = aDBHelper
							.getcusDetailsFromDB(
									reminderVo.requestId,
									ActionConstants.GETCUSTDETAILSREMINDERODC_CLP_QUERY);
					reminderVo.setReminderList(reminderCust);
				}
			}

			if (reminderVo.getProductCode().equalsIgnoreCase("MIS")) {
				if ((reminderVo).getEventCode().equalsIgnoreCase("MCRE")) {
					reminderCust = aDBHelper
							.getcusDetailsFromDB(
									reminderVo.requestId,
									ActionConstants.GETCUSTDETAILSREMINDERMIS_MCRE_QUERY);
					reminderVo.setReminderList(reminderCust);
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return reminderCust;
	}

	/* ADDED BY CHANDRU FOR IDC/ODC FLOW ON 29012020 */

	public void updateTFBOOdcFlow(String requestId, String direct,
			String mtReceived, String partPayment, String prodTypeIDC,
			String finSameDay) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		DBHelper aDBHelper = new DBHelper();

		// // CHANGED BY CHANDRU
		// if (direct != null && !direct.trim().equals("")) {
		// if (direct.equals("true")) {
		// direct = "Y";
		// } else {
		// direct = "N";
		// }
		// }
		// // ENDS

		aDBHelper.setValueODCFlow(prodTypeIDC, direct, mtReceived, finSameDay,
				partPayment, requestId,
				ActionConstants.GETUPDATETFBOODCFLOW_QUERY);
		logger.info(ActionConstants.EXITING_METHOD);
	}

	public void updateTFBOIdcFlow(String requestId, String direct,
			String prodTypeIDC) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		DBHelper aDBHelper = new DBHelper();

		// // CHANGED BY CHANDRU
		// if (direct != null && !direct.trim().equals("")) {
		// if (direct.equals("true")) {
		// direct = "Y";
		// } else {
		// direct = "N";
		// }
		// }
		// // ENDS

		aDBHelper.setValueIDCFlow(prodTypeIDC, direct, requestId,
				ActionConstants.GETUPDATETFBOIDCFLOW_QUERY);
		logger.info(ActionConstants.EXITING_METHOD);
	}

	public void updateTFBOELCFlow(String requestId, String finSameDay,
			String prodType) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		DBHelper aDBHelper = new DBHelper();

		// // CHANGED BY CHANDRU
		// if (direct != null && !direct.trim().equals("")) {
		// if (direct.equals("true")) {
		// direct = "Y";
		// } else {
		// direct = "N";
		// }
		// }
		// // ENDS

		aDBHelper.setValueELCFlow(prodType, finSameDay, requestId,
				ActionConstants.GETUPDATETFBOELCFLOW_QUERY);
		logger.info(ActionConstants.EXITING_METHOD);
	}

	/* ADDED BY CHANDRU FOR IDC/ODC FLOW ON 29012020 */

	public void insertIntoTFBOIDCODCFlow(String requestId, String prodCode,
			String eveCode) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		DBHelper aDBHelper = new DBHelper();
		aDBHelper.setValueInDB(requestId, prodCode, eveCode,
				ActionConstants.GETINSERTTFBOIDCODCFLOW_QUERY);
		logger.info(ActionConstants.EXITING_METHOD);
	}

	private void insertIntoTFBOISBCancel(String requestID) throws Exception {
		System.out.println(ActionConstants.ENTERING_METHOD);
		DBHelper aDBHelper = new DBHelper();
		aDBHelper.setValueInDB(requestID, ActionConstants.GETINSERTTFBOISBNIS);
		System.out.println(ActionConstants.EXITING_METHOD);
	}

	private void insertIntoTFBOISBClosure(String requestID) throws Exception {
		System.out.println(ActionConstants.ENTERING_METHOD);
		DBHelper aDBHelper = new DBHelper();
		aDBHelper.setValueInDB(requestID, ActionConstants.GETINSERTTFBOISBKIS);
		System.out.println(ActionConstants.EXITING_METHOD);

	}

	private void updateTFBOIsbcance(String requestId, String solID,
			String tiReferanceNo, String customeCif, String customeName,
			String tenure, String amount, String currency, String subProductCode)
			throws Exception {
		System.out.println(ActionConstants.ENTERING_METHOD);
		DBHelper aDBHelper = new DBHelper();
		aDBHelper.setValueInDB(tiReferanceNo, requestId,
				ActionConstants.GETUPDATETIREFERANCE_QUERY);
		aDBHelper.setISBCancelInDB(requestId, solID, tiReferanceNo, customeCif,
				customeName, tenure, amount, currency, subProductCode,
				ActionConstants.GETUPDATETFBOISB_CANCEL_QUERY);
		System.out.println(ActionConstants.EXITING_METHOD);

	}

	private void updateTFBOIsbclosuer(String requestId, String solID,
			String tiReferanceNo, String customeCif, String customeName,
			String tenure, String amount, String currency, String subProductCode)
			throws Exception {
		System.out.println(ActionConstants.ENTERING_METHOD);
		DBHelper aDBHelper = new DBHelper();
		aDBHelper.setValueInDB(tiReferanceNo, requestId,
				ActionConstants.GETUPDATETIREFERANCE_QUERY);
		aDBHelper.setISBClosurenDB(requestId, solID, tiReferanceNo, customeCif,
				customeName, tenure, amount, currency, subProductCode,
				ActionConstants.GETUPDATETFBOISB_CLOSURE_QUERY);
		System.out.println(ActionConstants.EXITING_METHOD);

	}

	public void updateTFBOTranLockStatus(UserTransactionVO userVo, String flag) {
		DBHelper aDBHelper = new DBHelper();
		try {
			if (userVo != null) {
				if (userVo.getRequestId() != null) {
					aDBHelper.setValueInDB(flag, userVo.getSessionUserName(),
							userVo.getRequestId(),
							ActionConstants.UPDATETRANSLOCK);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public boolean selectTFBOTranLockStatus(UserTransactionVO userVo,
			String flag) {
		DBHelper aDBHelper = new DBHelper();
		boolean lockFlag = false;
		try {
			String lockStatus = aDBHelper.getValueFromDB(userVo.getRequestId(),
					ActionConstants.SELECTTRANSLOCK);
			if (lockStatus != null && lockStatus.equals("1")) {
				lockFlag = true;
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return lockFlag;
	}

	public boolean selectTFBOTranLockStatus(UserTransactionVO userVo,
			String flag, String userName) {
		DBHelper aDBHelper = new DBHelper();
		boolean lockFlag = false;
		try {
			if (userVo != null) {

				String lockUser = aDBHelper
						.getValueFromDB(userVo.getRequestId(),
								ActionConstants.SELECTTRANSLOCK1);
				if (lockUser != null && !lockUser.trim().equals("")
						&& !lockUser.trim().equals(userName)) {
					lockFlag = true;
					userVo.setLockUser(lockUser);
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return lockFlag;
	}

	public boolean selectTFBOTranLockDashBoard(UserTransactionVO userVo,
			String flag, String userName) {
		DBHelper aDBHelper = new DBHelper();
		boolean lockFlag = false;
		try {
			if (userVo != null) {

				String lockUser = aDBHelper
						.getValueFromDB(userVo.getRequestId(),
								ActionConstants.SELECTTRANSLOCK1);
				if (lockUser != null && !lockUser.trim().equals("")
						&& lockUser.trim().equals(userName)) {
					lockFlag = true;
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return lockFlag;
	}

	public String selectTFBOTranLockStatusAlert(UserTransactionVO userVo,
			String flag, String userName) {
		DBHelper aDBHelper = new DBHelper();
		boolean lockFlag = true;
		String lockUser = "";
		try {
			if (userVo != null) {
				lockUser = aDBHelper.getValueFromDB(userVo.getRequestId(),
						ActionConstants.SELECTTRANSLOCK1);
				if (lockUser != null && !lockUser.trim().equals(userName)) {
					lockFlag = true;
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return lockUser;
	}

	public List<AlertMessagesVO> isTransLocked(UserTransactionVO userVo,
			List<AlertMessagesVO> errorDetailList) {
		CommonMethods aCommonMethods = new CommonMethods();
		DBHelper aDBHelper = new DBHelper();
		boolean lockStatus = false;
		try {
			if (aCommonMethods.isValueAvailable(userVo.getRequestId())) {
				lockStatus = aDBHelper.getValueFromDBForLock(userVo,
						ActionConstants.SELECTTRANSLOCK);
				if (lockStatus) {
					// errorDetailList = aCommonMethods.setErrorInList(
					// ActionConstants.ERRORCODE044, errorDetailList);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return errorDetailList;
	}

	// REPORTS

//	public void generateELCDetailedReportInExcel(ReportVO reportVo)
//			throws Exception {
//
//		logger.info(ActionConstants.ENTERING_METHOD
//				+ "<<generateELCDetailedReportInExcel DAO");
//		DBHelper aDBHelper = new DBHelper();
//		CommonMethods aCommonMethods = new CommonMethods();
//		try {
//
//			String elcDetailedReportQuery = "";
//
//			elcDetailedReportQuery = ActionConstants.GETELCDETAILEDRESULTS;
//
//			if (aCommonMethods.isValueAvailable(reportVo.getProductCodeList())) {
//				elcDetailedReportQuery = elcDetailedReportQuery
//						+ " WHERE TRANSACTION_TYPE LIKE '%"
//						+ reportVo.getProductCodeList().trim() + "%'";
//			}
//
//			if (aCommonMethods.isValueAvailable(reportVo.getSolID())) {
//				elcDetailedReportQuery = elcDetailedReportQuery
//						+ " AND SOL_ID LIKE '%" + reportVo.getSolID().trim()
//						+ "%'";
//			}
//
//			if (aCommonMethods.isValueAvailable(reportVo.getCurrency())) {
//				elcDetailedReportQuery = elcDetailedReportQuery
//						+ " AND CURRENCY LIKE '%"
//						+ reportVo.getCurrency().trim() + "%'";
//			}
//
//			if (aCommonMethods.isValueAvailable(reportVo.getRstatusFilter())) {
//				elcDetailedReportQuery = elcDetailedReportQuery
//						+ " AND STATUS LIKE '%"
//						+ reportVo.getRstatusFilter().trim() + "%'";
//			}
//
//			/*
//			 * if (aCommonMethods.isValueAvailable(reportVo.getUserIdList())) {
//			 * elcDetailedReportQuery = elcDetailedReportQuery +
//			 * " AND STATUS_CHANGED_BY LIKE '%" +
//			 * reportVo.getUserIdList().trim() + "%'"; }
//			 */
//			if (aCommonMethods.isValueAvailable(reportVo.getUserIdList())) {
//				elcDetailedReportQuery = elcDetailedReportQuery
//						+ " AND (INPUTUSER LIKE '%"
//						+ reportVo.getUserIdList().trim() + "%'"
//						+ " OR REVIEWUSER LIKE '%"
//						+ reportVo.getUserIdList().trim() + "%'"
//						+ " OR AUTHUSER LIKE '%"
//						+ reportVo.getUserIdList().trim() + "%'"
//						+ " OR FBOMAKER LIKE '%"
//						+ reportVo.getUserIdList().trim() + "%'"
//						+ " OR FBOCHECKER LIKE '%"
//						+ reportVo.getUserIdList().trim() + "%')";
//			}
//			if (aCommonMethods.isValueAvailable(reportVo.getFromDateFilter())
//					&& aCommonMethods.isValueAvailable(reportVo
//							.getToDateFilter())) {
//
//				elcDetailedReportQuery = elcDetailedReportQuery
//						+ " AND  trunc(TRANSACTION_GENERATE_TIME) BETWEEN "
//						+ "to_date('" + reportVo.getFromDateFilter()
//						+ "','dd-mm-yyyy') AND " + "to_date( '"
//						+ reportVo.getToDateFilter() + "','dd-mm-yyyy')";
//						
//			}
//			if (!aCommonMethods.isValueAvailable(reportVo.getFromDateFilter())
//					&& aCommonMethods.isValueAvailable(reportVo
//							.getToDateFilter())) {
//				elcDetailedReportQuery = elcDetailedReportQuery
//						+ " AND trunc(TRANSACTION_GENERATE_TIME)  BETWEEN '01-01-2019'"
//						+ " AND '" + reportVo.getToDateFilter() + "'";
//				reportVo.setFromDateFilter("01-01-2019");
//			}
//
//			if (aCommonMethods.isValueAvailable(reportVo.getFromDateFilter())
//					&& !aCommonMethods.isValueAvailable(reportVo
//							.getToDateFilter())) {
//				elcDetailedReportQuery = elcDetailedReportQuery
//						+ " AND trunc(TRANSACTION_GENERATE_TIME)  BETWEEN '"
//						+ reportVo.getFromDateFilter() + "' AND sysdate";
//				try {
//
//					SimpleDateFormat aSimpleDateFormat = new SimpleDateFormat(
//							"dd-MM-yyyy");
//					Date aDate = new Date();
//					reportVo.setToDateFilter(aSimpleDateFormat.format(aDate));
//				} catch (Exception e) {
//					e.printStackTrace();
//				}
//			}
//			aDBHelper.generateELCDetailedReportInExcel(elcDetailedReportQuery);
//
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//		logger.info(ActionConstants.EXITING_METHOD
//				+ "<<generateELCDetailedReportInExcel DAO");
//	}

//	public void generateFOCDetailedReportInExcel(ReportVO reportVo)
//			throws Exception {
//		logger.info(ActionConstants.ENTERING_METHOD
//				+ "<<generateFOCDetailedReportInExcel DAO");
//		DBHelper aDBHelper = new DBHelper();
//		CommonMethods aCommonMethods = new CommonMethods();
//		try {
//
//			String focDetailedReportQuery = "";
//
//			focDetailedReportQuery = ActionConstants.GETFOCDETAILEDRESULTS;
//
//			if (aCommonMethods.isValueAvailable(reportVo.getProductCodeList())) {
//				focDetailedReportQuery = focDetailedReportQuery
//						+ " WHERE TRANSACTION_TYPE LIKE '%"
//						+ reportVo.getProductCodeList().trim() + "%'";
//			}
//
//			if (aCommonMethods.isValueAvailable(reportVo.getSolID())) {
//				focDetailedReportQuery = focDetailedReportQuery
//						+ " AND SOL_ID LIKE '%" + reportVo.getSolID().trim()
//						+ "%'";
//			}
//
//			if (aCommonMethods.isValueAvailable(reportVo.getCurrency())) {
//				focDetailedReportQuery = focDetailedReportQuery
//						+ " AND CURRENCY LIKE '%"
//						+ reportVo.getCurrency().trim() + "%'";
//			}
//
//			if (aCommonMethods.isValueAvailable(reportVo.getRstatusFilter())) {
//				focDetailedReportQuery = focDetailedReportQuery
//						+ " AND STATUS LIKE '%"
//						+ reportVo.getRstatusFilter().trim() + "%'";
//			}
//
//			/*
//			 * if (aCommonMethods.isValueAvailable(reportVo.getUserIdList())) {
//			 * focDetailedReportQuery = focDetailedReportQuery +
//			 * " AND STATUS_CHANGED_BY LIKE '%" +
//			 * reportVo.getUserIdList().trim() + "%'"; }
//			 */
//			if (aCommonMethods.isValueAvailable(reportVo.getUserIdList())) {
//				focDetailedReportQuery = focDetailedReportQuery
//						+ " AND (INPUTUSER LIKE '%"
//						+ reportVo.getUserIdList().trim() + "%'"
//						+ " OR REVIEWUSER LIKE '%"
//						+ reportVo.getUserIdList().trim() + "%'"
//						+ " OR AUTHUSER LIKE '%"
//						+ reportVo.getUserIdList().trim() + "%'"
//						+ " OR FBOMAKER LIKE '%"
//						+ reportVo.getUserIdList().trim() + "%'"
//						+ " OR FBOCHECKER LIKE '%"
//						+ reportVo.getUserIdList().trim() + "%')";
//			}
//
//			if (aCommonMethods.isValueAvailable(reportVo.getFromDateFilter())
//					&& aCommonMethods.isValueAvailable(reportVo
//							.getToDateFilter())) {
//
//				focDetailedReportQuery = focDetailedReportQuery
//						+ " AND  trunc(TRANSACTION_GENERATE_TIME) BETWEEN "
//						+ "to_date('" + reportVo.getFromDateFilter()
//						+ "','dd-mm-yyyy') AND " + "to_date( '"
//						+ reportVo.getToDateFilter() + "','dd-mm-yyyy')";
//			}
//			if (!aCommonMethods.isValueAvailable(reportVo.getFromDateFilter())
//					&& aCommonMethods.isValueAvailable(reportVo
//							.getToDateFilter())) {
//				focDetailedReportQuery = focDetailedReportQuery
//						+ " AND trunc(TRANSACTION_GENERATE_TIME) BETWEEN '01-01-2019'"
//						+ " AND '" + reportVo.getToDateFilter() + "'";
//				reportVo.setFromDateFilter("01-01-2019");
//			}
//
//			if (aCommonMethods.isValueAvailable(reportVo.getFromDateFilter())
//					&& !aCommonMethods.isValueAvailable(reportVo
//							.getToDateFilter())) {
//				focDetailedReportQuery = focDetailedReportQuery
//						+ " AND trunc(TRANSACTION_GENERATE_TIME) BETWEEN '"
//						+ reportVo.getFromDateFilter() + "' AND sysdate";
//				try {
//
//					SimpleDateFormat aSimpleDateFormat = new SimpleDateFormat(
//							"dd-MM-yyyy");
//					Date aDate = new Date();
//					reportVo.setToDateFilter(aSimpleDateFormat.format(aDate));
//				} catch (Exception e) {
//					e.printStackTrace();
//				}
//			}
//
//			logger.info("Getting FOC Detailed Report Query (Excel) ==> "
//					+ focDetailedReportQuery);
//
//			aDBHelper.generateFOCDetailedReportInExcel(focDetailedReportQuery);
//
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//		logger.info(ActionConstants.EXITING_METHOD
//				+ "<<generateFOCDetailedReportInExcel DAO");
//	}

//	public void generateCPCIDetailedReportInExcel(ReportVO reportVo)
//			throws Exception {
//
//		logger.info(ActionConstants.ENTERING_METHOD
//				+ "<<generateCPCIDetailedReportInExcel DAO");
//
//		DBHelper aDBHelper = new DBHelper();
//		CommonMethods aCommonMethods = new CommonMethods();
//		try {
//
//			String cpciDetailedReportQuery = "";
//
//			cpciDetailedReportQuery = ActionConstants.GETCPCIDETAILEDRESULTS;
//
//			if (aCommonMethods.isValueAvailable(reportVo.getProductCodeList())) {
//				cpciDetailedReportQuery = cpciDetailedReportQuery
//						+ " WHERE TRANSACTION_TYPE LIKE '%"
//						+ reportVo.getProductCodeList().trim() + "%'";
//			}
//
//			if (aCommonMethods.isValueAvailable(reportVo.getSolID())) {
//				cpciDetailedReportQuery = cpciDetailedReportQuery
//						+ " AND SOL_ID LIKE '%" + reportVo.getSolID().trim()
//						+ "%'";
//			}
//
//			if (aCommonMethods.isValueAvailable(reportVo.getCurrency())) {
//				cpciDetailedReportQuery = cpciDetailedReportQuery
//						+ " AND CURRENCY LIKE '%"
//						+ reportVo.getCurrency().trim() + "%'";
//			}
//
//			if (aCommonMethods.isValueAvailable(reportVo.getRstatusFilter())) {
//				cpciDetailedReportQuery = cpciDetailedReportQuery
//						+ " AND STATUS LIKE '%"
//						+ reportVo.getRstatusFilter().trim() + "%'";
//			}
//
//			/*
//			 * if (aCommonMethods.isValueAvailable(reportVo.getUserIdList())) {
//			 * cpciDetailedReportQuery = cpciDetailedReportQuery +
//			 * " AND STATUS_CHANGED_BY LIKE '%" +
//			 * reportVo.getUserIdList().trim() + "%'"; }
//			 */
//			if (aCommonMethods.isValueAvailable(reportVo.getUserIdList())) {
//				cpciDetailedReportQuery = cpciDetailedReportQuery
//						+ " AND (INPUTUSER LIKE '%"
//						+ reportVo.getUserIdList().trim() + "%'"
//						+ " OR REVIEWUSER LIKE '%"
//						+ reportVo.getUserIdList().trim() + "%'"
//						+ " OR AUTHUSER LIKE '%"
//						+ reportVo.getUserIdList().trim() + "%'"
//						+ " OR FBOMAKER LIKE '%"
//						+ reportVo.getUserIdList().trim() + "%'"
//						+ " OR FBOCHECKER LIKE '%"
//						+ reportVo.getUserIdList().trim() + "%')";
//			}
//
//			if (aCommonMethods.isValueAvailable(reportVo.getFromDateFilter())
//					&& aCommonMethods.isValueAvailable(reportVo
//							.getToDateFilter())) {
//
//				cpciDetailedReportQuery = cpciDetailedReportQuery
//						+ " AND  trunc(TRANSACTION_GENERATE_TIME) BETWEEN "
//						+ "to_date('" + reportVo.getFromDateFilter()
//						+ "','dd-mm-yyyy') AND " + "to_date( '"
//						+ reportVo.getToDateFilter() + "','dd-mm-yyyy')";
//			}
//			if (!aCommonMethods.isValueAvailable(reportVo.getFromDateFilter())
//					&& aCommonMethods.isValueAvailable(reportVo
//							.getToDateFilter())) {
//				cpciDetailedReportQuery = cpciDetailedReportQuery
//						+ " AND trunc(TRANSACTION_GENERATE_TIME)  BETWEEN '01-01-2019'"
//						+ " AND '" + reportVo.getToDateFilter() + "'";
//				reportVo.setFromDateFilter("01-01-2019");
//			}
//
//			if (aCommonMethods.isValueAvailable(reportVo.getFromDateFilter())
//					&& !aCommonMethods.isValueAvailable(reportVo
//							.getToDateFilter())) {
//				cpciDetailedReportQuery = cpciDetailedReportQuery
//						+ " AND trunc(TRANSACTION_GENERATE_TIME)  BETWEEN '"
//						+ reportVo.getFromDateFilter() + "' AND sysdate";
//				try {
//
//					SimpleDateFormat aSimpleDateFormat = new SimpleDateFormat(
//							"dd-MM-yyyy");
//					Date aDate = new Date();
//					reportVo.setToDateFilter(aSimpleDateFormat.format(aDate));
//				} catch (Exception e) {
//					e.printStackTrace();
//				}
//			}
//
//			logger.info("Getting cpci Detailed Report Query ==> "
//					+ cpciDetailedReportQuery);
//			aDBHelper
//					.generateCPCIDetailedReportInExcel(cpciDetailedReportQuery);
//
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//		logger.info(ActionConstants.EXITING_METHOD
//				+ "<<generateCPCIDetailedReportInExcel DAO");
//	}

//	public List<ReportVO> generateGridSummaryReportQuery(ReportVO reportVo,
//			String summaryReportquery) throws Exception {
//
//		logger.info(ActionConstants.ENTERING_METHOD
//				+ "<<generateGridSummaryReportQuery DAO");
//
//		DBHelper aDBHelper = new DBHelper();
//		CommonMethods aCommonMethods = new CommonMethods();
//		List<ReportVO> summaryList = null;
//
//		try {
//
//			if (aCommonMethods.isValueAvailable(reportVo.getProductCodeList())) {
//
//				if (reportVo.getProductCodeList().equalsIgnoreCase("ALL")) {
//					summaryReportquery = summaryReportquery
//							+ " WHERE TRANSACTION_TYPE LIKE '%'";
//				} else {
//					summaryReportquery = summaryReportquery
//							+ " WHERE TRANSACTION_TYPE LIKE '%"
//							+ reportVo.getProductCodeList().trim() + "%'";
//				}
//			}
//
//			if (aCommonMethods.isValueAvailable(reportVo.getSolID())) {
//				summaryReportquery = summaryReportquery + " AND SOL_ID LIKE '%"
//						+ reportVo.getSolID().trim() + "%'";
//			}
//
//			if (aCommonMethods.isValueAvailable(reportVo.getCurrency())) {
//				summaryReportquery = summaryReportquery
//						+ " AND CURRENCY LIKE '%"
//						+ reportVo.getCurrency().trim() + "%'";
//			}
//
//			if (aCommonMethods.isValueAvailable(reportVo.getRstatusFilter())) {
//				summaryReportquery = summaryReportquery + " AND trim(STATUS) LIKE '%"
//						+ reportVo.getRstatusFilter().trim() + "%'";
//			}
//
//			if (aCommonMethods.isValueAvailable(reportVo.getUserIdList())) {
//				summaryReportquery = summaryReportquery
//						+ " AND (INPUTUSER LIKE '%"
//						+ reportVo.getUserIdList().trim() + "%'"
//						+ " OR REVIEWUSER LIKE '%"
//						+ reportVo.getUserIdList().trim() + "%'"
//						+ " OR AUTHUSER LIKE '%"
//						+ reportVo.getUserIdList().trim() + "%'"
//						+ " OR FBOMAKER LIKE '%"
//						+ reportVo.getUserIdList().trim() + "%'"
//						+ " OR FBOCHECKER LIKE '%"
//						+ reportVo.getUserIdList().trim() + "%')";
//			}
//
//			if (aCommonMethods.isValueAvailable(reportVo.getFromDateFilter())
//					&& aCommonMethods.isValueAvailable(reportVo
//							.getToDateFilter())) {
//				summaryReportquery = summaryReportquery
//						+ " AND  trunc(TRANSACTION_GENERATE_TIME) BETWEEN "
//						+ "to_date('" + reportVo.getFromDateFilter()
//						+ "','dd-mm-yyyy') AND " + "to_date( '"
//						+ reportVo.getToDateFilter() + "','dd-mm-yyyy')";
//
//			}
//
//			if (!aCommonMethods.isValueAvailable(reportVo.getFromDateFilter())
//					&& aCommonMethods.isValueAvailable(reportVo
//							.getToDateFilter())) {
//				summaryReportquery = summaryReportquery
//						+ " AND trunc(TRANSACTION_GENERATE_TIME) BETWEEN '01-01-2019'"
//						+ " AND '" + reportVo.getToDateFilter() + "'";
//				reportVo.setFromDateFilter("01-01-2019");
//			}
//
//			if (aCommonMethods.isValueAvailable(reportVo.getFromDateFilter())
//					&& !aCommonMethods.isValueAvailable(reportVo
//							.getToDateFilter())) {
//				summaryReportquery = summaryReportquery
//						+ " AND trunc(TRANSACTION_GENERATE_TIME) BETWEEN '"
//						+ reportVo.getFromDateFilter() + "' AND sysdate";
//				try {
//					SimpleDateFormat aSimpleDateFormat = new SimpleDateFormat(
//							"dd-MM-yyyy");
//					Date aDate = new Date();
//					logger.info("Getting To date Filter"
//							+ aSimpleDateFormat.format(aDate));
//
//					reportVo.setToDateFilter(aSimpleDateFormat.format(aDate));
//
//				} catch (Exception e) {
//					e.printStackTrace();
//				}
//
//			}
//
//			/*if (aCommonMethods.isValueAvailable(reportVo.getReportFrequency())) {
//				summaryReportquery = summaryReportquery
//						+ " AND REPORT_FREQUENCY LIKE '%"
//						+ reportVo.getReportFrequency() + "%'";
//			}*/
//			if(reportVo.getReportFrequency().equalsIgnoreCase("Hourly")){
//				summaryReportquery = summaryReportquery + " GROUP BY TRANSACTION_TYPE,to_date(TO_CHAR(TRUNC(TRANSACTION_GENERATE_TIME),'DD-MON-YYYY'),'DD-MON-YYYY'),to_date(TO_CHAR(TRUNC(TRANSACTION_GENERATE_TIME),'DD-MON-YYYY'),'DD-MON-YYYY')||' ' ||lpad(TO_CHAR(to_number(TO_CHAR(TRANSACTION_GENERATE_TIME,'HH'))),2,0) ||':00 ' ||'- ' ||TO_CHAR(CASE WHEN to_number(TO_CHAR(TRANSACTION_GENERATE_TIME,'HH'))+1 = 13 THEN '01' ||':00 HRS' ELSE lpad(to_number(TO_CHAR(TRANSACTION_GENERATE_TIME,'HH'))+1,2,0) ||':00 HRS' END )ORDER BY to_date(TO_CHAR(TRUNC(TRANSACTION_GENERATE_TIME),'DD-MON-YYYY'),'DD-MON-YYYY')";
//				logger.info("Getting Summary report query => " + summaryReportquery);
//				}
//				if(reportVo.getReportFrequency().equalsIgnoreCase("Daily")){
//					summaryReportquery = summaryReportquery + "group by TRANSACTION_TYPE,trunc(TRANSACTION_GENERATE_TIME) order by TRANSACTION_GENERATE_TIME asc ";
//					logger.info("Getting Summary report query => " + summaryReportquery);
//					}
//				
//				if(reportVo.getReportFrequency().equalsIgnoreCase("Weekly")){
//					summaryReportquery = summaryReportquery + "group by TRANSACTION_TYPE,to_char(TRANSACTION_GENERATE_TIME,'MON')||'-'||to_char(TRANSACTION_GENERATE_TIME,'YY')||'-'||to_char(TRANSACTION_GENERATE_TIME,'W') order  by TRANSACTION_GENERATE_TIME asc ";
//					logger.info("Getting Summary report query => " + summaryReportquery);
//					}
//				if(reportVo.getReportFrequency().equalsIgnoreCase("Monthly")){
//					summaryReportquery = summaryReportquery + "group by TRANSACTION_TYPE,to_char(TRANSACTION_GENERATE_TIME,'MON')||'-'||to_char(TRANSACTION_GENERATE_TIME,'YY') order by TRANSACTION_GENERATE_TIME asc ";
//					logger.info("Getting Summary report query => " + summaryReportquery);
//					}
//
//			logger.info("Getting Summary report query => " + summaryReportquery);
//
//			summaryList = aDBHelper.generateSummaryReportInGrid(
//					summaryReportquery, reportVo);
//
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//
//		logger.info(ActionConstants.EXITING_METHOD
//				+ "<<generateGridSummaryReportQuery DAO");
//		return summaryList;
//	}

//	public List<ReportVO> generateDetailedReportInGrid(ReportVO reportVo)
//			throws Exception {
//
//		logger.info(ActionConstants.ENTERING_METHOD
//				+ "<<generateDetailedReportInGrid DAO");
//
//		List<ReportVO> detailedList = null;
//
//		CommonMethods aCommonMethods = new CommonMethods();
//
//		try {
//
//			logger.info("Getting product name==> " + reportVo.getProductName());
//
//			if (aCommonMethods.isValueAvailable(reportVo.getProductName())) {
//
//				if (reportVo.getProductName().equalsIgnoreCase("ALL")) {
//
//					reportVo.setProductCodeList("ALL");
//
//				} else {
//					reportVo.setProductCodeList(getProductCodeFromDB(reportVo
//							.getProductName()));
//				}
//			}
//
//			logger.info("Getting product code ==> "
//					+ reportVo.getProductCodeList());
//
//			if (reportVo.getProductCodeList().equalsIgnoreCase("ILC")) {
//				detailedList = generateILCDetailedReportInGrid(reportVo);
//			}
//
//			else if (reportVo.getProductCodeList().equalsIgnoreCase("ELC")) {
//				detailedList = generateELCDetailedReportInGrid(reportVo);
//			}
//
//			else if (reportVo.getProductCodeList().equalsIgnoreCase("FOC")) {
//				detailedList = generateFOCDetailedReportInGrid(reportVo);
//			}
//
//			else if (reportVo.getProductCodeList().equalsIgnoreCase("CPCI")) {
//				detailedList = generateCPCIDetailedReportInGrid(reportVo);
//			}
//
//			else if (reportVo.getProductCodeList().equalsIgnoreCase("ISB")) {
//				detailedList = generateISBDetailedReportInGrid(reportVo);
//			}
//
//			else if (reportVo.getProductCodeList().equalsIgnoreCase("FSA")) {
//				detailedList = generateFSADetailedReportInGrid(reportVo);
//			}
//
//			else if (reportVo.getProductCodeList().equalsIgnoreCase("IDC")) {
//				detailedList = generateIDCDetailedReportInGrid(reportVo);
//			}
//
//			else if (reportVo.getProductCodeList().equalsIgnoreCase("ODC")) {
//				detailedList = generateODCDetailedReportInGrid(reportVo);
//			}
//
//			else if (reportVo.getProductCodeList().equalsIgnoreCase("IGT")) {
//				detailedList = generateIGTDetailedReportInGrid(reportVo);
//			}
//
//			else if (reportVo.getProductCodeList().equalsIgnoreCase("CPCO")) {
//				detailedList = generateCPCODetailedReportInGrid(reportVo);
//			}
//
//			else if (reportVo.getProductCodeList().equalsIgnoreCase("FEL")) {
//				detailedList = generateFELDetailedReportInGrid(reportVo);
//			}
//
//			else if (reportVo.getProductCodeList().equalsIgnoreCase("COR")) {
//				detailedList = generateCORDetailedReportInGrid(reportVo);
//			}
//
//			else if (reportVo.getProductCodeList().equalsIgnoreCase("ALL")) {
//				detailedList = generateALLDetailedReportInGrid(reportVo);
//			}
//
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//		logger.info(ActionConstants.EXITING_METHOD
//				+ "<<generateDetailedReportInGrid DAO");
//		return detailedList;
//	}

//	public List<ReportVO> generateILCDetailedReportInGrid(ReportVO reportVo)
//			throws Exception {
//
//		logger.info(ActionConstants.ENTERING_METHOD
//				+ "<<generateILCDetailedReportInGrid DAO");
//
//		List<ReportVO> detailedList = null;
//
//		try {
//
//			DBHelper aDBHelper = new DBHelper();
//			CommonMethods aCommonMethods = new CommonMethods();
//			String ilcDetailedReportQuery = "";
//
//			ilcDetailedReportQuery = ActionConstants.GETILCDETAILEDRESULTS;
//
//			if (aCommonMethods.isValueAvailable(reportVo.getProductCodeList())) {
//				ilcDetailedReportQuery = ilcDetailedReportQuery
//						+ " WHERE TRANSACTION_TYPE LIKE '%"
//						+ reportVo.getProductCodeList().trim() + "%'";
//			}
//
//			if (aCommonMethods.isValueAvailable(reportVo.getSolID())) {
//				ilcDetailedReportQuery = ilcDetailedReportQuery
//						+ " AND SOL_ID LIKE '%" + reportVo.getSolID().trim()
//						+ "%'";
//			}
//
//			if (aCommonMethods.isValueAvailable(reportVo.getCurrency())) {
//				ilcDetailedReportQuery = ilcDetailedReportQuery
//						+ " AND CURRENCY LIKE '%"
//						+ reportVo.getCurrency().trim() + "%'";
//			}
//
//			if (aCommonMethods.isValueAvailable(reportVo.getRstatusFilter())) {
//				ilcDetailedReportQuery = ilcDetailedReportQuery
//						+ " AND trim(STATUS) LIKE '%"
//						+ reportVo.getRstatusFilter().trim() + "%'";
//			}
//			/*
//			 * if (aCommonMethods.isValueAvailable(reportVo.getUserIdList())) {
//			 * ilcDetailedReportQuery = ilcDetailedReportQuery +
//			 * " AND STATUS_CHANGED_BY LIKE '%" +
//			 * reportVo.getUserIdList().trim() + "%'"; }
//			 */
//			if (aCommonMethods.isValueAvailable(reportVo.getUserIdList())) {
//				ilcDetailedReportQuery = ilcDetailedReportQuery
//						+ " AND (INPUTUSER LIKE '%"
//						+ reportVo.getUserIdList().trim() + "%'"
//						+ " OR REVIEWUSER LIKE '%"
//						+ reportVo.getUserIdList().trim() + "%'"
//						+ " OR AUTHUSER LIKE '%"
//						+ reportVo.getUserIdList().trim() + "%'"
//						+ " OR FBOMAKER LIKE '%"
//						+ reportVo.getUserIdList().trim() + "%'"
//						+ " OR FBOCHECKER LIKE '%"
//						+ reportVo.getUserIdList().trim() + "%')";
//			}
//
//			if (aCommonMethods.isValueAvailable(reportVo.getFromDateFilter())
//					&& aCommonMethods.isValueAvailable(reportVo
//							.getToDateFilter())) {
//				ilcDetailedReportQuery = ilcDetailedReportQuery
//						+ " AND  trunc(TRANSACTION_GENERATE_TIME) BETWEEN "
//						+ "to_date('" + reportVo.getFromDateFilter()
//						+ "','dd-mm-yyyy') AND " + "to_date( '"
//						+ reportVo.getToDateFilter() + "','dd-mm-yyyy')";
//
//			}
//
//			if (!aCommonMethods.isValueAvailable(reportVo.getFromDateFilter())
//					&& aCommonMethods.isValueAvailable(reportVo
//							.getToDateFilter())) {
//				ilcDetailedReportQuery = ilcDetailedReportQuery
//						+ " AND trunc(TRANSACTION_GENERATE_TIME) BETWEEN '01-01-2019'"
//						+ " AND '" + reportVo.getToDateFilter() + "'";
//				reportVo.setFromDateFilter("01-01-2019");
//			}
//
//			if (aCommonMethods.isValueAvailable(reportVo.getFromDateFilter())
//					&& !aCommonMethods.isValueAvailable(reportVo
//							.getToDateFilter())) {
//				ilcDetailedReportQuery = ilcDetailedReportQuery
//						+ " AND trunc(TRANSACTION_GENERATE_TIME) BETWEEN '"
//						+ reportVo.getFromDateFilter() + "' AND sysdate";
//				try {
//
//					SimpleDateFormat aSimpleDateFormat = new SimpleDateFormat(
//							"dd-MM-yyyy");
//					Date aDate = new Date();
//					logger.info("Getting To date filter ==> "
//							+ aSimpleDateFormat.format(aDate));
//
//					reportVo.setToDateFilter(aSimpleDateFormat.format(aDate));
//
//				} catch (Exception e) {
//					e.printStackTrace();
//				}
//
//			}
//			logger.info("ILC Detailed Report query ==> "
//					+ ilcDetailedReportQuery);
//			detailedList = aDBHelper.generateILCDetailedReportInGrid(
//					ilcDetailedReportQuery, reportVo);
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//		logger.info(ActionConstants.EXITING_METHOD
//				+ "<<generateILCDetailedReportInGrid DAO");
//		return detailedList;
//	}

//	public List<ReportVO> generateELCDetailedReportInGrid(ReportVO reportVo)
//			throws Exception {
//
//		logger.info(ActionConstants.ENTERING_METHOD
//				+ "<<generateELCDetailedReportInGrid DAO");
//
//		List<ReportVO> detailedList = null;
//
//		try {
//
//			DBHelper aDBHelper = new DBHelper();
//			CommonMethods aCommonMethods = new CommonMethods();
//			String elcDetailedReportQuery = "";
//
//			elcDetailedReportQuery = ActionConstants.GETELCDETAILEDRESULTS;
//
//			if (aCommonMethods.isValueAvailable(reportVo.getProductCodeList())) {
//				elcDetailedReportQuery = elcDetailedReportQuery
//						+ " WHERE TRANSACTION_TYPE LIKE '%"
//						+ reportVo.getProductCodeList().trim() + "%'";
//			}
//
//			if (aCommonMethods.isValueAvailable(reportVo.getSolID())) {
//				elcDetailedReportQuery = elcDetailedReportQuery
//						+ " AND SOL_ID LIKE '%" + reportVo.getSolID().trim()
//						+ "%'";
//			}
//
//			if (aCommonMethods.isValueAvailable(reportVo.getCurrency())) {
//				elcDetailedReportQuery = elcDetailedReportQuery
//						+ " AND CURRENCY LIKE '%"
//						+ reportVo.getCurrency().trim() + "%'";
//			}
//
//			if (aCommonMethods.isValueAvailable(reportVo.getRstatusFilter())) {
//				elcDetailedReportQuery = elcDetailedReportQuery
//						+ " AND STATUS LIKE '%"
//						+ reportVo.getRstatusFilter().trim() + "%'";
//			}
//
//			/*
//			 * if (aCommonMethods.isValueAvailable(reportVo.getUserIdList())) {
//			 * elcDetailedReportQuery = elcDetailedReportQuery +
//			 * " AND STATUS_CHANGED_BY LIKE '%" +
//			 * reportVo.getUserIdList().trim() + "%'"; }
//			 */
//			if (aCommonMethods.isValueAvailable(reportVo.getUserIdList())) {
//				elcDetailedReportQuery = elcDetailedReportQuery
//						+ " AND (INPUTUSER LIKE '%"
//						+ reportVo.getUserIdList().trim() + "%'"
//						+ " OR REVIEWUSER LIKE '%"
//						+ reportVo.getUserIdList().trim() + "%'"
//						+ " OR AUTHUSER LIKE '%"
//						+ reportVo.getUserIdList().trim() + "%'"
//						+ " OR FBOMAKER LIKE '%"
//						+ reportVo.getUserIdList().trim() + "%'"
//						+ " OR FBOCHECKER LIKE '%"
//						+ reportVo.getUserIdList().trim() + "%')";
//			}
//			if (aCommonMethods.isValueAvailable(reportVo.getFromDateFilter())
//					&& aCommonMethods.isValueAvailable(reportVo
//							.getToDateFilter())) {
//				elcDetailedReportQuery = elcDetailedReportQuery
//						+ " AND  trunc(TRANSACTION_GENERATE_TIME) BETWEEN "
//						+ "to_date('" + reportVo.getFromDateFilter()
//						+ "','dd-mm-yyyy') AND " + "to_date( '"
//						+ reportVo.getToDateFilter() + "','dd-mm-yyyy')";
//			}
//
//			if (!aCommonMethods.isValueAvailable(reportVo.getFromDateFilter())
//					&& aCommonMethods.isValueAvailable(reportVo
//							.getToDateFilter())) {
//				elcDetailedReportQuery = elcDetailedReportQuery
//						+ " AND TRANSACTION_GENERATE_TIME BETWEEN '01-01-2019'"
//						+ " AND '" + reportVo.getToDateFilter() + "'";
//				reportVo.setFromDateFilter("01-01-2019");
//			}
//
//			if (aCommonMethods.isValueAvailable(reportVo.getFromDateFilter())
//					&& !aCommonMethods.isValueAvailable(reportVo
//							.getToDateFilter())) {
//				elcDetailedReportQuery = elcDetailedReportQuery
//						+ " AND TRANSACTION_GENERATE_TIME BETWEEN '"
//						+ reportVo.getFromDateFilter() + "' AND sysdate";
//				try {
//
//					SimpleDateFormat formatter = new SimpleDateFormat(
//							"dd-MM-yyyy");
//					Date date = new Date();
//
//					logger.info("date" + formatter.format(date));
//
//					reportVo.setToDateFilter(formatter.format(date));
//
//				} catch (Exception e) {
//					e.printStackTrace();
//				}
//
//			}
//			logger.info("ELC Detailed Report query==> "
//					+ elcDetailedReportQuery);
//
//			detailedList = aDBHelper.generateELCDetailedReportInGrid(
//					elcDetailedReportQuery, reportVo);
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//		logger.info(ActionConstants.EXITING_METHOD
//				+ "<<generateELCDetailedReportInGrid DAO");
//		return detailedList;
//	}

//	public List<ReportVO> generateFOCDetailedReportInGrid(ReportVO reportVo)
//			throws Exception {
//
//		logger.info(ActionConstants.ENTERING_METHOD
//				+ "<<generateFOCDetailedReportInGrid DAO");
//
//		List<ReportVO> detailedList = null;
//
//		try {
//
//			DBHelper aDBHelper = new DBHelper();
//			CommonMethods aCommonMethods = new CommonMethods();
//			String focDetailedReportQuery = "";
//
//			focDetailedReportQuery = ActionConstants.GETFOCDETAILEDRESULTS;
//
//			if (aCommonMethods.isValueAvailable(reportVo.getProductCodeList())) {
//				focDetailedReportQuery = focDetailedReportQuery
//						+ " WHERE TRANSACTION_TYPE LIKE '%"
//						+ reportVo.getProductCodeList().trim() + "%'";
//			}
//
//			if (aCommonMethods.isValueAvailable(reportVo.getSolID())) {
//				focDetailedReportQuery = focDetailedReportQuery
//						+ " AND SOL_ID LIKE '%" + reportVo.getSolID().trim()
//						+ "%'";
//			}
//
//			if (aCommonMethods.isValueAvailable(reportVo.getCurrency())) {
//				focDetailedReportQuery = focDetailedReportQuery
//						+ " AND CURRENCY LIKE '%"
//						+ reportVo.getCurrency().trim() + "%'";
//			}
//
//			if (aCommonMethods.isValueAvailable(reportVo.getRstatusFilter())) {
//				focDetailedReportQuery = focDetailedReportQuery
//						+ " AND STATUS LIKE '%"
//						+ reportVo.getRstatusFilter().trim() + "%'";
//			}
//
//			/*
//			 * if (aCommonMethods.isValueAvailable(reportVo.getUserIdList())) {
//			 * focDetailedReportQuery = focDetailedReportQuery +
//			 * " AND STATUS_CHANGED_BY LIKE '%" +
//			 * reportVo.getUserIdList().trim() + "%'"; }
//			 */
//			if (aCommonMethods.isValueAvailable(reportVo.getUserIdList())) {
//				focDetailedReportQuery = focDetailedReportQuery
//						+ " AND (INPUTUSER LIKE '%"
//						+ reportVo.getUserIdList().trim() + "%'"
//						+ " OR REVIEWUSER LIKE '%"
//						+ reportVo.getUserIdList().trim() + "%'"
//						+ " OR AUTHUSER LIKE '%"
//						+ reportVo.getUserIdList().trim() + "%'"
//						+ " OR FBOMAKER LIKE '%"
//						+ reportVo.getUserIdList().trim() + "%'"
//						+ " OR FBOCHECKER LIKE '%"
//						+ reportVo.getUserIdList().trim() + "%')";
//			}
//
//			if (aCommonMethods.isValueAvailable(reportVo.getFromDateFilter())
//					&& aCommonMethods.isValueAvailable(reportVo
//							.getToDateFilter())) {
//				focDetailedReportQuery = focDetailedReportQuery
//						+ " AND  trunc(TRANSACTION_GENERATE_TIME) BETWEEN "
//						+ "to_date('" + reportVo.getFromDateFilter()
//						+ "','dd-mm-yyyy') AND " + "to_date( '"
//						+ reportVo.getToDateFilter() + "','dd-mm-yyyy')";
//
//			}
//
//			if (!aCommonMethods.isValueAvailable(reportVo.getFromDateFilter())
//					&& aCommonMethods.isValueAvailable(reportVo
//							.getToDateFilter())) {
//				focDetailedReportQuery = focDetailedReportQuery
//						+ " AND TRANSACTION_GENERATE_TIME BETWEEN '01-01-2019'"
//						+ " AND '" + reportVo.getToDateFilter() + "'";
//				reportVo.setFromDateFilter("01-01-2019");
//			}
//
//			if (aCommonMethods.isValueAvailable(reportVo.getFromDateFilter())
//					&& !aCommonMethods.isValueAvailable(reportVo
//							.getToDateFilter())) {
//				focDetailedReportQuery = focDetailedReportQuery
//						+ " AND TRANSACTION_GENERATE_TIME BETWEEN '"
//						+ reportVo.getFromDateFilter() + "' AND sysdate";
//				try {
//
//					SimpleDateFormat aSimpleDateFormat = new SimpleDateFormat(
//							"dd-MM-yyyy");
//					Date aDate = new Date();
//
//					logger.info("Getting To date ==> "
//							+ aSimpleDateFormat.format(aDate));
//
//					reportVo.setToDateFilter(aSimpleDateFormat.format(aDate));
//
//				} catch (Exception e) {
//					e.printStackTrace();
//				}
//
//			}
//			logger.info("FOC Detailed Reported query==> "
//					+ focDetailedReportQuery);
//
//			detailedList = aDBHelper.generateFOCDetailedReportInGrid(
//					focDetailedReportQuery, reportVo);
//
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//		logger.info(ActionConstants.EXITING_METHOD
//				+ "<<generateFOCDetailedReportInGrid DAO");
//		return detailedList;
//	}

//	public List<ReportVO> generateCPCIDetailedReportInGrid(ReportVO reportVo)
//			throws Exception {
//
//		logger.info(ActionConstants.ENTERING_METHOD
//				+ "<<generateCPCIDetailedReportInGrid DAO");
//		List<ReportVO> detailedList = null;
//
//		try {
//
//			DBHelper aDBHelper = new DBHelper();
//			CommonMethods aCommonMethods = new CommonMethods();
//			String cpciDetailedReportQuery = "";
//
//			cpciDetailedReportQuery = ActionConstants.GETCPCIDETAILEDRESULTS;
//
//			if (aCommonMethods.isValueAvailable(reportVo.getProductCodeList())) {
//				cpciDetailedReportQuery = cpciDetailedReportQuery
//						+ " WHERE TRANSACTION_TYPE LIKE '%"
//						+ reportVo.getProductCodeList().trim() + "%'";
//			}
//
//			if (aCommonMethods.isValueAvailable(reportVo.getSolID())) {
//				cpciDetailedReportQuery = cpciDetailedReportQuery
//						+ " AND SOL_ID LIKE '%" + reportVo.getSolID().trim()
//						+ "%'";
//			}
//
//			if (aCommonMethods.isValueAvailable(reportVo.getCurrency())) {
//				cpciDetailedReportQuery = cpciDetailedReportQuery
//						+ " AND CURRENCY LIKE '%"
//						+ reportVo.getCurrency().trim() + "%'";
//			}
//
//			if (aCommonMethods.isValueAvailable(reportVo.getRstatusFilter())) {
//				cpciDetailedReportQuery = cpciDetailedReportQuery
//						+ " AND STATUS LIKE '%"
//						+ reportVo.getRstatusFilter().trim() + "%'";
//			}
//			/*
//			 * if (aCommonMethods.isValueAvailable(reportVo.getUserIdList())) {
//			 * cpciDetailedReportQuery = cpciDetailedReportQuery +
//			 * " AND STATUS_CHANGED_BY LIKE '%" +
//			 * reportVo.getUserIdList().trim() + "%'"; }
//			 */
//
//			if (aCommonMethods.isValueAvailable(reportVo.getUserIdList())) {
//				cpciDetailedReportQuery = cpciDetailedReportQuery
//						+ " AND (INPUTUSER LIKE '%"
//						+ reportVo.getUserIdList().trim() + "%'"
//						+ " OR REVIEWUSER LIKE '%"
//						+ reportVo.getUserIdList().trim() + "%'"
//						+ " OR AUTHUSER LIKE '%"
//						+ reportVo.getUserIdList().trim() + "%'"
//						+ " OR FBOMAKER LIKE '%"
//						+ reportVo.getUserIdList().trim() + "%'"
//						+ " OR FBOCHECKER LIKE '%"
//						+ reportVo.getUserIdList().trim() + "%')";
//			}
//
//			if (aCommonMethods.isValueAvailable(reportVo.getFromDateFilter())
//					&& aCommonMethods.isValueAvailable(reportVo
//							.getToDateFilter())) {
//				cpciDetailedReportQuery = cpciDetailedReportQuery
//						+ " AND  trunc(TRANSACTION_GENERATE_TIME) BETWEEN "
//						+ "to_date('" + reportVo.getFromDateFilter()
//						+ "','dd-mm-yyyy') AND " + "to_date( '"
//						+ reportVo.getToDateFilter() + "','dd-mm-yyyy')";
//
//			}
//
//			if (!aCommonMethods.isValueAvailable(reportVo.getFromDateFilter())
//					&& aCommonMethods.isValueAvailable(reportVo
//							.getToDateFilter())) {
//				cpciDetailedReportQuery = cpciDetailedReportQuery
//						+ " AND TRANSACTION_GENERATE_TIME BETWEEN '01-01-2019'"
//						+ " AND '" + reportVo.getToDateFilter() + "'";
//				reportVo.setFromDateFilter("01-01-2019");
//			}
//
//			if (aCommonMethods.isValueAvailable(reportVo.getFromDateFilter())
//					&& !aCommonMethods.isValueAvailable(reportVo
//							.getToDateFilter())) {
//				cpciDetailedReportQuery = cpciDetailedReportQuery
//						+ " AND TRANSACTION_GENERATE_TIME BETWEEN '"
//						+ reportVo.getFromDateFilter() + "' AND sysdate";
//				try {
//
//					SimpleDateFormat aSimpleDateFormat = new SimpleDateFormat(
//							"dd-MM-yyyy");
//					Date aDate = new Date();
//
//					logger.info("Getting To date filter ==> "
//							+ aSimpleDateFormat.format(aDate));
//
//					reportVo.setToDateFilter(aSimpleDateFormat.format(aDate));
//
//				} catch (Exception e) {
//					e.printStackTrace();
//				}
//
//			}
//
//			logger.info("Inward Remittance Detailed Report query==> "
//					+ cpciDetailedReportQuery);
//
//			detailedList = aDBHelper.generateCPCIDetailedReportInGrid(
//					cpciDetailedReportQuery, reportVo);
//
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//		logger.info(ActionConstants.EXITING_METHOD
//				+ "<<generateCPCIDetailedReportInGrid DAO");
//		return detailedList;
//	}

//	public List<ReportVO> generateISBDetailedReportInGrid(ReportVO reportVo)
//			throws Exception {
//
//		logger.info(ActionConstants.ENTERING_METHOD
//				+ "<<generateISBDetailedReportInGrid DAO");
//		List<ReportVO> detailedList = null;
//
//		try {
//
//			DBHelper aDBHelper = new DBHelper();
//			CommonMethods aCommonMethods = new CommonMethods();
//			String isbDetailedReportQuery = "";
//
//			isbDetailedReportQuery = ActionConstants.GETISBDETAILEDRESULTS;
//
//			if (aCommonMethods.isValueAvailable(reportVo.getProductCodeList())) {
//				isbDetailedReportQuery = isbDetailedReportQuery
//						+ " WHERE TRANSACTION_TYPE LIKE '%"
//						+ reportVo.getProductCodeList().trim() + "%'";
//			}
//
//			if (aCommonMethods.isValueAvailable(reportVo.getSolID())) {
//				isbDetailedReportQuery = isbDetailedReportQuery
//						+ " AND SOL_ID LIKE '%" + reportVo.getSolID().trim()
//						+ "%'";
//			}
//
//			if (aCommonMethods.isValueAvailable(reportVo.getCurrency())) {
//				isbDetailedReportQuery = isbDetailedReportQuery
//						+ " AND CURRENCY LIKE '%"
//						+ reportVo.getCurrency().trim() + "%'";
//			}
//
//			/*
//			 * if (aCommonMethods.isValueAvailable(reportVo.getRstatusFilter()))
//			 * { isbDetailedReportQuery = isbDetailedReportQuery +
//			 * " AND STATUS LIKE '%" + reportVo.getRstatusFilter().trim() +
//			 * "%'"; }
//			 */
//			if (aCommonMethods.isValueAvailable(reportVo.getUserIdList())) {
//				isbDetailedReportQuery = isbDetailedReportQuery
//						+ " AND (INPUTUSER LIKE '%"
//						+ reportVo.getUserIdList().trim() + "%'"
//						+ " OR REVIEWUSER LIKE '%"
//						+ reportVo.getUserIdList().trim() + "%'"
//						+ " OR AUTHUSER LIKE '%"
//						+ reportVo.getUserIdList().trim() + "%'"
//						+ " OR FBOMAKER LIKE '%"
//						+ reportVo.getUserIdList().trim() + "%'"
//						+ " OR FBOCHECKER LIKE '%"
//						+ reportVo.getUserIdList().trim() + "%')";
//			}
//
//			if (aCommonMethods.isValueAvailable(reportVo.getUserIdList())) {
//				isbDetailedReportQuery = isbDetailedReportQuery
//						+ " AND STATUS_CHANGED_BY LIKE '%"
//						+ reportVo.getUserIdList().trim() + "%'";
//			}
//			if (aCommonMethods.isValueAvailable(reportVo.getFromDateFilter())
//					&& aCommonMethods.isValueAvailable(reportVo
//							.getToDateFilter())) {
//				isbDetailedReportQuery = isbDetailedReportQuery
//						+ " AND  trunc(TRANSACTION_GENERATE_TIME) BETWEEN "
//						+ "to_date('" + reportVo.getFromDateFilter()
//						+ "','dd-mm-yyyy') AND " + "to_date( '"
//						+ reportVo.getToDateFilter() + "','dd-mm-yyyy')";
//
//			}
//
//			if (!aCommonMethods.isValueAvailable(reportVo.getFromDateFilter())
//					&& aCommonMethods.isValueAvailable(reportVo
//							.getToDateFilter())) {
//				isbDetailedReportQuery = isbDetailedReportQuery
//						+ " AND TRANSACTION_GENERATE_TIME BETWEEN '01-01-2019'"
//						+ " AND '" + reportVo.getToDateFilter() + "'";
//				reportVo.setFromDateFilter("01-01-2019");
//			}
//
//			if (aCommonMethods.isValueAvailable(reportVo.getFromDateFilter())
//					&& !aCommonMethods.isValueAvailable(reportVo
//							.getToDateFilter())) {
//				isbDetailedReportQuery = isbDetailedReportQuery
//						+ " AND TRANSACTION_GENERATE_TIME BETWEEN '"
//						+ reportVo.getFromDateFilter() + "' AND sysdate";
//				try {
//
//					SimpleDateFormat aSimpleDateFormat = new SimpleDateFormat(
//							"dd-MM-yyyy");
//					Date aDate = new Date();
//
//					logger.info("Getting To date filter ==> "
//							+ aSimpleDateFormat.format(aDate));
//
//					reportVo.setToDateFilter(aSimpleDateFormat.format(aDate));
//
//				} catch (Exception e) {
//					e.printStackTrace();
//				}
//			}
//
//			logger.info("ISB Detailed Report query==> "
//					+ isbDetailedReportQuery);
//
//			detailedList = aDBHelper.generateISBDetailedReportInGrid(
//					isbDetailedReportQuery, reportVo);
//
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//		logger.info(ActionConstants.EXITING_METHOD
//				+ "<<generateISBDetailedReportInGrid DAO");
//		return detailedList;
//	}

//	public List<ReportVO> generateFSADetailedReportInGrid(ReportVO reportVo)
//			throws Exception {
//
//		logger.info(ActionConstants.ENTERING_METHOD
//				+ "<<generateFSADetailedReportInGrid DAO");
//
//		List<ReportVO> detailedList = null;
//
//		try {
//
//			DBHelper aDBHelper = new DBHelper();
//			CommonMethods aCommonMethods = new CommonMethods();
//			String fsaDetailedReportQuery = "";
//
//			fsaDetailedReportQuery = ActionConstants.GETFSADETAILEDRESULTS;
//
//			if (aCommonMethods.isValueAvailable(reportVo.getProductCodeList())) {
//				fsaDetailedReportQuery = fsaDetailedReportQuery
//						+ " WHERE TRANSACTION_TYPE LIKE '%"
//						+ reportVo.getProductCodeList().trim() + "%'";
//			}
//
//			if (aCommonMethods.isValueAvailable(reportVo.getSolID())) {
//				fsaDetailedReportQuery = fsaDetailedReportQuery
//						+ " AND SOL_ID LIKE '%" + reportVo.getSolID().trim()
//						+ "%'";
//			}
//
//			if (aCommonMethods.isValueAvailable(reportVo.getCurrency())) {
//				fsaDetailedReportQuery = fsaDetailedReportQuery
//						+ " AND CURRENCY LIKE '%"
//						+ reportVo.getCurrency().trim() + "%'";
//			}
//
//			if (aCommonMethods.isValueAvailable(reportVo.getRstatusFilter())) {
//				fsaDetailedReportQuery = fsaDetailedReportQuery
//						+ " AND STATUS LIKE '%"
//						+ reportVo.getRstatusFilter().trim() + "%'";
//			}
//
//			/*
//			 * if (aCommonMethods.isValueAvailable(reportVo.getUserIdList())) {
//			 * fsaDetailedReportQuery = fsaDetailedReportQuery +
//			 * " AND STATUS_CHANGED_BY LIKE '%" +
//			 * reportVo.getUserIdList().trim() + "%'"; }
//			 */
//			if (aCommonMethods.isValueAvailable(reportVo.getUserIdList())) {
//				fsaDetailedReportQuery = fsaDetailedReportQuery
//						+ " AND (INPUTUSER LIKE '%"
//						+ reportVo.getUserIdList().trim() + "%'"
//						+ " OR REVIEWUSER LIKE '%"
//						+ reportVo.getUserIdList().trim() + "%'"
//						+ " OR AUTHUSER LIKE '%"
//						+ reportVo.getUserIdList().trim() + "%'"
//						+ " OR FBOMAKER LIKE '%"
//						+ reportVo.getUserIdList().trim() + "%'"
//						+ " OR FBOCHECKER LIKE '%"
//						+ reportVo.getUserIdList().trim() + "%')";
//			}
//
//			if (aCommonMethods.isValueAvailable(reportVo.getFromDateFilter())
//					&& aCommonMethods.isValueAvailable(reportVo
//							.getToDateFilter())) {
//				fsaDetailedReportQuery = fsaDetailedReportQuery
//						+ " AND  trunc(TRANSACTION_GENERATE_TIME) BETWEEN "
//						+ "to_date('" + reportVo.getFromDateFilter()
//						+ "','dd-mm-yyyy') AND " + "to_date( '"
//						+ reportVo.getToDateFilter() + "','dd-mm-yyyy')";
//
//			}
//
//			if (!aCommonMethods.isValueAvailable(reportVo.getFromDateFilter())
//					&& aCommonMethods.isValueAvailable(reportVo
//							.getToDateFilter())) {
//				fsaDetailedReportQuery = fsaDetailedReportQuery
//						+ " AND TRANSACTION_GENERATE_TIME BETWEEN '01-01-2019'"
//						+ " AND '" + reportVo.getToDateFilter() + "'";
//				reportVo.setFromDateFilter("01-01-2019");
//			}
//
//			if (aCommonMethods.isValueAvailable(reportVo.getFromDateFilter())
//					&& !aCommonMethods.isValueAvailable(reportVo
//							.getToDateFilter())) {
//				fsaDetailedReportQuery = fsaDetailedReportQuery
//						+ " AND TRANSACTION_GENERATE_TIME BETWEEN '"
//						+ reportVo.getFromDateFilter() + "' AND sysdate";
//				try {
//
//					SimpleDateFormat aSimpleDateFormat = new SimpleDateFormat(
//							"dd-MM-yyyy");
//					Date aDate = new Date();
//
//					logger.info("Getting To date filter==> "
//							+ aSimpleDateFormat.format(aDate));
//
//					reportVo.setToDateFilter(aSimpleDateFormat.format(aDate));
//
//				} catch (Exception e) {
//					e.printStackTrace();
//				}
//			}
//			logger.info("FSA Detailed Report query==> "
//					+ fsaDetailedReportQuery);
//
//			detailedList = aDBHelper.generateFSADetailedReportInGrid(
//					fsaDetailedReportQuery, reportVo);
//
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//		logger.info(ActionConstants.EXITING_METHOD
//				+ "<<generateFSADetailedReportInGrid DAO");
//		return detailedList;
//	}

//	public List<ReportVO> generateIDCDetailedReportInGrid(ReportVO reportVo)
//			throws Exception {
//
//		logger.info(ActionConstants.ENTERING_METHOD
//				+ "<<generateIDCDetailedReportInGrid DAO");
//		List<ReportVO> detailedList = null;
//
//		try {
//
//			DBHelper aDBHelper = new DBHelper();
//			CommonMethods aCommonMethods = new CommonMethods();
//			String idcDetailedReportQuery = "";
//
//			idcDetailedReportQuery = ActionConstants.GETIDCDETAILEDRESULTS;
//
//			if (aCommonMethods.isValueAvailable(reportVo.getProductCodeList())) {
//				idcDetailedReportQuery = idcDetailedReportQuery
//						+ " WHERE TRANSACTION_TYPE LIKE '%"
//						+ reportVo.getProductCodeList().trim() + "%'";
//			}
//
//			if (aCommonMethods.isValueAvailable(reportVo.getSolID())) {
//				idcDetailedReportQuery = idcDetailedReportQuery
//						+ " AND SOL_ID LIKE '%" + reportVo.getSolID().trim()
//						+ "%'";
//			}
//
//			if (aCommonMethods.isValueAvailable(reportVo.getCurrency())) {
//				idcDetailedReportQuery = idcDetailedReportQuery
//						+ " AND CURRENCY LIKE '%"
//						+ reportVo.getCurrency().trim() + "%'";
//			}
//
//			if (aCommonMethods.isValueAvailable(reportVo.getRstatusFilter())) {
//				idcDetailedReportQuery = idcDetailedReportQuery
//						+ " AND STATUS LIKE '%"
//						+ reportVo.getRstatusFilter().trim() + "%'";
//			}
//
//			/*
//			 * if (aCommonMethods.isValueAvailable(reportVo.getUserIdList())) {
//			 * idcDetailedReportQuery = idcDetailedReportQuery +
//			 * " AND STATUS_CHANGED_BY LIKE '%" +
//			 * reportVo.getUserIdList().trim() + "%'"; }
//			 */
//			if (aCommonMethods.isValueAvailable(reportVo.getUserIdList())) {
//				idcDetailedReportQuery = idcDetailedReportQuery
//						+ " AND (INPUTUSER LIKE '%"
//						+ reportVo.getUserIdList().trim() + "%'"
//						+ " OR REVIEWUSER LIKE '%"
//						+ reportVo.getUserIdList().trim() + "%'"
//						+ " OR AUTHUSER LIKE '%"
//						+ reportVo.getUserIdList().trim() + "%'"
//						+ " OR FBOMAKER LIKE '%"
//						+ reportVo.getUserIdList().trim() + "%'"
//						+ " OR FBOCHECKER LIKE '%"
//						+ reportVo.getUserIdList().trim() + "%')";
//			}
//			if (aCommonMethods.isValueAvailable(reportVo.getFromDateFilter())
//					&& aCommonMethods.isValueAvailable(reportVo
//							.getToDateFilter())) {
//				idcDetailedReportQuery = idcDetailedReportQuery
//						+ " AND  trunc(TRANSACTION_GENERATE_TIME) BETWEEN "
//						+ "to_date('" + reportVo.getFromDateFilter()
//						+ "','dd-mm-yyyy') AND " + "to_date( '"
//						+ reportVo.getToDateFilter() + "','dd-mm-yyyy')";
//
//			}
//
//			if (!aCommonMethods.isValueAvailable(reportVo.getFromDateFilter())
//					&& aCommonMethods.isValueAvailable(reportVo
//							.getToDateFilter())) {
//				idcDetailedReportQuery = idcDetailedReportQuery
//						+ " AND TRANSACTION_GENERATE_TIME BETWEEN '01-01-2019'"
//						+ " AND '" + reportVo.getToDateFilter() + "'";
//				reportVo.setFromDateFilter("01-01-2019");
//			}
//
//			if (aCommonMethods.isValueAvailable(reportVo.getFromDateFilter())
//					&& !aCommonMethods.isValueAvailable(reportVo
//							.getToDateFilter())) {
//				idcDetailedReportQuery = idcDetailedReportQuery
//						+ " AND TRANSACTION_GENERATE_TIME BETWEEN '"
//						+ reportVo.getFromDateFilter() + "' AND sysdate";
//				try {
//
//					SimpleDateFormat aSimpleDateFormat = new SimpleDateFormat(
//							"dd-MM-yyyy");
//					Date aDate = new Date();
//					System.out
//							.println("date" + aSimpleDateFormat.format(aDate));
//					reportVo.setToDateFilter(aSimpleDateFormat.format(aDate));
//				} catch (Exception e) {
//					e.printStackTrace();
//				}
//			}
//
//			logger.info("IDC Detailed Report query==> "
//					+ idcDetailedReportQuery);
//
//			detailedList = aDBHelper.generateIDCDetailedReportInGrid(
//					idcDetailedReportQuery, reportVo);
//
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//		logger.info(ActionConstants.EXITING_METHOD
//				+ "<<generateIDCDetailedReportInGrid DAO");
//		return detailedList;
//	}

//	public List<ReportVO> generateODCDetailedReportInGrid(ReportVO reportVo)
//			throws Exception {
//
//		logger.info(ActionConstants.ENTERING_METHOD
//				+ "<<generateODCDetailedReportInGrid DAO");
//
//		List<ReportVO> detailedList = null;
//
//		try {
//
//			DBHelper aDBHelper = new DBHelper();
//			CommonMethods aCommonMethods = new CommonMethods();
//			String odcDetailedReportQuery = "";
//
//			odcDetailedReportQuery = ActionConstants.GETODCDETAILEDRESULTS;
//
//			if (aCommonMethods.isValueAvailable(reportVo.getProductCodeList())) {
//				odcDetailedReportQuery = odcDetailedReportQuery
//						+ " WHERE TRANSACTION_TYPE LIKE '%"
//						+ reportVo.getProductCodeList().trim() + "%'";
//			}
//
//			if (aCommonMethods.isValueAvailable(reportVo.getSolID())) {
//				odcDetailedReportQuery = odcDetailedReportQuery
//						+ " AND SOL_ID LIKE '%" + reportVo.getSolID().trim()
//						+ "%'";
//			}
//
//			if (aCommonMethods.isValueAvailable(reportVo.getCurrency())) {
//				odcDetailedReportQuery = odcDetailedReportQuery
//						+ " AND CURRENCY LIKE '%"
//						+ reportVo.getCurrency().trim() + "%'";
//			}
//
//			if (aCommonMethods.isValueAvailable(reportVo.getRstatusFilter())) {
//				odcDetailedReportQuery = odcDetailedReportQuery
//						+ " AND STATUS LIKE '%"
//						+ reportVo.getRstatusFilter().trim() + "%'";
//			}
//
//			/*
//			 * if (aCommonMethods.isValueAvailable(reportVo.getUserIdList())) {
//			 * odcDetailedReportQuery = odcDetailedReportQuery +
//			 * " AND STATUS_CHANGED_BY LIKE '%" +
//			 * reportVo.getUserIdList().trim() + "%'"; }
//			 */
//			if (aCommonMethods.isValueAvailable(reportVo.getUserIdList())) {
//				odcDetailedReportQuery = odcDetailedReportQuery
//						+ " AND (INPUTUSER LIKE '%"
//						+ reportVo.getUserIdList().trim() + "%'"
//						+ " OR REVIEWUSER LIKE '%"
//						+ reportVo.getUserIdList().trim() + "%'"
//						+ " OR AUTHUSER LIKE '%"
//						+ reportVo.getUserIdList().trim() + "%'"
//						+ " OR FBOMAKER LIKE '%"
//						+ reportVo.getUserIdList().trim() + "%'"
//						+ " OR FBOCHECKER LIKE '%"
//						+ reportVo.getUserIdList().trim() + "%')";
//			}
//			if (aCommonMethods.isValueAvailable(reportVo.getFromDateFilter())
//					&& aCommonMethods.isValueAvailable(reportVo
//							.getToDateFilter())) {
//				odcDetailedReportQuery = odcDetailedReportQuery
//						+ " AND  trunc(TRANSACTION_GENERATE_TIME) BETWEEN "
//						+ "to_date('" + reportVo.getFromDateFilter()
//						+ "','dd-mm-yyyy') AND " + "to_date( '"
//						+ reportVo.getToDateFilter() + "','dd-mm-yyyy')";
//
//			}
//
//			if (!aCommonMethods.isValueAvailable(reportVo.getFromDateFilter())
//					&& aCommonMethods.isValueAvailable(reportVo
//							.getToDateFilter())) {
//				odcDetailedReportQuery = odcDetailedReportQuery
//						+ " AND TRANSACTION_GENERATE_TIME BETWEEN '01-01-2019'"
//						+ " AND '" + reportVo.getToDateFilter() + "'";
//				reportVo.setFromDateFilter("01-01-2019");
//			}
//
//			if (aCommonMethods.isValueAvailable(reportVo.getFromDateFilter())
//					&& !aCommonMethods.isValueAvailable(reportVo
//							.getToDateFilter())) {
//				odcDetailedReportQuery = odcDetailedReportQuery
//						+ " AND TRANSACTION_GENERATE_TIME BETWEEN '"
//						+ reportVo.getFromDateFilter() + "' AND sysdate";
//				try {
//
//					SimpleDateFormat aSimpleDateFormat = new SimpleDateFormat(
//							"dd-MM-yyyy");
//					Date aDate = new Date();
//
//					logger.info("Getting To date filter==> "
//							+ aSimpleDateFormat.format(aDate));
//
//					reportVo.setToDateFilter(aSimpleDateFormat.format(aDate));
//
//				} catch (Exception e) {
//					e.printStackTrace();
//				}
//			}
//
//			logger.info("ODC Detailed Report query==> "
//					+ odcDetailedReportQuery);
//
//			detailedList = aDBHelper.generateODCDetailedReportInGrid(
//					odcDetailedReportQuery, reportVo);
//
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//		logger.info(ActionConstants.EXITING_METHOD
//				+ "<<generateODCDetailedReportInGrid DAO");
//		return detailedList;
//	}

//	public List<ReportVO> generateIGTDetailedReportInGrid(ReportVO reportVo)
//			throws Exception {
//
//		logger.info(ActionConstants.ENTERING_METHOD
//				+ "<<generateIGTDetailedReportInGrid DAO");
//		List<ReportVO> detailedList = null;
//
//		try {
//
//			DBHelper aDBHelper = new DBHelper();
//			CommonMethods aCommonMethods = new CommonMethods();
//			String igtDetailedReportQuery = "";
//
//			igtDetailedReportQuery = ActionConstants.GETIGTDETAILEDRESULTS;
//
//			if (aCommonMethods.isValueAvailable(reportVo.getProductCodeList())) {
//				igtDetailedReportQuery = igtDetailedReportQuery
//						+ " WHERE TRANSACTION_TYPE LIKE '%"
//						+ reportVo.getProductCodeList().trim() + "%'";
//			}
//
//			if (aCommonMethods.isValueAvailable(reportVo.getSolID())) {
//				igtDetailedReportQuery = igtDetailedReportQuery
//						+ " AND SOL_ID LIKE '%" + reportVo.getSolID().trim()
//						+ "%'";
//			}
//
//			if (aCommonMethods.isValueAvailable(reportVo.getCurrency())) {
//				igtDetailedReportQuery = igtDetailedReportQuery
//						+ " AND CURRENCY LIKE '%"
//						+ reportVo.getCurrency().trim() + "%'";
//			}
//
//			if (aCommonMethods.isValueAvailable(reportVo.getRstatusFilter())) {
//				igtDetailedReportQuery = igtDetailedReportQuery
//						+ " AND STATUS LIKE '%"
//						+ reportVo.getRstatusFilter().trim() + "%'";
//			}
//
//			/*
//			 * if (aCommonMethods.isValueAvailable(reportVo.getUserIdList())) {
//			 * igtDetailedReportQuery = igtDetailedReportQuery +
//			 * " AND STATUS_CHANGED_BY LIKE '%" +
//			 * reportVo.getUserIdList().trim() + "%'"; }
//			 */
//			if (aCommonMethods.isValueAvailable(reportVo.getUserIdList())) {
//				igtDetailedReportQuery = igtDetailedReportQuery
//						+ " AND (INPUTUSER LIKE '%"
//						+ reportVo.getUserIdList().trim() + "%'"
//						+ " OR REVIEWUSER LIKE '%"
//						+ reportVo.getUserIdList().trim() + "%'"
//						+ " OR AUTHUSER LIKE '%"
//						+ reportVo.getUserIdList().trim() + "%'"
//						+ " OR FBOMAKER LIKE '%"
//						+ reportVo.getUserIdList().trim() + "%'"
//						+ " OR FBOCHECKER LIKE '%"
//						+ reportVo.getUserIdList().trim() + "%')";
//			}
//
//			if (aCommonMethods.isValueAvailable(reportVo.getFromDateFilter())
//					&& aCommonMethods.isValueAvailable(reportVo
//							.getToDateFilter())) {
//				igtDetailedReportQuery = igtDetailedReportQuery
//						+ " AND  trunc(TRANSACTION_GENERATE_TIME) BETWEEN "
//						+ "to_date('" + reportVo.getFromDateFilter()
//						+ "','dd-mm-yyyy') AND " + "to_date( '"
//						+ reportVo.getToDateFilter() + "','dd-mm-yyyy')";
//
//			}
//
//			if (!aCommonMethods.isValueAvailable(reportVo.getFromDateFilter())
//					&& aCommonMethods.isValueAvailable(reportVo
//							.getToDateFilter())) {
//				igtDetailedReportQuery = igtDetailedReportQuery
//						+ " AND TRANSACTION_GENERATE_TIME BETWEEN '01-01-2019'"
//						+ " AND '" + reportVo.getToDateFilter() + "'";
//				reportVo.setFromDateFilter("01-01-2019");
//			}
//
//			if (aCommonMethods.isValueAvailable(reportVo.getFromDateFilter())
//					&& !aCommonMethods.isValueAvailable(reportVo
//							.getToDateFilter())) {
//				igtDetailedReportQuery = igtDetailedReportQuery
//						+ " AND TRANSACTION_GENERATE_TIME BETWEEN '"
//						+ reportVo.getFromDateFilter() + "' AND sysdate";
//				try {
//
//					SimpleDateFormat aSimpleDateFormat = new SimpleDateFormat(
//							"dd-MM-yyyy");
//					Date aDate = new Date();
//
//					logger.info("Getting To date filter==> "
//							+ aSimpleDateFormat.format(aDate));
//
//					reportVo.setToDateFilter(aSimpleDateFormat.format(aDate));
//
//				} catch (Exception e) {
//					e.printStackTrace();
//				}
//			}
//
//			logger.info("IGT Detailed Report query==> "
//					+ igtDetailedReportQuery);
//
//			detailedList = aDBHelper.generateIGTDetailedReportInGrid(
//					igtDetailedReportQuery, reportVo);
//
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//		logger.info(ActionConstants.EXITING_METHOD
//				+ "<<generateIGTDetailedReportInGrid DAO");
//		return detailedList;
//	}

//	public List<ReportVO> generateCPCODetailedReportInGrid(ReportVO reportVo)
//			throws Exception {
//
//		logger.info(ActionConstants.ENTERING_METHOD
//				+ "<<generateCPCODetailedReportInGrid DAO");
//		List<ReportVO> detailedList = null;
//
//		try {
//
//			DBHelper aDBHelper = new DBHelper();
//			CommonMethods aCommonMethods = new CommonMethods();
//			String cpcoDetailedReportQuery = "";
//
//			cpcoDetailedReportQuery = ActionConstants.GETCPCODETAILEDRESULTS;
//
//			if (aCommonMethods.isValueAvailable(reportVo.getProductCodeList())) {
//				cpcoDetailedReportQuery = cpcoDetailedReportQuery
//						+ " WHERE TRANSACTION_TYPE LIKE '%"
//						+ reportVo.getProductCodeList().trim() + "%'";
//			}
//
//			if (aCommonMethods.isValueAvailable(reportVo.getSolID())) {
//				cpcoDetailedReportQuery = cpcoDetailedReportQuery
//						+ " AND SOL_ID LIKE '%" + reportVo.getSolID().trim()
//						+ "%'";
//			}
//
//			if (aCommonMethods.isValueAvailable(reportVo.getCurrency())) {
//				cpcoDetailedReportQuery = cpcoDetailedReportQuery
//						+ " AND CURRENCY LIKE '%"
//						+ reportVo.getCurrency().trim() + "%'";
//			}
//
//			if (aCommonMethods.isValueAvailable(reportVo.getRstatusFilter())) {
//				cpcoDetailedReportQuery = cpcoDetailedReportQuery
//						+ " AND STATUS LIKE '%"
//						+ reportVo.getRstatusFilter().trim() + "%'";
//			}
//
//			/*
//			 * if (aCommonMethods.isValueAvailable(reportVo.getUserIdList())) {
//			 * cpcoDetailedReportQuery = cpcoDetailedReportQuery +
//			 * " AND STATUS_CHANGED_BY LIKE '%" +
//			 * reportVo.getUserIdList().trim() + "%'"; }
//			 */
//			if (aCommonMethods.isValueAvailable(reportVo.getUserIdList())) {
//				cpcoDetailedReportQuery = cpcoDetailedReportQuery
//						+ " AND (INPUTUSER LIKE '%"
//						+ reportVo.getUserIdList().trim() + "%'"
//						+ " OR REVIEWUSER LIKE '%"
//						+ reportVo.getUserIdList().trim() + "%'"
//						+ " OR AUTHUSER LIKE '%"
//						+ reportVo.getUserIdList().trim() + "%'"
//						+ " OR FBOMAKER LIKE '%"
//						+ reportVo.getUserIdList().trim() + "%'"
//						+ " OR FBOCHECKER LIKE '%"
//						+ reportVo.getUserIdList().trim() + "%')";
//			}
//
//			if (aCommonMethods.isValueAvailable(reportVo.getFromDateFilter())
//					&& aCommonMethods.isValueAvailable(reportVo
//							.getToDateFilter())) {
//				cpcoDetailedReportQuery = cpcoDetailedReportQuery
//						+ " AND  trunc(TRANSACTION_GENERATE_TIME) BETWEEN "
//						+ "to_date('" + reportVo.getFromDateFilter()
//						+ "','dd-mm-yyyy') AND " + "to_date( '"
//						+ reportVo.getToDateFilter() + "','dd-mm-yyyy')";
//
//			}
//
//			if (!aCommonMethods.isValueAvailable(reportVo.getFromDateFilter())
//					&& aCommonMethods.isValueAvailable(reportVo
//							.getToDateFilter())) {
//				cpcoDetailedReportQuery = cpcoDetailedReportQuery
//						+ " AND TRANSACTION_GENERATE_TIME BETWEEN '01-01-2019'"
//						+ " AND '" + reportVo.getToDateFilter() + "'";
//				reportVo.setFromDateFilter("01-01-2019");
//			}
//
//			if (aCommonMethods.isValueAvailable(reportVo.getFromDateFilter())
//					&& !aCommonMethods.isValueAvailable(reportVo
//							.getToDateFilter())) {
//				cpcoDetailedReportQuery = cpcoDetailedReportQuery
//						+ " AND TRANSACTION_GENERATE_TIME BETWEEN '"
//						+ reportVo.getFromDateFilter() + "' AND sysdate";
//				try {
//
//					SimpleDateFormat aSimpleDateFormat = new SimpleDateFormat(
//							"dd-MM-yyyy");
//					Date aDate = new Date();
//
//					logger.info("Getting To date filter==> "
//							+ aSimpleDateFormat.format(aDate));
//
//					reportVo.setToDateFilter(aSimpleDateFormat.format(aDate));
//
//				} catch (Exception e) {
//					e.printStackTrace();
//				}
//
//			}
//
//			logger.info("Outward remittance detailed report query==> "
//					+ cpcoDetailedReportQuery);
//
//			detailedList = aDBHelper.generateCPCODetailedReportInGrid(
//					cpcoDetailedReportQuery, reportVo);
//
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//		logger.info(ActionConstants.EXITING_METHOD
//				+ "<<generateCPCODetailedReportInGrid DAO");
//		return detailedList;
//	}

//	public List<ReportVO> generateFELDetailedReportInGrid(ReportVO reportVo)
//			throws Exception {
//
//		logger.info(ActionConstants.ENTERING_METHOD
//				+ "<<generateFELDetailedReportInGrid DAO");
//		List<ReportVO> detailedList = null;
//
//		try {
//
//			DBHelper aDBHelper = new DBHelper();
//			CommonMethods aCommonMethods = new CommonMethods();
//			String felDetailedReportQuery = "";
//
//			felDetailedReportQuery = ActionConstants.GETFELDETAILEDRESULTS;
//
//			if (aCommonMethods.isValueAvailable(reportVo.getProductCodeList())) {
//				felDetailedReportQuery = felDetailedReportQuery
//						+ " WHERE TRANSACTION_TYPE LIKE '%"
//						+ reportVo.getProductCodeList().trim() + "%'";
//			}
//
//			if (aCommonMethods.isValueAvailable(reportVo.getSolID())) {
//				felDetailedReportQuery = felDetailedReportQuery
//						+ " AND SOL_ID LIKE '%" + reportVo.getSolID().trim()
//						+ "%'";
//			}
//
//			if (aCommonMethods.isValueAvailable(reportVo.getCurrency())) {
//				felDetailedReportQuery = felDetailedReportQuery
//						+ " AND CURRENCY LIKE '%"
//						+ reportVo.getCurrency().trim() + "%'";
//			}
//
//			if (aCommonMethods.isValueAvailable(reportVo.getRstatusFilter())) {
//				felDetailedReportQuery = felDetailedReportQuery
//						+ " AND STATUS LIKE '%"
//						+ reportVo.getRstatusFilter().trim() + "%'";
//			}
//
//			/*
//			 * if (aCommonMethods.isValueAvailable(reportVo.getUserIdList())) {
//			 * felDetailedReportQuery = felDetailedReportQuery +
//			 * " AND STATUS_CHANGED_BY LIKE '%" +
//			 * reportVo.getUserIdList().trim() + "%'"; }
//			 */
//			if (aCommonMethods.isValueAvailable(reportVo.getUserIdList())) {
//				felDetailedReportQuery = felDetailedReportQuery
//						+ " AND (INPUTUSER LIKE '%"
//						+ reportVo.getUserIdList().trim() + "%'"
//						+ " OR REVIEWUSER LIKE '%"
//						+ reportVo.getUserIdList().trim() + "%'"
//						+ " OR AUTHUSER LIKE '%"
//						+ reportVo.getUserIdList().trim() + "%'"
//						+ " OR FBOMAKER LIKE '%"
//						+ reportVo.getUserIdList().trim() + "%'"
//						+ " OR FBOCHECKER LIKE '%"
//						+ reportVo.getUserIdList().trim() + "%')";
//			}
//
//			if (aCommonMethods.isValueAvailable(reportVo.getFromDateFilter())
//					&& aCommonMethods.isValueAvailable(reportVo
//							.getToDateFilter())) {
//				felDetailedReportQuery = felDetailedReportQuery
//						+ " AND  trunc(TRANSACTION_GENERATE_TIME) BETWEEN "
//						+ "to_date('" + reportVo.getFromDateFilter()
//						+ "','dd-mm-yyyy') AND " + "to_date( '"
//						+ reportVo.getToDateFilter() + "','dd-mm-yyyy')";
//
//			}
//
//			if (!aCommonMethods.isValueAvailable(reportVo.getFromDateFilter())
//					&& aCommonMethods.isValueAvailable(reportVo
//							.getToDateFilter())) {
//				felDetailedReportQuery = felDetailedReportQuery
//						+ " AND TRANSACTION_GENERATE_TIME BETWEEN '01-01-2019'"
//						+ " AND '" + reportVo.getToDateFilter() + "'";
//				reportVo.setFromDateFilter("01-01-2019");
//			}
//
//			if (aCommonMethods.isValueAvailable(reportVo.getFromDateFilter())
//					&& !aCommonMethods.isValueAvailable(reportVo
//							.getToDateFilter())) {
//				felDetailedReportQuery = felDetailedReportQuery
//						+ " AND TRANSACTION_GENERATE_TIME BETWEEN '"
//						+ reportVo.getFromDateFilter() + "' AND sysdate";
//				try {
//
//					SimpleDateFormat aSimpleDateFormat = new SimpleDateFormat(
//							"dd-MM-yyyy");
//					Date aDate = new Date();
//
//					logger.info("Getting To date filter==> "
//							+ aSimpleDateFormat.format(aDate));
//
//					reportVo.setToDateFilter(aSimpleDateFormat.format(aDate));
//
//				} catch (Exception e) {
//					e.printStackTrace();
//				}
//			}
//
//			logger.info("FEL Detailed Report query==> "
//					+ felDetailedReportQuery);
//
//			detailedList = aDBHelper.generateFELDetailedReportInGrid(
//					felDetailedReportQuery, reportVo);
//
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//		logger.info(ActionConstants.EXITING_METHOD
//				+ "<<generateFELDetailedReportInGrid DAO");
//		return detailedList;
//	}

//	public List<ReportVO> generateCORDetailedReportInGrid(ReportVO reportVo)
//			throws Exception {
//
//		logger.info(ActionConstants.ENTERING_METHOD
//				+ "<<generateCORDetailedReportInGrid DAO");
//
//		List<ReportVO> detailedList = null;
//
//		try {
//
//			DBHelper aDBHelper = new DBHelper();
//			CommonMethods aCommonMethods = new CommonMethods();
//			String corDetailedReportQuery = "";
//
//			corDetailedReportQuery = ActionConstants.GETCORDETAILEDRESULTS;
//
//			if (aCommonMethods.isValueAvailable(reportVo.getProductCodeList())) {
//				corDetailedReportQuery = corDetailedReportQuery
//						+ " WHERE TRANSACTION_TYPE LIKE '%"
//						+ reportVo.getProductCodeList().trim() + "%'";
//			}
//
//			if (aCommonMethods.isValueAvailable(reportVo.getSolID())) {
//				corDetailedReportQuery = corDetailedReportQuery
//						+ " AND SOL_ID LIKE '%" + reportVo.getSolID().trim()
//						+ "%'";
//			}
//
//			if (aCommonMethods.isValueAvailable(reportVo.getCurrency())) {
//				corDetailedReportQuery = corDetailedReportQuery
//						+ " AND CURRENCY LIKE '%"
//						+ reportVo.getCurrency().trim() + "%'";
//			}
//
//			if (aCommonMethods.isValueAvailable(reportVo.getRstatusFilter())) {
//				corDetailedReportQuery = corDetailedReportQuery
//						+ " AND STATUS LIKE '%"
//						+ reportVo.getRstatusFilter().trim() + "%'";
//			}
//
//			/*
//			 * if (aCommonMethods.isValueAvailable(reportVo.getUserIdList())) {
//			 * corDetailedReportQuery = corDetailedReportQuery +
//			 * " AND STATUS_CHANGED_BY LIKE '%" +
//			 * reportVo.getUserIdList().trim() + "%'"; }
//			 */
//
//			if (aCommonMethods.isValueAvailable(reportVo.getUserIdList())) {
//				corDetailedReportQuery = corDetailedReportQuery
//						+ " AND (INPUTUSER LIKE '%"
//						+ reportVo.getUserIdList().trim() + "%'"
//						+ " OR REVIEWUSER LIKE '%"
//						+ reportVo.getUserIdList().trim() + "%'"
//						+ " OR AUTHUSER LIKE '%"
//						+ reportVo.getUserIdList().trim() + "%'"
//						+ " OR FBOMAKER LIKE '%"
//						+ reportVo.getUserIdList().trim() + "%'"
//						+ " OR FBOCHECKER LIKE '%"
//						+ reportVo.getUserIdList().trim() + "%')";
//			}
//			if (aCommonMethods.isValueAvailable(reportVo.getFromDateFilter())
//					&& aCommonMethods.isValueAvailable(reportVo
//							.getToDateFilter())) {
//				corDetailedReportQuery = corDetailedReportQuery
//						+ " AND  trunc(TRANSACTION_GENERATE_TIME) BETWEEN "
//						+ "to_date('" + reportVo.getFromDateFilter()
//						+ "','dd-mm-yyyy') AND " + "to_date( '"
//						+ reportVo.getToDateFilter() + "','dd-mm-yyyy')";
//
//			}
//
//			if (!aCommonMethods.isValueAvailable(reportVo.getFromDateFilter())
//					&& aCommonMethods.isValueAvailable(reportVo
//							.getToDateFilter())) {
//				corDetailedReportQuery = corDetailedReportQuery
//						+ " AND TRANSACTION_GENERATE_TIME BETWEEN '01-01-2019'"
//						+ " AND '" + reportVo.getToDateFilter() + "'";
//				reportVo.setFromDateFilter("01-01-2019");
//			}
//
//			if (aCommonMethods.isValueAvailable(reportVo.getFromDateFilter())
//					&& !aCommonMethods.isValueAvailable(reportVo
//							.getToDateFilter())) {
//				corDetailedReportQuery = corDetailedReportQuery
//						+ " AND TRANSACTION_GENERATE_TIME BETWEEN '"
//						+ reportVo.getFromDateFilter() + "' AND sysdate";
//				try {
//
//					SimpleDateFormat aSimpleDateFormat = new SimpleDateFormat(
//							"dd-MM-yyyy");
//					Date aDate = new Date();
//
//					logger.info("Getting To date filter==> "
//							+ aSimpleDateFormat.format(aDate));
//
//					reportVo.setToDateFilter(aSimpleDateFormat.format(aDate));
//
//				} catch (Exception e) {
//					e.printStackTrace();
//				}
//			}
//
//			logger.info("Miscellanous detailed report query==> "
//					+ corDetailedReportQuery);
//
//			detailedList = aDBHelper.generateCORDetailedReportInGrid(
//					corDetailedReportQuery, reportVo);
//
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//		logger.info(ActionConstants.EXITING_METHOD
//				+ "<<generateCORDetailedReportInGrid DAO");
//		return detailedList;
//	}

//	public List<ReportVO> generateALLDetailedReportInGrid(ReportVO reportVo)
//			throws Exception {
//
//		logger.info(ActionConstants.ENTERING_METHOD
//				+ "<<generateALLDetailedReportInGrid DAO");
//
//		List<ReportVO> detailedList = null;
//
//		try {
//
//			DBHelper aDBHelper = new DBHelper();
//			CommonMethods aCommonMethods = new CommonMethods();
//			String detailedReportQuery = "";
//
//			detailedReportQuery = ActionConstants.GETALLDETAILEDRESULTS;
//
//			if (aCommonMethods.isValueAvailable(reportVo.getProductCodeList())) {
//				detailedReportQuery = detailedReportQuery
//						+ " WHERE TRANSACTION_TYPE LIKE '%'";
//			}
//
//			if (aCommonMethods.isValueAvailable(reportVo.getSolID())) {
//				detailedReportQuery = detailedReportQuery
//						+ " AND SOL_ID LIKE '%" + reportVo.getSolID().trim()
//						+ "%'";
//			}
//
//			if (aCommonMethods.isValueAvailable(reportVo.getCurrency())) {
//				detailedReportQuery = detailedReportQuery
//						+ " AND CURRENCY LIKE '%"
//						+ reportVo.getCurrency().trim() + "%'";
//			}
//
//			if (aCommonMethods.isValueAvailable(reportVo.getRstatusFilter())) {
//				detailedReportQuery = detailedReportQuery
//						+ " AND STATUS LIKE '%"
//						+ reportVo.getRstatusFilter().trim() + "%'";
//			}
//
//			/*
//			 * if (aCommonMethods.isValueAvailable(reportVo.getUserIdList())) {
//			 * detailedReportQuery = detailedReportQuery +
//			 * " AND STATUS_CHANGED_BY LIKE '%" +
//			 * reportVo.getUserIdList().trim() + "%'"; }
//			 */
//			if (aCommonMethods.isValueAvailable(reportVo.getUserIdList())) {
//				detailedReportQuery = detailedReportQuery
//						+ " AND (INPUTUSER LIKE '%"
//						+ reportVo.getUserIdList().trim() + "%'"
//						+ " OR REVIEWUSER LIKE '%"
//						+ reportVo.getUserIdList().trim() + "%'"
//						+ " OR AUTHUSER LIKE '%"
//						+ reportVo.getUserIdList().trim() + "%'"
//						+ " OR FBOMAKER LIKE '%"
//						+ reportVo.getUserIdList().trim() + "%'"
//						+ " OR FBOCHECKER LIKE '%"
//						+ reportVo.getUserIdList().trim() + "%')";
//			}
//			if (aCommonMethods.isValueAvailable(reportVo.getFromDateFilter())
//					&& aCommonMethods.isValueAvailable(reportVo
//							.getToDateFilter())) {
//				detailedReportQuery = detailedReportQuery
//						+ " AND  trunc(TRANSACTION_GENERATE_TIME) BETWEEN "
//						+ "to_date('" + reportVo.getFromDateFilter()
//						+ "','dd-mm-yyyy') AND " + "to_date( '"
//						+ reportVo.getToDateFilter() + "','dd-mm-yyyy')";
//
//			}
//
//			if (!aCommonMethods.isValueAvailable(reportVo.getFromDateFilter())
//					&& aCommonMethods.isValueAvailable(reportVo
//							.getToDateFilter())) {
//				detailedReportQuery = detailedReportQuery
//						+ " AND TRANSACTION_GENERATE_TIME BETWEEN '01-01-2019'"
//						+ " AND '" + reportVo.getToDateFilter() + "'";
//				reportVo.setFromDateFilter("01-01-2019");
//			}
//
//			if (aCommonMethods.isValueAvailable(reportVo.getFromDateFilter())
//					&& !aCommonMethods.isValueAvailable(reportVo
//							.getToDateFilter())) {
//				detailedReportQuery = detailedReportQuery
//						+ " AND TRANSACTION_GENERATE_TIME BETWEEN '"
//						+ reportVo.getFromDateFilter() + "' AND sysdate";
//				try {
//
//					SimpleDateFormat aSimpleDateFormat = new SimpleDateFormat(
//							"dd-MM-yyyy");
//					Date aDate = new Date();
//
//					logger.info("Getting To date filter==> "
//							+ aSimpleDateFormat.format(aDate));
//
//					reportVo.setToDateFilter(aSimpleDateFormat.format(aDate));
//				} catch (Exception e) {
//					e.printStackTrace();
//				}
//			}
//			logger.info("ALL detailed report query==> " + detailedReportQuery);
//			detailedList = aDBHelper.generateALLDetailedReportInGrid(
//					detailedReportQuery, reportVo);
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//		logger.info(ActionConstants.EXITING_METHOD
//				+ "<<generateALLDetailedReportInGrid DAO");
//		return detailedList;
//	}

	/*public void generateSummaryReportInExcel(ReportVO reportVo)
			throws Exception {

		logger.info(ActionConstants.ENTERING_METHOD
				+ "<<generateSummaryReportInExcel DAO");

		String summaryReportQuery = "";
		CommonMethods aCommonMethods = new CommonMethods();

		try {

			logger.info("Getting product name==> " + reportVo.getProductName());

			if (aCommonMethods.isValueAvailable(reportVo.getProductName())) {

				if (reportVo.getProductName().equalsIgnoreCase("ALL")) {

					reportVo.setProductCodeList("ALL");

				} else {
					reportVo.setProductCodeList(getProductCodeFromDB(reportVo
							.getProductName()));
				}
			}

			logger.info("Getting product code==> "
					+ reportVo.getProductCodeList());

			if (reportVo.getProductCodeList().equalsIgnoreCase("ILC")) {
				summaryReportQuery = ActionConstants.GETILCSUMMARYRESULTS;
				generateExcelSummaryReportQuery(reportVo, summaryReportQuery);
			}

			else if (reportVo.getProductCodeList().equalsIgnoreCase("ELC")) {
				summaryReportQuery = ActionConstants.GETELCSUMMARYRESULTS;
				generateExcelSummaryReportQuery(reportVo, summaryReportQuery);
			}

			else if (reportVo.getProductCodeList().equalsIgnoreCase("FOC")) {
				summaryReportQuery = ActionConstants.GETFOCSUMMARYRESULTS;
				generateExcelSummaryReportQuery(reportVo, summaryReportQuery);
			}

			else if (reportVo.getProductCodeList().equalsIgnoreCase("CPCI")) {
				summaryReportQuery = ActionConstants.GETCPCISUMMARYRESULTS;
				generateExcelSummaryReportQuery(reportVo, summaryReportQuery);
			}

			else if (reportVo.getProductCodeList().equalsIgnoreCase("ISB")) {
				summaryReportQuery = ActionConstants.GETISBSUMMARYRESULTS;
				generateExcelSummaryReportQuery(reportVo, summaryReportQuery);
			}

			else if (reportVo.getProductCodeList().equalsIgnoreCase("FSA")) {
				summaryReportQuery = ActionConstants.GETFSASUMMARYRESULTS;
				generateExcelSummaryReportQuery(reportVo, summaryReportQuery);
			}

			else if (reportVo.getProductCodeList().equalsIgnoreCase("IDC")) {
				summaryReportQuery = ActionConstants.GETIDCSUMMARYRESULTS;
				generateExcelSummaryReportQuery(reportVo, summaryReportQuery);
			}

			else if (reportVo.getProductCodeList().equalsIgnoreCase("ODC")) {
				summaryReportQuery = ActionConstants.GETODCSUMMARYRESULTS;
				generateExcelSummaryReportQuery(reportVo, summaryReportQuery);
			}

			else if (reportVo.getProductCodeList().equalsIgnoreCase("IGT")) {
				summaryReportQuery = ActionConstants.GETIGTSUMMARYRESULTS;
				generateExcelSummaryReportQuery(reportVo, summaryReportQuery);
			}

			else if (reportVo.getProductCodeList().equalsIgnoreCase("CPCO")) {
				summaryReportQuery = ActionConstants.GETCPCOSUMMARYRESULTS;
				generateExcelSummaryReportQuery(reportVo, summaryReportQuery);
			}

			else if (reportVo.getProductCodeList().equalsIgnoreCase("FEL")) {
				summaryReportQuery = ActionConstants.GETFELSUMMARYRESULTS;
				generateExcelSummaryReportQuery(reportVo, summaryReportQuery);
			}

			else if (reportVo.getProductCodeList().equalsIgnoreCase("COR")) {
				summaryReportQuery = ActionConstants.GETCORSUMMARYRESULTS;
				generateExcelSummaryReportQuery(reportVo, summaryReportQuery);
			}

			else if (reportVo.getProductCodeList().equalsIgnoreCase("ALL")) {
				summaryReportQuery = ActionConstants.GETALLSUMMARYRESULTS;
				generateExcelSummaryReportQuery(reportVo, summaryReportQuery);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		logger.info(ActionConstants.EXITING_METHOD
				+ "<<generateReportInExcel DAO");
	}
*/
//	public void generateSummaryReportInExcel(ReportVO reportVo)
//			throws Exception {
//
//		logger.info(ActionConstants.ENTERING_METHOD
//				+ "<<generateSummaryReportInExcel DAO");
//
//		String summaryReportQuery = "";
//		CommonMethods aCommonMethods = new CommonMethods();
//
//		try {
//
//			logger.info("Getting product name==> " + reportVo.getProductName());
//
//			if (aCommonMethods.isValueAvailable(reportVo.getProductName())) {
//
//				if (reportVo.getProductName().equalsIgnoreCase("ALL")) {
//
//					reportVo.setProductCodeList("ALL");
//
//				} else {
//					reportVo.setProductCodeList(getProductCodeFromDB(reportVo
//							.getProductName()));
//				}
//			}
//
//			logger.info("Getting product code==> "
//					+ reportVo.getProductCodeList());
//
//			if (reportVo.getProductCodeList().equalsIgnoreCase("ILC")) {
//				
//				if(reportVo.getReportFrequency().equalsIgnoreCase("Hourly")){
//					summaryReportQuery = ActionConstants.GET_ILCSUMMARYRESULTS_HOURLY;
//					generateExcelSummaryReportQuery(reportVo, summaryReportQuery);
//				}
//				if(reportVo.getReportFrequency().equalsIgnoreCase("Daily")){
//					summaryReportQuery = ActionConstants.GET_ILCSUMMARYRESULTS_DAILY;
//					generateExcelSummaryReportQuery(reportVo, summaryReportQuery);
//				}
//				if(reportVo.getReportFrequency().equalsIgnoreCase("Weekly")){
//					summaryReportQuery = ActionConstants.GET_ILCSUMMARYRESULTS_WEEKLY;
//					generateExcelSummaryReportQuery(reportVo, summaryReportQuery);
//				}
//				if(reportVo.getReportFrequency().equalsIgnoreCase("Monthly")){
//					summaryReportQuery = ActionConstants.GET_ILCSUMMARYRESULTS_MONTHLY;
//					generateExcelSummaryReportQuery(reportVo, summaryReportQuery);
//				}
//				
//			}
//
//			else if (reportVo.getProductCodeList().equalsIgnoreCase("ELC")) {
//				if(reportVo.getReportFrequency().equalsIgnoreCase("Hourly")){
//					summaryReportQuery = ActionConstants.GET_ELCSUMMARYRESULTS_HOURLY;
//					generateExcelSummaryReportQuery(reportVo, summaryReportQuery);
//				}if(reportVo.getReportFrequency().equalsIgnoreCase("Daily")){
//					summaryReportQuery = ActionConstants.GET_ELCSUMMARYRESULTS_DAILY;
//					generateExcelSummaryReportQuery(reportVo, summaryReportQuery);
//				}
//				if(reportVo.getReportFrequency().equalsIgnoreCase("Weekly")){
//					summaryReportQuery = ActionConstants.GET_ELCSUMMARYRESULTS_WEEKLY;
//					generateExcelSummaryReportQuery(reportVo, summaryReportQuery);
//				}
//				if(reportVo.getReportFrequency().equalsIgnoreCase("Monthly")){
//					summaryReportQuery = ActionConstants.GET_ELCSUMMARYRESULTS_MONTHLY;
//					generateExcelSummaryReportQuery(reportVo, summaryReportQuery);
//				}
//			}
//			
//			else if (reportVo.getProductCodeList().equalsIgnoreCase("FOC")) {
//				if(reportVo.getReportFrequency().equalsIgnoreCase("Hourly")){
//				summaryReportQuery = ActionConstants.GET_FOCSUMMARYRESULTS_HOURLY;
//				generateExcelSummaryReportQuery(reportVo, summaryReportQuery);
//				}
//				if(reportVo.getReportFrequency().equalsIgnoreCase("Daily")){
//					summaryReportQuery = ActionConstants.GET_FOCSUMMARYRESULTS_DAILY;
//					generateExcelSummaryReportQuery(reportVo, summaryReportQuery);
//					}
//				if(reportVo.getReportFrequency().equalsIgnoreCase("Weekly")){
//					summaryReportQuery = ActionConstants.GET_FOCSUMMARYRESULTS_WEEKLY;
//					generateExcelSummaryReportQuery(reportVo, summaryReportQuery);
//					}
//				if(reportVo.getReportFrequency().equalsIgnoreCase("Monthly")){
//					summaryReportQuery = ActionConstants.GET_FOCSUMMARYRESULTS_MONTHLY;
//					generateExcelSummaryReportQuery(reportVo, summaryReportQuery);
//					}
//			}
//
//			else if (reportVo.getProductCodeList().equalsIgnoreCase("CPCI")) {
//				
//				  if(reportVo.getReportFrequency().equalsIgnoreCase("Hourly")){
//					  summaryReportQuery = ActionConstants.GET_CPCISUMMARYRESULTS_HOURLY;
//						generateExcelSummaryReportQuery(reportVo, summaryReportQuery);
//						}
//						if(reportVo.getReportFrequency().equalsIgnoreCase("Daily")){
//							summaryReportQuery = ActionConstants.GET_CPCISUMMARYRESULTS_DAILY;
//							generateExcelSummaryReportQuery(reportVo, summaryReportQuery);
//					}
//						if(reportVo.getReportFrequency().equalsIgnoreCase("Weekly")){
//							summaryReportQuery = ActionConstants.GET_CPCISUMMARYRESULTS_WEEKLY;
//							generateExcelSummaryReportQuery(reportVo, summaryReportQuery);
//				      }
//						if(reportVo.getReportFrequency().equalsIgnoreCase("Monthly")){
//							summaryReportQuery = ActionConstants.GET_CPCISUMMARYRESULTS_MONTHLY;
//							generateExcelSummaryReportQuery(reportVo, summaryReportQuery);
//				      }
//			}
//
//			else if (reportVo.getProductCodeList().equalsIgnoreCase("ISB")) {
//				  if(reportVo.getReportFrequency().equalsIgnoreCase("Hourly")){
//				  summaryReportQuery = ActionConstants.GET_ISBSUMMARYRESULTS_HOURLY;
//				  generateExcelSummaryReportQuery(reportVo, summaryReportQuery);
//				  }
//				  if(reportVo.getReportFrequency().equalsIgnoreCase("Daily")){
//						summaryReportQuery = ActionConstants.GET_ISBSUMMARYRESULTS_DAILY;
//						generateExcelSummaryReportQuery(reportVo, summaryReportQuery);
//						  }
//				  if(reportVo.getReportFrequency().equalsIgnoreCase("Weekly")){
//						summaryReportQuery = ActionConstants.GET_ISBSUMMARYRESULTS_WEEKLY;
//						generateExcelSummaryReportQuery(reportVo, summaryReportQuery);
//						  }
//				  if(reportVo.getReportFrequency().equalsIgnoreCase("Monthly")){
//						summaryReportQuery = ActionConstants.GET_ISBSUMMARYRESULTS_MONTHLY;
//						generateExcelSummaryReportQuery(reportVo, summaryReportQuery);
//						  }
//			}
//
//			else if (reportVo.getProductCodeList().equalsIgnoreCase("FSA")) {
//				/*summaryReportQuery = ActionConstants.GETFSASUMMARYRESULTS;
//				generateExcelSummaryReportQuery(reportVo, summaryReportQuery);*/
//				 if(reportVo.getReportFrequency().equalsIgnoreCase("Hourly")){
//					  summaryReportQuery = ActionConstants.GET_FSASUMMARYRESULTS_HOURLY;
//					  generateExcelSummaryReportQuery(reportVo, summaryReportQuery);
//					  }
//					  if(reportVo.getReportFrequency().equalsIgnoreCase("Daily")){
//							summaryReportQuery = ActionConstants.GET_FSASUMMARYRESULTS_DAILY;
//							generateExcelSummaryReportQuery(reportVo, summaryReportQuery);
//							  }
//					  if(reportVo.getReportFrequency().equalsIgnoreCase("Weekly")){
//							summaryReportQuery = ActionConstants.GET_FSASUMMARYRESULTS_WEEKLY;
//							generateExcelSummaryReportQuery(reportVo, summaryReportQuery);
//							  }
//					  if(reportVo.getReportFrequency().equalsIgnoreCase("Monthly")){
//							summaryReportQuery = ActionConstants.GET_FSASUMMARYRESULTS_MONTHLY;
//							generateExcelSummaryReportQuery(reportVo, summaryReportQuery);
//							  }
//			}
//
//			else if (reportVo.getProductCodeList().equalsIgnoreCase("IDC")) {
//				/*summaryReportQuery = ActionConstants.GETIDCSUMMARYRESULTS;
//				generateExcelSummaryReportQuery(reportVo, summaryReportQuery);*/
//				if(reportVo.getReportFrequency().equalsIgnoreCase("Hourly")){
//					  summaryReportQuery = ActionConstants.GET_IDCSUMMARYRESULTS_HOURLY;
//					  generateExcelSummaryReportQuery(reportVo, summaryReportQuery);
//					  }
//					  if(reportVo.getReportFrequency().equalsIgnoreCase("Daily")){
//							summaryReportQuery = ActionConstants.GET_IDCSUMMARYRESULTS_DAILY;
//							generateExcelSummaryReportQuery(reportVo, summaryReportQuery);
//							  }
//					 if(reportVo.getReportFrequency().equalsIgnoreCase("Weekly")){
//							summaryReportQuery = ActionConstants.GET_IDCSUMMARYRESULTS_WEEKLY;
//							generateExcelSummaryReportQuery(reportVo, summaryReportQuery);
//							  }
//					 if(reportVo.getReportFrequency().equalsIgnoreCase("Monthly")){
//							summaryReportQuery = ActionConstants.GET_IDCSUMMARYRESULTS_MONTHLY;
//							generateExcelSummaryReportQuery(reportVo, summaryReportQuery);
//							  }
//			}
//
//			else if (reportVo.getProductCodeList().equalsIgnoreCase("ODC")) {
//				/*summaryReportQuery = ActionConstants.GETODCSUMMARYRESULTS;
//				generateExcelSummaryReportQuery(reportVo, summaryReportQuery);*/
//				  if(reportVo.getReportFrequency().equalsIgnoreCase("Hourly")){
//					  summaryReportQuery = ActionConstants.GET_ODCSUMMARYRESULTS_HOURLY;
//					  generateExcelSummaryReportQuery(reportVo, summaryReportQuery);
//					  }
//				   if(reportVo.getReportFrequency().equalsIgnoreCase("Daily")){
//							summaryReportQuery = ActionConstants.GET_ODCSUMMARYRESULTS_DAILY;
//							generateExcelSummaryReportQuery(reportVo, summaryReportQuery);
//							  }
//				 if(reportVo.getReportFrequency().equalsIgnoreCase("Weekly")){
//							summaryReportQuery = ActionConstants.GET_ODCSUMMARYRESULTS_WEEKLY;
//							generateExcelSummaryReportQuery(reportVo, summaryReportQuery);
//							  }
//				  if(reportVo.getReportFrequency().equalsIgnoreCase("Monthly")){
//							summaryReportQuery = ActionConstants.GET_ODCSUMMARYRESULTS_MONTHLY;
//							generateExcelSummaryReportQuery(reportVo, summaryReportQuery);
//							  }
//			}
//
//			else if (reportVo.getProductCodeList().equalsIgnoreCase("IGT")) {
//				/*summaryReportQuery = ActionConstants.GETIGTSUMMARYRESULTS;
//				generateExcelSummaryReportQuery(reportVo, summaryReportQuery);*/
//				 if(reportVo.getReportFrequency().equalsIgnoreCase("Hourly")){
//					  summaryReportQuery = ActionConstants.GET_IGTSUMMARYRESULTS_HOURLY;
//					  generateExcelSummaryReportQuery(reportVo, summaryReportQuery);
//					  }
//				   if(reportVo.getReportFrequency().equalsIgnoreCase("Daily")){
//							summaryReportQuery = ActionConstants.GET_IGTSUMMARYRESULTS_DAILY;
//							generateExcelSummaryReportQuery(reportVo, summaryReportQuery);
//							  }
//				 if(reportVo.getReportFrequency().equalsIgnoreCase("Weekly")){
//							summaryReportQuery = ActionConstants.GET_IGTSUMMARYRESULTS_WEEKLY;
//							generateExcelSummaryReportQuery(reportVo, summaryReportQuery);
//							  }
//				  if(reportVo.getReportFrequency().equalsIgnoreCase("Monthly")){
//							summaryReportQuery = ActionConstants.GET_IGTSUMMARYRESULTS_MONTHLY;
//							generateExcelSummaryReportQuery(reportVo, summaryReportQuery);
//							  }
//			}
//
//			else if (reportVo.getProductCodeList().equalsIgnoreCase("CPCO")) {
//				/*summaryReportQuery = ActionConstants.GETCPCOSUMMARYRESULTS;
//				generateExcelSummaryReportQuery(reportVo, summaryReportQuery);*/
//			    if(reportVo.getReportFrequency().equalsIgnoreCase("Hourly")){
//					  summaryReportQuery = ActionConstants.GET_CPCOSUMMARYRESULTS_HOURLY;
//					  generateExcelSummaryReportQuery(reportVo, summaryReportQuery);
//					  }
//				   if(reportVo.getReportFrequency().equalsIgnoreCase("Daily")){
//							summaryReportQuery = ActionConstants.GET_CPCOSUMMARYRESULTS_DAILY;
//							generateExcelSummaryReportQuery(reportVo, summaryReportQuery);
//							  }
//				 if(reportVo.getReportFrequency().equalsIgnoreCase("Weekly")){
//							summaryReportQuery = ActionConstants.GET_CPCOSUMMARYRESULTS_WEEKLY;
//							generateExcelSummaryReportQuery(reportVo, summaryReportQuery);
//							  }
//				  if(reportVo.getReportFrequency().equalsIgnoreCase("Monthly")){
//							summaryReportQuery = ActionConstants.GET_CPCOSUMMARYRESULTS_MONTHLY;
//							generateExcelSummaryReportQuery(reportVo, summaryReportQuery);
//							  }
//			}
//
//			else if (reportVo.getProductCodeList().equalsIgnoreCase("FEL")) {
//				/*summaryReportQuery = ActionConstants.GETFELSUMMARYRESULTS;
//				generateExcelSummaryReportQuery(reportVo, summaryReportQuery);*/
//				  if(reportVo.getReportFrequency().equalsIgnoreCase("Hourly")){
//					  summaryReportQuery = ActionConstants.GET_FELSUMMARYRESULTS_HOURLY;
//					  generateExcelSummaryReportQuery(reportVo, summaryReportQuery);
//					  }
//				   if(reportVo.getReportFrequency().equalsIgnoreCase("Daily")){
//							summaryReportQuery = ActionConstants.GET_FELSUMMARYRESULTS_DAILY;
//							generateExcelSummaryReportQuery(reportVo, summaryReportQuery);
//							  }
//				 if(reportVo.getReportFrequency().equalsIgnoreCase("Weekly")){
//							summaryReportQuery = ActionConstants.GET_FELSUMMARYRESULTS_WEEKLY;
//							generateExcelSummaryReportQuery(reportVo, summaryReportQuery);
//							  }
//				  if(reportVo.getReportFrequency().equalsIgnoreCase("Monthly")){
//							summaryReportQuery = ActionConstants.GET_FELSUMMARYRESULTS_MONTHLY;
//							generateExcelSummaryReportQuery(reportVo, summaryReportQuery);
//							  }
//			}
//
//			else if (reportVo.getProductCodeList().equalsIgnoreCase("COR")) {
//				/*summaryReportQuery = ActionConstants.GETCORSUMMARYRESULTS;
//				generateExcelSummaryReportQuery(reportVo, summaryReportQuery);*/
//				 if(reportVo.getReportFrequency().equalsIgnoreCase("Hourly")){
//					  summaryReportQuery = ActionConstants.GET_CORSUMMARYRESULTS_HOURLY;
//					  generateExcelSummaryReportQuery(reportVo, summaryReportQuery);
//					  }
//				   if(reportVo.getReportFrequency().equalsIgnoreCase("Daily")){
//							summaryReportQuery = ActionConstants.GET_CORSUMMARYRESULTS_DAILY;
//							generateExcelSummaryReportQuery(reportVo, summaryReportQuery);
//							  }
//				 if(reportVo.getReportFrequency().equalsIgnoreCase("Weekly")){
//							summaryReportQuery = ActionConstants.GET_CORSUMMARYRESULTS_WEEKLY;
//							generateExcelSummaryReportQuery(reportVo, summaryReportQuery);
//							  }
//				  if(reportVo.getReportFrequency().equalsIgnoreCase("Monthly")){
//							summaryReportQuery = ActionConstants.GET_CORSUMMARYRESULTS_MONTHLY;
//							generateExcelSummaryReportQuery(reportVo, summaryReportQuery);
//							  }
//			}
//
//			else if (reportVo.getProductCodeList().equalsIgnoreCase("ALL")) {
////				summaryReportQuery = ActionConstants.GETALLSUMMARYRESULTS;
////				generateExcelSummaryReportQuery(reportVo, summaryReportQuery);
//				
//				if(reportVo.getReportFrequency().equalsIgnoreCase("Hourly")){
//					summaryReportQuery = ActionConstants.GETALLSUMMARYRESULTS_HOURLY;
//					generateExcelSummaryReportQuery(reportVo,
//							summaryReportQuery);
//					}
//				if(reportVo.getReportFrequency().equalsIgnoreCase("Daily")){
//					summaryReportQuery = ActionConstants.GETALLSUMMARYRESULTS_DAILY;
//					generateExcelSummaryReportQuery(reportVo,
//							summaryReportQuery);
//					}
//				if(reportVo.getReportFrequency().equalsIgnoreCase("Weekly")){
//					summaryReportQuery = ActionConstants.GETALLSUMMARYRESULTS_WEEKLY;
//					generateExcelSummaryReportQuery(reportVo,
//							summaryReportQuery);
//					}
//				if(reportVo.getReportFrequency().equalsIgnoreCase("Monthly")){
//					summaryReportQuery = ActionConstants.GETALLSUMMARYRESULTS_MONTHLY;
//					generateExcelSummaryReportQuery(reportVo,
//							summaryReportQuery);
//					}
//				
//			}
//
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//		logger.info(ActionConstants.EXITING_METHOD
//				+ "<<generateReportInExcel DAO");
//	}
	
//	public void generateExcelSummaryReportQuery(ReportVO reportVo,
//			String summaryReportQuery) throws Exception {
//
//		logger.info(ActionConstants.ENTERING_METHOD
//				+ "<<generateExcelSummaryReportQuery DAO");
//
//		DBHelper aDBHelper = new DBHelper();
//		CommonMethods aCommonMethods = new CommonMethods();
//
//		try {
//
//			if (aCommonMethods.isValueAvailable(reportVo.getProductCodeList())) {
//
//				if (reportVo.getProductCodeList().equalsIgnoreCase("ALL")) {
//					summaryReportQuery = summaryReportQuery
//							+ " WHERE TRANSACTION_TYPE LIKE '%'";
//				} else {
//					summaryReportQuery = summaryReportQuery
//							+ " WHERE TRANSACTION_TYPE LIKE '%"
//							+ reportVo.getProductCodeList().trim() + "%'";
//				}
//			}
//
//			if (aCommonMethods.isValueAvailable(reportVo.getSolID())) {
//				summaryReportQuery = summaryReportQuery + " AND SOL_ID LIKE '%"
//						+ reportVo.getSolID().trim() + "%'";
//			}
//
//			if (aCommonMethods.isValueAvailable(reportVo.getCurrency())) {
//				summaryReportQuery = summaryReportQuery
//						+ " AND CURRENCY LIKE '%"
//						+ reportVo.getCurrency().trim() + "%'";
//			}
//
//			if (aCommonMethods.isValueAvailable(reportVo.getRstatusFilter())) {
//				summaryReportQuery = summaryReportQuery + " AND STATUS LIKE '%"
//						+ reportVo.getRstatusFilter().trim() + "%'";
//			}
//
//			if (aCommonMethods.isValueAvailable(reportVo.getUserIdList())) {
//				summaryReportQuery = summaryReportQuery
//						+ " AND STATUS_CHANGED_BY LIKE '%"
//						+ reportVo.getUserIdList().trim() + "%'";
//			}
//
//			if (aCommonMethods.isValueAvailable(reportVo.getFromDateFilter())
//					&& aCommonMethods.isValueAvailable(reportVo
//							.getToDateFilter())) {
//				summaryReportQuery = summaryReportQuery
//						+ " AND TRANSACTION_GENERATE_TIME BETWEEN '"
//						+ reportVo.getFromDateFilter() + "' AND '"
//						+ reportVo.getToDateFilter() + "'";
//
//			}
//
//			if (!aCommonMethods.isValueAvailable(reportVo.getFromDateFilter())
//					&& aCommonMethods.isValueAvailable(reportVo
//							.getToDateFilter())) {
//				summaryReportQuery = summaryReportQuery
//						+ " AND TRANSACTION_GENERATE_TIME BETWEEN '01-01-2019'"
//						+ " AND '" + reportVo.getToDateFilter() + "'";
//				reportVo.setFromDateFilter("01-01-2019");
//			}
//
//			if (aCommonMethods.isValueAvailable(reportVo.getFromDateFilter())
//					&& !aCommonMethods.isValueAvailable(reportVo
//							.getToDateFilter())) {
//				summaryReportQuery = summaryReportQuery
//						+ " AND TRANSACTION_GENERATE_TIME BETWEEN '"
//						+ reportVo.getFromDateFilter() + "' AND sysdate";
//				try {
//
//					SimpleDateFormat aSimpleDateFormat = new SimpleDateFormat(
//							"dd-MM-yyyy");
//					Date aDate = new Date();
//
//					logger.info("Getting To date filter ==> "
//							+ aSimpleDateFormat.format(aDate));
//
//					reportVo.setToDateFilter(aSimpleDateFormat.format(aDate));
//
//				} catch (Exception e) {
//					e.printStackTrace();
//				}
//			}
//
//			/*if (aCommonMethods.isValueAvailable(reportVo.getReportFrequency())) {
//				summaryReportQuery = summaryReportQuery
//						+ " AND REPORT_FREQUENCY LIKE '%"
//						+ reportVo.getReportFrequency() + "%'";
//			}*/
//			if(reportVo.getReportFrequency().equalsIgnoreCase("Hourly")){
//				summaryReportQuery = summaryReportQuery + " GROUP BY TRANSACTION_TYPE,to_date(TO_CHAR(TRUNC(TRANSACTION_GENERATE_TIME),'DD-MON-YYYY'),'DD-MON-YYYY'),to_date(TO_CHAR(TRUNC(TRANSACTION_GENERATE_TIME),'DD-MON-YYYY'),'DD-MON-YYYY')||' ' ||lpad(TO_CHAR(to_number(TO_CHAR(TRANSACTION_GENERATE_TIME,'HH'))),2,0) ||':00 ' ||'- ' ||TO_CHAR(CASE WHEN to_number(TO_CHAR(TRANSACTION_GENERATE_TIME,'HH'))+1 = 13 THEN '01' ||':00 HRS' ELSE lpad(to_number(TO_CHAR(TRANSACTION_GENERATE_TIME,'HH'))+1,2,0) ||':00 HRS' END )ORDER BY to_date(TO_CHAR(TRUNC(TRANSACTION_GENERATE_TIME),'DD-MON-YYYY'),'DD-MON-YYYY')";
//				}
//				if(reportVo.getReportFrequency().equalsIgnoreCase("Daily")){
//					summaryReportQuery = summaryReportQuery + "group by TRANSACTION_TYPE,trunc(TRANSACTION_GENERATE_TIME) order by TRANSACTION_GENERATE_TIME asc";
//					}
//				if(reportVo.getReportFrequency().equalsIgnoreCase("Weekly")){
//					summaryReportQuery = summaryReportQuery + "";
//					}
//				if(reportVo.getReportFrequency().equalsIgnoreCase("Monthly")){
//					summaryReportQuery = summaryReportQuery + " ";
//					}
//				logger.info("Getting summary report query (Excel) ==> "
//						+ summaryReportQuery);
//			logger.info("Getting summary report query (Excel) ==> "
//					+ summaryReportQuery);
//
//			aDBHelper.generateSummaryReportInExcel(summaryReportQuery);
//
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//		logger.info(ActionConstants.EXITING_METHOD
//				+ "<<generateExcelSummaryReportQuery DAO");
//	}

//	public void generateDetailedReportInExcel(ReportVO reportVo)
//			throws Exception {
//
//		logger.info(ActionConstants.ENTERING_METHOD
//				+ "<<generateDetailedReportInExcel DAO");
//
//		CommonMethods aCommonMethods = new CommonMethods();
//
//		try {
//
//			logger.info("Getting product name==> " + reportVo.getProductName());
//
//			if (aCommonMethods.isValueAvailable(reportVo.getProductName())) {
//
//				if (reportVo.getProductName().equalsIgnoreCase("ALL")) {
//
//					reportVo.setProductCodeList("ALL");
//
//				} else {
//					reportVo.setProductCodeList(getProductCodeFromDB(reportVo
//							.getProductName()));
//				}
//			}
//
//			logger.info("Getting product code==> "
//					+ reportVo.getProductCodeList());
//
//			if (reportVo.getProductCodeList().equalsIgnoreCase("ILC")) {
//				generateILCDetailedReportInExcel(reportVo);
//			}
//
//			else if (reportVo.getProductCodeList().equalsIgnoreCase("ELC")) {
//				generateELCDetailedReportInExcel(reportVo);
//			}
//
//			else if (reportVo.getProductCodeList().equalsIgnoreCase("FOC")) {
//				generateFOCDetailedReportInExcel(reportVo);
//			}
//
//			else if (reportVo.getProductCodeList().equalsIgnoreCase("CPCI")) {
//				generateCPCIDetailedReportInExcel(reportVo);
//			}
//
//			else if (reportVo.getProductCodeList().equalsIgnoreCase("ISB")) {
//				generateISBDetailedReportInExcel(reportVo);
//			}
//
//			else if (reportVo.getProductCodeList().equalsIgnoreCase("FSA")) {
//				generateFSADetailedReportInExcel(reportVo);
//			}
//
//			else if (reportVo.getProductCodeList().equalsIgnoreCase("IDC")) {
//				generateIDCDetailedReportInExcel(reportVo);
//			}
//
//			else if (reportVo.getProductCodeList().equalsIgnoreCase("ODC")) {
//				generateODCDetailedReportInExcel(reportVo);
//			}
//
//			else if (reportVo.getProductCodeList().equalsIgnoreCase("IGT")) {
//				generateIGTDetailedReportInExcel(reportVo);
//			}
//
//			else if (reportVo.getProductCodeList().equalsIgnoreCase("CPCO")) {
//				generateCPCODetailedReportInExcel(reportVo);
//			}
//
//			else if (reportVo.getProductCodeList().equalsIgnoreCase("FEL")) {
//				generateFELDetailedReportInExcel(reportVo);
//			}
//
//			else if (reportVo.getProductCodeList().equalsIgnoreCase("COR")) {
//				generateCORDetailedReportInExcel(reportVo);
//			}
//
//			else if (reportVo.getProductCodeList().equalsIgnoreCase("ALL")) {
//				generateALLDetailedReportInExcel(reportVo);
//			}
//
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//		logger.info(ActionConstants.EXITING_METHOD
//				+ "<<generateDetailedReportInExcel DAO");
//
//	}

//	public void generateISBDetailedReportInExcel(ReportVO reportVo)
//			throws Exception {
//
//		logger.info(ActionConstants.ENTERING_METHOD
//				+ "<<generateISBDetailedReportInExcel DAO");
//
//		DBHelper aDBHelper = new DBHelper();
//		CommonMethods aCommonMethods = new CommonMethods();
//		try {
//
//			String isbDetailedReportQuery = "";
//
//			isbDetailedReportQuery = ActionConstants.GETISBDETAILEDRESULTS;
//
//			if (aCommonMethods.isValueAvailable(reportVo.getProductCodeList())) {
//				isbDetailedReportQuery = isbDetailedReportQuery
//						+ " WHERE TRANSACTION_TYPE LIKE '%"
//						+ reportVo.getProductCodeList().trim() + "%'";
//			}
//
//			if (aCommonMethods.isValueAvailable(reportVo.getSolID())) {
//				isbDetailedReportQuery = isbDetailedReportQuery
//						+ " AND SOL_ID LIKE '%" + reportVo.getSolID().trim()
//						+ "%'";
//			}
//
//			if (aCommonMethods.isValueAvailable(reportVo.getCurrency())) {
//				isbDetailedReportQuery = isbDetailedReportQuery
//						+ " AND CURRENCY LIKE '%"
//						+ reportVo.getCurrency().trim() + "%'";
//			}
//
//			if (aCommonMethods.isValueAvailable(reportVo.getRstatusFilter())) {
//				isbDetailedReportQuery = isbDetailedReportQuery
//						+ " AND STATUS LIKE '%"
//						+ reportVo.getRstatusFilter().trim() + "%'";
//			}
//
//			/*
//			 * if (aCommonMethods.isValueAvailable(reportVo.getUserIdList())) {
//			 * isbDetailedReportQuery = isbDetailedReportQuery +
//			 * " AND STATUS_CHANGED_BY LIKE '%" +
//			 * reportVo.getUserIdList().trim() + "%'"; }
//			 */
//			if (aCommonMethods.isValueAvailable(reportVo.getUserIdList())) {
//				isbDetailedReportQuery = isbDetailedReportQuery
//						+ " AND (INPUTUSER LIKE '%"
//						+ reportVo.getUserIdList().trim() + "%'"
//						+ " OR REVIEWUSER LIKE '%"
//						+ reportVo.getUserIdList().trim() + "%'"
//						+ " OR AUTHUSER LIKE '%"
//						+ reportVo.getUserIdList().trim() + "%'"
//						+ " OR FBOMAKER LIKE '%"
//						+ reportVo.getUserIdList().trim() + "%'"
//						+ " OR FBOCHECKER LIKE '%"
//						+ reportVo.getUserIdList().trim() + "%')";
//			}
//
//			if (aCommonMethods.isValueAvailable(reportVo.getFromDateFilter())
//					&& aCommonMethods.isValueAvailable(reportVo
//							.getToDateFilter())) {
//
//				isbDetailedReportQuery = isbDetailedReportQuery
//						+ " AND  trunc(TRANSACTION_GENERATE_TIME) BETWEEN "
//						+ "to_date('" + reportVo.getFromDateFilter()
//						+ "','dd-mm-yyyy') AND " + "to_date( '"
//						+ reportVo.getToDateFilter() + "','dd-mm-yyyy')";
//			}
//			if (!aCommonMethods.isValueAvailable(reportVo.getFromDateFilter())
//					&& aCommonMethods.isValueAvailable(reportVo
//							.getToDateFilter())) {
//				isbDetailedReportQuery = isbDetailedReportQuery
//						+ " AND trunc(TRANSACTION_GENERATE_TIME) BETWEEN '01-01-2019'"
//						+ " AND '" + reportVo.getToDateFilter() + "'";
//				reportVo.setFromDateFilter("01-01-2019");
//			}
//
//			if (aCommonMethods.isValueAvailable(reportVo.getFromDateFilter())
//					&& !aCommonMethods.isValueAvailable(reportVo
//							.getToDateFilter())) {
//				isbDetailedReportQuery = isbDetailedReportQuery
//						+ " AND trunc(TRANSACTION_GENERATE_TIME) BETWEEN '"
//						+ reportVo.getFromDateFilter() + "' AND sysdate";
//				try {
//
//					SimpleDateFormat aSimpleDateFormat = new SimpleDateFormat(
//							"dd-MM-yyyy");
//					Date aDate = new Date();
//					reportVo.setToDateFilter(aSimpleDateFormat.format(aDate));
//				} catch (Exception e) {
//					e.printStackTrace();
//				}
//			}
//
//			logger.info("Getting ISB Detailed Report Query ==> "
//					+ isbDetailedReportQuery);
//			aDBHelper.generateISBDetailedReportInExcel(isbDetailedReportQuery);
//
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//		logger.info(ActionConstants.EXITING_METHOD
//				+ "<<generateISBDetailedReportInExcel DAO");
//	}

//	public void generateFSADetailedReportInExcel(ReportVO reportVo)
//			throws Exception {
//
//		logger.info(ActionConstants.ENTERING_METHOD
//				+ "<<generateFSADetailedReportInExcel DAO");
//
//		DBHelper aDBHelper = new DBHelper();
//		CommonMethods aCommonMethods = new CommonMethods();
//
//		try {
//
//			String fsaDetailedReportQuery = "";
//
//			fsaDetailedReportQuery = ActionConstants.GETFSADETAILEDRESULTS;
//
//			if (aCommonMethods.isValueAvailable(reportVo.getProductCodeList())) {
//				fsaDetailedReportQuery = fsaDetailedReportQuery
//						+ " WHERE TRANSACTION_TYPE LIKE '%"
//						+ reportVo.getProductCodeList().trim() + "%'";
//			}
//
//			if (aCommonMethods.isValueAvailable(reportVo.getSolID())) {
//				fsaDetailedReportQuery = fsaDetailedReportQuery
//						+ " AND SOL_ID LIKE '%" + reportVo.getSolID().trim()
//						+ "%'";
//			}
//
//			if (aCommonMethods.isValueAvailable(reportVo.getCurrency())) {
//				fsaDetailedReportQuery = fsaDetailedReportQuery
//						+ " AND CURRENCY LIKE '%"
//						+ reportVo.getCurrency().trim() + "%'";
//			}
//
//			if (aCommonMethods.isValueAvailable(reportVo.getRstatusFilter())) {
//				fsaDetailedReportQuery = fsaDetailedReportQuery
//						+ " AND STATUS LIKE '%"
//						+ reportVo.getRstatusFilter().trim() + "%'";
//			}
//
//			/*
//			 * if (aCommonMethods.isValueAvailable(reportVo.getUserIdList())) {
//			 * fsaDetailedReportQuery = fsaDetailedReportQuery +
//			 * " AND STATUS_CHANGED_BY LIKE '%" +
//			 * reportVo.getUserIdList().trim() + "%'"; }
//			 */
//			if (aCommonMethods.isValueAvailable(reportVo.getUserIdList())) {
//				fsaDetailedReportQuery = fsaDetailedReportQuery
//						+ " AND (INPUTUSER LIKE '%"
//						+ reportVo.getUserIdList().trim() + "%'"
//						+ " OR REVIEWUSER LIKE '%"
//						+ reportVo.getUserIdList().trim() + "%'"
//						+ " OR AUTHUSER LIKE '%"
//						+ reportVo.getUserIdList().trim() + "%'"
//						+ " OR FBOMAKER LIKE '%"
//						+ reportVo.getUserIdList().trim() + "%'"
//						+ " OR FBOCHECKER LIKE '%"
//						+ reportVo.getUserIdList().trim() + "%')";
//			}
//
//			if (aCommonMethods.isValueAvailable(reportVo.getFromDateFilter())
//					&& aCommonMethods.isValueAvailable(reportVo
//							.getToDateFilter())) {
//
//				fsaDetailedReportQuery = fsaDetailedReportQuery
//						+ " AND  trunc(TRANSACTION_GENERATE_TIME) BETWEEN "
//						+ "to_date('" + reportVo.getFromDateFilter()
//						+ "','dd-mm-yyyy') AND " + "to_date( '"
//						+ reportVo.getToDateFilter() + "','dd-mm-yyyy')";
//			}
//			if (!aCommonMethods.isValueAvailable(reportVo.getFromDateFilter())
//					&& aCommonMethods.isValueAvailable(reportVo
//							.getToDateFilter())) {
//				fsaDetailedReportQuery = fsaDetailedReportQuery
//						+ " AND trunc(TRANSACTION_GENERATE_TIME) BETWEEN '01-01-2019'"
//						+ " AND '" + reportVo.getToDateFilter() + "'";
//				reportVo.setFromDateFilter("01-01-2019");
//			}
//
//			if (aCommonMethods.isValueAvailable(reportVo.getFromDateFilter())
//					&& !aCommonMethods.isValueAvailable(reportVo
//							.getToDateFilter())) {
//				fsaDetailedReportQuery = fsaDetailedReportQuery
//						+ " AND trunc(TRANSACTION_GENERATE_TIME) BETWEEN '"
//						+ reportVo.getFromDateFilter() + "' AND sysdate";
//				try {
//
//					SimpleDateFormat aSimpleDateFormat = new SimpleDateFormat(
//							"dd-MM-yyyy");
//					Date aDate = new Date();
//					reportVo.setToDateFilter(aSimpleDateFormat.format(aDate));
//				} catch (Exception e) {
//					e.printStackTrace();
//				}
//			}
//
//			logger.info("Getting FSA Detailed Report Query ===> "
//					+ fsaDetailedReportQuery);
//			aDBHelper.generateFSADetailedReportInExcel(fsaDetailedReportQuery);
//
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//		logger.info(ActionConstants.EXITING_METHOD
//				+ "<<generateFSADetailedReportInExcel DAO");
//	}

//	public void generateIDCDetailedReportInExcel(ReportVO reportVo)
//			throws Exception {
//
//		logger.info(ActionConstants.ENTERING_METHOD
//				+ "<<generateIDCDetailedReportInExcel DAO");
//
//		DBHelper aDBHelper = new DBHelper();
//		CommonMethods aCommonMethods = new CommonMethods();
//
//		try {
//
//			String idcDetailedReportQuery = "";
//
//			idcDetailedReportQuery = ActionConstants.GETIDCDETAILEDRESULTS;
//
//			if (aCommonMethods.isValueAvailable(reportVo.getProductCodeList())) {
//				idcDetailedReportQuery = idcDetailedReportQuery
//						+ " WHERE TRANSACTION_TYPE LIKE '%"
//						+ reportVo.getProductCodeList().trim() + "%'";
//			}
//
//			if (aCommonMethods.isValueAvailable(reportVo.getSolID())) {
//				idcDetailedReportQuery = idcDetailedReportQuery
//						+ " AND SOL_ID LIKE '%" + reportVo.getSolID().trim()
//						+ "%'";
//			}
//
//			if (aCommonMethods.isValueAvailable(reportVo.getCurrency())) {
//				idcDetailedReportQuery = idcDetailedReportQuery
//						+ " AND CURRENCY LIKE '%"
//						+ reportVo.getCurrency().trim() + "%'";
//			}
//
//			if (aCommonMethods.isValueAvailable(reportVo.getRstatusFilter())) {
//				idcDetailedReportQuery = idcDetailedReportQuery
//						+ " AND STATUS LIKE '%"
//						+ reportVo.getRstatusFilter().trim() + "%'";
//			}
//
//			/*
//			 * if (aCommonMethods.isValueAvailable(reportVo.getUserIdList())) {
//			 * idcDetailedReportQuery = idcDetailedReportQuery +
//			 * " AND STATUS_CHANGED_BY LIKE '%" +
//			 * reportVo.getUserIdList().trim() + "%'"; }
//			 */
//			if (aCommonMethods.isValueAvailable(reportVo.getUserIdList())) {
//				idcDetailedReportQuery = idcDetailedReportQuery
//						+ " AND (INPUTUSER LIKE '%"
//						+ reportVo.getUserIdList().trim() + "%'"
//						+ " OR REVIEWUSER LIKE '%"
//						+ reportVo.getUserIdList().trim() + "%'"
//						+ " OR AUTHUSER LIKE '%"
//						+ reportVo.getUserIdList().trim() + "%'"
//						+ " OR FBOMAKER LIKE '%"
//						+ reportVo.getUserIdList().trim() + "%'"
//						+ " OR FBOCHECKER LIKE '%"
//						+ reportVo.getUserIdList().trim() + "%')";
//			}
//
//			if (aCommonMethods.isValueAvailable(reportVo.getFromDateFilter())
//					&& aCommonMethods.isValueAvailable(reportVo
//							.getToDateFilter())) {
//
//				idcDetailedReportQuery = idcDetailedReportQuery
//						+ " AND  trunc(TRANSACTION_GENERATE_TIME) BETWEEN "
//						+ "to_date('" + reportVo.getFromDateFilter()
//						+ "','dd-mm-yyyy') AND " + "to_date( '"
//						+ reportVo.getToDateFilter() + "','dd-mm-yyyy')";
//			}
//			if (!aCommonMethods.isValueAvailable(reportVo.getFromDateFilter())
//					&& aCommonMethods.isValueAvailable(reportVo
//							.getToDateFilter())) {
//				idcDetailedReportQuery = idcDetailedReportQuery
//						+ " AND trunc(TRANSACTION_GENERATE_TIME) BETWEEN '01-01-2019'"
//						+ " AND '" + reportVo.getToDateFilter() + "'";
//				reportVo.setFromDateFilter("01-01-2019");
//			}
//
//			if (aCommonMethods.isValueAvailable(reportVo.getFromDateFilter())
//					&& !aCommonMethods.isValueAvailable(reportVo
//							.getToDateFilter())) {
//				idcDetailedReportQuery = idcDetailedReportQuery
//						+ " AND trunc(TRANSACTION_GENERATE_TIME) BETWEEN '"
//						+ reportVo.getFromDateFilter() + "' AND sysdate";
//				try {
//
//					SimpleDateFormat aSimpleDateFormat = new SimpleDateFormat(
//							"dd-MM-yyyy");
//					Date aDate = new Date();
//					reportVo.setToDateFilter(aSimpleDateFormat.format(aDate));
//				} catch (Exception e) {
//					e.printStackTrace();
//				}
//			}
//
//			logger.info("Getting IDC Detailed Report Query ==> "
//					+ idcDetailedReportQuery);
//			aDBHelper.generateIDCDetailedReportInExcel(idcDetailedReportQuery);
//
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//		logger.info(ActionConstants.EXITING_METHOD
//				+ "<<generateIDCDetailedReportInExcel DAO");
//	}

//	public void generateODCDetailedReportInExcel(ReportVO reportVo)
//			throws Exception {
//
//		logger.info(ActionConstants.ENTERING_METHOD
//				+ "<<generateODCDetailedReportInExcel DAO");
//
//		DBHelper aDBHelper = new DBHelper();
//		CommonMethods aCommonMethods = new CommonMethods();
//
//		try {
//
//			String odcDetailedReportQuery = "";
//
//			odcDetailedReportQuery = ActionConstants.GETODCDETAILEDRESULTS;
//
//			if (aCommonMethods.isValueAvailable(reportVo.getProductCodeList())) {
//				odcDetailedReportQuery = odcDetailedReportQuery
//						+ " WHERE TRANSACTION_TYPE LIKE '%"
//						+ reportVo.getProductCodeList().trim() + "%'";
//			}
//
//			if (aCommonMethods.isValueAvailable(reportVo.getSolID())) {
//				odcDetailedReportQuery = odcDetailedReportQuery
//						+ " AND SOL_ID LIKE '%" + reportVo.getSolID().trim()
//						+ "%'";
//			}
//
//			if (aCommonMethods.isValueAvailable(reportVo.getCurrency())) {
//				odcDetailedReportQuery = odcDetailedReportQuery
//						+ " AND CURRENCY LIKE '%"
//						+ reportVo.getCurrency().trim() + "%'";
//			}
//
//			if (aCommonMethods.isValueAvailable(reportVo.getRstatusFilter())) {
//				odcDetailedReportQuery = odcDetailedReportQuery
//						+ " AND STATUS LIKE '%"
//						+ reportVo.getRstatusFilter().trim() + "%'";
//			}
//
//			/*
//			 * if (aCommonMethods.isValueAvailable(reportVo.getUserIdList())) {
//			 * odcDetailedReportQuery = odcDetailedReportQuery +
//			 * " AND STATUS_CHANGED_BY LIKE '%" +
//			 * reportVo.getUserIdList().trim() + "%'"; }
//			 */
//			if (aCommonMethods.isValueAvailable(reportVo.getUserIdList())) {
//				odcDetailedReportQuery = odcDetailedReportQuery
//						+ " AND (INPUTUSER LIKE '%"
//						+ reportVo.getUserIdList().trim() + "%'"
//						+ " OR REVIEWUSER LIKE '%"
//						+ reportVo.getUserIdList().trim() + "%'"
//						+ " OR AUTHUSER LIKE '%"
//						+ reportVo.getUserIdList().trim() + "%'"
//						+ " OR FBOMAKER LIKE '%"
//						+ reportVo.getUserIdList().trim() + "%'"
//						+ " OR FBOCHECKER LIKE '%"
//						+ reportVo.getUserIdList().trim() + "%')";
//			}
//
//			if (aCommonMethods.isValueAvailable(reportVo.getFromDateFilter())
//					&& aCommonMethods.isValueAvailable(reportVo
//							.getToDateFilter())) {
//
//				odcDetailedReportQuery = odcDetailedReportQuery
//						+ " AND  trunc(TRANSACTION_GENERATE_TIME) BETWEEN "
//						+ "to_date('" + reportVo.getFromDateFilter()
//						+ "','dd-mm-yyyy') AND " + "to_date( '"
//						+ reportVo.getToDateFilter() + "','dd-mm-yyyy')";
//			}
//			if (!aCommonMethods.isValueAvailable(reportVo.getFromDateFilter())
//					&& aCommonMethods.isValueAvailable(reportVo
//							.getToDateFilter())) {
//				odcDetailedReportQuery = odcDetailedReportQuery
//						+ " AND trunc(TRANSACTION_GENERATE_TIME) BETWEEN '01-01-2019'"
//						+ " AND '" + reportVo.getToDateFilter() + "'";
//				reportVo.setFromDateFilter("01-01-2019");
//			}
//
//			if (aCommonMethods.isValueAvailable(reportVo.getFromDateFilter())
//					&& !aCommonMethods.isValueAvailable(reportVo
//							.getToDateFilter())) {
//				odcDetailedReportQuery = odcDetailedReportQuery
//						+ " AND trunc(TRANSACTION_GENERATE_TIME) BETWEEN '"
//						+ reportVo.getFromDateFilter() + "' AND sysdate";
//				try {
//
//					SimpleDateFormat aSimpleDateFormat = new SimpleDateFormat(
//							"dd-MM-yyyy");
//					Date aDate = new Date();
//					reportVo.setToDateFilter(aSimpleDateFormat.format(aDate));
//				} catch (Exception e) {
//					e.printStackTrace();
//				}
//			}
//
//			logger.info("Getting odc Detailed Report Query ==> "
//					+ odcDetailedReportQuery);
//			aDBHelper.generateODCDetailedReportInExcel(odcDetailedReportQuery);
//
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//		logger.info(ActionConstants.EXITING_METHOD
//				+ "<<generateODCDetailedReportInExcel DAO");
//	}

//	public void generateALLDetailedReportInExcel(ReportVO reportVo)
//			throws Exception {
//
//		logger.info(ActionConstants.ENTERING_METHOD
//				+ "<<generateALLDetailedReportInExcel DAO");
//
//		DBHelper aDBHelper = new DBHelper();
//		CommonMethods aCommonMethods = new CommonMethods();
//		try {
//
//			String detailedReportQuery = "";
//
//			detailedReportQuery = ActionConstants.GETALLDETAILEDRESULTS;
//
//			if (aCommonMethods.isValueAvailable(reportVo.getProductCodeList())) {
//				detailedReportQuery = detailedReportQuery
//						+ " WHERE TRANSACTION_TYPE LIKE '%'";
//			}
//
//			if (aCommonMethods.isValueAvailable(reportVo.getSolID())) {
//				detailedReportQuery = detailedReportQuery
//						+ " AND SOL_ID LIKE '%" + reportVo.getSolID().trim()
//						+ "%'";
//			}
//
//			if (aCommonMethods.isValueAvailable(reportVo.getCurrency())) {
//				detailedReportQuery = detailedReportQuery
//						+ " AND CURRENCY LIKE '%"
//						+ reportVo.getCurrency().trim() + "%'";
//			}
//
//			if (aCommonMethods.isValueAvailable(reportVo.getRstatusFilter())) {
//				detailedReportQuery = detailedReportQuery
//						+ " AND STATUS LIKE '%"
//						+ reportVo.getRstatusFilter().trim() + "%'";
//			}
//
//			/*
//			 * if (aCommonMethods.isValueAvailable(reportVo.getUserIdList())) {
//			 * detailedReportQuery = detailedReportQuery +
//			 * " AND STATUS_CHANGED_BY LIKE '%" +
//			 * reportVo.getUserIdList().trim() + "%'"; }
//			 */
//			if (aCommonMethods.isValueAvailable(reportVo.getUserIdList())) {
//				detailedReportQuery = detailedReportQuery
//						+ " AND (INPUTUSER LIKE '%"
//						+ reportVo.getUserIdList().trim() + "%'"
//						+ " OR REVIEWUSER LIKE '%"
//						+ reportVo.getUserIdList().trim() + "%'"
//						+ " OR AUTHUSER LIKE '%"
//						+ reportVo.getUserIdList().trim() + "%'"
//						+ " OR FBOMAKER LIKE '%"
//						+ reportVo.getUserIdList().trim() + "%'"
//						+ " OR FBOCHECKER LIKE '%"
//						+ reportVo.getUserIdList().trim() + "%')";
//			}
//			if (aCommonMethods.isValueAvailable(reportVo.getFromDateFilter())
//					&& aCommonMethods.isValueAvailable(reportVo
//							.getToDateFilter())) {
//
//				detailedReportQuery = detailedReportQuery
//						+ " AND  trunc(TRANSACTION_GENERATE_TIME) BETWEEN "
//						+ "to_date('" + reportVo.getFromDateFilter()
//						+ "','dd-mm-yyyy') AND " + "to_date( '"
//						+ reportVo.getToDateFilter() + "','dd-mm-yyyy')";
//			}
//			if (!aCommonMethods.isValueAvailable(reportVo.getFromDateFilter())
//					&& aCommonMethods.isValueAvailable(reportVo
//							.getToDateFilter())) {
//				detailedReportQuery = detailedReportQuery
//						+ " AND trunc(TRANSACTION_GENERATE_TIME) BETWEEN '01-01-2019'"
//						+ " AND '" + reportVo.getToDateFilter() + "'";
//				reportVo.setFromDateFilter("01-01-2019");
//			}
//
//			if (aCommonMethods.isValueAvailable(reportVo.getFromDateFilter())
//					&& !aCommonMethods.isValueAvailable(reportVo
//							.getToDateFilter())) {
//				detailedReportQuery = detailedReportQuery
//						+ " AND trunc(TRANSACTION_GENERATE_TIME) BETWEEN '"
//						+ reportVo.getFromDateFilter() + "' AND sysdate";
//				try {
//
//					SimpleDateFormat aSimpleDateFormat = new SimpleDateFormat(
//							"dd-MM-yyyy");
//					Date aDate = new Date();
//					reportVo.setToDateFilter(aSimpleDateFormat.format(aDate));
//				} catch (Exception e) {
//					e.printStackTrace();
//				}
//			}
//
//			logger.info("Getting detailed Report Query ==> "
//					+ detailedReportQuery);
//			aDBHelper.generateALLDetailedReportInExcel(detailedReportQuery);
//
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//		logger.info(ActionConstants.EXITING_METHOD
//				+ "<<generateALLDetailedReportInExcel DAO");
//	}

//	public void generateIGTDetailedReportInExcel(ReportVO reportVo)
//			throws Exception {
//
//		logger.info(ActionConstants.ENTERING_METHOD
//				+ "<<generateIGTDetailedReportInExcel DAO");
//
//		DBHelper aDBHelper = new DBHelper();
//		CommonMethods aCommonMethods = new CommonMethods();
//		try {
//
//			String igtDetailedReportQuery = "";
//
//			igtDetailedReportQuery = ActionConstants.GETIGTDETAILEDRESULTS;
//
//			if (aCommonMethods.isValueAvailable(reportVo.getProductCodeList())) {
//				igtDetailedReportQuery = igtDetailedReportQuery
//						+ " WHERE TRANSACTION_TYPE LIKE '%"
//						+ reportVo.getProductCodeList().trim() + "%'";
//			}
//
//			if (aCommonMethods.isValueAvailable(reportVo.getSolID())) {
//				igtDetailedReportQuery = igtDetailedReportQuery
//						+ " AND SOL_ID LIKE '%" + reportVo.getSolID().trim()
//						+ "%'";
//			}
//
//			if (aCommonMethods.isValueAvailable(reportVo.getCurrency())) {
//				igtDetailedReportQuery = igtDetailedReportQuery
//						+ " AND CURRENCY LIKE '%"
//						+ reportVo.getCurrency().trim() + "%'";
//			}
//
//			if (aCommonMethods.isValueAvailable(reportVo.getRstatusFilter())) {
//				igtDetailedReportQuery = igtDetailedReportQuery
//						+ " AND STATUS LIKE '%"
//						+ reportVo.getRstatusFilter().trim() + "%'";
//			}
//
//			/*
//			 * if (aCommonMethods.isValueAvailable(reportVo.getUserIdList())) {
//			 * igtDetailedReportQuery = igtDetailedReportQuery +
//			 * " AND STATUS_CHANGED_BY LIKE '%" +
//			 * reportVo.getUserIdList().trim() + "%'"; }
//			 */
//			if (aCommonMethods.isValueAvailable(reportVo.getUserIdList())) {
//				igtDetailedReportQuery = igtDetailedReportQuery
//						+ " AND (INPUTUSER LIKE '%"
//						+ reportVo.getUserIdList().trim() + "%'"
//						+ " OR REVIEWUSER LIKE '%"
//						+ reportVo.getUserIdList().trim() + "%'"
//						+ " OR AUTHUSER LIKE '%"
//						+ reportVo.getUserIdList().trim() + "%'"
//						+ " OR FBOMAKER LIKE '%"
//						+ reportVo.getUserIdList().trim() + "%'"
//						+ " OR FBOCHECKER LIKE '%"
//						+ reportVo.getUserIdList().trim() + "%')";
//			}
//			if (aCommonMethods.isValueAvailable(reportVo.getFromDateFilter())
//					&& aCommonMethods.isValueAvailable(reportVo
//							.getToDateFilter())) {
//
//				igtDetailedReportQuery = igtDetailedReportQuery
//						+ " AND  trunc(TRANSACTION_GENERATE_TIME) BETWEEN "
//						+ "to_date('" + reportVo.getFromDateFilter()
//						+ "','dd-mm-yyyy') AND " + "to_date( '"
//						+ reportVo.getToDateFilter() + "','dd-mm-yyyy')";
//			}
//			if (!aCommonMethods.isValueAvailable(reportVo.getFromDateFilter())
//					&& aCommonMethods.isValueAvailable(reportVo
//							.getToDateFilter())) {
//				igtDetailedReportQuery = igtDetailedReportQuery
//						+ " AND trunc(TRANSACTION_GENERATE_TIME) BETWEEN '01-01-2019'"
//						+ " AND '" + reportVo.getToDateFilter() + "'";
//				reportVo.setFromDateFilter("01-01-2019");
//			}
//
//			if (aCommonMethods.isValueAvailable(reportVo.getFromDateFilter())
//					&& !aCommonMethods.isValueAvailable(reportVo
//							.getToDateFilter())) {
//				igtDetailedReportQuery = igtDetailedReportQuery
//						+ " AND trunc(TRANSACTION_GENERATE_TIME) BETWEEN '"
//						+ reportVo.getFromDateFilter() + "' AND sysdate";
//				try {
//
//					SimpleDateFormat aSimpleDateFormat = new SimpleDateFormat(
//							"dd-MM-yyyy");
//					Date aDate = new Date();
//					reportVo.setToDateFilter(aSimpleDateFormat.format(aDate));
//				} catch (Exception e) {
//					e.printStackTrace();
//				}
//			}
//
//			logger.info("Getting igt Detailed Report Query ==> "
//					+ igtDetailedReportQuery);
//			aDBHelper.generateIGTDetailedReportInExcel(igtDetailedReportQuery);
//
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//		logger.info(ActionConstants.EXITING_METHOD
//				+ "<<generateIGTDetailedReportInExcel DAO");
//	}

//	public void generateCPCODetailedReportInExcel(ReportVO reportVo)
//			throws Exception {
//
//		logger.info(ActionConstants.ENTERING_METHOD
//				+ "<<generateCPCODetailedReportInExcel DAO");
//
//		DBHelper aDBHelper = new DBHelper();
//		CommonMethods aCommonMethods = new CommonMethods();
//		try {
//
//			String cpcoDetailedReportQuery = "";
//
//			cpcoDetailedReportQuery = ActionConstants.GETCPCODETAILEDRESULTS;
//
//			if (aCommonMethods.isValueAvailable(reportVo.getProductCodeList())) {
//				cpcoDetailedReportQuery = cpcoDetailedReportQuery
//						+ " WHERE TRANSACTION_TYPE LIKE '%"
//						+ reportVo.getProductCodeList().trim() + "%'";
//			}
//
//			if (aCommonMethods.isValueAvailable(reportVo.getSolID())) {
//				cpcoDetailedReportQuery = cpcoDetailedReportQuery
//						+ " AND SOL_ID LIKE '%" + reportVo.getSolID().trim()
//						+ "%'";
//			}
//
//			if (aCommonMethods.isValueAvailable(reportVo.getCurrency())) {
//				cpcoDetailedReportQuery = cpcoDetailedReportQuery
//						+ " AND CURRENCY LIKE '%"
//						+ reportVo.getCurrency().trim() + "%'";
//			}
//
//			if (aCommonMethods.isValueAvailable(reportVo.getRstatusFilter())) {
//				cpcoDetailedReportQuery = cpcoDetailedReportQuery
//						+ " AND STATUS LIKE '%"
//						+ reportVo.getRstatusFilter().trim() + "%'";
//			}
//
//			/*
//			 * if (aCommonMethods.isValueAvailable(reportVo.getUserIdList())) {
//			 * cpcoDetailedReportQuery = cpcoDetailedReportQuery +
//			 * " AND STATUS_CHANGED_BY LIKE '%" +
//			 * reportVo.getUserIdList().trim() + "%'"; }
//			 */
//			if (aCommonMethods.isValueAvailable(reportVo.getUserIdList())) {
//				cpcoDetailedReportQuery = cpcoDetailedReportQuery
//						+ " AND (INPUTUSER LIKE '%"
//						+ reportVo.getUserIdList().trim() + "%'"
//						+ " OR REVIEWUSER LIKE '%"
//						+ reportVo.getUserIdList().trim() + "%'"
//						+ " OR AUTHUSER LIKE '%"
//						+ reportVo.getUserIdList().trim() + "%'"
//						+ " OR FBOMAKER LIKE '%"
//						+ reportVo.getUserIdList().trim() + "%'"
//						+ " OR FBOCHECKER LIKE '%"
//						+ reportVo.getUserIdList().trim() + "%')";
//			}
//
//			if (aCommonMethods.isValueAvailable(reportVo.getFromDateFilter())
//					&& aCommonMethods.isValueAvailable(reportVo
//							.getToDateFilter())) {
//
//				cpcoDetailedReportQuery = cpcoDetailedReportQuery
//						+ " AND  trunc(TRANSACTION_GENERATE_TIME) BETWEEN "
//						+ "to_date('" + reportVo.getFromDateFilter()
//						+ "','dd-mm-yyyy') AND " + "to_date( '"
//						+ reportVo.getToDateFilter() + "','dd-mm-yyyy')";
//			}
//			if (!aCommonMethods.isValueAvailable(reportVo.getFromDateFilter())
//					&& aCommonMethods.isValueAvailable(reportVo
//							.getToDateFilter())) {
//				cpcoDetailedReportQuery = cpcoDetailedReportQuery
//						+ " AND trunc(TRANSACTION_GENERATE_TIME) BETWEEN '01-01-2019'"
//						+ " AND '" + reportVo.getToDateFilter() + "'";
//				reportVo.setFromDateFilter("01-01-2019");
//			}
//
//			if (aCommonMethods.isValueAvailable(reportVo.getFromDateFilter())
//					&& !aCommonMethods.isValueAvailable(reportVo
//							.getToDateFilter())) {
//				cpcoDetailedReportQuery = cpcoDetailedReportQuery
//						+ " AND trunc(TRANSACTION_GENERATE_TIME) BETWEEN '"
//						+ reportVo.getFromDateFilter() + "' AND sysdate";
//				try {
//
//					SimpleDateFormat aSimpleDateFormat = new SimpleDateFormat(
//							"dd-MM-yyyy");
//					Date aDate = new Date();
//					reportVo.setToDateFilter(aSimpleDateFormat.format(aDate));
//				} catch (Exception e) {
//					e.printStackTrace();
//				}
//			}
//
//			logger.info("Getting cpco Detailed Report Query==> "
//					+ cpcoDetailedReportQuery);
//			aDBHelper
//					.generateCPCODetailedReportInExcel(cpcoDetailedReportQuery);
//
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//		logger.info(ActionConstants.EXITING_METHOD
//				+ "<<generateCPCODetailedReportInExcel DAO");
//	}

//	public void generateFELDetailedReportInExcel(ReportVO reportVo)
//			throws Exception {
//
//		logger.info(ActionConstants.ENTERING_METHOD
//				+ "<<generateFELDetailedReportInExcel DAO");
//
//		DBHelper aDBHelper = new DBHelper();
//		CommonMethods aCommonMethods = new CommonMethods();
//		try {
//
//			String felDetailedReportQuery = "";
//
//			felDetailedReportQuery = ActionConstants.GETFELDETAILEDRESULTS;
//
//			if (aCommonMethods.isValueAvailable(reportVo.getProductCodeList())) {
//				felDetailedReportQuery = felDetailedReportQuery
//						+ " WHERE TRANSACTION_TYPE LIKE '%"
//						+ reportVo.getProductCodeList().trim() + "%'";
//			}
//
//			if (aCommonMethods.isValueAvailable(reportVo.getSolID())) {
//				felDetailedReportQuery = felDetailedReportQuery
//						+ " AND SOL_ID LIKE '%" + reportVo.getSolID().trim()
//						+ "%'";
//			}
//
//			if (aCommonMethods.isValueAvailable(reportVo.getCurrency())) {
//				felDetailedReportQuery = felDetailedReportQuery
//						+ " AND CURRENCY LIKE '%"
//						+ reportVo.getCurrency().trim() + "%'";
//			}
//
//			if (aCommonMethods.isValueAvailable(reportVo.getRstatusFilter())) {
//				felDetailedReportQuery = felDetailedReportQuery
//						+ " AND STATUS LIKE '%"
//						+ reportVo.getRstatusFilter().trim() + "%'";
//			}
//
//			/*
//			 * if (aCommonMethods.isValueAvailable(reportVo.getUserIdList())) {
//			 * felDetailedReportQuery = felDetailedReportQuery +
//			 * " AND STATUS_CHANGED_BY LIKE '%" +
//			 * reportVo.getUserIdList().trim() + "%'"; }
//			 */
//			if (aCommonMethods.isValueAvailable(reportVo.getUserIdList())) {
//				felDetailedReportQuery = felDetailedReportQuery
//						+ " AND (INPUTUSER LIKE '%"
//						+ reportVo.getUserIdList().trim() + "%'"
//						+ " OR REVIEWUSER LIKE '%"
//						+ reportVo.getUserIdList().trim() + "%'"
//						+ " OR AUTHUSER LIKE '%"
//						+ reportVo.getUserIdList().trim() + "%'"
//						+ " OR FBOMAKER LIKE '%"
//						+ reportVo.getUserIdList().trim() + "%'"
//						+ " OR FBOCHECKER LIKE '%"
//						+ reportVo.getUserIdList().trim() + "%')";
//			}
//
//			if (aCommonMethods.isValueAvailable(reportVo.getFromDateFilter())
//					&& aCommonMethods.isValueAvailable(reportVo
//							.getToDateFilter())) {
//
//				felDetailedReportQuery = felDetailedReportQuery
//						+ " AND  trunc(TRANSACTION_GENERATE_TIME) BETWEEN "
//						+ "to_date('" + reportVo.getFromDateFilter()
//						+ "','dd-mm-yyyy') AND " + "to_date( '"
//						+ reportVo.getToDateFilter() + "','dd-mm-yyyy')";
//			}
//			if (!aCommonMethods.isValueAvailable(reportVo.getFromDateFilter())
//					&& aCommonMethods.isValueAvailable(reportVo
//							.getToDateFilter())) {
//				felDetailedReportQuery = felDetailedReportQuery
//						+ " AND  trunc(TRANSACTION_GENERATE_TIME) BETWEEN '01-01-2019'"
//						+ " AND '" + reportVo.getToDateFilter() + "'";
//				reportVo.setFromDateFilter("01-01-2019");
//			}
//
//			if (aCommonMethods.isValueAvailable(reportVo.getFromDateFilter())
//					&& !aCommonMethods.isValueAvailable(reportVo
//							.getToDateFilter())) {
//				felDetailedReportQuery = felDetailedReportQuery
//						+ " AND  trunc(TRANSACTION_GENERATE_TIME) BETWEEN '"
//						+ reportVo.getFromDateFilter() + "' AND sysdate";
//				try {
//
//					SimpleDateFormat aSimpleDateFormat = new SimpleDateFormat(
//							"dd-MM-yyyy");
//					Date aDate = new Date();
//					reportVo.setToDateFilter(aSimpleDateFormat.format(aDate));
//				} catch (Exception e) {
//					e.printStackTrace();
//				}
//			}
//
//			logger.info("Getting FEL Detailed Report Query ==> "
//					+ felDetailedReportQuery);
//			aDBHelper.generateFELDetailedReportInExcel(felDetailedReportQuery);
//
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//		logger.info(ActionConstants.EXITING_METHOD
//				+ "<<generateFELDetailedReportInExcel DAO");
//	}

//	public void generateCORDetailedReportInExcel(ReportVO reportVo)
//			throws Exception {
//
//		logger.info(ActionConstants.ENTERING_METHOD
//				+ "<<generateCORDetailedReportInExcel DAO");
//
//		DBHelper aDBHelper = new DBHelper();
//		CommonMethods aCommonMethods = new CommonMethods();
//
//		try {
//
//			String corDetailedReportQuery = "";
//
//			corDetailedReportQuery = ActionConstants.GETCORDETAILEDRESULTS;
//
//			if (aCommonMethods.isValueAvailable(reportVo.getProductCodeList())) {
//				corDetailedReportQuery = corDetailedReportQuery
//						+ " WHERE TRANSACTION_TYPE LIKE '%"
//						+ reportVo.getProductCodeList().trim() + "%'";
//			}
//
//			if (aCommonMethods.isValueAvailable(reportVo.getSolID())) {
//				corDetailedReportQuery = corDetailedReportQuery
//						+ " AND SOL_ID LIKE '%" + reportVo.getSolID().trim()
//						+ "%'";
//			}
//
//			if (aCommonMethods.isValueAvailable(reportVo.getCurrency())) {
//				corDetailedReportQuery = corDetailedReportQuery
//						+ " AND CURRENCY LIKE '%"
//						+ reportVo.getCurrency().trim() + "%'";
//			}
//
//			if (aCommonMethods.isValueAvailable(reportVo.getRstatusFilter())) {
//				corDetailedReportQuery = corDetailedReportQuery
//						+ " AND STATUS LIKE '%"
//						+ reportVo.getRstatusFilter().trim() + "%'";
//			}
//
//			/*
//			 * if (aCommonMethods.isValueAvailable(reportVo.getUserIdList())) {
//			 * corDetailedReportQuery = corDetailedReportQuery +
//			 * " AND STATUS_CHANGED_BY LIKE '%" +
//			 * reportVo.getUserIdList().trim() + "%'"; }
//			 */
//			if (aCommonMethods.isValueAvailable(reportVo.getUserIdList())) {
//				corDetailedReportQuery = corDetailedReportQuery
//						+ " AND (INPUTUSER LIKE '%"
//						+ reportVo.getUserIdList().trim() + "%'"
//						+ " OR REVIEWUSER LIKE '%"
//						+ reportVo.getUserIdList().trim() + "%'"
//						+ " OR AUTHUSER LIKE '%"
//						+ reportVo.getUserIdList().trim() + "%'"
//						+ " OR FBOMAKER LIKE '%"
//						+ reportVo.getUserIdList().trim() + "%'"
//						+ " OR FBOCHECKER LIKE '%"
//						+ reportVo.getUserIdList().trim() + "%')";
//			}
//
//			if (aCommonMethods.isValueAvailable(reportVo.getFromDateFilter())
//					&& aCommonMethods.isValueAvailable(reportVo
//							.getToDateFilter())) {
//
//				corDetailedReportQuery = corDetailedReportQuery
//						+ " AND  trunc(TRANSACTION_GENERATE_TIME) BETWEEN "
//						+ "to_date('" + reportVo.getFromDateFilter()
//						+ "','dd-mm-yyyy') AND " + "to_date( '"
//						+ reportVo.getToDateFilter() + "','dd-mm-yyyy')";
//			}
//			if (!aCommonMethods.isValueAvailable(reportVo.getFromDateFilter())
//					&& aCommonMethods.isValueAvailable(reportVo
//							.getToDateFilter())) {
//				corDetailedReportQuery = corDetailedReportQuery
//						+ " AND trunc(TRANSACTION_GENERATE_TIME) BETWEEN '01-01-2019'"
//						+ " AND '" + reportVo.getToDateFilter() + "'";
//				reportVo.setFromDateFilter("01-01-2019");
//			}
//
//			if (aCommonMethods.isValueAvailable(reportVo.getFromDateFilter())
//					&& !aCommonMethods.isValueAvailable(reportVo
//							.getToDateFilter())) {
//				corDetailedReportQuery = corDetailedReportQuery
//						+ " AND trunc(TRANSACTION_GENERATE_TIME) BETWEEN '"
//						+ reportVo.getFromDateFilter() + "' AND sysdate";
//				try {
//
//					SimpleDateFormat aSimpleDateFormat = new SimpleDateFormat(
//							"dd-MM-yyyy");
//					Date aDate = new Date();
//					reportVo.setToDateFilter(aSimpleDateFormat.format(aDate));
//				} catch (Exception e) {
//					e.printStackTrace();
//				}
//			}
//
//			logger.info("Getting COR Detailed Report Query ==> "
//					+ corDetailedReportQuery);
//			aDBHelper.generateCORDetailedReportInExcel(corDetailedReportQuery);
//
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//		logger.info(ActionConstants.EXITING_METHOD
//				+ "<<generateCORDetailedReportInExcel DAO");
//	}

	// ////KARTHIK MISSLANEOUS 01022020 STARTS
	/*
	 * public void updateMakerComment(String missComment, UserTransactionVO
	 * userVo) {
	 * 
	 * logger.info(ActionConstants.ENTERING_METHOD); DBHelper aDBHelper = new
	 * DBHelper(); aDBHelper.updatemakerMiscellComment(userVo,
	 * ActionConstants.UPDATEMISCELLANOUS_COMMENT, missComment);
	 * 
	 * }
	 * 
	 * public void updatecheckerComment(String misscheckerComment,
	 * UserTransactionVO userVo) { logger.info(ActionConstants.ENTERING_METHOD);
	 * DBHelper aDBHelper = new DBHelper();
	 * 
	 * aDBHelper.updateMiscellCheckerComment(userVo,
	 * ActionConstants.UPDATE_MISCELLANOUSCHECKER_COMMENT, misscheckerComment);
	 * 
	 * }
	 * 
	 * public void getMiscellanousComments(UserTransactionVO userVo) { DBHelper
	 * aDBHelper = new DBHelper(); try {
	 * aDBHelper.getmiscellCommentFromDB(userVo,
	 * ActionConstants.GET_MISCELL_COMMENT_QUERY); } catch (Exception e) {
	 * e.printStackTrace(); }
	 * 
	 * }
	 */
	public void updateMakerComment(String missComment, UserTransactionVO userVo) {

		logger.info(ActionConstants.ENTERING_METHOD);
		DBHelper aDBHelper = new DBHelper();
		// CommonMethods acommMethods = new CommonMethods();
		// List<AlertMessagesVO> errorDetailList = new
		// LinkedList<AlertMessagesVO>();

		aDBHelper.updatemakerMiscellComment(userVo,
				ActionConstants.UPDATEMISCELLANOUS_COMMENT, missComment);

	}

	public void updatecheckerComment(String misscheckerComment,
			UserTransactionVO userVo) {
		logger.info(ActionConstants.ENTERING_METHOD);
		DBHelper aDBHelper = new DBHelper();

		aDBHelper.updateMiscellCheckerComment(userVo,
				ActionConstants.UPDATE_MISCELLANOUSCHECKER_COMMENT,
				misscheckerComment);

	}

	public void getMiscellanousComments(UserTransactionVO userVo) {
		DBHelper aDBHelper = new DBHelper();
		try {
			aDBHelper.getmiscellCommentFromDB(userVo,
					ActionConstants.GET_MISCELL_COMMENT_QUERY);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	// //KARTHIK MISSLANEOUS 01022020 ENDS

	/* ADDED BY CHANDRU */

	public List<AlertMessagesVO> checkTransInProgressTI(
			UserTransactionVO userVo, List<AlertMessagesVO> errorDetailList) {
		CommonMethods aCommonMethods = new CommonMethods();
		DBHelper aDBHelper = new DBHelper();
		boolean lockStatus = false;
		String tiReferenceNo = "";
		try {
			if (userVo.getProductCode().trim().equalsIgnoreCase("ILC")) {
				tiReferenceNo = userVo.getTiReferanceNo();
			}
			if (tiReferenceNo != null) {
				if (aCommonMethods.isValueAvailable(userVo.getRequestId())) {
					lockStatus = aDBHelper.getTIInprogressCount(tiReferenceNo,
							userVo.getRequestId(),
							ActionConstants.GETTIINPROGRESSTRANSCOUNT);
					if (lockStatus) {
						errorDetailList = aCommonMethods.setErrorInList(
								ActionConstants.ERRORCODE045, errorDetailList);
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return errorDetailList;
	}

	/* ADDED BY CHANDRU */
	
	
public String getStepPhaseFromDB(String requestId) throws Exception {
		
		DBHelper aDBHelper = new DBHelper();
		String stepPhase = "";
		try {
			stepPhase = aDBHelper.getValueFromDB(requestId,
					ActionConstants.GETSTEPPHASE_NAME_QUERY);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		logger.info(ActionConstants.EXITING_METHOD + ">>" + stepPhase);
		return stepPhase;
	}
}
