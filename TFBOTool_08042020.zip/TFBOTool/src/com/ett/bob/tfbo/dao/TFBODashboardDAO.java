package com.ett.bob.tfbo.dao;

import java.util.LinkedList;
import java.util.List;

import org.apache.log4j.Logger;

import com.ett.bob.tfbo.dbutil.DashboardHelper;
import com.ett.bob.tfbo.model.TFBODashboardCountVO;
import com.ett.bob.tfbo.model.TFBODashboardVO;
import com.ett.bob.tfbo.util.ActionConstants;

public class TFBODashboardDAO {
	private static Logger logger = Logger.getLogger(TFBODashboardDAO.class
			.getName());

	public void setDashboardAtBranch(TFBODashboardVO branchDB) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		DashboardHelper aDashboardHelper = new DashboardHelper();
		List<TFBODashboardCountVO> eachRowCount = new LinkedList<TFBODashboardCountVO>();
		try {
			eachRowCount.addAll(aDashboardHelper
					.getEachRowCount(1, "Pending With Maker",
							ActionConstants.GETATBRANCHROW1_QUERY));
			eachRowCount.addAll(aDashboardHelper.getEachRowCount(2,
					"Pending With Checker",
					ActionConstants.GETATBRANCHROW2_QUERY));
			eachRowCount.addAll(aDashboardHelper.getEachRowCount(3,
					"Query by FBO", ActionConstants.GETATBRANCHROW3_QUERY));
			eachRowCount.addAll(aDashboardHelper.getEachRowCount(4, "Rejected",
					ActionConstants.GETATBRANCHROW4_QUERY));
			eachRowCount.addAll(aDashboardHelper.getEachRowCount(5,
					"Approved-Completed in TFBO",
					ActionConstants.GETATBRANCHROW5_QUERY));
			branchDB.setDashboardBranchCountList(eachRowCount);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		logger.info(ActionConstants.EXITING_METHOD);
	}

	/*
	 * public void setDashboardAtFBO(TFBODashboardVO branchDB) throws Exception
	 * { logger.info(ActionConstants.ENTERING_METHOD); DashboardHelper
	 * aDashboardHelper = new DashboardHelper(); List<TFBODashboardCountVO>
	 * eachRowCount = new LinkedList<TFBODashboardCountVO>(); try {
	 * eachRowCount.addAll(aDashboardHelper.getEachRowCount(6,
	 * "Pending for Scrutinity", ActionConstants.GETATBRANCHROW6_QUERY));
	 * eachRowCount.addAll(aDashboardHelper.getEachRowCount(7,
	 * "Queried requests", ActionConstants.GETATBRANCHROW7_QUERY));
	 * eachRowCount.addAll(aDashboardHelper.getEachRowCount(8, "Rejected",
	 * ActionConstants.GETATBRANCHROW8_QUERY));
	 * eachRowCount.addAll(aDashboardHelper.getEachRowCount(9,
	 * "Transaction Pending for Entry in FBTI",
	 * ActionConstants.GETATBRANCHROW9_QUERY));
	 * eachRowCount.addAll(aDashboardHelper.getEachRowCount(10,
	 * "Transaction Pending for Approval in FBTI",
	 * ActionConstants.GETATBRANCHROW10_QUERY));
	 * eachRowCount.addAll(aDashboardHelper.getEachRowCount(11,
	 * "Approved-Completed in FBTI", ActionConstants.GETATBRANCHROW11_QUERY));
	 * branchDB.setDashboardFBOCountList(eachRowCount); } catch (Exception e) {
	 * e.printStackTrace(); throw e; }
	 * logger.info(ActionConstants.EXITING_METHOD); }
	 */
	/*
	 * public void setDashboardAtFBO(TFBODashboardVO branchDB) throws Exception
	 * { logger.info(ActionConstants.ENTERING_METHOD); DashboardHelper
	 * aDashboardHelper = new DashboardHelper(); List<TFBODashboardCountVO>
	 * eachRowCount = new LinkedList<TFBODashboardCountVO>(); try {
	 * eachRowCount.addAll(aDashboardHelper.getEachRowCount(6,
	 * "Pending for Scrutinity", ActionConstants.GETATBRANCHROW6_QUERY));
	 * eachRowCount.addAll(aDashboardHelper.getEachRowCount(7,
	 * "Queried requests", ActionConstants.GETATBRANCHROW7_QUERY));
	 * eachRowCount.addAll(aDashboardHelper.getEachRowCount(8, "Rejected",
	 * ActionConstants.GETATBRANCHROW8_QUERY));
	 * eachRowCount.addAll(aDashboardHelper.getEachRowCountDUMMY(9,
	 * "Transaction Pending for Entry in FBTI",
	 * ActionConstants.GETATBRANCHROW9_QUERY,
	 * ActionConstants.idcDummyDirectInp));
	 * eachRowCount.addAll(aDashboardHelper.getEachRowCountDUMMY(10,
	 * "Transaction Pending for Approval in FBTI",
	 * ActionConstants.GETATBRANCHROW10_QUERY,
	 * ActionConstants.idcDummyDirectAuth));
	 * eachRowCount.addAll(aDashboardHelper.getEachRowCountDUMMYFLAG(11,
	 * "Approved-Completed in FBTI", ActionConstants.GETATBRANCHROW11_QUERY,
	 * ActionConstants.idcDummyDirectComp,
	 * ActionConstants.idcDummyDirectCompFlag));
	 * branchDB.setDashboardFBOCountList(eachRowCount); } catch (Exception e) {
	 * e.printStackTrace(); throw e; }
	 * logger.info(ActionConstants.EXITING_METHOD); }
	 */

	public void setDashboardAtFBO(TFBODashboardVO branchDB) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		DashboardHelper aDashboardHelper = new DashboardHelper();
		List<TFBODashboardCountVO> eachRowCount = new LinkedList<TFBODashboardCountVO>();
		try {
			eachRowCount.addAll(aDashboardHelper.getEachRowCount(6,
					"Pending for Scrutinity",
					ActionConstants.GETATBRANCHROW6_QUERY));
//			eachRowCount.addAll(aDashboardHelper.getEachRowCount(7,
//					"Queried requests", ActionConstants.GETATBRANCHROW7_QUERY));//pandi
			
			eachRowCount.addAll(aDashboardHelper.getEachRowCountDUMMY(9,
					"Transaction Pending for Entry in FBTI",
					ActionConstants.GETATBRANCHROW9_QUERY,
					ActionConstants.idcDummyDirectInp,
					ActionConstants.GET_TFBO_MIS_COUNTQUERY));
			eachRowCount.addAll(aDashboardHelper.getEachRowCountDUMMY(10,
					"Transaction Pending for Approval in FBTI",
					ActionConstants.GETATBRANCHROW10_QUERY,
					ActionConstants.idcDummyDirectAuth,
					ActionConstants.GET_TFBO_MIS_CHCKER_COUNT));
			eachRowCount.addAll(aDashboardHelper.getEachRowCountDUMMYFLAG(11,
					"Approved-Completed in FBTI",
					ActionConstants.GETATBRANCHROW11_QUERY,
					ActionConstants.idcDummyDirectComp,
					ActionConstants.idcDummyDirectCompFlag,
					ActionConstants.odcDummyDirectCompFlag,
					ActionConstants.GET_TFBO_MIS_MAKER_COUNT,
					ActionConstants.elcDummyCompFlag));
			eachRowCount.addAll(aDashboardHelper.getEachRowCount(8, "Rejected",
					ActionConstants.GETATBRANCHROW8_QUERY));//pandi
			branchDB.setDashboardFBOCountList(eachRowCount);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		logger.info(ActionConstants.EXITING_METHOD);
	}
}
