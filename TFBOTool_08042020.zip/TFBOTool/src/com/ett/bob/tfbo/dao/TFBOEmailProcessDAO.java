package com.ett.bob.tfbo.dao;

import org.apache.log4j.Logger;

import com.ett.bob.tfbo.commonutil.CommonMethods;
import com.ett.bob.tfbo.model.TFBOReminderVO;
import com.ett.bob.tfbo.model.UserTransactionVO;
import com.ett.bob.tfbo.util.ActionConstants;

public class TFBOEmailProcessDAO {
	private static Logger logger = Logger.getLogger(TFBOEmailProcessDAO.class
			.getName());

	public String getMailSubjectToBranch(UserTransactionVO userVo) {
		logger.info(ActionConstants.ENTERING_METHOD);
		CommonMethods aCommonMethods = new CommonMethods();
		String tiReferenceNo = userVo.getTiReferanceNo();
		if (!aCommonMethods.isValueAvailable(tiReferenceNo)) {
			tiReferenceNo = userVo.getRequestId();
		}
		String mailSubjectToBranch = "BarodaINSTA Transaction Acknowledgement(BN): "
				+ userVo.getProductName() + "-" + tiReferenceNo;
		logger.info("Mail Subject-->" + mailSubjectToBranch);
		logger.info(ActionConstants.EXITING_METHOD);
		return mailSubjectToBranch;
	}

	public String getMailSubjectToCustomer(UserTransactionVO userVo) {
		logger.info(ActionConstants.ENTERING_METHOD);
		CommonMethods aCommonMethods = new CommonMethods();
		String tiReferenceNo = userVo.getTiReferanceNo();
		if (!aCommonMethods.isValueAvailable(tiReferenceNo)) {
			tiReferenceNo = userVo.getRequestId();
		}
		String mailSubjectToCustomer = "BarodaINSTA Transaction Acknowledgement(CN): "
				+ userVo.getProductName() + "-" + tiReferenceNo;
		logger.info("Mail Subject-->" + mailSubjectToCustomer);
		logger.info(ActionConstants.EXITING_METHOD);
		return mailSubjectToCustomer;
	}

	public String getMailBodyToBranch(UserTransactionVO userVo) {
		logger.info(ActionConstants.ENTERING_METHOD);
		CommonMethods aCommonMethods = new CommonMethods();
		String tiReferenceNo = userVo.getTiReferanceNo();
		if (!aCommonMethods.isValueAvailable(tiReferenceNo)) {
			tiReferenceNo = userVo.getRequestId();
		}
		String mailBodyToBranch = "Dear Sir/Madam," + "\n" + "\n"
				+ "We have received your request for "
				+ userVo.getProductName()
				+ " bearing the system reference (ref."
				+ tiReferenceNo
				+ "). We request you to provide clarification on following points to enable us to complete the transaction."
				+ "\n\n"
				+ "Product Name: "
				+ userVo.getProductName()
				+ "\n"
				+ "Customer Details: "
				+ userVo.getCustomeCif()
				+ "\n"
				+ "Customer reference: "
				+ userVo.getRequestId()
				+ "\n"
				+ "Amount: "
				+ userVo.getAmount()
				+ " "
				+ userVo.getCurrency()
				+ "\n"
				+ "Clarification sought:"
				+ userVo.getUserComment()
				+ "\n"
				+ "\n"
				+ "Thank you for choosing Bank of Baroda. We look forward to more opportunities to serve you."
				+ "\n"
				+ "This is an auto generated Email. Please reach out to the base branch for revert and further queries."
				+ "\n" + "\n" + "Best Regards" + "\n" + "Bank of Baroda";
		logger.info("Mail body-->" + mailBodyToBranch);
		logger.info(ActionConstants.EXITING_METHOD);
		return mailBodyToBranch;
	}

	public String getMailBodyToCustomer(UserTransactionVO userVo) {
		logger.info(ActionConstants.ENTERING_METHOD);
		CommonMethods aCommonMethods = new CommonMethods();
		String tiReferenceNo = userVo.getTiReferanceNo();
		if (!aCommonMethods.isValueAvailable(tiReferenceNo)) {
			tiReferenceNo = userVo.getRequestId();
		}
		String mailBodyToCustomer = "Dear Sir/Madam," + "\n" + "\n"
				+ "We have received your request for "
				+ userVo.getProductName()
				+ " bearing the system reference (ref."
				+ tiReferenceNo
				+ "). We request you to provide clarification on following points to enable us to complete the transaction."
				+ "\n\n"
				+ "Product Name: "
				+ userVo.getProductName()
				+ "\n"
				+ "Customer reference: "
				+ userVo.getRequestId()
				+ "\n"
				+ "Amount: "
				+ userVo.getAmount()
				+ " "
				+ userVo.getCurrency()
				+ "\n"
				+ "Clarification sought:"
				+ userVo.getMailToCustomer()
				+ "\n"
				+ "\n"
				+ "Thank you for choosing Bank of Baroda. We look forward to more opportunities to serve you."
				+ "\n"
				+ "This is an auto generated Email. Please reach out to the base branch for revert and further queries."
				+ "\n" + "\n" + "Best Regards" + "\n" + "Bank of Baroda";
		logger.info("Mail body-->" + mailBodyToCustomer);
		logger.info(ActionConstants.EXITING_METHOD);
		return mailBodyToCustomer;
	}

	public String getMailSubjectToReminder(TFBOReminderVO reminderVO) {
		logger.info(ActionConstants.ENTERING_METHOD);
		CommonMethods aCommonMethods = new CommonMethods();
		String tiReferenceNo = reminderVO.getTiReference();
		if (!aCommonMethods.isValueAvailable(tiReferenceNo)) {
			tiReferenceNo = reminderVO.getRequestId();
		}
		String mailSubjectToBranch = "REMINDER for Query pending response from Branch : -"
				+ tiReferenceNo;
		logger.info("Mail Subject-->" + mailSubjectToBranch);
		logger.info(ActionConstants.EXITING_METHOD);
		return mailSubjectToBranch;

	}

	public String getMailBodyToReminder(TFBOReminderVO reminderVO) {
		logger.info(ActionConstants.ENTERING_METHOD);
		CommonMethods aCommonMethods = new CommonMethods();
		String tiReferenceNo = reminderVO.getTiReference();
		if (!aCommonMethods.isValueAvailable(tiReferenceNo)) {
			tiReferenceNo = reminderVO.getRequestId();
		}
		String mailBodyToBranch = "Dear Sir/Madam,"
				+ "\n"
				+ "\n"
				+ "Please note that for the below mentioned transaction, response against Query raised by TFBO is still pending at your end:"
				+ "\n" + "Customer ID: "
				+ reminderVO.getCustomeCif()
				+ "\n"
				+ "Customer Name: "
				+ reminderVO.getCustomeName()
				+ "\n"
				+ "Product Type: "
				+ reminderVO.getProdDescription()
				+ "\n"
				+ "Transaction Amount: "
				+ reminderVO.getAmount()
				+ "\n"
				+ "Tool reference No.: "
				+ reminderVO.getRequestId()
				+ "\n"
				+ "Ti reference No.: "
				+ tiReferenceNo
				+ "\n"
				+ "Event: "
				+ reminderVO.getEvtDescription()
				+ "\n"
				+ "\n"
				+ "Kindly respond at the earliest to enable TFBO to complete processing of transaction."
				+ "\n" + "\n" + "Regards," + "\n" + "Trade Finance Back Office";
		logger.info("Mail body-->" + mailBodyToBranch);
		logger.info(ActionConstants.EXITING_METHOD);
		return mailBodyToBranch;
	}
}
