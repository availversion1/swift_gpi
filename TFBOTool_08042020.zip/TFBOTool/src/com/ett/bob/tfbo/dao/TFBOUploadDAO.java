package com.ett.bob.tfbo.dao;

import java.util.LinkedList;
import java.util.List;

import org.apache.log4j.Logger;

import com.ett.bob.tfbo.dbutil.DBHelper;
import com.ett.bob.tfbo.model.CustomerProfileManageVO;
import com.ett.bob.tfbo.model.UserTransactionVO;
import com.ett.bob.tfbo.util.ActionConstants;

public class TFBOUploadDAO {
	private static Logger logger = Logger.getLogger(TFBOUploadDAO.class
			.getName());

	public void uploadDocumentInDB(String transID, String fileName,
			String fileLocation, String userName,String typeOfDoc) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		DBHelper aDBHelper = new DBHelper();
		String docDesc = "";
		try {
			
			if (typeOfDoc.equals("APP")) {
				docDesc = "Application Form";
			} else if (typeOfDoc.equals("CIN")) {
				docDesc = "Commercial Invoice";
			} else if (typeOfDoc.equals("CCP")) {
				docDesc = "Copy of Contract/Proforma Invoice";
			} else if (typeOfDoc.equals("DBE")) {
				docDesc = "Draft / Bill of Exchange";
			} else if (typeOfDoc.equals("RCS")) {
				docDesc = "Remitting Bank Covering Schedule";
			} else if (typeOfDoc.equals("SBD")) {
				docDesc = "Shipping Document (Bill of Lading, Airway Bill, Postal Receipt)";
			} else if (typeOfDoc.equals("IMG")) {
				docDesc = "Original valid license for Import of negative list goods";
			} else if (typeOfDoc.equals("IND")) {
				docDesc = "Insurance Document ( Policy / Certificate)";
			} else if (typeOfDoc.equals("ANC")) {
				docDesc = "Analysis Certificate";
			} else if (typeOfDoc.equals("SWG")) {
				docDesc = "Shipping Bill/EDF/SOFTEX of Waiver of GR";
			} else if (typeOfDoc.equals("BOE")) {
				docDesc = "Bill of Entry";
			} else if (typeOfDoc.equals("PKL")) {
				docDesc = "Packing List";
			} else if (typeOfDoc.equals("ELC")) {
				docDesc = "Export LC";
			} else if (typeOfDoc.equals("DBG")) {
				docDesc = "Draft of Foreign Bank Guarantee duly signed by Applicant, if any";
			} else if (typeOfDoc.equals("CNS")) {
				docDesc = "Counter Indemnity on Non Judicial Stamp Paper";
			} else if (typeOfDoc.equals("CBG")) {
				docDesc = "Counter Bank Guarantee draft";
			} else if (typeOfDoc.equals("OAS")) {
				docDesc = "Original Authenticated SWIFT Msg MT-103";
			} else if (typeOfDoc.equals("OTH")) {
				docDesc = "Other";
			} 
			
			aDBHelper.setValueInDB(transID, fileName, fileLocation, userName,typeOfDoc,docDesc,
					ActionConstants.GETINSERTDOCUMENT_QUERY);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		logger.info(ActionConstants.EXITING_METHOD);
	}
	
	
	public void uploadCustDocumentInDB(String transID, String fileName,
			String fileLocation, String userName,String typeOfDoc) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		DBHelper aDBHelper = new DBHelper();
		String docDesc = "";
		try {
			
			if (typeOfDoc.equals("IEC")) {
				docDesc = "IE Code";
			} else if (typeOfDoc.equals("ADS")) {
				docDesc = "Annexure D (Terms of Sanction)";
			} else if (typeOfDoc.equals("SER")) {
				docDesc = "Sanction copy of Exchange rate Margin";
			} else if (typeOfDoc.equals("SOF")) {
				docDesc = "Softex";
			} else if (typeOfDoc.equals("APF")) {
				docDesc = "Application form";
			} else if (typeOfDoc.equals("OTH")) {
				docDesc = "Other";
			}
			
			aDBHelper.setValueInDB(transID, fileName, fileLocation, userName,typeOfDoc,docDesc,
					ActionConstants.GETINSERTDOCUMENTCUST);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		logger.info(ActionConstants.EXITING_METHOD);
	}

	public UserTransactionVO getDocumentList(UserTransactionVO userVo)
			throws Exception {
		DBHelper aDBHelper = new DBHelper();
		String documentFlag = "N";
		try {
			logger.info("Tran ID inside getDocumentList-->"
					+ userVo.getRequestId());
			userVo.setDocumentList(aDBHelper.getDocumentListFromDB(
					userVo.getRequestId(), documentFlag));
			logger.info("Size-->" + userVo.getDocumentList().size());
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		return userVo;
	}

	public UserTransactionVO getDocumentPath(UserTransactionVO userVo)
			throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		DBHelper aDBHelper = new DBHelper();
		try {
			aDBHelper.getDocumentPathFromDB(userVo,
					ActionConstants.GETDOCUMENTLOCATION_QUERY);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		logger.info(ActionConstants.EXITING_METHOD);
		return userVo;
	}
	
	public UserTransactionVO getDocumentCustPath(UserTransactionVO userVo)
			throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		DBHelper aDBHelper = new DBHelper();
		try {
			aDBHelper.getDocumentPathFromDB(userVo,
					ActionConstants.GETCUSTDOCUMENTLOCATION);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		logger.info(ActionConstants.EXITING_METHOD);
		return userVo;
	}

	public void deleteDocument(String docID) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		DBHelper aDBHelper = new DBHelper();
		String documentFlag = "D";
		try {
			aDBHelper.setValueInDB(documentFlag, docID,
					ActionConstants.GETUPDATEDOCUMENTFLAG_QUERY);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		logger.info(ActionConstants.EXITING_METHOD);
	}
	
	public void deleteCustDocument(String docID) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		DBHelper aDBHelper = new DBHelper();
		String documentFlag = "D";
		try {
			aDBHelper.setValueInDB(documentFlag, docID,
					ActionConstants.GETUPDATEDOCUMENTFLAGCUST);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		logger.info(ActionConstants.EXITING_METHOD);
	}
	
	public CustomerProfileManageVO getCustDocumentList(
			CustomerProfileManageVO custProfileVo) throws Exception {
		DBHelper aDBHelper = new DBHelper();
		String documentFlag = "N";
		try {
			if (custProfileVo.getCustID() != null
					&& !custProfileVo.getCustID().trim().equals("")) {
				custProfileVo.setDocumentList(aDBHelper
						.getCustDocumentListFromDB(custProfileVo.getCustID(),
								documentFlag));
			} else {
				custProfileVo.documentList = null;
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		return custProfileVo;
	}
	
	public CustomerProfileManageVO getCustVerifyList(String custSolid,
			CustomerProfileManageVO custProfileVo) throws Exception {
		DBHelper aDBHelper = new DBHelper();
		try {
			custProfileVo.setCustVerifyList(aDBHelper
					.getCustVerifyListFromDB(custProfileVo.getCustID(),custSolid));
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		return custProfileVo;
	}
	
	public CustomerProfileManageVO getTransLevelDetails(CustomerProfileManageVO custProfileVo,
			String requestId) throws Exception {
		DBHelper aDBHelper = new DBHelper();
		String documentFlag = "N";
		List<CustomerProfileManageVO> custProfileList = new LinkedList<CustomerProfileManageVO>();
		try {
			if (requestId != null && !requestId.trim().equals(""))
				custProfileVo.setTransDocList(aDBHelper.getDocumentListFromDB(
						requestId, documentFlag));
			if (!custProfileVo.getCustID().equals("")) {

				custProfileVo.setDocumentList(aDBHelper
						.getCustDocumentListFromDB(custProfileVo.getCustID(),
								documentFlag));
				custProfileList = aDBHelper
						.fetchcustomerDetailsFromProfile(ActionConstants.FETCHCUSTOMERDETAILSFROMPROFILE
								+ " WHERE TRIM(CUSTID) = '"
								+ custProfileVo.getCustID() + "'");

				for (CustomerProfileManageVO custProVO : custProfileList) {
					custProfileVo.custID = custProfileVo.getCustID();
					custProfileVo.custName = custProVO.getCustName();
					custProfileVo.emailID = custProVO.getEmailID();
					custProfileVo.mobileNo = custProVO.getMobileNo();
					custProfileVo.rateMarginFrom = custProVO
							.getRateMarginFrom();
					custProfileVo.rateMarginTo = custProVO.getRateMarginTo();
					custProfileVo.operAccNo = custProVO.getOperAccNo();
					custProfileVo.operSolID = custProVO.getOperSolID();
					custProfileVo.alphaCode = custProVO.getAlphaCode();
					custProfileVo.lineofActivity = custProVO
							.getLineofActivity();
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		return custProfileVo;
	}
	
	
	
}
