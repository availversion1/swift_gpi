package com.ett.bob.tfbo.dao;

import org.apache.log4j.Logger;

import com.ett.bob.tfbo.model.UserTransactionVO;
import com.ett.bob.tfbo.util.ActionConstants;

public class TFBOXmlProcessDAO {
	private static Logger logger = Logger.getLogger(TFBOXmlProcessDAO.class
			.getName());

	public String getXMLtoPush(UserTransactionVO userVo) {
		logger.info(ActionConstants.ENTERING_METHOD);
		String xmlString = "";
		String productCode = userVo.getProductCode();
		String eventCode = userVo.getEventCode();
		// Outward Remittance Changes 23/12/2019 start
		String subProduct = userVo.getSubProductCode();
		// Outward Remittance Changes 23/12/2019 end
		if (productCode.trim().equalsIgnoreCase("ILC")) {
			if (eventCode.trim().equalsIgnoreCase("ISI")) {
				logger.info("Currency in getXMLtoPush-->"
						+ userVo.getCurrency());
				xmlString = getIlcIssueXML(userVo.getSolID(),
						userVo.getCustomeCif(), userVo.getAmount(),
						userVo.getCurrency(), userVo.getRequestId());
			}
			// Expiry,closure,cancellation Changes Starts
			if (eventCode.trim().equalsIgnoreCase("EXI")) {
				logger.info("Currency in getXMLtoPush-->"
						+ userVo.getCurrency());
				xmlString = getIlcExpiryXML(userVo.getSolID(),
						productCode.trim(), eventCode.trim(),
						userVo.getRequestId(), userVo.getTiReferanceNo());
			}
			// Expiry,closure,cancellation Changes Ends
			if (eventCode.trim().equalsIgnoreCase("NAMI")) {
				xmlString = getIlcAmendXML(userVo.getSolID(),
						userVo.getTiReferanceNo(), userVo.getCustomeCif(),
						userVo.getRequestId());
			}
			if (eventCode.trim().equalsIgnoreCase("CRC")) {
				xmlString = getIlcClaimRcvXML(userVo.getSolID(),
						userVo.getTiReferanceNo(), productCode, eventCode,
						userVo.getRequestId());
			}
			if (eventCode.trim().equalsIgnoreCase("POCA")
					|| eventCode.trim().equalsIgnoreCase("POCP")
					|| eventCode.trim().equalsIgnoreCase("POCD")) {
				xmlString = getIlcOutstandingClaimXML(userVo.getSolID(),
						userVo.getTiReferanceNo(), userVo.getCustomeCif(),
						userVo.getRequestId());
			}
			if (eventCode.trim().equalsIgnoreCase("COI")) {
				xmlString = getIlcCorrespondenceXML(userVo.getSolID(),
						userVo.getProductCode(), userVo.getEventCode(),
						userVo.getRequestId(), userVo.getTiReferanceNo());
			}
		}
		// Miscellanous changes starts 08-01-2020
		if (productCode.trim().equalsIgnoreCase("COR")) {
			if (eventCode.trim().equalsIgnoreCase("CRCR")) {

				logger.info("Get sub product code in xml process==>"
						+ userVo.getSubProductCode());

				if (userVo.getSubProductCode().trim().equalsIgnoreCase("OTH")) {

					String toolDetails = "Customer Cif:"
							+ userVo.getCustomeCif().trim() + " , " + "Amount:"
							+ userVo.getAmount().trim() + " , " + "Currency:"
							+ userVo.getCurrency().trim();

					xmlString = getMiscellanousCreateXML(userVo.getSolID(),
							productCode.trim(), eventCode.trim(),
							userVo.getRequestId(), toolDetails);
				}
			}
		}

		// Miscellanous changes ends 08-01-2020

		// Inward Remittance changes 23-12-2019 starts
		if (productCode.trim().equalsIgnoreCase("CPCI")) {
			if (eventCode.trim().equalsIgnoreCase("PCIC")) {

				if (userVo.getSubProductCode().trim().equalsIgnoreCase("IBP")) {
					productCode = "CPBI";
					eventCode = "PBIC";
				}

				String toolDetails = "Customer Cif:"
						+ userVo.getCustomeCif().trim() + " , " + "Currency:"
						+ userVo.getCurrency().trim() + " , " + "Product type:"
						+ userVo.getSubProductCode().trim();
				xmlString = getRemittanceCreateXML(userVo.getSolID(),
						productCode, eventCode, userVo.getRequestId(),
						toolDetails);
			}
		}
		// Inward Remittance changes 23-12-2019 ends

		// Outward Remittance Changes 23/12/2019 start
		if (productCode.trim().equalsIgnoreCase("CPCO")) {
			if (eventCode.trim().equalsIgnoreCase("PCOC")) {
				logger.info("Currency in getXMLtoPush-->"
						+ userVo.getCurrency());

				String toolDetails = "Customer Cif:"
						+ userVo.getCustomeCif().trim() + " , " + "Amount:"
						+ userVo.getAmount() + " , " + "Currency:"
						+ userVo.getCurrency().trim() + " , " + "Product type:"
						+ userVo.getSubProductCode().trim();

				if (subProduct.trim().equalsIgnoreCase("BBB")) {
					String product = "CPBO";
					String event = "PBOC";
					xmlString = getRemittanceCreateXML(userVo.getSolID(),
							product, event, userVo.getRequestId(), toolDetails);
				}

				else if (subProduct.trim().equalsIgnoreCase("DDI")) {
					String product = "CPHO";
					String event = "PHOC";
					xmlString = getRemittanceCreateXML(userVo.getSolID(),
							product, event, userVo.getRequestId(), toolDetails);
				} else {
					xmlString = getCPCOCreXML(userVo.getSolID(),
							userVo.getCustomeCif(), userVo.getCustomeName(),
							userVo.getAmount(), userVo.getCurrency(),
							userVo.getSubProductCode(), userVo.requestId);
				}
			}
		}
		// Outward Remittance Changes 23/12/2019 end

		if (productCode.trim().equalsIgnoreCase("ODC")) {
			if (eventCode.trim().equalsIgnoreCase("CRE")) {
				logger.info("ODC Create getXMLtoPush-->" + userVo.getCurrency());
				System.out.println("Direct-->" + userVo.getDirect());
				logger.info("Direct-->" + userVo.getDirect());
				xmlString = getOdcCreateXML(userVo.getProductCode(),
						userVo.getEventCode(), userVo.getSolID(),
						userVo.getCurrency(), userVo.getDirect(),
						userVo.getCustomeCif(), userVo.getAmount(),
						userVo.getSubProductCode(), userVo.getRequestId());
			}
			if (eventCode.trim().equalsIgnoreCase("CLP")) {
				logger.info("ODC Create getXMLtoPush-->" + userVo.getCurrency());
				xmlString = getOdcPaymentXML(userVo.getProductCode(),
						userVo.getEventCode(), userVo.getSolID(),
						userVo.getTiReferanceNo(), userVo.getRequestId());
			}
			// CHANGES FOR ODC CAC 08012020 NY SAI STARTS HERE
			if (eventCode.trim().equalsIgnoreCase("CAC")) {
				logger.info("ODC Accept getXMLtoPush-->" + userVo.getCurrency());
				xmlString = getOdcAcceptXML(userVo.getProductCode(),
						userVo.getEventCode(), userVo.getSolID(),
						userVo.getTiReferanceNo(), userVo.getRequestId());
				System.out.println("xmlString in ODC Accept===" + xmlString);
			}

			if (eventCode.trim().equalsIgnoreCase("CCO")) {
				xmlString = getCcoCorrespondenceXML(userVo.getSolID(),
						userVo.getProductCode(), userVo.getEventCode(),
						userVo.getRequestId(), userVo.getTiReferanceNo());
			}

		}
		// CHANGES FOR ODC CAC 08012020 NY SAI ENDS HERE
		// FOC-CREATE
		if (productCode.trim().equalsIgnoreCase("FOC")) {
			if (eventCode.trim().equalsIgnoreCase("CSA1")) {
				logger.info("FOC Create getXMLtoPush-->" + userVo.getCurrency());
				xmlString = getFocCreateXML(userVo.getProductCode(),
						userVo.getEventCode(), userVo.getSolID(),
						userVo.getFinanceAmount(), userVo.getCurrency(),
						userVo.getTiReferanceNo(), userVo.getSubProductCode(),
						userVo.getCustomeCif(), userVo.getRequestId());
			}
			if (eventCode.trim().equalsIgnoreCase("JSA1")) {
				logger.info("FOC Adjust getXMLtoPush-->" + userVo.getCurrency());
				xmlString = getFocAdjustXML(userVo.getProductCode(),
						userVo.getEventCode(), userVo.getSolID(),
						userVo.getTiReferanceNo(), userVo.getRequestId());
			}
			if (eventCode.trim().equalsIgnoreCase("RSA1")
					|| eventCode.trim().equalsIgnoreCase("CRYST")) {
				logger.info("FOC Adjust getXMLtoPush-->" + userVo.getCurrency());
				xmlString = getFocRepayXML(userVo.getProductCode(),
						userVo.getEventCode(), userVo.getSolID(),
						userVo.getTiReferanceNo(), userVo.getCustomeCif(),
						userVo.getRequestId());
			}

			if (eventCode.trim().equalsIgnoreCase("PSA1")) {
				logger.info("FOC PSA1 getXMLtoPush" + userVo.getCurrency());
				xmlString = getFocPsa1XML(userVo.getSolID(),
						userVo.getProductCode(), userVo.getEventCode(),
						userVo.getRequestId(), userVo.getTiReferanceNo());
			}

		}
		if (productCode.trim().equalsIgnoreCase("FSA")) {
			if (eventCode.trim().equalsIgnoreCase("CSA")) {
				logger.info("FSA Create getXMLtoPush-->" + userVo.getCurrency());
				xmlString = getFsaCreateXML(userVo.getProductCode(),
						userVo.getEventCode(), userVo.getSolID(),
						userVo.getAmount(), userVo.getCurrency(),
						userVo.getSubProductCode(), userVo.getCustomeCif(),
						userVo.getRequestId());
			}
			if (eventCode.trim().equalsIgnoreCase("JSA")) {
				logger.info("FSA Adjust getXMLtoPush-->" + userVo.getCurrency());
				xmlString = getFocAdjustXML(userVo.getProductCode(),
						userVo.getEventCode(), userVo.getSolID(),
						userVo.getTiReferanceNo(), userVo.getRequestId());
			}
			if (eventCode.trim().equalsIgnoreCase("RSA")) {
				logger.info("RSA Adjust getXMLtoPush-->" + userVo.getCurrency());
				xmlString = getFocAdjustXML(userVo.getProductCode(),
						userVo.getEventCode(), userVo.getSolID(),
						userVo.getTiReferanceNo(), userVo.getRequestId());
			}
		}
		// FOC-CREATE
		if (productCode.trim().equalsIgnoreCase("ELC")) {
			if (eventCode.trim().equalsIgnoreCase("ADE")) {
				logger.info("Currency in getXMLtoPush-->"
						+ userVo.getCurrency());
				xmlString = getElcAdviseXML(userVo.getProductCode(),
						userVo.getEventCode(), userVo.getSolID(),
						userVo.getCustomeCif(), userVo.getAmount(),
						userVo.getCurrency(), userVo.getRequestId());
			}
			if (eventCode.trim().equalsIgnoreCase("NAME")) {
				xmlString = getElcAmendXML(userVo.getSolID(),
						userVo.getTiReferanceNo(), userVo.getRequestId());
			}
			if (eventCode.trim().equalsIgnoreCase("DOP")) {
				xmlString = getElcDocpresentXML(userVo.getProductCode(),
						userVo.getEventCode(), userVo.getTiReferanceNo(),
						userVo.getSolID(), userVo.getRequestId());
			}
			// Changes for ELC and IGT Starts 25-12-2019
			if (eventCode.trim().equalsIgnoreCase("PODA")
					|| eventCode.trim().equalsIgnoreCase("PODP")) {
				xmlString = getElcOutstandingPresXML(userVo.getSolID(),
						userVo.getTiReferanceNo(), userVo.getCustomeCif(),
						userVo.getRequestId(), userVo.getBillReference());
			}
			// Expiry,closure,cancellation Changes Starts
			if (eventCode.trim().equalsIgnoreCase("EXP")) {
				logger.info("Currency in getXMLtoPush-->"
						+ userVo.getCurrency());
				xmlString = getElcExpiryXML(userVo.getSolID(),
						productCode.trim(), eventCode.trim(),
						userVo.getRequestId(), userVo.getTiReferanceNo());
			}
			// Expiry,closure,cancellation Changes Ends
			if (eventCode.trim().equalsIgnoreCase("COE")) {
				xmlString = getElcCorrespondenceXML(userVo.getSolID(),
						userVo.getProductCode(), userVo.getEventCode(),
						userVo.getRequestId(), userVo.getTiReferanceNo());

			}

			// Changes for ELC and IGT ends 25-12-2019
		}
		// Changes for ELC and IGT starts 25-12-2019
		if (productCode.trim().equalsIgnoreCase("IGT")) {
			if (eventCode.trim().equalsIgnoreCase("IIG")) {
				xmlString = getIgtIssueXML(userVo.getSolID(),
						userVo.getTiReferanceNo(), userVo.getCustomeCif(),
						userVo.getAmount(), userVo.getCurrency(),
						userVo.getRequestId());
			}
			if (eventCode.trim().equalsIgnoreCase("NAIG")) {
				xmlString = getIgtAmendXML(userVo.getSolID(),
						userVo.getTiReferanceNo(), userVo.getCustomeCif(),
						userVo.getAmount(), userVo.getCurrency(),
						userVo.getRequestId());
			}
			if (eventCode.trim().equalsIgnoreCase("LIG")) {
				xmlString = getIgtClaimRcvXML(userVo.getSolID(),
						userVo.getTiReferanceNo(), userVo.getProductCode(),
						userVo.getEventCode(), userVo.getRequestId());
			}
			if (eventCode.trim().equalsIgnoreCase("OIG")) {
				xmlString = getIgtPaymentXML(userVo.getSolID(),
						userVo.getTiReferanceNo(), userVo.getCustomeCif(),
						userVo.getAmount(), userVo.getCurrency(),
						userVo.getRequestId(), userVo.getBillReference());
			}
			// Expiry,closure,cancellation Changes Starts
			if (eventCode.trim().equalsIgnoreCase("NIG")) {
				logger.info("Currency in getXMLtoPush-->"
						+ userVo.getCurrency());

				xmlString = getIgtCancelXML(userVo.getSolID(),
						productCode.trim(), eventCode.trim(),
						userVo.getRequestId(), userVo.getTiReferanceNo(),
						userVo.getCustomeCif());
			}

			if (eventCode.trim().equalsIgnoreCase("KIG")) {
				logger.info("Currency in getXMLtoPush-->"
						+ userVo.getCurrency());
				xmlString = getIgtClosureXML(userVo.getRequestId(),
						userVo.getSolID(), productCode.trim(),
						eventCode.trim(), userVo.getTiReferanceNo());
			}
			if (eventCode.trim().equalsIgnoreCase("XIG")){
				xmlString = getIgtExpireXML(userVo.getRequestId(),
						userVo.getSolID(), productCode.trim(),
						eventCode.trim() , userVo.getTiReferanceNo());
				
			}
			// Expiry,closure,cancellation Changes Ends
		}
		// Changes for ELC and IGT ends 25-12-2019
		if (productCode.trim().equalsIgnoreCase("IDC")) {
			if (eventCode.trim().equalsIgnoreCase("CRE")) {
				logger.info("Currency in getXMLtoPush-->"
						+ userVo.getCurrency());
				String toolDetails = "Customer Cif:"
						+ userVo.getCustomeCif().trim() + " , " + "Currency:"
						+ userVo.getCurrency().trim() + " , " + "Product type:"
						+ userVo.getSubProductCode().trim() + " , "
						+ "Direct : " + userVo.getDirect().trim();

				xmlString = getIDCCreXML(userVo.getSolID(), productCode,
						eventCode, userVo.getRequestId(), toolDetails);
			}
			if (eventCode.trim().equalsIgnoreCase("CAC")) {
				logger.info("Currency in getXMLtoPush-->"
						+ userVo.getCurrency());
				xmlString = getIDCAcceptXML(userVo.getSolID(), productCode,
						eventCode, userVo.getTiReferanceNo(),
						userVo.getRequestId(), userVo.getCustomeCif().trim());
			}
			if (eventCode.trim().equalsIgnoreCase("CLP")) {
				logger.info("Currency in getXMLtoPush-->"
						+ userVo.getCurrency());
				xmlString = getIDCPaymentXML(userVo.getSolID(), productCode,
						eventCode, userVo.getTiReferanceNo(),
						userVo.getRequestId(), userVo.getCustomeCif());
			}

			if (eventCode.trim().equalsIgnoreCase("CCO")) {
				xmlString = getIDCCcoXML(userVo.getSolID(),
						userVo.getProductCode(), userVo.getEventCode(),
						userVo.getRequestId(), userVo.getTiReferanceNo());

			}

		}
		if (productCode.trim().equalsIgnoreCase("FEL")) {
			if (eventCode.trim().equalsIgnoreCase("CSA4")) {
				xmlString = getFelCreateXML(userVo.getProductCode(),
						userVo.getEventCode(), userVo.getSolID(),
						userVo.getFncAmount(), userVo.getCurrency(),
						userVo.getLcRefNum(), userVo.getSubProductCode(),
						userVo.getRequestId(), userVo.getCustomeCif(),
						userVo.getBillReferenceNo());
			}

			if (eventCode.trim().equalsIgnoreCase("JSA4")) {
				xmlString = getFelAdjustXML(userVo.getProductCode(),
						userVo.getEventCode(), userVo.getSolID(),
						userVo.getLcRefNum(), userVo.getRequestId());
			}

			if (eventCode.trim().equalsIgnoreCase("CRYST")
					|| eventCode.trim().equalsIgnoreCase("RSA4")) {
				xmlString = getFelCrystalizationXML(userVo.getProductCode(),
						userVo.getEventCode(), userVo.getSolID(),
						userVo.getLcRefNum(), userVo.getRequestId(),
						userVo.getCustomeCif(), userVo.getCustomeName(),
						userVo.getCurrency(), userVo.getFncAmount());
			}

			if (eventCode.trim().equalsIgnoreCase("PSA4")) {
				xmlString = getFelCorrespondenceXML(userVo.getSolID(),
						userVo.getProductCode(), userVo.getEventCode(),
						userVo.getRequestId(), userVo.getTiReferanceNo());
			}
		}

		// SBLC_251219
		if (productCode.trim().equalsIgnoreCase("ISB")) {

			if (eventCode.trim().equalsIgnoreCase("KIS")) {
				logger.info("Currency in getXMLtoPush-->"
						+ userVo.getCurrency());
				xmlString = getIsbClosureXML(userVo.getRequestId(),
						userVo.getSolID(), productCode.trim(),
						eventCode.trim(), userVo.getTiReferanceNo());
			}

			if (eventCode.trim().equalsIgnoreCase("NIS")) {
				logger.info("Currency in getXMLtoPush-->"
						+ userVo.getCurrency());
				xmlString = getIsbCancelXML(userVo.getRequestId(),
						userVo.getSolID(), productCode.trim(),
						eventCode.trim(), userVo.getTiReferanceNo());
			}

			if (eventCode.trim().equalsIgnoreCase("IIS")) {

				xmlString = getIsbIssue(userVo.getRequestId(),
						userVo.getSolID(), productCode, eventCode,
						userVo.getCustomeCif(), userVo.getAmount(),
						userVo.getCurrency());
			}
			if (eventCode.trim().equalsIgnoreCase("NJIS")) {
				xmlString = getisbAdjust(userVo.getRequestId(),
						userVo.getSolID(), productCode, eventCode,
						userVo.getTiReferanceNo());
			}
			if (eventCode.trim().equalsIgnoreCase("NAIS")) {
				xmlString = getIsbAmd(userVo.getRequestId(), userVo.getSolID(),
						productCode, eventCode, userVo.getTiReferanceNo(),
						userVo.getCustomeCif());

			}
			if (eventCode.trim().equalsIgnoreCase("LIS")) {
				xmlString = getIsbClaimRec(userVo.getRequestId(),
						userVo.getSolID(), productCode, eventCode,
						userVo.getTiReferanceNo());

			}

			if (eventCode.trim().equalsIgnoreCase("OIS")) {
				xmlString = getIsbOutStdClaim(userVo.getRequestId(),
						userVo.getSolID(), productCode, eventCode,
						userVo.getTiReferanceNo(), userVo.getCustomeCif(),
						userVo.getBillReference());

			}

		}
		// SBLC_251219_END

		logger.info(ActionConstants.EXITING_METHOD);
		return xmlString;
	}

	// SBLC_251219

	private String getIsbOutStdClaim(String requestId, String solID,
			String productCode, String eventCode, String tiReferanceNo,
			String custCif, String billref) {

		logger.info(ActionConstants.ENTERING_METHOD);
		logger.info("ISB_OIS_Sol id==>" + solID.trim());
		logger.info("ISB_OIS_productCode ==>" + productCode.trim());
		logger.info("ISB_OIS_eventCode ==>" + eventCode.trim());

		String xmlString = "<?xml version=\"1.0\" standalone=\"yes\"?>"
				+ "<ServiceRequest xmlns:xsi='http://www.w3.org/2001/XMLSchema-instance' "
				+ "xmlns:m='urn:messages.service.ti.apps.tiplus2.misys.com' "
				+ "xmlns:c='urn:common.service.ti.apps.tiplus2.misys.com' "
				+ "xmlns:n='urn:custom.service.ti.apps.tiplus2.misys.com' "
				+ "xmlns='urn:control.services.tiplus2.misys.com'>"
				+ "<RequestHeader>" + "<Service>TI</Service>"
				+ "<Operation>TFISBPYR</Operation>" + "<Credentials>"
				+ "<Name>Name</Name>" + "<Password>Password</Password>"
				+ "<Certificate>Certificate</Certificate>"
				+ "<Digest>Digest</Digest>" + "</Credentials>"
				+ "<ReplyFormat>FULL</ReplyFormat>" + "<NoRepair>Y</NoRepair>"
				+ "<NoOverride>Y</NoOverride>"
				+ "<CorrelationId>CorrelationId</CorrelationId>"
				+ "<TransactionControl>NONE</TransactionControl>"
				+ "</RequestHeader>" + "<m:TFISBPYR>" + "<m:Context>"
				+ "<c:Product>"
				+ productCode.trim()
				+ "</c:Product>"
				+ "<c:Event>"
				+ eventCode.trim()
				+ "</c:Event>"
				+ "<c:OurReference>"
				+ tiReferanceNo.trim()
				+ "</c:OurReference>"
				+ "<c:TheirReference>"
				+ tiReferanceNo.trim()
				+ "</c:TheirReference>"
				+ "<c:BehalfOfBranch>"
				+ solID.trim()
				+ "</c:BehalfOfBranch>"
				+ "</m:Context>"
				+ "<m:MasterRef>"
				+ tiReferanceNo.trim()
				+ "</m:MasterRef>"
				+ "<m:ClaimId>"
				+ billref
				+ "</m:ClaimId>"
				+ "<m:Sender>"
				+ "<c:Customer>"
				+ custCif.trim()
				+ "</c:Customer>"
				+ "</m:Sender>"
				+ "<m:ExtraData>"
				+ "<n:REQUSTID>"
				+ requestId.trim()
				+ "</n:REQUSTID>"
				+ "</m:ExtraData>"
				+ "</m:TFISBPYR>"
				+ "</ServiceRequest>";

		return xmlString;
	}

	private String getIsbClaimRec(String requestId, String solID,
			String productCode, String eventCode, String tiReferanceNo) {

		logger.info(ActionConstants.ENTERING_METHOD);
		logger.info("ISB_LIS_Sol id==>" + solID.trim());
		logger.info("ISB_LIS_productCode ==>" + productCode.trim());
		logger.info("ISB_LIS_eventCode ==>" + eventCode.trim());

		String xmlString = "<?xml version=\"1.0\" standalone=\"yes\"?>"
				+ "<ServiceRequest xmlns:xsi='http://www.w3.org/2001/XMLSchema-instance' "
				+ "xmlns:m='urn:messages.service.ti.apps.tiplus2.misys.com' "
				+ " xmlns:c='urn:common.service.ti.apps.tiplus2.misys.com' "
				+ "xmlns:n='urn:custom.service.ti.apps.tiplus2.misys.com' "
				+ " xmlns='urn:control.services.tiplus2.misys.com'>"
				+ "<RequestHeader>" + "<Service>TI</Service>"
				+ "<Operation>TFATTDOC</Operation>" + "<Credentials>"
				+ "<Name>Name</Name>" + "<Password>Password</Password>"
				+ "<Certificate>Certificate</Certificate>"
				+ "<Digest>Digest</Digest>" + "</Credentials>"
				+ "<ReplyFormat>FULL</ReplyFormat>" + "<NoRepair>Y</NoRepair>"
				+ "<NoOverride>Y</NoOverride>"
				+ "<CorrelationId>CorrelationId</CorrelationId>"
				+ "<TransactionControl>NONE</TransactionControl>"
				+ "</RequestHeader>" + "<m:TFATTDOC>" + "<m:Context>"
				+ "<c:Branch>5860</c:Branch>" + "<c:Product>"
				+ productCode
				+ "</c:Product>"
				+ "<c:Event>"
				+ eventCode
				+ "</c:Event>"
				+ "<c:OurReference>"
				+ tiReferanceNo.trim()
				+ "</c:OurReference>"
				+ "<c:TheirReference>"
				+ tiReferanceNo.trim()
				+ "</c:TheirReference>"
				+ "<c:BehalfOfBranch>"
				+ solID.trim()
				+ "</c:BehalfOfBranch>"
				+ "</m:Context>"
				+ "<m:ExtraData>"
				+ "<n:REQUSTID>"
				+ requestId.trim()
				+ "</n:REQUSTID>"
				+ "</m:ExtraData>"
				+ "</m:TFATTDOC>" + "</ServiceRequest>";

		return xmlString;
	}

	private String getIsbAmd(String requestId, String solID,
			String productCode, String eventCode, String tiReferanceNo,
			String custCif) {

		logger.info(ActionConstants.ENTERING_METHOD);
		logger.info("ISB_NAIS_Sol id==>" + solID.trim());
		logger.info("ISB_NAIS_productCode ==>" + productCode.trim());
		logger.info("ISB_NAIS_eventCode ==>" + eventCode.trim());

		String xmlString = "<?xml version=\"1.0\" standalone=\"yes\"?>"
				+ "<ServiceRequest xmlns:xsi='http://www.w3.org/2001/XMLSchema-instance' "
				+ "xmlns:m='urn:messages.service.ti.apps.tiplus2.misys.com' "
				+ "xmlns:c='urn:common.service.ti.apps.tiplus2.misys.com' "
				+ "xmlns:n='urn:custom.service.ti.apps.tiplus2.misys.com' "
				+ "xmlns='urn:control.services.tiplus2.misys.com'>"
				+ "<RequestHeader>" + "<Service>TI</Service>"
				+ "<Operation>TFISBAMN</Operation>" + "<Credentials>"
				+ "<Name>Name</Name>" + "<Password>Password</Password>"
				+ "<Certificate>Certificate</Certificate>"
				+ "<Digest>Digest</Digest>" + "</Credentials>"
				+ "<ReplyFormat>FULL</ReplyFormat>" + "<NoRepair>Y</NoRepair>"
				+ "<NoOverride>Y</NoOverride>"
				+ "<CorrelationId>CorrelationId</CorrelationId>"
				+ "<TransactionControl>NONE</TransactionControl>"
				+ "</RequestHeader>" + "<m:TFISBAMN>" + "<m:Context>"
				+ "<c:Product>"
				+ productCode.trim()
				+ "</c:Product>"
				+ "<c:Event>"
				+ eventCode.trim()
				+ "</c:Event>"
				+ "<c:OurReference>"
				+ tiReferanceNo.trim()
				+ "</c:OurReference>"
				+ "<c:TheirReference>"
				+ tiReferanceNo.trim()
				+ "</c:TheirReference>"
				+ "<c:BehalfOfBranch>"
				+ solID.trim()
				+ "</c:BehalfOfBranch>"
				+ "</m:Context>"
				+ "<m:MasterRef>"
				+ tiReferanceNo.trim()
				+ "</m:MasterRef>"
				+ "<m:Sender>"
				+ "<c:Customer>"
				+ custCif.trim()
				+ "</c:Customer>"
				+ "</m:Sender>"
				+ "<m:ExtraData>"
				+ "<n:REQUSTID>"
				+ requestId.trim()
				+ "</n:REQUSTID>"
				+ "</m:ExtraData>"
				+ "</m:TFISBAMN>" + "</ServiceRequest>";

		return xmlString;
	}

	private String getisbAdjust(String requestId, String solID,
			String productCode, String eventCode, String tiReferanceNo) {

		logger.info(ActionConstants.ENTERING_METHOD);
		logger.info("ISB_NJIS_Sol id==>" + solID.trim());
		logger.info("ISB_NJIS_productCode ==>" + productCode.trim());
		logger.info("ISB_NJIS_eventCode ==>" + eventCode.trim());

		String xmlString = "<?xml version=\"1.0\" standalone=\"yes\"?>"
				+ "<ServiceRequest xmlns:xsi='http://www.w3.org/2001/XMLSchema-instance' "
				+ "xmlns:m='urn:messages.service.ti.apps.tiplus2.misys.com' "
				+ " xmlns:c='urn:common.service.ti.apps.tiplus2.misys.com' "
				+ "xmlns:n='urn:custom.service.ti.apps.tiplus2.misys.com' "
				+ " xmlns='urn:control.services.tiplus2.misys.com'>"
				+ "<RequestHeader>" + "<Service>TI</Service>"
				+ "<Operation>TFATTDOC</Operation>" + "<Credentials>"
				+ "<Name>Name</Name>" + "<Password>Password</Password>"
				+ "<Certificate>Certificate</Certificate>"
				+ "<Digest>Digest</Digest>" + "</Credentials>"
				+ "<ReplyFormat>FULL</ReplyFormat>" + "<NoRepair>Y</NoRepair>"
				+ "<NoOverride>Y</NoOverride>"
				+ "<CorrelationId>CorrelationId</CorrelationId>"
				+ "<TransactionControl>NONE</TransactionControl>"
				+ "</RequestHeader>" + "<m:TFATTDOC>" + "<m:Context>"
				+ "<c:Branch>5860</c:Branch>" + "<c:Product>"
				+ productCode
				+ "</c:Product>"
				+ "<c:Event>"
				+ eventCode
				+ "</c:Event>"
				+ "<c:OurReference>"
				+ tiReferanceNo.trim()
				+ "</c:OurReference>"
				+ "<c:TheirReference>"
				+ tiReferanceNo.trim()
				+ "</c:TheirReference>"
				+ "<c:BehalfOfBranch>"
				+ solID.trim()
				+ "</c:BehalfOfBranch>"
				+ "</m:Context>"
				+ "<m:ExtraData>"
				+ "<n:REQUSTID>"
				+ requestId.trim()
				+ "</n:REQUSTID>"
				+ "</m:ExtraData>"
				+ "</m:TFATTDOC>" + "</ServiceRequest>";

		return xmlString;
	}

	// Changes by onsite team 26122019 starts
	/*
	 * private String getIsbIssue(String requestId, String solID, String
	 * productCode, String eventCode, String custCif, String amount, String
	 * currency) {
	 * 
	 * logger.info(ActionConstants.ENTERING_METHOD); logger.info("Sol id==>" +
	 * solID.trim()); logger.info("ISB_productCode ==>" + productCode.trim());
	 * logger.info("ISB_eventCode ==>" + eventCode.trim());
	 * 
	 * String xmlString = "<?xml version=\"1.0\" standalone=\"yes\"?>" +
	 * "<ServiceRequest xmlns:xsi='http://www.w3.org/2001/XMLSchema-instance' "
	 * + "xmlns:m='urn:messages.service.ti.apps.tiplus2.misys.com' " +
	 * "xmlns:c='urn:common.service.ti.apps.tiplus2.misys.com' " +
	 * "xmlns='urn:control.services.tiplus2.misys.com'>" + "<RequestHeader>" +
	 * "<Service>TI</Service>" + "<Operation>TFISBAPP</Operation>" +
	 * "<Credentials>" + "<Name>Name</Name>" + "<Password>Password</Password>" +
	 * "<Certificate>Certificate</Certificate>" + "<Digest>Digest</Digest>" +
	 * "</Credentials>" + "<ReplyFormat>FULL</ReplyFormat>" +
	 * "<NoRepair>Y</NoRepair>" + "<NoOverride>Y</NoOverride>" +
	 * "<CorrelationId>CorrelationId</CorrelationId>" +
	 * "<TransactionControl>NONE</TransactionControl>" + "</RequestHeader>" +
	 * "<m:TFISBAPP>" + "<m:Context>" + "<c:Branch>5860</c:Branch>" +
	 * "<c:Product>" + productCode.trim() + "</c:Product>" + "<c:Event>" +
	 * eventCode.trim() + "</c:Event>" + "<c:BehalfOfBranch>" + solID.trim() +
	 * "</c:BehalfOfBranch>" + "</m:Context>" + "<m:Applicant>" + "<c:Customer>"
	 * + custCif.trim() + "</c:Customer>" + "</m:Applicant>" + "<m:LCAmount>" +
	 * "<c:Amount>" + amount.trim() + "</c:Amount>" + "<c:Currency>" +
	 * currency.trim() + "</c:Currency>" + "</m:LCAmount>" + "<m:ExtraData>" +
	 * "<n:REQUSTID>" + requestId.trim() + "</n:REQUSTID>" + "</m:ExtraData>" +
	 * "</m:TFISBAPP>" + "</ServiceRequest>";
	 * 
	 * logger.info(ActionConstants.EXITING_METHOD);
	 * System.out.println("Issue ISB xml===>"+xmlString); return xmlString;
	 * 
	 * }
	 */

	private String getIsbIssue(String requestId, String solID,
			String productCode, String eventCode, String custCif,
			String amount, String currency) {

		logger.info(ActionConstants.ENTERING_METHOD);
		logger.info("Sol id==>" + solID.trim());
		logger.info("ISB_productCode ==>" + productCode.trim());
		logger.info("ISB_eventCode ==>" + eventCode.trim());
		// CHANGED BY CHANDRU
		String xmlString = "<?xml version=\"1.0\" standalone=\"yes\"?>"
				+ "<ServiceRequest xmlns:xsi='http://www.w3.org/2001/XMLSchema-instance' "
				+ "xmlns:m='urn:messages.service.ti.apps.tiplus2.misys.com' "
				+ "xmlns:c='urn:common.service.ti.apps.tiplus2.misys.com' "
				+ "xmlns:n='urn:custom.service.ti.apps.tiplus2.misys.com' "
				+ "xmlns='urn:control.services.tiplus2.misys.com'>"
				+ "<RequestHeader>" + "<Service>TI</Service>"
				+ "<Operation>TFISBAPP</Operation>" + "<Credentials>"
				+ "<Name>Name</Name>" + "<Password>Password</Password>"
				+ "<Certificate>Certificate</Certificate>"
				+ "<Digest>Digest</Digest>" + "</Credentials>"
				+ "<ReplyFormat>FULL</ReplyFormat>" + "<NoRepair>Y</NoRepair>"
				+ "<NoOverride>Y</NoOverride>"
				+ "<CorrelationId>CorrelationId</CorrelationId>"
				+ "<TransactionControl>NONE</TransactionControl>"
				+ "</RequestHeader>" + "<m:TFISBAPP>" + "<m:Context>"
				+ "<c:Branch>5860</c:Branch>" + "<c:Product>"
				+ productCode.trim()
				+ "</c:Product>"
				+ "<c:Event>"
				+ eventCode.trim()
				+ "</c:Event>"
				+ "<c:BehalfOfBranch>"
				+ solID.trim()
				+ "</c:BehalfOfBranch>"
				+ "</m:Context>"
				+ "<m:Applicant>"
				+ "<c:Customer>"
				+ custCif.trim()
				+ "</c:Customer>"
				+ "</m:Applicant>"
				+ "<m:LCAmount>"
				+ "<c:Amount>"
				+ amount.trim()
				+ "</c:Amount>"
				+ "<c:Currency>"
				+ currency.trim()
				+ "</c:Currency>"
				+ "</m:LCAmount>"
				+ "<m:ExtraData>"
				+ "<n:REQUSTID>"
				+ requestId.trim()
				+ "</n:REQUSTID>"
				+ "</m:ExtraData>"
				+ "</m:TFISBAPP>"
				+ "</ServiceRequest>";

		logger.info(ActionConstants.EXITING_METHOD);
		System.out.println("Issue ISB xml===>" + xmlString);
		return xmlString;

	}

	// Changes by onsite team 26122019 ends

	private String getIDCPaymentXML(String solID, String productCode,
			String eventCode, String tiReferanceNo, String requestId,
			String custMnm) {

		logger.info(ActionConstants.ENTERING_METHOD);
		logger.info("Sol id==>" + solID.trim());
		logger.info("IDC_productCode ==>" + productCode.trim());
		logger.info("IDC_eventCode ==>" + eventCode.trim());
		/*
		 * String xmlString = "<?xml version=\"1.0\" standalone=\"yes\"?>" +
		 * "<ServiceRequest xmlns:xsi='http://www.w3.org/2001/XMLSchema-instance' "
		 * + "xmlns:m='urn:messages.service.ti.apps.tiplus2.misys.com' " +
		 * "xmlns:c='urn:common.service.ti.apps.tiplus2.misys.com' " +
		 * "xmlns:n='urn:custom.service.ti.apps.tiplus2.misys.com' " +
		 * "xmlns='urn:control.services.tiplus2.misys.com'>" + "<RequestHeader>"
		 * + "<Service>TI</Service>" + "<Operation>TFCOLPAY</Operation>" +
		 * "<Credentials>" + "<Name>Name</Name>" +
		 * "<Password>Password</Password>" +
		 * "<Certificate>Certificate</Certificate>" + "<Digest>Digest</Digest>"
		 * + "</Credentials>" + "<ReplyFormat>FULL</ReplyFormat>" +
		 * "<NoRepair>Y</NoRepair>" + "<NoOverride>Y</NoOverride>" +
		 * "<CorrelationId>CorrelationId</CorrelationId>" +
		 * "<TransactionControl>NONE</TransactionControl>" + "</RequestHeader>"
		 * + "<m:TFCOLPAY>" + "<m:Context>" + "<c:Branch>5860</c:Branch>" +
		 * "<c:Product>" + productCode.trim() + "</c:Product>" + "<c:Event>" +
		 * eventCode.trim() + "</c:Event>" + "<c:BehalfOfBranch>" + solID.trim()
		 * + "</c:BehalfOfBranch>" + "</m:Context>" + "<m:MasterRef>" +
		 * tiReferanceNo + "</m:MasterRef>" + "<m:ExtraData>" + "<n:REQUSTID>" +
		 * requestId.trim() + "</n:REQUSTID>" + "</m:ExtraData>" +
		 * "</m:TFCOLPAY>" + "</ServiceRequest>";
		 */

		String xmlString = "<?xml version=\"1.0\" standalone=\"yes\"?>"
				+ "<ServiceRequest xmlns:xsi='http://www.w3.org/2001/XMLSchema-instance' "
				+ "xmlns:m='urn:messages.service.ti.apps.tiplus2.misys.com' "
				+ "xmlns:c='urn:common.service.ti.apps.tiplus2.misys.com' "
				+ "xmlns:n='urn:custom.service.ti.apps.tiplus2.misys.com' "
				+ "xmlns='urn:control.services.tiplus2.misys.com'>"
				+ "<RequestHeader>" + "<Service>TI</Service>"
				+ "<Operation>TFCOLPAY</Operation>" + "<Credentials>"
				+ "<Name>Name</Name>" + "<Password>Password</Password>"
				+ "<Certificate>Certificate</Certificate>"
				+ "<Digest>Digest</Digest>" + "</Credentials>"
				+ "<ReplyFormat>FULL</ReplyFormat>" + "<NoRepair>Y</NoRepair>"
				+ "<NoOverride>Y</NoOverride>"
				+ "<CorrelationId>CorrelationId</CorrelationId>"
				+ "<TransactionControl>NONE</TransactionControl>"
				+ "</RequestHeader>" + "<m:TFCOLPAY>" + "<m:Context>"
				+ "<c:Branch>5860</c:Branch>" + "<c:Product>"
				+ productCode.trim()
				+ "</c:Product>"
				+ "<c:Event>"
				+ eventCode.trim()
				+ "</c:Event>"
				+ "<c:BehalfOfBranch>"
				+ solID.trim()
				+ "</c:BehalfOfBranch>"
				+ "</m:Context>"
				+ "<m:MasterRef>"
				+ tiReferanceNo
				+ "</m:MasterRef>"
				+ "<m:Sender>"
				+ "<c:Customer>"
				+ custMnm.trim()
				+ "</c:Customer>"
				+ "</m:Sender>"
				+ "<m:ExtraData>"
				+ "<n:REQUSTID>"
				+ requestId.trim()
				+ "</n:REQUSTID>"
				+ "</m:ExtraData>" + "</m:TFCOLPAY>" + "</ServiceRequest>";
		logger.info(ActionConstants.EXITING_METHOD);

		return xmlString;

	}

	private String getIDCCcoXML(String solID, String productCode,
			String eventCode, String requestId, String tiReferanceNo) {

		logger.info(ActionConstants.ENTERING_METHOD
				+ "getIDCCCorrespondenceXML method");
		logger.info("Sol id==>" + solID.trim());
		logger.info(" productCode ==>" + productCode.trim());
		logger.info(" eventCode ==>" + eventCode.trim());
		String xmlString = "<?xml version=\"1.0\" standalone=\"yes\"?>"
				+ "<ServiceRequest xmlns:xsi='http://www.w3.org/2001/XMLSchema-instance' "
				+ "xmlns:m='urn:messages.service.ti.apps.tiplus2.misys.com' "
				+ " xmlns:c='urn:common.service.ti.apps.tiplus2.misys.com' "
				+ "xmlns:n='urn:custom.service.ti.apps.tiplus2.misys.com' "
				+ " xmlns='urn:control.services.tiplus2.misys.com'>"
				+ "<RequestHeader>" + "<Service>TI</Service>"
				+ "<Operation>TFATTDOC</Operation>" + "<Credentials>"
				+ "<Name>Name</Name>" + "<Password>Password</Password>"
				+ "<Certificate>Certificate</Certificate>"
				+ "<Digest>Digest</Digest>" + "</Credentials>"
				+ "<ReplyFormat>FULL</ReplyFormat>" + "<NoRepair>Y</NoRepair>"
				+ "<NoOverride>Y</NoOverride>"
				+ "<CorrelationId>CorrelationId</CorrelationId>"
				+ "<TransactionControl>NONE</TransactionControl>"
				+ "</RequestHeader>" + "<m:TFATTDOC>" + "<m:Context>"
				+ "<c:Branch>5860</c:Branch>" + "<c:Product>" + productCode
				+ "</c:Product>" + "<c:Event>" + eventCode + "</c:Event>"
				+ "<c:OurReference>" + tiReferanceNo.trim()
				+ "</c:OurReference>" + "<c:BehalfOfBranch>" + solID.trim()
				+ "</c:BehalfOfBranch>" + "</m:Context>" + "<m:ExtraData>"
				+ "<n:REQUSTID>" + requestId.trim() + "</n:REQUSTID>"
				+ "</m:ExtraData>" + "</m:TFATTDOC>" + "</ServiceRequest>";
		logger.info(ActionConstants.EXITING_METHOD
				+ "getIDCCorrespondenceXML method");
		return xmlString;
	}

	private String getIDCAcceptXML(String solID, String productCode,
			String eventCode, String tiReferanceNo, String requestId,
			String custMnm) {
		logger.info(ActionConstants.ENTERING_METHOD);
		logger.info("Sol id==>" + solID.trim());
		logger.info("IDC_productCode ==>" + productCode.trim());
		logger.info("IDC_eventCode ==>" + eventCode.trim());
		String xmlString = "<?xml version=\"1.0\" standalone=\"yes\"?>"
				+ "<ServiceRequest xmlns:xsi='http://www.w3.org/2001/XMLSchema-instance' "
				+ " xmlns:m='urn:messages.service.ti.apps.tiplus2.misys.com' "
				+ " xmlns:c='urn:common.service.ti.apps.tiplus2.misys.com' "
				+ "xmlns:n='urn:custom.service.ti.apps.tiplus2.misys.com' "
				+ "xmlns='urn:control.services.tiplus2.misys.com'>"
				+ "<RequestHeader>" + "<Service>TI</Service>"
				+ "<Operation>TFCOLACP</Operation>" + "<Credentials>"
				+ "<Name>Name</Name>" + "<Password>Password</Password>"
				+ "<Certificate>Certificate</Certificate>"
				+ "<Digest>Digest</Digest>" + "</Credentials>"
				+ "<ReplyFormat>FULL</ReplyFormat>" + "<NoRepair>Y</NoRepair>"
				+ "<NoOverride>Y</NoOverride>"
				+ "<CorrelationId>CorrelationId</CorrelationId>"
				+ "<TransactionControl>NONE</TransactionControl>"
				+ "</RequestHeader>" + "<m:TFCOLACP>" + "<m:Context>"
				+ "<c:Branch>5860</c:Branch>" + "<c:Product>"
				+ productCode.trim()
				+ "</c:Product>"
				+ "<c:Event>"
				+ eventCode.trim()
				+ "</c:Event>"
				+ "<c:BehalfOfBranch>"
				+ solID.trim()
				+ "</c:BehalfOfBranch>"
				+ "</m:Context>"
				+ "<m:MasterRef>"
				+ tiReferanceNo.trim()
				+ "</m:MasterRef>"
				+ "<m:Sender>"
				+ "<c:Customer>"
				+ custMnm.trim()
				+ "</c:Customer>"
				+ "</m:Sender>"
				+ "<m:ExtraData>"
				+ "<n:REQUSTID>"
				+ requestId.trim()
				+ "</n:REQUSTID>"
				+ "</m:ExtraData>" + "</m:TFCOLACP>" + "</ServiceRequest>";
		logger.info(ActionConstants.EXITING_METHOD);
		return xmlString;
	}

	private String getIDCCreXML(String solID, String productCode,
			String eventCode, String requestId, String toolDetails) {
		logger.info(ActionConstants.ENTERING_METHOD);
		logger.info("Sol id==>" + solID.trim());
		logger.info("IDC_productCode ==>" + productCode.trim());
		logger.info("IDC_eventCode ==>" + eventCode.trim());
		String xmlString = "<?xml version=\"1.0\" standalone=\"yes\"?>"
				+ "<ServiceRequest xmlns:xsi='http://www.w3.org/2001/XMLSchema-instance' "
				+ "xmlns:m='urn:messages.service.ti.apps.tiplus2.misys.com' "
				+ " xmlns:c='urn:common.service.ti.apps.tiplus2.misys.com' "
				+ "xmlns:n='urn:custom.service.ti.apps.tiplus2.misys.com' "
				+ " xmlns='urn:control.services.tiplus2.misys.com'>"
				+ "<RequestHeader>" + "<Service>TI</Service>"
				+ "<Operation>TFATTDOC</Operation>" + "<Credentials>"
				+ "<Name>Name</Name>" + "<Password>Password</Password>"
				+ "<Certificate>Certificate</Certificate>"
				+ "<Digest>Digest</Digest>" + "</Credentials>"
				+ "<ReplyFormat>FULL</ReplyFormat>" + "<NoRepair>Y</NoRepair>"
				+ "<NoOverride>Y</NoOverride>"
				+ "<CorrelationId>CorrelationId</CorrelationId>"
				+ "<TransactionControl>NONE</TransactionControl>"
				+ "</RequestHeader>" + "<m:TFATTDOC>" + "<m:Context>"
				+ "<c:Branch>5860</c:Branch>" + "<c:Product>" + productCode
				+ "</c:Product>" + "<c:Event>" + eventCode + "</c:Event>"
				+ "<c:BehalfOfBranch>" + solID.trim() + "</c:BehalfOfBranch>"
				+ "</m:Context>" + "<m:ExtraData>" + "<n:REQUSTID>"
				+ requestId.trim() + "</n:REQUSTID>" + "<n:TOOLDTLS>"
				+ toolDetails + "</n:TOOLDTLS>" + "</m:ExtraData>"
				+ "</m:TFATTDOC>" + "</ServiceRequest>";
		logger.info(ActionConstants.EXITING_METHOD);
		return xmlString;
	}

	// ELC DOP Issue Fix 20-12-2019 starts
	private String getElcDocpresentXML(String productCode, String eventCode,
			String tiReferanceNo, String solID, String requestId) {
		logger.info(ActionConstants.ENTERING_METHOD);
		logger.info("Sol id==>" + solID.trim());
		logger.info("Customer cif==>" + tiReferanceNo.trim());
		String xmlString = "<?xml version=\"1.0\" standalone=\"yes\"?>"
				+ "<ServiceRequest xmlns:xsi='http://www.w3.org/2001/XMLSchema-instance' "
				+ "xmlns:m='urn:messages.service.ti.apps.tiplus2.misys.com' "
				+ "xmlns:c='urn:common.service.ti.apps.tiplus2.misys.com' "
				+ "xmlns:n='urn:custom.service.ti.apps.tiplus2.misys.com' "
				+ "xmlns='urn:control.services.tiplus2.misys.com'>"
				+ "<RequestHeader>" + "<Service>TI</Service>"
				+ "<Operation>TFATTDOC</Operation>" + "<Credentials>"
				+ "<Name>Name</Name>" + "<Password>Password</Password>"
				+ "<Certificate>Certificate</Certificate>"
				+ "<Digest>Digest</Digest>" + "</Credentials>"
				+ "<ReplyFormat>FULL</ReplyFormat>" + "<NoRepair>Y</NoRepair>"
				+ "<NoOverride>Y</NoOverride>"
				+ "<CorrelationId>CorrelationId</CorrelationId>"
				+ "<TransactionControl>NONE</TransactionControl>"
				+ "</RequestHeader>" + "<m:TFATTDOC>" + "<m:Context>"
				+ "<c:Branch>5860</c:Branch>" + "<c:Product>" + productCode
				+ "</c:Product>" + "<c:Event>" + eventCode + "</c:Event>"
				+ "<c:OurReference>" + tiReferanceNo.trim()
				+ "</c:OurReference>" + "<c:BehalfOfBranch>" + solID.trim()
				+ "</c:BehalfOfBranch>" + "</m:Context>" + "<m:ExtraData>"
				+ "<n:REQUSTID>" + requestId.trim() + "</n:REQUSTID>"
				+ "</m:ExtraData>" + "</m:TFATTDOC>" + "</ServiceRequest>";
		logger.info(ActionConstants.EXITING_METHOD);
		return xmlString;
	}

	// ELC DOP Issue Fix 20-12-2019 ends

	public String getIlcClaimRcvXML(String solId, String tiReferanceNo,
			String productCode, String eventCode, String requestId) {
		logger.info(ActionConstants.ENTERING_METHOD);
		logger.info("Sol id==>" + solId.trim());
		logger.info("Customer cif==>" + tiReferanceNo.trim());
		String xmlString = "<?xml version=\"1.0\" standalone=\"yes\"?>"
				+ "<ServiceRequest xmlns:xsi='http://www.w3.org/2001/XMLSchema-instance' "
				+ "xmlns:m='urn:messages.service.ti.apps.tiplus2.misys.com' "
				+ "xmlns:c='urn:common.service.ti.apps.tiplus2.misys.com' "
				+ "xmlns:n='urn:custom.service.ti.apps.tiplus2.misys.com' "
				+ "xmlns='urn:control.services.tiplus2.misys.com'>"
				+ "<RequestHeader>" + "<Service>TI</Service>"
				+ "<Operation>TFATTDOC</Operation>" + "<Credentials>"
				+ "<Name>Name</Name>" + "<Password>Password</Password>"
				+ "<Certificate>Certificate</Certificate>"
				+ "<Digest>Digest</Digest>" + "</Credentials>"
				+ "<ReplyFormat>FULL</ReplyFormat>" + "<NoRepair>Y</NoRepair>"
				+ "<NoOverride>Y</NoOverride>"
				+ "<CorrelationId>CorrelationId</CorrelationId>"
				+ "<TransactionControl>NONE</TransactionControl>"
				+ "</RequestHeader>" + "<m:TFATTDOC>" + "<m:Context>"
				+ "<c:Branch>5860</c:Branch>" + "<c:Product>" + productCode
				+ "</c:Product>" + "<c:Event>" + eventCode + "</c:Event>"
				+ "<c:OurReference>" + tiReferanceNo.trim()
				+ "</c:OurReference>" + "<c:BehalfOfBranch>" + solId.trim()
				+ "</c:BehalfOfBranch>" + "</m:Context>" + "<m:ExtraData>"
				+ "<n:REQUSTID>" + requestId.trim() + "</n:REQUSTID>"
				+ "</m:ExtraData>" + "</m:TFATTDOC>" + "</ServiceRequest>";
		logger.info(ActionConstants.EXITING_METHOD);
		return xmlString;
	}

	public String getIlcOutstandingClaimXML(String solId, String tiReferanceNo,
			String customerCif, String requestId) {
		logger.info(ActionConstants.ENTERING_METHOD);
		String xmlString = "<?xml version=\"1.0\" standalone=\"yes\"?>"
				+ "<ServiceRequest xmlns:xsi='http://www.w3.org/2001/XMLSchema-instance' "
				+ "xmlns:m='urn:messages.service.ti.apps.tiplus2.misys.com' "
				+ "xmlns:c='urn:common.service.ti.apps.tiplus2.misys.com' "
				+ "xmlns:n='urn:custom.service.ti.apps.tiplus2.misys.com' "
				+ "xmlns='urn:control.services.tiplus2.misys.com'>"
				+ "<RequestHeader>" + "<Service>TI</Service>"
				+ "<Operation>TFILCPYR</Operation>" + "<Credentials>"
				+ "<Name>Name</Name>" + "<Password>Password</Password>"
				+ "<Certificate>Certificate</Certificate>"
				+ "<Digest>Digest</Digest>" + "</Credentials>"
				+ "<ReplyFormat>FULL</ReplyFormat>" + "<NoRepair>Y</NoRepair>"
				+ "<NoOverride>Y</NoOverride>"
				+ "<CorrelationId>CorrelationId</CorrelationId>"
				+ "<TransactionControl>NONE</TransactionControl>"
				+ "</RequestHeader>" + "<m:TFILCPYR>" + "<m:Context>"
				+ "<c:Branch>5860</c:Branch>" + "<c:BehalfOfBranch>"
				+ solId.trim() + "</c:BehalfOfBranch>" + "</m:Context>"
				+ "<m:MasterRef>" + tiReferanceNo.trim() + "</m:MasterRef>"
				+ "<m:Sender>" + "<c:Customer>" + customerCif.trim()
				+ "</c:Customer>" + "</m:Sender>" + "<m:ExtraData>"
				+ "<n:REQUSTID>" + requestId.trim() + "</n:REQUSTID>"
				+ "</m:ExtraData>" + "</m:TFILCPYR>" + "</ServiceRequest>";
		logger.info(ActionConstants.EXITING_METHOD);
		return xmlString;
	}

	// /getIlcCorrespondenceXML
	private String getIlcCorrespondenceXML(String solID, String productCode,
			String eventCode, String requestId, String tiReferanceNo) {
		logger.info(ActionConstants.ENTERING_METHOD
				+ "getIlcCorrespondenceXML method");
		logger.info("Sol id==>" + solID.trim());
		logger.info(" productCode ==>" + productCode.trim());
		logger.info(" eventCode ==>" + eventCode.trim());
		String xmlString = "<?xml version=\"1.0\" standalone=\"yes\"?>"
				+ "<ServiceRequest xmlns:xsi='http://www.w3.org/2001/XMLSchema-instance' "
				+ "xmlns:m='urn:messages.service.ti.apps.tiplus2.misys.com' "
				+ " xmlns:c='urn:common.service.ti.apps.tiplus2.misys.com' "
				+ "xmlns:n='urn:custom.service.ti.apps.tiplus2.misys.com' "
				+ " xmlns='urn:control.services.tiplus2.misys.com'>"
				+ "<RequestHeader>" + "<Service>TI</Service>"
				+ "<Operation>TFATTDOC</Operation>" + "<Credentials>"
				+ "<Name>Name</Name>" + "<Password>Password</Password>"
				+ "<Certificate>Certificate</Certificate>"
				+ "<Digest>Digest</Digest>" + "</Credentials>"
				+ "<ReplyFormat>FULL</ReplyFormat>" + "<NoRepair>Y</NoRepair>"
				+ "<NoOverride>Y</NoOverride>"
				+ "<CorrelationId>CorrelationId</CorrelationId>"
				+ "<TransactionControl>NONE</TransactionControl>"
				+ "</RequestHeader>" + "<m:TFATTDOC>" + "<m:Context>"
				+ "<c:Branch>5860</c:Branch>" + "<c:Product>" + productCode
				+ "</c:Product>" + "<c:Event>" + eventCode + "</c:Event>"
				+ "<c:OurReference>" + tiReferanceNo.trim()
				+ "</c:OurReference>" + "<c:BehalfOfBranch>" + solID.trim()
				+ "</c:BehalfOfBranch>" + "</m:Context>" + "<m:ExtraData>"
				+ "<n:REQUSTID>" + requestId.trim() + "</n:REQUSTID>"
				+ "</m:ExtraData>" + "</m:TFATTDOC>" + "</ServiceRequest>";
		logger.info(ActionConstants.EXITING_METHOD
				+ "getIlcCorrespondenceXML method");
		return xmlString;

	}

	public String getIlcIssueXML(String solId, String customerCif,
			String amount, String currency, String requestId) {
		logger.info(ActionConstants.ENTERING_METHOD);
		logger.info("Sol id==>" + solId.trim());
		logger.info("Customer cif==>" + customerCif.trim());
		logger.info("Amount==>" + amount.trim());
		logger.info("Currency==>" + currency);
		logger.info("Currency==>" + currency.trim());
		logger.info("Request Id==>" + requestId.trim());
		String xmlString = "<?xml version=\"1.0\" standalone=\"yes\"?>"
				+ "<ServiceRequest xmlns:xsi='http://www.w3.org/2001/XMLSchema-instance' "
				+ "xmlns:m='urn:messages.service.ti.apps.tiplus2.misys.com' "
				+ "xmlns:c='urn:common.service.ti.apps.tiplus2.misys.com' "
				+ "xmlns:n='urn:custom.service.ti.apps.tiplus2.misys.com' "
				+ "xmlns='urn:control.services.tiplus2.misys.com'>"
				+ "<RequestHeader>" + "<Service>TI</Service>"
				+ "<Operation>TFILCAPP</Operation>" + "<Credentials>"
				+ "<Name>Name</Name>" + "<Password>Password</Password>"
				+ "<Certificate>Certificate</Certificate>"
				+ "<Digest>Digest</Digest>" + "</Credentials>"
				+ "<ReplyFormat>FULL</ReplyFormat>" + "<NoRepair>Y</NoRepair>"
				+ "<NoOverride>Y</NoOverride>"
				+ "<CorrelationId>CorrelationId</CorrelationId>"
				+ "<TransactionControl>NONE</TransactionControl>"
				+ "</RequestHeader>" + "<m:TFILCAPP>" + "<m:Context>"
				+ "<c:Branch>5860</c:Branch>" + "<c:BehalfOfBranch>"
				+ solId.trim()
				+ "</c:BehalfOfBranch>"
				+ "</m:Context>"
				+ "<m:Applicant>"
				+ "<c:Customer>"
				+ customerCif.trim()
				+ "</c:Customer>"
				+ "</m:Applicant>"
				+ "<m:LCAmount>"
				+ "<c:Amount>"
				+ amount.trim()
				+ "</c:Amount>"
				+ "<c:Currency>"
				+ currency.trim()
				+ "</c:Currency>"
				+ "</m:LCAmount>"
				+ "<m:ExtraData>"
				+ "<n:REQUSTID>"
				+ requestId.trim()
				+ "</n:REQUSTID>"
				+ "</m:ExtraData>"
				+ "</m:TFILCAPP>"
				+ "</ServiceRequest>";
		logger.info(ActionConstants.EXITING_METHOD);
		return xmlString;
	}

	public String getOdcCreateXML(String prodCode, String eventCode,
			String solId, String currency, String direct, String customerCif,
			String amount, String subProduct, String requestId) {
		logger.info(ActionConstants.ENTERING_METHOD);
		String xmlString = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>"
				+ "<ServiceRequest xmlns='urn:control.services.tiplus2.misys.com' "
				+ "xmlns:c='urn:common.service.ti.apps.tiplus2.misys.com' "
				+ "xmlns:n='urn:custom.service.ti.apps.tiplus2.misys.com' "
				+ "xmlns:m='urn:messages.service.ti.apps.tiplus2.misys.com' "
				+ "xmlns:xsi='http://www.w3.org/2001/XMLSchema-instance'>"
				+ "<RequestHeader>" + "<Service>TI</Service>"
				+ "<Operation>TFCOLNEW</Operation>" + "<Credentials>"
				+ "<Name>Name</Name>" + "<Password>Password</Password>"
				+ "<Certificate>Certificate</Certificate>"
				+ "<Digest>Digest</Digest>" + "</Credentials>"
				+ "<ReplyFormat>FULL</ReplyFormat>" + "<NoRepair>Y</NoRepair>"
				+ "<NoOverride>Y</NoOverride>"
				+ "<CorrelationId>CorrelationId</CorrelationId>"
				+ "</RequestHeader>" + "<m:TFCOLNEW>" + "<m:Context>"
				+ "<c:Branch>5860</c:Branch>" + "<c:Product>"
				+ prodCode.trim()
				+ "</c:Product>"
				+ "<c:Event>"
				+ eventCode.trim()
				+ "</c:Event>"
				+ "<c:BehalfOfBranch>"
				+ solId.trim()
				+ "</c:BehalfOfBranch>"
				+ "</m:Context>"
				+ "<m:CollectionType>T</m:CollectionType>"
				+ "<m:Drawer>"
				+ "<c:Customer>"
				+ customerCif.trim()
				+ "</c:Customer>"
				+ "</m:Drawer>"
				+ "<m:DirectCollection>"
				+ direct.trim()
				+ "</m:DirectCollection>"
				+ "<m:CollectionAmount>"
				+ "<c:Amount>"
				+ amount.trim()
				+ "</c:Amount>"
				+ "<c:Currency>"
				+ currency.trim()
				+ "</c:Currency>"
				+ "</m:CollectionAmount>"
				+ "<m:ProductType>"
				+ subProduct.trim()
				+ "</m:ProductType>"
				+ "<m:ExtraData>"
				+ "<n:REQUSTID>"
				+ requestId.trim()
				+ "</n:REQUSTID>"
				+ "</m:ExtraData>"
				+ "</m:TFCOLNEW>"
				+ "</ServiceRequest>";

		logger.info(ActionConstants.EXITING_METHOD);
		return xmlString;
	}

	public String getOdcPaymentXML(String prodCode, String eventCode,
			String solId, String masterRef, String requestId) {
		logger.info(ActionConstants.ENTERING_METHOD);
		String xmlString = "<?xml version=\"1.0\" standalone=\"yes\"?>"
				+ "<ServiceRequest xmlns:xsi='http://www.w3.org/2001/XMLSchema-instance' "
				+ "xmlns:m='urn:messages.service.ti.apps.tiplus2.misys.com' "
				+ "xmlns:c='urn:common.service.ti.apps.tiplus2.misys.com' "
				+ "xmlns:n='urn:custom.service.ti.apps.tiplus2.misys.com' "
				+ "xmlns='urn:control.services.tiplus2.misys.com'>"
				+ "<RequestHeader>" + "<Service>TI</Service>"
				+ "<Operation>TFATTDOC</Operation>" + "<Credentials>"
				+ "<Name>Name</Name>" + "<Password>Password</Password>"
				+ "<Certificate>Certificate</Certificate>"
				+ "<Digest>Digest</Digest>" + "</Credentials>"
				+ "<ReplyFormat>FULL</ReplyFormat>" + "<NoRepair>Y</NoRepair>"
				+ "<NoOverride>Y</NoOverride>"
				+ "<CorrelationId>CorrelationId</CorrelationId>"
				+ "</RequestHeader>" + "<m:TFATTDOC>" + "<m:Context>"
				+ "<c:Branch>5860</c:Branch>" + "<c:Product>"
				+ prodCode.trim()
				+ "</c:Product>"
				+ "<c:Event>"
				+ eventCode.trim()
				+ "</c:Event>"
				+ "<c:OurReference>"
				+ masterRef.trim()
				+ "</c:OurReference>"
				+ "<c:TheirReference>"
				+ masterRef.trim()
				+ "</c:TheirReference>"
				+ "<c:BehalfOfBranch>"
				+ solId.trim()
				+ "</c:BehalfOfBranch>"
				+ "</m:Context>"
				+ "<m:MasterRef>"
				+ masterRef.trim()
				+ "</m:MasterRef>"
				+ "<m:ExtraData>"
				+ "<n:REQUSTID>"
				+ requestId.trim()
				+ "</n:REQUSTID>"
				+ "</m:ExtraData>"
				+ "</m:TFATTDOC>" + "</ServiceRequest>";
		logger.info(ActionConstants.EXITING_METHOD);
		return xmlString;
	}

	public String getFocAdjustXML(String prodCode, String eventCode,
			String solId, String masterRef, String requestId) {
		logger.info(ActionConstants.ENTERING_METHOD);

		String xmlString = "<?xml version=\"1.0\" standalone=\"yes\"?>"
				+ "<ServiceRequest xmlns:xsi='http://www.w3.org/2001/XMLSchema-instance' "
				+ "xmlns:m='urn:messages.service.ti.apps.tiplus2.misys.com' "
				+ "xmlns:c='urn:common.service.ti.apps.tiplus2.misys.com' "
				+ "xmlns:n='urn:custom.service.ti.apps.tiplus2.misys.com' "
				+ "xmlns='urn:control.services.tiplus2.misys.com'>"
				+ "<RequestHeader>" + "<Service>TI</Service>"
				+ "<Operation>TFATTDOC</Operation>" + "<Credentials>"
				+ "<Name>Name</Name>" + "<Password>Password</Password>"
				+ "<Certificate>Certificate</Certificate>"
				+ "<Digest>Digest</Digest>" + "</Credentials>"
				+ "<ReplyFormat>FULL</ReplyFormat>" + "<NoRepair>Y</NoRepair>"
				+ "<NoOverride>Y</NoOverride>"
				+ "<CorrelationId>CorrelationId</CorrelationId>"
				+ "</RequestHeader>" + "<m:TFATTDOC>" + "<m:Context>"
				+ "<c:Branch>5860</c:Branch>" + "<c:Product>"
				+ prodCode.trim()
				+ "</c:Product>"
				+ "<c:Event>"
				+ eventCode.trim()
				+ "</c:Event>"
				+ "<c:OurReference>"
				+ masterRef.trim()
				+ "</c:OurReference>"
				+ "<c:TheirReference>"
				+ masterRef.trim()
				+ "</c:TheirReference>"
				+ "<c:BehalfOfBranch>"
				+ solId.trim()
				+ "</c:BehalfOfBranch>"
				+ "</m:Context>"
				+ "<m:MasterRef>"
				+ masterRef.trim()
				+ "</m:MasterRef>"
				+ "<m:ExtraData>"
				+ "<n:REQUSTID>"
				+ requestId.trim()
				+ "</n:REQUSTID>"
				+ "</m:ExtraData>"
				+ "</m:TFATTDOC>" + "</ServiceRequest>";
		logger.info(ActionConstants.EXITING_METHOD);
		return xmlString;
	}

	public String getFsaRepayXML(String prodCode, String eventCode,
			String solId, String masterRef, String customerCif, String requestId) {

		String xmlString = "<?xml version=\"1.0\" standalone=\"yes\"?>"
				+ "<ServiceRequest xmlns:xsi='http://www.w3.org/2001/XMLSchema-instance' "
				+ "xmlns:m='urn:messages.service.ti.apps.tiplus2.misys.com' "
				+ "xmlns:c='urn:common.service.ti.apps.tiplus2.misys.com' "
				+ "xmlns:n='urn:custom.service.ti.apps.tiplus2.misys.com' "
				+ "xmlns='urn:control.services.tiplus2.misys.com'>"
				+ "<RequestHeader>" + "<Service>TI</Service>"
				+ "<Operation>TFFSARPY</Operation>" + "<Credentials>"
				+ "<Name>Name</Name>" + "<Password>Password</Password>"
				+ "<Certificate>Certificate</Certificate>"
				+ "<Digest>Digest</Digest>" + "</Credentials>"
				+ "<ReplyFormat>FULL</ReplyFormat>" + "<NoRepair>Y</NoRepair>"
				+ "<NoOverride>Y</NoOverride>"
				+ "<CorrelationId>CorrelationId</CorrelationId>"
				+ "</RequestHeader>" + "<m:TFFSARPY>" + "<m:Context>"
				+ "<c:Branch>5860</c:Branch>" + "<c:Customer>"
				+ customerCif.trim()
				+ "</c:Customer>"
				+ "	<c:Product>"
				+ prodCode.trim()
				+ "</c:Product>"
				+ "<c:Event>"
				+ eventCode.trim()
				+ "</c:Event>"
				+ "	<c:OurReference>"
				+ masterRef.trim()
				+ "</c:OurReference>"
				+ "	<c:TheirReference>"
				+ masterRef.trim()
				+ "</c:TheirReference>"
				+ "	 <c:BehalfOfBranch>"
				+ solId.trim()
				+ "</c:BehalfOfBranch>"
				+ "	</m:Context>"
				+ "	<m:MasterRef>"
				+ masterRef.trim()
				+ "</m:MasterRef>"
				+ "<m:RepaymentAction>P</m:RepaymentAction>"
				+ "<m:ExtraData>"
				+ "<n:REQUSTID>"
				+ requestId.trim()
				+ "</n:REQUSTID>"
				+ "</m:ExtraData>" + "</TFFSARPY>" + "</ServiceRequest>";
		logger.info(ActionConstants.EXITING_METHOD);
		return xmlString;
	}

	public String getFocRepayXML(String prodCode, String eventCode,
			String solId, String masterRef, String customerCif, String requestId) {
		logger.info(ActionConstants.ENTERING_METHOD);
		if (eventCode.equalsIgnoreCase("CRYST")) {
			eventCode = "RSA1";
		}

		String xmlString = "<?xml version=\"1.0\" standalone=\"yes\"?>"
				+ "<ServiceRequest xmlns:xsi='http://www.w3.org/2001/XMLSchema-instance' "
				+ "xmlns:m='urn:messages.service.ti.apps.tiplus2.misys.com' "
				+ "xmlns:c='urn:common.service.ti.apps.tiplus2.misys.com' "
				+ "xmlns:n='urn:custom.service.ti.apps.tiplus2.misys.com' "
				+ "xmlns='urn:control.services.tiplus2.misys.com'>"
				+ "<RequestHeader>" + "<Service>TI</Service>"
				+ "<Operation>TFFOCRPY</Operation>" + "<Credentials>"
				+ "<Name>Name</Name>" + "<Password>Password</Password>"
				+ "<Certificate>Certificate</Certificate>"
				+ "<Digest>Digest</Digest>" + "</Credentials>"
				+ "<ReplyFormat>FULL</ReplyFormat>" + "<NoRepair>Y</NoRepair>"
				+ "<NoOverride>Y</NoOverride>"
				+ "<CorrelationId>CorrelationId</CorrelationId>"
				+ "</RequestHeader>" + "<m:TFFOCRPY>" + "<m:Context>"
				+ "<c:Branch>5860</c:Branch>" + "<c:Customer>"
				+ customerCif.trim()
				+ "</c:Customer>"
				+ "	<c:Product>"
				+ prodCode.trim()
				+ "</c:Product>"
				+ "<c:Event>"
				+ eventCode.trim()
				+ "</c:Event>"
				+ "	<c:OurReference>"
				+ masterRef.trim()
				+ "</c:OurReference>"
				+ "	<c:TheirReference>"
				+ masterRef.trim()
				+ "</c:TheirReference>"
				+ "	 <c:BehalfOfBranch>"
				+ solId.trim()
				+ "</c:BehalfOfBranch>"
				+ "	</m:Context>"
				+ "	<m:MasterRef>"
				+ masterRef.trim()
				+ "</m:MasterRef>"
				+ "<m:RepaymentAction>P</m:RepaymentAction>"
				+ "<m:ExtraData>"
				+ "<n:REQUSTID>"
				+ requestId.trim()
				+ "</n:REQUSTID>"
				+ "</m:ExtraData>" + "</m:TFFOCRPY>" + "</ServiceRequest>";
		logger.info(ActionConstants.EXITING_METHOD);
		return xmlString;
	}

	private String getFocPsa1XML(String solID, String productCode,
			String eventCode, String requestId, String tiReferanceNo) {
		logger.info(ActionConstants.ENTERING_METHOD
				+ "getFOCCorrespondenceXML method");
		logger.info("Sol id==>" + solID.trim());
		logger.info(" productCode ==>" + productCode.trim());
		logger.info(" eventCode ==>" + eventCode.trim());
		String xmlString = "<?xml version=\"1.0\" standalone=\"yes\"?>"
				+ "<ServiceRequest xmlns:xsi='http://www.w3.org/2001/XMLSchema-instance' "
				+ "xmlns:m='urn:messages.service.ti.apps.tiplus2.misys.com' "
				+ " xmlns:c='urn:common.service.ti.apps.tiplus2.misys.com' "
				+ "xmlns:n='urn:custom.service.ti.apps.tiplus2.misys.com' "
				+ " xmlns='urn:control.services.tiplus2.misys.com'>"
				+ "<RequestHeader>" + "<Service>TI</Service>"
				+ "<Operation>TFATTDOC</Operation>" + "<Credentials>"
				+ "<Name>Name</Name>" + "<Password>Password</Password>"
				+ "<Certificate>Certificate</Certificate>"
				+ "<Digest>Digest</Digest>" + "</Credentials>"
				+ "<ReplyFormat>FULL</ReplyFormat>" + "<NoRepair>Y</NoRepair>"
				+ "<NoOverride>Y</NoOverride>"
				+ "<CorrelationId>CorrelationId</CorrelationId>"
				+ "<TransactionControl>NONE</TransactionControl>"
				+ "</RequestHeader>" + "<m:TFATTDOC>" + "<m:Context>"
				+ "<c:Branch>5860</c:Branch>" + "<c:Product>" + productCode
				+ "</c:Product>" + "<c:Event>" + eventCode + "</c:Event>"
				+ "<c:OurReference>" + tiReferanceNo.trim()
				+ "</c:OurReference>" + "<c:BehalfOfBranch>" + solID.trim()
				+ "</c:BehalfOfBranch>" + "</m:Context>" + "<m:ExtraData>"
				+ "<n:REQUSTID>" + requestId.trim() + "</n:REQUSTID>"
				+ "</m:ExtraData>" + "</m:TFATTDOC>" + "</ServiceRequest>";
		logger.info(ActionConstants.EXITING_METHOD
				+ "getFOCCorrespondenceXML method");
		return xmlString;
	}

	public String getIlcAmendXML(String solId, String tiReferanceNo,
			String customerCif, String requestId) {
		logger.info(ActionConstants.ENTERING_METHOD);
		String xmlString = "<?xml version=\"1.0\" standalone=\"yes\"?>"
				+ "<ServiceRequest xmlns:xsi='http://www.w3.org/2001/XMLSchema-instance' "
				+ "xmlns:m='urn:messages.service.ti.apps.tiplus2.misys.com' "
				+ "xmlns:c='urn:common.service.ti.apps.tiplus2.misys.com' "
				+ "xmlns:n='urn:custom.service.ti.apps.tiplus2.misys.com' "
				+ "xmlns='urn:control.services.tiplus2.misys.com'>"
				+ "<RequestHeader>" + "<Service>TI</Service>"
				+ "<Operation>TFILCAPP</Operation>" + "<Credentials>"
				+ "<Name>Name</Name>" + "<Password>Password</Password>"
				+ "<Certificate>Certificate</Certificate>"
				+ "<Digest>Digest</Digest>" + "</Credentials>"
				+ "<ReplyFormat>FULL</ReplyFormat>" + "<NoRepair>Y</NoRepair>"
				+ "<NoOverride>Y</NoOverride>"
				+ "<CorrelationId>CorrelationId</CorrelationId>"
				+ "<TransactionControl>NONE</TransactionControl>"
				+ "</RequestHeader>" + "<m:TFILCAMN>" + "<m:Context>"
				+ "<c:Branch>5860</c:Branch>" + "<c:BehalfOfBranch>"
				+ solId.trim() + "</c:BehalfOfBranch>" + "</m:Context>"
				+ "<m:MasterRef>" + tiReferanceNo.trim() + "</m:MasterRef>"
				+ "<m:Sender>" + "<c:Customer>" + customerCif.trim()
				+ "</c:Customer>" + "</m:Sender>" + "<m:ExtraData>"
				+ "<n:REQUSTID>" + requestId.trim() + "</n:REQUSTID>"
				+ "</m:ExtraData>" + "</m:TFILCAMN>" + "</ServiceRequest>";
		logger.info(ActionConstants.EXITING_METHOD);
		return xmlString;
	}

	private String getElcAdviseXML(String productCode, String eventCode,
			String solID, String customeCif, String amount, String currency,
			String requestId) {
		logger.info(ActionConstants.ENTERING_METHOD + ">> getElcAdviseXML");
		logger.info("Getting Product Code==> " + productCode);
		logger.info("Getting event Code==> " + eventCode);
		logger.info("Getting Sol ID==> " + solID);
		logger.info("Getting custome Cif==> " + customeCif);
		logger.info("Getting amount==> " + amount);
		logger.info("Getting currency==> " + currency);
		logger.info("Getting requestId==> " + requestId);

		String xmlString = "<?xml version=\"1.0\" standalone=\"yes\"?>"
				+ "<ServiceRequest xmlns:xsi='http://www.w3.org/2001/XMLSchema-instance' "
				+ "xmlns:m='urn:messages.service.ti.apps.tiplus2.misys.com' "
				+ "xmlns:c='urn:common.service.ti.apps.tiplus2.misys.com' "
				+ "xmlns:n='urn:custom.service.ti.apps.tiplus2.misys.com' "
				+ "xmlns='urn:control.services.tiplus2.misys.com'>"
				+ "<RequestHeader>" + "<Service>TI</Service>"
				+ "<Operation>TFELCNEW</Operation>" + "<Credentials>"
				+ "<Name>Name</Name>" + "<Password>Password</Password>"
				+ "<Certificate>Certificate</Certificate>"
				+ "<Digest>Digest</Digest>" + "</Credentials>"
				+ "<ReplyFormat>FULL</ReplyFormat>" + "<NoRepair>Y</NoRepair>"
				+ "<NoOverride>Y</NoOverride>"
				+ "<CorrelationId>CorrelationId</CorrelationId>"
				+ "<TransactionControl>NONE</TransactionControl>"
				+ "</RequestHeader>" + "<m:TFELCNEW>" + "<m:Context>"
				+ "<c:Branch>5860</c:Branch>" + "<c:Product>"
				+ productCode.trim()
				+ "</c:Product>"
				+ "<c:Event>"
				+ eventCode.trim()
				+ "</c:Event>"
				+ "<c:BehalfOfBranch>"
				+ solID.trim()
				+ "</c:BehalfOfBranch> "
				+ "</m:Context>"
				+ "<m:Beneficiary>"
				+ "<c:Customer>"
				+ customeCif.trim()
				+ "</c:Customer>"
				+ "</m:Beneficiary>"
				+ "<m:LCAmount>"
				+ "<c:Amount>"
				+ amount.trim()
				+ "</c:Amount>"
				+ "<c:Currency>"
				+ currency.trim()
				+ "</c:Currency>"
				+ "</m:LCAmount>"
				+ "<m:ExtraData>"
				+ "<n:REQUSTID>"
				+ requestId.trim()
				+ "</n:REQUSTID>"
				+ "</m:ExtraData>"
				+ "</m:TFELCNEW>"
				+ "</ServiceRequest>";

		logger.info("Final Elc Advise XML==> " + xmlString);

		logger.info(ActionConstants.EXITING_METHOD + ">> getElcAdviseXML");
		return xmlString;
	}

	private String getElcAmendXML(String solID, String tiReferenceNo,
			String requestId) {

		logger.info(ActionConstants.ENTERING_METHOD + ">> getElcAmendXML");
		logger.info("Getting solID==>" + solID);
		logger.info("Getting tiReferenceNo==>" + tiReferenceNo);
		logger.info("Getting requestId==>" + requestId);

		String xmlString = "<?xml version=\"1.0\" standalone=\"yes\"?>"
				+ "<ServiceRequest xmlns:xsi='http://www.w3.org/2001/XMLSchema-instance' "
				+ "xmlns:m='urn:messages.service.ti.apps.tiplus2.misys.com' "
				+ "xmlns:c='urn:common.service.ti.apps.tiplus2.misys.com' "
				+ "xmlns:n='urn:custom.service.ti.apps.tiplus2.misys.com' "
				+ "xmlns='urn:control.services.tiplus2.misys.com'>"
				+ "<RequestHeader>" + "<Service>TI</Service>"
				+ "<Operation>TFELCAMD</Operation>" + "<Credentials>"
				+ "<Name>Name</Name>" + "<Password>Password</Password>"
				+ "<Certificate>Certificate</Certificate>"
				+ "<Digest>Digest</Digest>" + "</Credentials>"
				+ "<ReplyFormat>FULL</ReplyFormat>" + "<NoRepair>Y</NoRepair>"
				+ "<NoOverride>Y</NoOverride>"
				+ "<CorrelationId>CorrelationId</CorrelationId>"
				+ "<TransactionControl>NONE</TransactionControl>"
				+ "</RequestHeader>" + "<m:TFELCAMD>" + "<m:Context>"
				+ "<c:BehalfOfBranch>" + solID.trim() + "</c:BehalfOfBranch>"
				+ "</m:Context>" + "<m:MasterRef>" + tiReferenceNo.trim()
				+ "</m:MasterRef>" + "<m:ExtraData>" + "<n:REQUSTID>"
				+ requestId.trim() + "</n:REQUSTID>" + "</m:ExtraData>"
				+ "</m:TFELCAMD>" + "</ServiceRequest>";
		logger.info("Final Elc Amend XML==> " + xmlString);
		logger.info(ActionConstants.EXITING_METHOD + ">> getElcAmendXML");
		return xmlString;
	}

	/*
	 * public String getFelCreateXML(String prodCode, String eventCode, String
	 * solId, String FncAmt, String curr, String LcRefNum, String subProdCode,
	 * String requestId) { logger.info(ActionConstants.ENTERING_METHOD); String
	 * xmlString = "<?xml version=\"1.0\" standalone=\"yes\"?><ServiceRequest "
	 * + "xmlns:xsi='http://www.w3.org/2001/XMLSchema-instance' " +
	 * "xmlns:m='urn:messages.service.ti.apps.tiplus2.misys.com' " +
	 * "xmlns:c='urn:common.service.ti.apps.tiplus2.misys.com' " +
	 * "xmlns='urn:control.services.tiplus2.misys.com'>	" +
	 * "<RequestHeader><Service>TI</Service><Operation>TFFINNEW</Operation>" +
	 * "<Credentials><Name>Name</Name><Password>Password</Password>" +
	 * "<Certificate>Certificate</Certificate><Digest>Diges</Digest></Credentials>"
	 * +
	 * "<ReplyFormat>FULL</ReplyFormat><NoRepair>Y</NoRepair><NoOverride>Y</NoOverride>"
	 * +
	 * "<CorrelationIdCorrelationId</CorrelationId></RequestHeader><m:TFFINNEW>"
	 * + "<m:Context><c:Branch>5860</c:Branch><c:Product>" + prodCode.trim() +
	 * "</c:Product>" + "<c:Event>" + eventCode.trim() + "</c:Event>" +
	 * "<c:BehalfOfBranch>" + solId.trim() +
	 * "</c:BehalfOfBranch></m:Context><m:FinanceAmount>" + "<c:Amount>" +
	 * FncAmt + "</c:Amount><c:Currency>" + curr.trim() +
	 * "</c:Currency></m:FinanceAmount>" + "<m:RelatedMasterRef>" +
	 * LcRefNum.trim() + "</m:RelatedMasterRef>" + "<m:ProductCode>" +
	 * prodCode.trim() + "</m:ProductCode><m:ProductType>" + subProdCode.trim()
	 * + "</m:ProductType></m:TFFINNEW></ServiceRequest>";
	 * 
	 * logger.info(ActionConstants.EXITING_METHOD); return xmlString; }
	 */

	// Changed by ETT offshore Team starts 27122019
	/*
	 * public String getFocCreateXML(String prodCode, String eventCode, String
	 * solId, String FinanceAmt, String curr, String masterRef, String
	 * subProductCode, String customerCif, String requestId) {
	 * logger.info(ActionConstants.ENTERING_METHOD); String xmlString =
	 * "<?xml version=\"1.0\" standalone=\"yes\"?><ServiceRequest " +
	 * "xmlns:xsi='http://www.w3.org/2001/XMLSchema-instance' " +
	 * "xmlns:m='urn:messages.service.ti.apps.tiplus2.misys.com' " +
	 * "xmlns:c='urn:common.service.ti.apps.tiplus2.misys.com' " +
	 * "xmlns:n='urn:custom.service.ti.apps.tiplus2.misys.com' " +
	 * "xmlns='urn:control.services.tiplus2.misys.com'>	" +
	 * "<RequestHeader><Service>TI</Service><Operation>TFFINNEW</Operation>" +
	 * "<Credentials><Name>Name</Name><Password>Password</Password>" +
	 * "<Certificate>Certificate</Certificate><Digest>Diges</Digest></Credentials>"
	 * +
	 * "<ReplyFormat>FULL</ReplyFormat><NoRepair>Y</NoRepair><NoOverride>Y</NoOverride>"
	 * +
	 * "<CorrelationId>CorrelationId</CorrelationId></RequestHeader><m:TFFINNEW>"
	 * + "<m:Context><c:Branch>5860</c:Branch><c:Product>" + prodCode.trim() +
	 * "</c:Product>" + "<c:Event>" + eventCode.trim() + "</c:Event>" +
	 * "<c:BehalfOfBranch>" + solId.trim() +
	 * "</c:BehalfOfBranch></m:Context><m:FinanceAmount>" + "<c:Amount>" +
	 * FinanceAmt.trim() + "</c:Amount><c:Currency>" + curr.trim() +
	 * "</c:Currency></m:FinanceAmount>" + "<m:FinanceToParty>" + "<c:Customer>"
	 * + customerCif.trim() + "</c:Customer>" + "</m:FinanceToParty>" +
	 * "<m:RelatedMasterRef>" + masterRef.trim() + "</m:RelatedMasterRef>" +
	 * "<m:ProductCode>" + prodCode.trim() + "</m:ProductCode><m:ProductType>" +
	 * subProductCode.trim() + "</m:ProductType>" + "<m:ExtraData>" +
	 * "<n:REQUSTID>" + requestId.trim() + "</n:REQUSTID>" + "</m:ExtraData>" +
	 * "</m:TFFINNEW></ServiceRequest>";
	 * 
	 * logger.info(ActionConstants.EXITING_METHOD); return xmlString; }
	 */
	public String getFocCreateXML(String prodCode, String eventCode,
			String solId, String FinanceAmt, String curr, String masterRef,
			String subProductCode, String customerCif, String requestId) {
		logger.info(ActionConstants.ENTERING_METHOD);
		String xmlString = "<?xml version=\"1.0\" standalone=\"yes\"?>"
				+ "<ServiceRequest xmlns:xsi='http://www.w3.org/2001/XMLSchema-instance' "
				+ "xmlns:m='urn:messages.service.ti.apps.tiplus2.misys.com' "
				+ "xmlns:c='urn:common.service.ti.apps.tiplus2.misys.com' "
				+ "xmlns:n='urn:custom.service.ti.apps.tiplus2.misys.com' "
				+ "xmlns='urn:control.services.tiplus2.misys.com'>"
				+ "<RequestHeader>" + "<Service>TI</Service>"
				+ "<Operation>TFATTDOC</Operation>" + "<Credentials>"
				+ "<Name>Name</Name>" + "<Password>Password</Password>"
				+ "<Certificate>Certificate</Certificate>"
				+ "<Digest>Digest</Digest>" + "</Credentials>"
				+ "<ReplyFormat>FULL</ReplyFormat>" + "<NoRepair>Y</NoRepair>"
				+ "<NoOverride>Y</NoOverride>"
				+ "<CorrelationId>CorrelationId</CorrelationId>"
				+ "</RequestHeader>" + "<m:TFATTDOC>" + "<m:Context>"
				+ "<c:Branch>5860</c:Branch>" + "<c:Product>ODC</c:Product>"
				+ "<c:Event>FEC</c:Event>" + "<c:OurReference>"
				+ masterRef.trim() + "</c:OurReference>" + "<c:TheirReference>"
				+ masterRef.trim() + "</c:TheirReference>"
				+ "<c:BehalfOfBranch>" + solId.trim() + "</c:BehalfOfBranch>"
				+ "</m:Context>" + "<m:MasterRef>" + masterRef.trim()
				+ "</m:MasterRef>" + "<m:ExtraData>" + "<n:REQUSTID>"
				+ requestId.trim() + "</n:REQUSTID>" + "</m:ExtraData>"
				+ "</m:TFATTDOC>" + "</ServiceRequest>";

		logger.info(ActionConstants.EXITING_METHOD);
		return xmlString;
	}

	// Changed by ETT offshore Team ends 27122019

	/*
	 * public String getFelAdjustXML(String prodCode, String eventCode, String
	 * solId, String LcRefNum, String requestId) {
	 * logger.info(ActionConstants.ENTERING_METHOD);
	 * 
	 * String xmlString = "<?xml version=\"1.0\" standalone=\"yes\"?>" +
	 * "<ServiceRequest xmlns:xsi='http://www.w3.org/2001/XMLSchema-instance' "
	 * + "xmlns:m='urn:messages.service.ti.apps.tiplus2.misys.com' " +
	 * "xmlns:c='urn:common.service.ti.apps.tiplus2.misys.com' " +
	 * "xmlns:n='urn:custom.service.ti.apps.tiplus2.misys.com' " +
	 * "xmlns='urn:control.services.tiplus2.misys.com'>" + "<RequestHeader>" +
	 * "<Service>TI</Service>" + "<Operation>TFATTDOC</Operation>" +
	 * "<Credentials>" + "<Name>Name</Name>" + "<Password>Password</Password>" +
	 * "<Certificate>Certificate</Certificate>" + "<Digest>Digest</Digest>" +
	 * "</Credentials>" + "<ReplyFormat>FULL</ReplyFormat>" +
	 * "<NoRepair>Y</NoRepair>" + "<NoOverride>Y</NoOverride>" +
	 * "<CorrelationId>CorrelationId</CorrelationId>" + "</RequestHeader>" +
	 * "<m:TFATTDOC>" + "<m:Context>" + "<c:Branch>5860</c:Branch>" +
	 * "<c:Product>" + prodCode.trim() + "</c:Product>" + "<c:Event>" +
	 * eventCode.trim() + "</c:Event>" + "<c:OurReference>" + LcRefNum.trim() +
	 * "</c:OurReference>" + "<c:TheirReference>" + LcRefNum.trim() +
	 * "</c:TheirReference>" + "<c:BehalfOfBranch>" + solId.trim() +
	 * "</c:BehalfOfBranch>" + "</m:Context>" + "<m:MasterRef>" +
	 * LcRefNum.trim() + "</m:MasterRef>" + "<m:ExtraData>" + "<n:REQUSTID>" +
	 * requestId.trim() + "</n:REQUSTID>" + "</m:ExtraData>" + "</m:TFATTDOC>" +
	 * "</ServiceRequest>";
	 * 
	 * logger.info(ActionConstants.EXITING_METHOD); return xmlString; }
	 */

	/*
	 * public String getFelCrystalizationXML(String prodCode, String eventCode,
	 * String solId, String LcRefNum, String requestId, String CustomerCif,
	 * String CustomerName, String currency, String fncAmount) {
	 * logger.info(ActionConstants.ENTERING_METHOD);
	 * 
	 * String xmlString = "<?xml version=\"1.0\" standalone=\"yes\"?>" +
	 * "<ServiceRequest xmlns:xsi='http://www.w3.org/2001/XMLSchema-instance'" +
	 * " xmlns:m='urn:messages.service.ti.apps.tiplus2.misys.com'" +
	 * " xmlns:c='urn:common.service.ti.apps.tiplus2.misys.com'" +
	 * " xmlns='urn:control.services.tiplus2.misys.com'>" + "	<RequestHeader>" +
	 * "		<Service>TI</Service>" + "		<Operation>TFFELRPY</Operation>" +
	 * "		<Credentials>" + "			<Name>Name</Name>" +
	 * "			<Password>Password</Password>" +
	 * "			<Certificate>Certificate</Certificate>" + "		<Digest>Digest</Digest>"
	 * + "		</Credentials>" + "		<ReplyFormat>FULL</ReplyFormat>" +
	 * "	<NoRepair>Y</NoRepair>" + "		<NoOverride>Y</NoOverride>" +
	 * "		<CorrelationId>CorrelationId</CorrelationId>" + "	</RequestHeader>" +
	 * "	<m:TFFELRPY> 		<m:Context>" +
	 * "			<c:Branch>5860</c:Branch> 			<c:Customer>" + CustomerCif.trim() +
	 * "</c:Customer>" + "			<c:Product>" + prodCode.trim() + "</c:Product>" +
	 * "			<c:Event>RSA4</c:Event>" + "			<c:OurReference>" + LcRefNum.trim() +
	 * "</c:OurReference>" + "			<c:BehalfOfBranch>" + solId.trim() +
	 * "</c:BehalfOfBranch>" + "		</m:Context>" + " <m:MasterRef>" +
	 * LcRefNum.trim() + "</m:MasterRef>" +
	 * " <m:RepaymentAction>P</m:RepaymentAction>" + "<m:ExtraData>" +
	 * "<n:REQUSTID>" + requestId.trim() + "</n:REQUSTID>" +
	 * "</m:ExtraData> 	</m:TFFELRPY> </ServiceRequest>";
	 * 
	 * logger.info(ActionConstants.EXITING_METHOD); return xmlString; }
	 */

	public String getFsaCreateXML(String prodCode, String eventCode,
			String solId, String FinanceAmt, String curr,
			String subProductCode, String customerCif, String requestId) {
		logger.info(ActionConstants.ENTERING_METHOD);
		System.out.println("FinanceAmt-->" + FinanceAmt);
		String xmlString = "<?xml version=\"1.0\" standalone=\"yes\"?><ServiceRequest "
				+ "xmlns:xsi='http://www.w3.org/2001/XMLSchema-instance' "
				+ "xmlns:m='urn:messages.service.ti.apps.tiplus2.misys.com' "
				+ "xmlns:c='urn:common.service.ti.apps.tiplus2.misys.com' "
				+ "xmlns:n='urn:custom.service.ti.apps.tiplus2.misys.com' "
				+ "xmlns='urn:control.services.tiplus2.misys.com'>	"
				+ "<RequestHeader><Service>TI</Service><Operation>TFFINNEW</Operation>"
				+ "<Credentials><Name>Name</Name><Password>Password</Password>"
				+ "<Certificate>Certificate</Certificate><Digest>Diges</Digest></Credentials>"
				+ "<ReplyFormat>FULL</ReplyFormat><NoRepair>Y</NoRepair><NoOverride>Y</NoOverride>"
				+ "<CorrelationId>CorrelationId</CorrelationId></RequestHeader><m:TFFINNEW>"
				+ "<m:Context><c:Branch>5860</c:Branch><c:Product>"
				+ prodCode.trim()
				+ "</c:Product>"
				+ "<c:Event>"
				+ eventCode.trim()
				+ "</c:Event>"
				+ "<c:BehalfOfBranch>"
				+ solId.trim()
				+ "</c:BehalfOfBranch></m:Context>"
				+ "<m:Amount>"
				+ "<c:Amount>"
				+ FinanceAmt.trim()
				+ "</c:Amount><c:Currency>"
				+ curr.trim()
				+ "</c:Currency></m:Amount>"
				+ "<m:FinanceAmount>"
				+ "<c:Amount>"
				+ FinanceAmt.trim()
				+ "</c:Amount><c:Currency>"
				+ curr.trim()
				+ "</c:Currency></m:FinanceAmount>"
				+ "<m:FinanceToParty>"
				+ "<c:Customer>"
				+ customerCif.trim()
				+ "</c:Customer>"
				+ "</m:FinanceToParty>"
				+ "<m:ProductCode>"
				+ prodCode.trim()
				+ "</m:ProductCode><m:ProductType>"
				+ subProductCode.trim()
				+ "</m:ProductType>"
				+ "<m:ExtraData>"
				+ "<n:REQUSTID>"
				+ requestId.trim()
				+ "</n:REQUSTID>"
				+ "</m:ExtraData>" + "</m:TFFINNEW></ServiceRequest>";

		logger.info(ActionConstants.EXITING_METHOD);
		return xmlString;
	}

	// Inward Remittance changes 23-12-2019 starts
	private String getRemittanceCreateXML(String solID, String productCode,
			String eventCode, String requestId, String toolDetails) {
		logger.info(ActionConstants.ENTERING_METHOD);
		logger.info("Sol id==>" + solID.trim());
		logger.info("Inward Remittance productCode ==>" + productCode.trim());
		logger.info("Inward Remittance eventCode ==>" + eventCode.trim());

		String xmlString = "<?xml version=\"1.0\" standalone=\"yes\"?>"
				+ "<ServiceRequest xmlns:xsi='http://www.w3.org/2001/XMLSchema-instance' "
				+ "xmlns:m='urn:messages.service.ti.apps.tiplus2.misys.com' "
				+ " xmlns:c='urn:common.service.ti.apps.tiplus2.misys.com' "
				+ "xmlns:n='urn:custom.service.ti.apps.tiplus2.misys.com' "
				+ " xmlns='urn:control.services.tiplus2.misys.com'>"
				+ "<RequestHeader>" + "<Service>TI</Service>"
				+ "<Operation>TFATTDOC</Operation>" + "<Credentials>"
				+ "<Name>Name</Name>" + "<Password>Password</Password>"
				+ "<Certificate>Certificate</Certificate>"
				+ "<Digest>Digest</Digest>" + "</Credentials>"
				+ "<ReplyFormat>FULL</ReplyFormat>" + "<NoRepair>Y</NoRepair>"
				+ "<NoOverride>Y</NoOverride>"
				+ "<CorrelationId>CorrelationId</CorrelationId>"
				+ "<TransactionControl>NONE</TransactionControl>"
				+ "</RequestHeader>" + "<m:TFATTDOC>" + "<m:Context>"
				+ "<c:Branch>5860</c:Branch>" + "<c:Product>" + productCode
				+ "</c:Product>" + "<c:Event>" + eventCode + "</c:Event>"
				+ "<c:BehalfOfBranch>" + solID.trim() + "</c:BehalfOfBranch>"
				+ "</m:Context>" + "<m:ExtraData>" + "<n:REQUSTID>"
				+ requestId.trim() + "</n:REQUSTID>" + "<n:TOOLDTLS>"
				+ toolDetails + "</n:TOOLDTLS>" + "</m:ExtraData>"
				+ "</m:TFATTDOC>" + "</ServiceRequest>";
		logger.info(ActionConstants.EXITING_METHOD);
		return xmlString;
	}

	// Inward Remittance changes 23-12-2019 ends
	// Outward Remittance Changes 23/12/2019 start

	public String getCPCOCreXML(String solId, String customerCif,
			String customerName, String amount, String currency,
			String subProduct, String requestId) {
		logger.info(ActionConstants.ENTERING_METHOD);
		logger.info("Sol id==>" + solId.trim());
		logger.info("Customer cif==>" + customerCif.trim());
		logger.info("customerName==>" + customerName.trim());
		logger.info("Amount==>" + amount.trim());
		logger.info("Currency==>" + currency);
		logger.info("Currency==>" + currency.trim());
		logger.info("Request Id==>" + subProduct.trim());
		String xmlString = "<?xml version=\"1.0\" standalone=\"yes\"?>"
				+ "<ServiceRequest xmlns:xsi='http://www.w3.org/2001/XMLSchema-instance' "
				+ "xmlns:m='urn:messages.service.ti.apps.tiplus2.misys.com' "
				+ "xmlns:c='urn:common.service.ti.apps.tiplus2.misys.com' "
				+ "xmlns:n='urn:custom.service.ti.apps.tiplus2.misys.com' "
				+ "xmlns='urn:control.services.tiplus2.misys.com'>"
				+ "<RequestHeader>" + "<Service>TI</Service>"
				+ "<Operation>TFCPCCRT</Operation>" + "<Credentials>"
				+ "<Name>Name</Name>" + "<Password>Password</Password>"
				+ "<Certificate>Certificate</Certificate>"
				+ "<Digest>Digest</Digest>" + "</Credentials>"
				+ "<ReplyFormat>FULL</ReplyFormat>" + "<NoRepair>Y</NoRepair>"
				+ "<NoOverride>Y</NoOverride>"
				+ "<CorrelationId>CorrelationId</CorrelationId>"
				+ "<TransactionControl>NONE</TransactionControl>"
				+ "</RequestHeader>" + "<m:TFCPCCRT>" + "<m:Context>"
				+ "<c:Branch>5860</c:Branch>" + "<c:BehalfOfBranch>"
				+ solId.trim()
				+ "</c:BehalfOfBranch>"
				+ "</m:Context>"
				+ "<m:Sender>"
				+ "<c:Customer>"
				+ customerCif.trim()
				+ "</c:Customer>"
				+ "<c:NameAddress>"
				+ customerName.trim()
				+ "</c:NameAddress>"
				+ "</m:Sender>"
				+ "<m:Remitter>"
				+ "<c:Customer>"
				+ customerCif.trim()
				+ "</c:Customer>"
				+ "<c:NameAddress>"
				+ customerName.trim()
				+ "</c:NameAddress>"
				+ "</m:Remitter>"
				+ "<m:RemitterAmount>"
				+ "<c:Amount>"
				+ amount.trim()
				+ "</c:Amount>"
				+ "<c:Currency>"
				+ currency.trim()
				+ "</c:Currency>"
				+ "</m:RemitterAmount>"
				+ "<m:ProductType>"
				+ subProduct.trim()
				+ "</m:ProductType>"
				+ "<m:ExtraData>"
				+ "<n:REQUSTID>"
				+ requestId.trim()
				+ "</n:REQUSTID>"
				+ "</m:ExtraData>"
				+ "</m:TFCPCCRT>"
				+ "</ServiceRequest>";
		logger.info(ActionConstants.EXITING_METHOD);
		return xmlString;
	}

	/*
	 * private String getCPBOCreXML(String solID, String productCode, String
	 * eventCode, String requestId) {
	 * logger.info(ActionConstants.ENTERING_METHOD); logger.info("Sol id==>" +
	 * solID.trim()); logger.info("CPBO_productCode ==>" + productCode.trim());
	 * logger.info("PBOC_eventCode ==>" + eventCode.trim()); String xmlString =
	 * "<?xml version=\"1.0\" standalone=\"yes\"?>" +
	 * "<ServiceRequest xmlns:xsi='http://www.w3.org/2001/XMLSchema-instance' "
	 * + "xmlns:m='urn:messages.service.ti.apps.tiplus2.misys.com' " +
	 * " xmlns:c='urn:common.service.ti.apps.tiplus2.misys.com' " +
	 * "xmlns:n='urn:custom.service.ti.apps.tiplus2.misys.com' " +
	 * " xmlns='urn:control.services.tiplus2.misys.com'>" + "<RequestHeader>" +
	 * "<Service>TI</Service>" + "<Operation>TFATTDOC</Operation>" +
	 * "<Credentials>" + "<Name>Name</Name>" + "<Password>Password</Password>" +
	 * "<Certificate>Certificate</Certificate>" + "<Digest>Digest</Digest>" +
	 * "</Credentials>" + "<ReplyFormat>FULL</ReplyFormat>" +
	 * "<NoRepair>Y</NoRepair>" + "<NoOverride>Y</NoOverride>" +
	 * "<CorrelationId>CorrelationId</CorrelationId>" +
	 * "<TransactionControl>NONE</TransactionControl>" + "</RequestHeader>" +
	 * "<m:TFATTDOC>" + "<m:Context>" + "<c:Branch>5860</c:Branch>" +
	 * "<c:Product>" + productCode + "</c:Product>" + "<c:Event>" + eventCode +
	 * "</c:Event>" + "<c:BehalfOfBranch>" + solID.trim() +
	 * "</c:BehalfOfBranch>" + "</m:Context>" + "<m:ExtraData>" + "<n:REQUSTID>"
	 * + requestId.trim() + "</n:REQUSTID>" + "</m:ExtraData>" + "</m:TFATTDOC>"
	 * + "</ServiceRequest>"; logger.info(ActionConstants.EXITING_METHOD);
	 * return xmlString; }
	 */
	// Outward Remittance Changes 23/12/2019 end
	// Changes for ELC and IGT Starts 25-12-2019

	private String getIgtIssueXML(String solID, String tiReferanceNo,
			String customeCif, String amount, String currency, String requestId) {

		logger.info(ActionConstants.ENTERING_METHOD);
		logger.info("Sol id==>" + solID.trim());
		String xmlString = "<?xml version=\"1.0\" standalone=\"yes\"?>  "
				+ "<ServiceRequest xmlns:xsi='http://www.w3.org/2001/XMLSchema-instance'  "
				+ "xmlns:m='urn:messages.service.ti.apps.tiplus2.misys.com'  "
				+ "xmlns:c='urn:common.service.ti.apps.tiplus2.misys.com'  "
				+ "xmlns:n='urn:custom.service.ti.apps.tiplus2.misys.com'  "
				+ "xmlns='urn:control.services.tiplus2.misys.com'> "
				+ "  <RequestHeader> " + "    <Service>TI</Service> "
				+ "    <Operation>TFIGTAPP</Operation> " + "    <Credentials> "
				+ "      <Name>Name</Name> "
				+ "      <Password>Password</Password> "
				+ "      <Certificate>Certificate</Certificate> "
				+ "      <Digest>Digest</Digest> " + "    </Credentials> "
				+ "    <ReplyFormat>FULL</ReplyFormat> "
				+ "    <NoRepair>Y</NoRepair> "
				+ "    <NoOverride>Y</NoOverride> "
				+ "    <CorrelationId>CorrelationId</CorrelationId> "
				+ "    <TransactionControl>NONE</TransactionControl> "
				+ "  </RequestHeader> " + "  <m:TFIGTAPP> "
				+ "    <m:Context> " + "      <c:BehalfOfBranch>"
				+ solID
				+ "</c:BehalfOfBranch> "
				+ "    </m:Context> "
				+ "    <m:Applicant> "
				+ "      <c:Customer>"
				+ customeCif
				+ "</c:Customer> "
				+ "    </m:Applicant> "
				+ "    <m:LCAmount> "
				+ "      <c:Amount>"
				+ amount
				+ "</c:Amount> "
				+ "      <c:Currency>"
				+ currency
				+ "</c:Currency> "
				+ "    </m:LCAmount> "
				+ "    <m:ExtraData> "
				+ "      <n:REQUSTID>"
				+ requestId
				+ "</n:REQUSTID> "
				+ "    </m:ExtraData> "
				+ "  </m:TFIGTAPP> "
				+ "</ServiceRequest> ";
		logger.info(ActionConstants.EXITING_METHOD);
		return xmlString;
	}

	private String getIgtAmendXML(String solID, String tiReferanceNo,
			String customeCif, String amount, String currency, String requestId) {

		logger.info(ActionConstants.ENTERING_METHOD);
		logger.info("Sol id==>" + solID.trim());
		String xmlString = "<?xml version=\"1.0\" standalone=\"yes\"?>"
				+ "<ServiceRequest xmlns:xsi='http://www.w3.org/2001/XMLSchema-instance' "
				+ "xmlns:m='urn:messages.service.ti.apps.tiplus2.misys.com' "
				+ "xmlns:c='urn:common.service.ti.apps.tiplus2.misys.com' "
				+ "xmlns:n='urn:custom.service.ti.apps.tiplus2.misys.com' "
				+ "xmlns='urn:control.services.tiplus2.misys.com'>"
				+ "<RequestHeader>" + "<Service>TI</Service>"
				+ "<Operation>TFIGTAMN</Operation>" + "<Credentials>"
				+ "<Name>Name</Name>" + "<Password>Password</Password>"
				+ "<Certificate>Certificate</Certificate>"
				+ "<Digest>Digest</Digest>" + "</Credentials>"
				+ "<ReplyFormat>FULL</ReplyFormat>" + "<NoRepair>Y</NoRepair>"
				+ "<NoOverride>Y</NoOverride>"
				+ "<CorrelationId>CorrelationId</CorrelationId>"
				+ "<TransactionControl>NONE</TransactionControl>"
				+ "</RequestHeader>" + "<m:TFIGTAMN>" + "<m:Context>"
				+ "<c:BehalfOfBranch>" + solID.trim() + "</c:BehalfOfBranch>"
				+ "</m:Context>" + "<m:MasterRef>" + tiReferanceNo.trim()
				+ "</m:MasterRef>" + "<m:Sender>" + "<c:Customer>"
				+ customeCif.trim() + "</c:Customer>" + "</m:Sender>"
				+ "<m:ExtraData>" + "<n:REQUSTID>" + requestId.trim()
				+ "</n:REQUSTID>" + "</m:ExtraData>" + "</m:TFIGTAMN>"
				+ "</ServiceRequest>";
		logger.info(ActionConstants.EXITING_METHOD);
		return xmlString;
	}

	private String getIgtPaymentXML(String solID, String tiReferanceNo,
			String customeCif, String amount, String currency,
			String requestId, String billref) {

		logger.info(ActionConstants.ENTERING_METHOD);
		logger.info("Sol id==>" + solID.trim());
		String xmlString = "<?xml version=\"1.0\" standalone=\"yes\"?>"
				+ "<ServiceRequest xmlns:xsi='http://www.w3.org/2001/XMLSchema-instance' "
				+ "xmlns:m='urn:messages.service.ti.apps.tiplus2.misys.com' "
				+ "xmlns:c='urn:common.service.ti.apps.tiplus2.misys.com' "
				+ "xmlns:n='urn:custom.service.ti.apps.tiplus2.misys.com' "
				+ "xmlns='urn:control.services.tiplus2.misys.com'>"
				+ "<RequestHeader>" + "<Service>TI</Service>"
				+ "<Operation>TFIGTPYR</Operation>" + "<Credentials>"
				+ "<Name>Name</Name>" + "<Password>Password</Password>"
				+ "<Certificate>Certificate</Certificate>"
				+ "<Digest>Digest</Digest>" + "</Credentials>"
				+ "<ReplyFormat>FULL</ReplyFormat>" + "<NoRepair>Y</NoRepair>"
				+ "<NoOverride>Y</NoOverride>"
				+ "<CorrelationId>CorrelationId</CorrelationId>"
				+ "<TransactionControl>NONE</TransactionControl>"
				+ "</RequestHeader>" + "<m:TFIGTPYR>" + "<m:Context>"
				+ "<c:BehalfOfBranch>" + solID.trim() + "</c:BehalfOfBranch>"
				+ "</m:Context>" + "<m:MasterRef>" + tiReferanceNo.trim()
				+ "</m:MasterRef>" + "<m:ClaimId>" + billref.trim()
				+ "</m:ClaimId>" + "<m:Sender>" + "<c:Customer>"
				+ customeCif.trim() + "</c:Customer>" + "</m:Sender>"
				+ "<m:ExtraData>" + "<n:REQUSTID>" + requestId.trim()
				+ "</n:REQUSTID>" + "</m:ExtraData>" + "</m:TFIGTPYR>"
				+ "</ServiceRequest>";
		;
		logger.info(ActionConstants.EXITING_METHOD);
		return xmlString;
	}

	public String getIgtClaimRcvXML(String solId, String tiReferanceNo,
			String productCode, String eventCode, String requestId) {
		logger.info(ActionConstants.ENTERING_METHOD);
		logger.info("Sol id==>" + solId.trim());
		logger.info("Customer cif==>" + tiReferanceNo.trim());
		String xmlString = "<?xml version=\"1.0\" standalone=\"yes\"?>"
				+ "<ServiceRequest xmlns:xsi='http://www.w3.org/2001/XMLSchema-instance' "
				+ "xmlns:m='urn:messages.service.ti.apps.tiplus2.misys.com' "
				+ "xmlns:c='urn:common.service.ti.apps.tiplus2.misys.com' "
				+ "xmlns:n='urn:custom.service.ti.apps.tiplus2.misys.com' "
				+ "xmlns='urn:control.services.tiplus2.misys.com'>"
				+ "<RequestHeader>" + "<Service>TI</Service>"
				+ "<Operation>TFATTDOC</Operation>" + "<Credentials>"
				+ "<Name>Name</Name>" + "<Password>Password</Password>"
				+ "<Certificate>Certificate</Certificate>"
				+ "<Digest>Digest</Digest>" + "</Credentials>"
				+ "<ReplyFormat>FULL</ReplyFormat>" + "<NoRepair>Y</NoRepair>"
				+ "<NoOverride>Y</NoOverride>"
				+ "<CorrelationId>CorrelationId</CorrelationId>"
				+ "<TransactionControl>NONE</TransactionControl>"
				+ "</RequestHeader>" + "<m:TFATTDOC>" + "<m:Context>"
				+ "<c:Branch>5860</c:Branch>" + "<c:Product>" + productCode
				+ "</c:Product>" + "<c:Event>" + eventCode + "</c:Event>"
				+ "<c:OurReference>" + tiReferanceNo.trim()
				+ "</c:OurReference>" + "<c:BehalfOfBranch>" + solId.trim()
				+ "</c:BehalfOfBranch>" + "</m:Context>" + "<m:ExtraData>"
				+ "<n:REQUSTID>" + requestId.trim() + "</n:REQUSTID>"
				+ "</m:ExtraData>" + "</m:TFATTDOC>" + "</ServiceRequest>";
		logger.info(ActionConstants.EXITING_METHOD);
		return xmlString;
	}

	public String getElcOutstandingPresXML(String solId, String tiReferanceNo,
			String customerCif, String requestId, String billref) {
		logger.info(ActionConstants.ENTERING_METHOD);
		String xmlString = "<?xml version=\"1.0\" standalone=\"yes\"?><ServiceRequest xmlns:xsi='http://www.w3.org/2001/XMLSchema-instance' xmlns:m='urn:messages.service.ti.apps.tiplus2.misys.com' xmlns:c='urn:common.service.ti.apps.tiplus2.misys.com' xmlns='urn:control.services.tiplus2.misys.com' xmlns:n='urn:custom.service.ti.apps.tiplus2.misys.com' > "
				+ "	<RequestHeader> "
				+ "		<Service>TI</Service> "
				+ "		<Operation>TFELCPYR</Operation> "
				+ "		<Credentials> "
				+ "			<Name>Name</Name> "
				+ "			<Password>Password</Password> "
				+ "			<Certificate>Certificate</Certificate> "
				+ "			<Digest>Digest</Digest> "
				+ "		</Credentials> "
				+ "		<ReplyFormat>FULL</ReplyFormat> "
				+ "		<NoRepair>Y</NoRepair> "
				+ "		<NoOverride>Y</NoOverride> "
				+ "		<CorrelationId>CorrelationId</CorrelationId> "
				+ "		<TransactionControl>NONE</TransactionControl> "
				+ "	</RequestHeader> "
				+ "	<m:TFELCPYR> "
				+ "		<m:Context> "
				+ "			<c:BehalfOfBranch>"
				+ solId.trim()
				+ "</c:BehalfOfBranch> "
				+ "		</m:Context> "
				+ "		<m:MasterRef>"
				+ tiReferanceNo.trim()
				+ "</m:MasterRef> "
				+ "		<m:ClaimId>"
				+ billref.trim()
				+ "</m:ClaimId> "
				+ "		<m:Sender> "
				+ "			<c:Customer>"
				+ customerCif.trim()
				+ "</c:Customer> "
				+ "		</m:Sender> "
				+ "		<m:ExtraData> "
				+ "		<n:REQUSTID>"
				+ requestId.trim()
				+ "</n:REQUSTID> "
				+ "		</m:ExtraData> "
				+ "	</m:TFELCPYR> "
				+ "</ServiceRequest> ";
		logger.info(ActionConstants.EXITING_METHOD);
		return xmlString;
	}

	private String getElcCorrespondenceXML(String solID, String productCode,
			String eventCode, String requestId, String tiReferanceNo) {
		logger.info(ActionConstants.ENTERING_METHOD
				+ "getIElcCorrespondenceXML method");
		logger.info("Sol id==>" + solID.trim());
		logger.info(" productCode ==>" + productCode.trim());
		logger.info(" eventCode ==>" + eventCode.trim());
		String xmlString = "<?xml version=\"1.0\" standalone=\"yes\"?>"
				+ "<ServiceRequest xmlns:xsi='http://www.w3.org/2001/XMLSchema-instance' "
				+ "xmlns:m='urn:messages.service.ti.apps.tiplus2.misys.com' "
				+ " xmlns:c='urn:common.service.ti.apps.tiplus2.misys.com' "
				+ "xmlns:n='urn:custom.service.ti.apps.tiplus2.misys.com' "
				+ " xmlns='urn:control.services.tiplus2.misys.com'>"
				+ "<RequestHeader>" + "<Service>TI</Service>"
				+ "<Operation>TFATTDOC</Operation>" + "<Credentials>"
				+ "<Name>Name</Name>" + "<Password>Password</Password>"
				+ "<Certificate>Certificate</Certificate>"
				+ "<Digest>Digest</Digest>" + "</Credentials>"
				+ "<ReplyFormat>FULL</ReplyFormat>" + "<NoRepair>Y</NoRepair>"
				+ "<NoOverride>Y</NoOverride>"
				+ "<CorrelationId>CorrelationId</CorrelationId>"
				+ "<TransactionControl>NONE</TransactionControl>"
				+ "</RequestHeader>" + "<m:TFATTDOC>" + "<m:Context>"
				+ "<c:Branch>5860</c:Branch>" + "<c:Product>" + productCode
				+ "</c:Product>" + "<c:Event>" + eventCode + "</c:Event>"
				+ "<c:OurReference>" + tiReferanceNo.trim()
				+ "</c:OurReference>" + "<c:BehalfOfBranch>" + solID.trim()
				+ "</c:BehalfOfBranch>" + "</m:Context>" + "<m:ExtraData>"
				+ "<n:REQUSTID>" + requestId.trim() + "</n:REQUSTID>"
				+ "</m:ExtraData>" + "</m:TFATTDOC>" + "</ServiceRequest>";
		logger.info(ActionConstants.EXITING_METHOD
				+ "getElcCorrespondenceXML method");
		return xmlString;
	}

	// Changes for ELC and IGT ends 25-12-2019

	// CHANGES FOR ODC CAC 08012020 NY SAI STARTS HERE
	public String getOdcAcceptXML(String prodCode, String eventCode,
			String solId, String masterRef, String requestId) {
		logger.info(ActionConstants.ENTERING_METHOD);
		String xmlString = "<?xml version=\"1.0\" standalone=\"yes\"?>"
				+ "<ServiceRequest xmlns:xsi='http://www.w3.org/2001/XMLSchema-instance' "
				+ "xmlns:m='urn:messages.service.ti.apps.tiplus2.misys.com' "
				+ "xmlns:c='urn:common.service.ti.apps.tiplus2.misys.com' "
				+ "xmlns:n='urn:custom.service.ti.apps.tiplus2.misys.com' "
				+ "xmlns='urn:control.services.tiplus2.misys.com'>"
				+ "<RequestHeader>" + "<Service>TI</Service>"
				+ "<Operation>TFATTDOC</Operation>" + "<Credentials>"
				+ "<Name>Name</Name>" + "<Password>Password</Password>"
				+ "<Certificate>Certificate</Certificate>"
				+ "<Digest>Digest</Digest>" + "</Credentials>"
				+ "<ReplyFormat>FULL</ReplyFormat>" + "<NoRepair>Y</NoRepair>"
				+ "<NoOverride>Y</NoOverride>"
				+ "<CorrelationId>CorrelationId</CorrelationId>"
				+ "</RequestHeader>" + "<m:TFATTDOC>" + "<m:Context>"
				+ "<c:Branch>5860</c:Branch>" + "<c:Product>"
				+ prodCode.trim()
				+ "</c:Product>"
				+ "<c:Event>"
				+ eventCode.trim()
				+ "</c:Event>"
				+ "<c:OurReference>"
				+ masterRef.trim()
				+ "</c:OurReference>"
				+ "<c:TheirReference>"
				+ masterRef.trim()
				+ "</c:TheirReference>"
				+ "<c:BehalfOfBranch>"
				+ solId.trim()
				+ "</c:BehalfOfBranch>"
				+ "</m:Context>"
				+ "<m:MasterRef>"
				+ masterRef.trim()
				+ "</m:MasterRef>"
				+ "<m:ExtraData>"
				+ "<n:REQUSTID>"
				+ requestId.trim()
				+ "</n:REQUSTID>"
				+ "</m:ExtraData>"
				+ "</m:TFATTDOC>" + "</ServiceRequest>";
		logger.info(ActionConstants.EXITING_METHOD);
		return xmlString;
	}

	private String getCcoCorrespondenceXML(String solID, String productCode,
			String eventCode, String requestId, String tiReferanceNo) {

		logger.info(ActionConstants.ENTERING_METHOD
				+ "getFODCCorrespondenceXML method");
		logger.info("Sol id==>" + solID.trim());
		logger.info(" productCode ==>" + productCode.trim());
		logger.info(" eventCode ==>" + eventCode.trim());
		String xmlString = "<?xml version=\"1.0\" standalone=\"yes\"?>"
				+ "<ServiceRequest xmlns:xsi='http://www.w3.org/2001/XMLSchema-instance' "
				+ "xmlns:m='urn:messages.service.ti.apps.tiplus2.misys.com' "
				+ " xmlns:c='urn:common.service.ti.apps.tiplus2.misys.com' "
				+ "xmlns:n='urn:custom.service.ti.apps.tiplus2.misys.com' "
				+ " xmlns='urn:control.services.tiplus2.misys.com'>"
				+ "<RequestHeader>" + "<Service>TI</Service>"
				+ "<Operation>TFATTDOC</Operation>" + "<Credentials>"
				+ "<Name>Name</Name>" + "<Password>Password</Password>"
				+ "<Certificate>Certificate</Certificate>"
				+ "<Digest>Digest</Digest>" + "</Credentials>"
				+ "<ReplyFormat>FULL</ReplyFormat>" + "<NoRepair>Y</NoRepair>"
				+ "<NoOverride>Y</NoOverride>"
				+ "<CorrelationId>CorrelationId</CorrelationId>"
				+ "<TransactionControl>NONE</TransactionControl>"
				+ "</RequestHeader>" + "<m:TFATTDOC>" + "<m:Context>"
				+ "<c:Branch>5860</c:Branch>" + "<c:Product>" + productCode
				+ "</c:Product>" + "<c:Event>" + eventCode + "</c:Event>"
				+ "<c:OurReference>" + tiReferanceNo.trim()
				+ "</c:OurReference>" + "<c:BehalfOfBranch>" + solID.trim()
				+ "</c:BehalfOfBranch>" + "</m:Context>" + "<m:ExtraData>"
				+ "<n:REQUSTID>" + requestId.trim() + "</n:REQUSTID>"
				+ "</m:ExtraData>" + "</m:TFATTDOC>" + "</ServiceRequest>";
		logger.info(ActionConstants.EXITING_METHOD
				+ "geODCCorrespondenceXML method");
		return xmlString;
	}

	// CHANGES FOR ODC CAC 08012020 NY SAI ENDS HERE

	// Miscellanous changes starts 08-01-2020
	private String getMiscellanousCreateXML(String solID, String productCode,
			String eventCode, String requestId, String toolDetails) {
		logger.info(ActionConstants.ENTERING_METHOD
				+ "getMiscellanousCreateXML method");
		logger.info("Sol id of free correspondence==>" + solID.trim());
		logger.info("Getting productCode of free correspondence==>"
				+ productCode.trim());
		logger.info("Getting eventCode of free correspondence ==>"
				+ eventCode.trim());
		logger.info("Getting request of free correspondence ==>"
				+ requestId.trim());

		String xmlString = "<?xml version=\"1.0\" standalone=\"yes\"?>"
				+ "<ServiceRequest xmlns:xsi='http://www.w3.org/2001/XMLSchema-instance' "
				+ "xmlns:m='urn:messages.service.ti.apps.tiplus2.misys.com' "
				+ " xmlns:c='urn:common.service.ti.apps.tiplus2.misys.com' "
				+ "xmlns:n='urn:custom.service.ti.apps.tiplus2.misys.com' "
				+ " xmlns='urn:control.services.tiplus2.misys.com'>"
				+ "<RequestHeader>" + "<Service>TI</Service>"
				+ "<Operation>TFATTDOC</Operation>" + "<Credentials>"
				+ "<Name>Name</Name>" + "<Password>Password</Password>"
				+ "<Certificate>Certificate</Certificate>"
				+ "<Digest>Digest</Digest>" + "</Credentials>"
				+ "<ReplyFormat>FULL</ReplyFormat>" + "<NoRepair>Y</NoRepair>"
				+ "<NoOverride>Y</NoOverride>"
				+ "<CorrelationId>CorrelationId</CorrelationId>"
				+ "<TransactionControl>NONE</TransactionControl>"
				+ "</RequestHeader>" + "<m:TFATTDOC>" + "<m:Context>"
				+ "<c:Branch>5860</c:Branch>" + "<c:Product>" + productCode
				+ "</c:Product>" + "<c:Event>" + eventCode + "</c:Event>"
				+ "<c:BehalfOfBranch>" + solID.trim() + "</c:BehalfOfBranch>"
				+ "</m:Context>" + "<m:ExtraData>" + "<n:REQUSTID>"
				+ requestId.trim() + "</n:REQUSTID>" + "<n:TOOLDTLS>"
				+ toolDetails + "</n:TOOLDTLS>" + "</m:ExtraData>"
				+ "</m:TFATTDOC>" + "</ServiceRequest>";
		logger.info(ActionConstants.EXITING_METHOD
				+ "getMiscellanousCreateXML method");
		return xmlString;
	}

	// Miscellanous changes ends 08-01-2020

	// FEL
	// FEL starts
	public String getFelCreateXML(String prodCode, String eventCode,
			String solId, String FncAmt, String curr, String LcRefNum,
			String subProdCode, String requestId, String customerCif,
			String billRef) {
		logger.info(ActionConstants.ENTERING_METHOD);
		/*
		 * String xmlString =userVo.getCustomeCif(),userVo.getBillReferenceNo()
		 * "<?xml version=\"1.0\" standalone=\"yes\"?><ServiceRequest " +
		 * "xmlns:xsi='http://www.w3.org/2001/XMLSchema-instance' " +
		 * "xmlns:m='urn:messages.service.ti.apps.tiplus2.misys.com' " +
		 * "xmlns:c='urn:common.service.ti.apps.tiplus2.misys.com' " +
		 * "xmlns:n='urn:custom.service.ti.apps.tiplus2.misys.com' " +
		 * "xmlns='urn:control.services.tiplus2.misys.com'>	" +
		 * "<RequestHeader><Service>TI</Service><Operation>TFFINNEW</Operation>"
		 * + "<Credentials><Name>Name</Name><Password>Password</Password>" +
		 * "<Certificate>Certificate</Certificate><Digest>Diges</Digest></Credentials>"
		 * +
		 * "<ReplyFormat>FULL</ReplyFormat><NoRepair>Y</NoRepair><NoOverride>Y</NoOverride>"
		 * +
		 * "<CorrelationId>CorrelationId</CorrelationId></RequestHeader><m:TFFINNEW>"
		 * + "<m:Context><c:Branch>5860</c:Branch><c:Product>" + prodCode.trim()
		 * + "</c:Product>" + "<c:Event>" + eventCode.trim() + "</c:Event>" +
		 * "<c:BehalfOfBranch>" + solId.trim() +
		 * "</c:BehalfOfBranch></m:Context><m:FinanceAmount>" + "<c:Amount>" +
		 * FncAmt + "</c:Amount><c:Currency>" + curr.trim() +
		 * "</c:Currency></m:FinanceAmount>" + "<m:RelatedMasterRef>" +
		 * LcRefNum.trim() + "</m:RelatedMasterRef>" + "<m:ProductCode>" +
		 * prodCode.trim() + "</m:ProductCode><m:ProductType>" +
		 * subProdCode.trim() + "</m:ProductType>" + "<m:ExtraData>" +
		 * "<n:REQUSTID>" + requestId.trim() + "</n:REQUSTID>" +
		 * "</m:ExtraData>" + "</m:TFFINNEW></ServiceRequest>";
		 */
		String xmlString = "<?xml version=\"1.0\" standalone=\"yes\"?><ServiceRequest xmlns:xsi='http://www.w3.org/2001/XMLSchema-instance' xmlns:m='urn:messages.service.ti.apps.tiplus2.misys.com' xmlns:c='urn:common.service.ti.apps.tiplus2.misys.com' xmlns='urn:control.services.tiplus2.misys.com' xmlns:n='urn:custom.service.ti.apps.tiplus2.misys.com' > "
				+ "	<RequestHeader> "
				+ "		<Service>TI</Service> "
				+ "		<Operation>TFELCPYR</Operation> "
				+ "		<Credentials> "
				+ "			<Name>Name</Name> "
				+ "			<Password>Password</Password> "
				+ "			<Certificate>Certificate</Certificate> "
				+ "			<Digest>Digest</Digest> "
				+ "		</Credentials> "
				+ "		<ReplyFormat>FULL</ReplyFormat> "
				+ "		<NoRepair>Y</NoRepair> "
				+ "		<NoOverride>Y</NoOverride> "
				+ "		<CorrelationId>CorrelationId</CorrelationId> "
				+ "		<TransactionControl>NONE</TransactionControl> "
				+ "	</RequestHeader> "
				+ "	<m:TFELCPYR> "
				+ "		<m:Context> "
				+ "			<c:BehalfOfBranch>"
				+ solId.trim()
				+ "</c:BehalfOfBranch> "
				+ "		</m:Context> "
				+ "		<m:MasterRef>"
				+ LcRefNum.trim()
				+ "</m:MasterRef> "
				+ "		<m:ClaimId>"
				+ billRef.trim()
				+ "</m:ClaimId> "
				+ "		<m:Sender> "
				+ "			<c:Customer>"
				+ customerCif.trim()
				+ "</c:Customer> "
				+ "		</m:Sender> "
				+ "		<m:ExtraData> "
				+ "		<n:REQUSTID>"
				+ requestId.trim()
				+ "</n:REQUSTID> "
				+ "		</m:ExtraData> "
				+ "	</m:TFELCPYR> "
				+ "</ServiceRequest> ";

		logger.info(ActionConstants.EXITING_METHOD);
		return xmlString;
	}

	public String getFelAdjustXML(String prodCode, String eventCode,
			String solId, String LcRefNum, String requestId) {
		logger.info(ActionConstants.ENTERING_METHOD);

		String xmlString = "<?xml version=\"1.0\" standalone=\"yes\"?>"
				+ "<ServiceRequest xmlns:xsi='http://www.w3.org/2001/XMLSchema-instance' "
				+ "xmlns:m='urn:messages.service.ti.apps.tiplus2.misys.com' "
				+ "xmlns:c='urn:common.service.ti.apps.tiplus2.misys.com' "
				+ "xmlns:n='urn:custom.service.ti.apps.tiplus2.misys.com' "
				+ "xmlns='urn:control.services.tiplus2.misys.com'>"
				+ "<RequestHeader>" + "<Service>TI</Service>"
				+ "<Operation>TFATTDOC</Operation>" + "<Credentials>"
				+ "<Name>Name</Name>" + "<Password>Password</Password>"
				+ "<Certificate>Certificate</Certificate>"
				+ "<Digest>Digest</Digest>" + "</Credentials>"
				+ "<ReplyFormat>FULL</ReplyFormat>" + "<NoRepair>Y</NoRepair>"
				+ "<NoOverride>Y</NoOverride>"
				+ "<CorrelationId>CorrelationId</CorrelationId>"
				+ "</RequestHeader>" + "<m:TFATTDOC>" + "<m:Context>"
				+ "<c:Branch>5860</c:Branch>" + "<c:Product>"
				+ prodCode.trim()
				+ "</c:Product>"
				+ "<c:Event>"
				+ eventCode.trim()
				+ "</c:Event>"
				+ "<c:OurReference>"
				+ LcRefNum.trim()
				+ "</c:OurReference>"
				+ "<c:TheirReference>"
				+ LcRefNum.trim()
				+ "</c:TheirReference>"
				+ "<c:BehalfOfBranch>"
				+ solId.trim()
				+ "</c:BehalfOfBranch>"
				+ "</m:Context>"
				+ "<m:MasterRef>"
				+ LcRefNum.trim()
				+ "</m:MasterRef>"
				+ "<m:ExtraData>"
				+ "<n:REQUSTID>"
				+ requestId.trim()
				+ "</n:REQUSTID>"
				+ "</m:ExtraData>"
				+ "</m:TFATTDOC>" + "</ServiceRequest>";

		logger.info(ActionConstants.EXITING_METHOD);
		return xmlString;
	}

	public String getFelCrystalizationXML(String prodCode, String eventCode,
			String solId, String LcRefNum, String requestId,
			String CustomerCif, String CustomerName, String currency,
			String fncAmount) {
		logger.info(ActionConstants.ENTERING_METHOD);

		String xmlString = "<?xml version=\"1.0\" standalone=\"yes\"?>"
				+ "<ServiceRequest xmlns:xsi='http://www.w3.org/2001/XMLSchema-instance'"
				+ " xmlns:m='urn:messages.service.ti.apps.tiplus2.misys.com'"
				+ " xmlns:c='urn:common.service.ti.apps.tiplus2.misys.com'"
				+ " xmlns='urn:control.services.tiplus2.misys.com'"
				+ " xmlns:n='urn:custom.service.ti.apps.tiplus2.misys.com'>"
				+ "	<RequestHeader>" + "		<Service>TI</Service>"
				+ "		<Operation>TFFELRPY</Operation>" + "		<Credentials>"
				+ "			<Name>Name</Name>" + "			<Password>Password</Password>"
				+ "			<Certificate>Certificate</Certificate>"
				+ "		<Digest>Digest</Digest>" + "		</Credentials>"
				+ "		<ReplyFormat>FULL</ReplyFormat>"
				+ "	<NoRepair>Y</NoRepair>" + "		<NoOverride>Y</NoOverride>"
				+ "		<CorrelationId>CorrelationId</CorrelationId>"
				+ "	</RequestHeader>" + "	<m:TFFELRPY> 		<m:Context>"
				+ "			<c:Branch>5860</c:Branch> 			<c:Customer>"
				+ CustomerCif.trim()
				+ "</c:Customer>"
				+ "			<c:Product>"
				+ prodCode.trim()
				+ "</c:Product>"
				+ "			<c:Event>RSA4</c:Event>"
				+ "			<c:OurReference>"
				+ LcRefNum.trim()
				+ "</c:OurReference>"
				+ "			<c:BehalfOfBranch>"
				+ solId.trim()
				+ "</c:BehalfOfBranch>"
				+ "		</m:Context>"
				+ " <m:MasterRef>"
				+ LcRefNum.trim()
				+ "</m:MasterRef>"
				+ " <m:RepaymentAction>P</m:RepaymentAction>"
				+ "<m:ExtraData>"
				+ "<n:REQUSTID>"
				+ requestId.trim()
				+ "</n:REQUSTID>"
				+ "</m:ExtraData> 	</m:TFFELRPY> </ServiceRequest>";

		logger.info(ActionConstants.EXITING_METHOD);
		return xmlString;
	}

	private String getFelCorrespondenceXML(String solID, String productCode,
			String eventCode, String requestId, String tiReferanceNo) {

		logger.info(ActionConstants.ENTERING_METHOD
				+ "getIFelCorrespondenceXML method");
		logger.info("Sol id==>" + solID.trim());
		logger.info(" productCode ==>" + productCode.trim());
		logger.info(" eventCode ==>" + eventCode.trim());
		String xmlString = "<?xml version=\"1.0\" standalone=\"yes\"?>"
				+ "<ServiceRequest xmlns:xsi='http://www.w3.org/2001/XMLSchema-instance' "
				+ "xmlns:m='urn:messages.service.ti.apps.tiplus2.misys.com' "
				+ " xmlns:c='urn:common.service.ti.apps.tiplus2.misys.com' "
				+ "xmlns:n='urn:custom.service.ti.apps.tiplus2.misys.com' "
				+ " xmlns='urn:control.services.tiplus2.misys.com'>"
				+ "<RequestHeader>" + "<Service>TI</Service>"
				+ "<Operation>TFATTDOC</Operation>" + "<Credentials>"
				+ "<Name>Name</Name>" + "<Password>Password</Password>"
				+ "<Certificate>Certificate</Certificate>"
				+ "<Digest>Digest</Digest>" + "</Credentials>"
				+ "<ReplyFormat>FULL</ReplyFormat>" + "<NoRepair>Y</NoRepair>"
				+ "<NoOverride>Y</NoOverride>"
				+ "<CorrelationId>CorrelationId</CorrelationId>"
				+ "<TransactionControl>NONE</TransactionControl>"
				+ "</RequestHeader>" + "<m:TFATTDOC>" + "<m:Context>"
				+ "<c:Branch>5860</c:Branch>" + "<c:Product>" + productCode
				+ "</c:Product>" + "<c:Event>" + eventCode + "</c:Event>"
				+ "<c:OurReference>" + tiReferanceNo.trim()
				+ "</c:OurReference>" + "<c:BehalfOfBranch>" + solID.trim()
				+ "</c:BehalfOfBranch>" + "</m:Context>" + "<m:ExtraData>"
				+ "<n:REQUSTID>" + requestId.trim() + "</n:REQUSTID>"
				+ "</m:ExtraData>" + "</m:TFATTDOC>" + "</ServiceRequest>";
		logger.info(ActionConstants.EXITING_METHOD
				+ "getFleCorrespondenceXML method");
		return xmlString;
	}

	// FEL ends

	// Expiry,closure,cancellation Changes Starts
	public String getIlcExpiryXML(String solID, String productCode,
			String eventCode, String requestId, String tiReferanceNo) {
		logger.info(ActionConstants.ENTERING_METHOD + "<<getIlcExpiryXML");
		/*
		 * String xmlString =
		 * "<?xml version=\"1.0\" standalone=\"yes\"?><ServiceRequest xmlns:xsi='http://www.w3.org/2001/XMLSchema-instance' xmlns:m='urn:messages.service.ti.apps.tiplus2.misys.com' xmlns:c='urn:common.service.ti.apps.tiplus2.misys.com' xmlns:n='urn:custom.service.ti.apps.tiplus2.misys.com' xmlns='urn:control.services.tiplus2.misys.com'>"
		 * + "	<RequestHeader>" + "	<Service>TI</Service>" +
		 * "	<Operation>TFEXPEVT</Operation>" + "	<Credentials>" +
		 * "	<Name>Name</Name>" + "	<Password>Password</Password>" +
		 * "	<Certificate>Certificate</Certificate>" +
		 * "	<Digest>Digest</Digest>" + "	</Credentials>" +
		 * "	<ReplyFormat>FULL</ReplyFormat>" + "	<NoRepair>Y</NoRepair>" +
		 * "	<NoOverride>Y</NoOverride>" +
		 * "	<CorrelationId>CorrelationId</CorrelationId>" +
		 * "	<TransactionControl>NONE</TransactionControl>" +
		 * "	</RequestHeader>" + "	<m:TFEXPEVT>" + "	<m:Context>" +
		 * "	<c:Product>" + productCode + "</c:Product>" + "	<c:Event>" +
		 * eventCode + "</c:Event>" + "	<c:OurReference>" + tiReferanceNo.trim()
		 * + "</c:OurReference>" + "	<c:BehalfOfBranch>" + solID.trim() +
		 * "</c:BehalfOfBranch>" + "	</m:Context>" + "<m:ExtraData>" +
		 * "<n:REQUSTID>" + requestId.trim() + "</n:REQUSTID>" +
		 * "</m:ExtraData>" + "	</m:TFEXPEVT>" + "</ServiceRequest>";
		 */
		String xmlString = "<?xml version=\"1.0\" standalone=\"yes\"?>"
				+ "<ServiceRequest xmlns:xsi='http://www.w3.org/2001/XMLSchema-instance' "
				+ "xmlns:m='urn:messages.service.ti.apps.tiplus2.misys.com' "
				+ " xmlns:c='urn:common.service.ti.apps.tiplus2.misys.com' "
				+ "xmlns:n='urn:custom.service.ti.apps.tiplus2.misys.com' "
				+ " xmlns='urn:control.services.tiplus2.misys.com'>"
				+ "<RequestHeader>" + "<Service>TI</Service>"
				+ "<Operation>TFATTDOC</Operation>" + "<Credentials>"
				+ "<Name>Name</Name>" + "<Password>Password</Password>"
				+ "<Certificate>Certificate</Certificate>"
				+ "<Digest>Digest</Digest>" + "</Credentials>"
				+ "<ReplyFormat>FULL</ReplyFormat>" + "<NoRepair>Y</NoRepair>"
				+ "<NoOverride>Y</NoOverride>"
				+ "<CorrelationId>CorrelationId</CorrelationId>"
				+ "<TransactionControl>NONE</TransactionControl>"
				+ "</RequestHeader>" + "<m:TFATTDOC>" + "<m:Context>"
				+ "<c:Product>" + productCode + "</c:Product>" + "<c:Event>"
				+ eventCode + "</c:Event>" + "<c:OurReference>"
				+ tiReferanceNo.trim() + "</c:OurReference>"
				+ "<c:BehalfOfBranch>" + solID.trim() + "</c:BehalfOfBranch>"
				+ "</m:Context>" + "<m:ExtraData>" + "<n:REQUSTID>"
				+ requestId.trim() + "</n:REQUSTID>" + "</m:ExtraData>"
				+ "</m:TFATTDOC>" + "</ServiceRequest>";

		logger.info("Final ILC Expiry Xml ==> " + xmlString);
		logger.info(ActionConstants.EXITING_METHOD + "<<getIlcExpiryXML");
		return xmlString;
	}

	public String getElcExpiryXML(String solID, String productCode,
			String eventCode, String requestId, String tiReferanceNo) {
		logger.info(ActionConstants.ENTERING_METHOD + "<<getElcExpiryXML");
		logger.info("Request Id==>" + tiReferanceNo.trim());
		/*
		 * String xmlString =
		 * "<?xml version=\"1.0\" standalone=\"yes\"?><ServiceRequest xmlns:xsi='http://www.w3.org/2001/XMLSchema-instance' xmlns:m='urn:messages.service.ti.apps.tiplus2.misys.com' xmlns:c='urn:common.service.ti.apps.tiplus2.misys.com' xmlns:n='urn:custom.service.ti.apps.tiplus2.misys.com' xmlns='urn:control.services.tiplus2.misys.com'>"
		 * + "	<RequestHeader>" + "	<Service>TI</Service>" +
		 * "	<Operation>TFEXPEVT</Operation>" + "	<Credentials>" +
		 * "	<Name>Name</Name>" + "	<Password>Password</Password>" +
		 * "	<Certificate>Certificate</Certificate>" +
		 * "	<Digest>Digest</Digest>" + "	</Credentials>" +
		 * "	<ReplyFormat>FULL</ReplyFormat>" + "	<NoRepair>Y</NoRepair>" +
		 * "	<NoOverride>Y</NoOverride>" +
		 * "	<CorrelationId>CorrelationId</CorrelationId>" +
		 * "	<TransactionControl>NONE</TransactionControl>" +
		 * "	</RequestHeader>" + "	<m:TFEXPEVT>" + "	<m:Context>" +
		 * "	<c:Product>" + productCode + "</c:Product>" + "	<c:Event>" +
		 * eventCode + "</c:Event>" + "	<c:OurReference>" + tiReferanceNo.trim()
		 * + "</c:OurReference>" + "	<c:BehalfOfBranch>" + solID.trim() +
		 * "</c:BehalfOfBranch>" + "	</m:Context>" + "<m:ExtraData>" +
		 * "<n:REQUSTID>" + requestId.trim() + "</n:REQUSTID>" +
		 * "</m:ExtraData>" + "	</m:TFEXPEVT>" + "</ServiceRequest>";
		 */
		String xmlString = "<?xml version=\"1.0\" standalone=\"yes\"?>"
				+ "<ServiceRequest xmlns:xsi='http://www.w3.org/2001/XMLSchema-instance' "
				+ "xmlns:m='urn:messages.service.ti.apps.tiplus2.misys.com' "
				+ " xmlns:c='urn:common.service.ti.apps.tiplus2.misys.com' "
				+ "xmlns:n='urn:custom.service.ti.apps.tiplus2.misys.com' "
				+ " xmlns='urn:control.services.tiplus2.misys.com'>"
				+ "<RequestHeader>" + "<Service>TI</Service>"
				+ "<Operation>TFATTDOC</Operation>" + "<Credentials>"
				+ "<Name>Name</Name>" + "<Password>Password</Password>"
				+ "<Certificate>Certificate</Certificate>"
				+ "<Digest>Digest</Digest>" + "</Credentials>"
				+ "<ReplyFormat>FULL</ReplyFormat>" + "<NoRepair>Y</NoRepair>"
				+ "<NoOverride>Y</NoOverride>"
				+ "<CorrelationId>CorrelationId</CorrelationId>"
				+ "<TransactionControl>NONE</TransactionControl>"
				+ "</RequestHeader>" + "<m:TFATTDOC>" + "<m:Context>"
				+ "<c:Product>" + productCode + "</c:Product>" + "<c:Event>"
				+ eventCode + "</c:Event>" + "<c:OurReference>"
				+ tiReferanceNo.trim() + "</c:OurReference>"
				+ "<c:BehalfOfBranch>" + solID.trim() + "</c:BehalfOfBranch>"
				+ "</m:Context>" + "<m:ExtraData>" + "<n:REQUSTID>"
				+ requestId.trim() + "</n:REQUSTID>" + "</m:ExtraData>"
				+ "</m:TFATTDOC>" + "</ServiceRequest>";
		logger.info("Final ELC Expiry xml==> " + xmlString);
		logger.info(ActionConstants.EXITING_METHOD + "<<getElcExpiryXML");
		return xmlString;
	}

	public String getIgtCancelXML(String solID, String productCode,
			String eventCode, String requestId, String tiReferanceNo,
			String customerCif) {
		logger.info(ActionConstants.ENTERING_METHOD + "<<getIgtCancelXML");
		/*
		 * String xmlString =
		 * "<?xml version=\"1.0\" standalone=\"yes\"?><ServiceRequest xmlns:xsi='http://www.w3.org/2001/XMLSchema-instance' xmlns:m='urn:messages.service.ti.apps.tiplus2.misys.com' xmlns:c='urn:common.service.ti.apps.tiplus2.misys.com' xmlns:n='urn:custom.service.ti.apps.tiplus2.misys.com' xmlns='urn:control.services.tiplus2.misys.com'>"
		 * + "	<RequestHeader>" + "	<Service>TI</Service>" +
		 * "	<Operation>TFIGTCAN</Operation>" + "	<Credentials>" +
		 * "	<Name>Name</Name>" + "	<Password>Password</Password>" +
		 * "	<Certificate>Certificate</Certificate>" +
		 * "	<Digest>Digest</Digest>" + "	</Credentials>" +
		 * "	<ReplyFormat>FULL</ReplyFormat>" + "	<NoRepair>Y</NoRepair>" +
		 * "	<NoOverride>Y</NoOverride>" +
		 * "	<CorrelationId>CorrelationId</CorrelationId>" +
		 * "	<TransactionControl>NONE</TransactionControl>" +
		 * "	</RequestHeader>" + "	<m:TFIGTCAN>" + "	<m:Context>" +
		 * "	<c:Product>" + productCode + "</c:Product>" + "	<c:Event>" +
		 * eventCode + "</c:Event>" + "	<c:OurReference>" + tiReferanceNo.trim()
		 * + "</c:OurReference>" + "	<c:BehalfOfBranch>" + solID.trim() +
		 * "</c:BehalfOfBranch>" + "	</m:Context>" + " <m:Sender>" +
		 * "	<c:Customer>" + customerCif.trim() + "</c:Customer>" +
		 * "</m:Sender>" + "<m:ExtraData>" + "<n:REQUSTID>" + requestId.trim() +
		 * "</n:REQUSTID>" + "</m:ExtraData>" + "</m:TFIGTCAN>" +
		 * "</ServiceRequest>";
		 */
		String xmlString = "<?xml version=\"1.0\" standalone=\"yes\"?>"
				+ "<ServiceRequest xmlns:xsi='http://www.w3.org/2001/XMLSchema-instance' "
				+ "xmlns:m='urn:messages.service.ti.apps.tiplus2.misys.com' "
				+ " xmlns:c='urn:common.service.ti.apps.tiplus2.misys.com' "
				+ "xmlns:n='urn:custom.service.ti.apps.tiplus2.misys.com' "
				+ " xmlns='urn:control.services.tiplus2.misys.com'>"
				+ "<RequestHeader>" + "<Service>TI</Service>"
				+ "<Operation>TFATTDOC</Operation>" + "<Credentials>"
				+ "<Name>Name</Name>" + "<Password>Password</Password>"
				+ "<Certificate>Certificate</Certificate>"
				+ "<Digest>Digest</Digest>" + "</Credentials>"
				+ "<ReplyFormat>FULL</ReplyFormat>" + "<NoRepair>Y</NoRepair>"
				+ "<NoOverride>Y</NoOverride>"
				+ "<CorrelationId>CorrelationId</CorrelationId>"
				+ "<TransactionControl>NONE</TransactionControl>"
				+ "</RequestHeader>" + "<m:TFATTDOC>" + "<m:Context>"
				+ "<c:Product>" + productCode + "</c:Product>" + "<c:Event>"
				+ eventCode + "</c:Event>" + "<c:OurReference>"
				+ tiReferanceNo.trim() + "</c:OurReference>"
				+ "<c:BehalfOfBranch>" + solID.trim() + "</c:BehalfOfBranch>"
				+ "</m:Context>" + "<m:ExtraData>" + "<n:REQUSTID>"
				+ requestId.trim() + "</n:REQUSTID>" + "</m:ExtraData>"
				+ "</m:TFATTDOC>" + "</ServiceRequest>";

		logger.info("Final IGT Cancel Xml==> " + xmlString);
		logger.info(ActionConstants.EXITING_METHOD + "<<getIgtCancelXML");
		return xmlString;
	}

	private String getIgtClosureXML(String requestId, String solID,
			String productCode, String eventCode, String tiReferanceNo) {

		logger.info(ActionConstants.ENTERING_METHOD + "<<getIgtClosureXML");
		String xmlString = "<?xml version=\"1.0\" standalone=\"yes\"?>"
				+ "<ServiceRequest xmlns:xsi='http://www.w3.org/2001/XMLSchema-instance' "
				+ "xmlns:m='urn:messages.service.ti.apps.tiplus2.misys.com' "
				+ " xmlns:c='urn:common.service.ti.apps.tiplus2.misys.com' "
				+ "xmlns:n='urn:custom.service.ti.apps.tiplus2.misys.com' "
				+ " xmlns='urn:control.services.tiplus2.misys.com'>"
				+ "<RequestHeader>" + "<Service>TI</Service>"
				+ "<Operation>TFATTDOC</Operation>" + "<Credentials>"
				+ "<Name>Name</Name>" + "<Password>Password</Password>"
				+ "<Certificate>Certificate</Certificate>"
				+ "<Digest>Digest</Digest>" + "</Credentials>"
				+ "<ReplyFormat>FULL</ReplyFormat>" + "<NoRepair>Y</NoRepair>"
				+ "<NoOverride>Y</NoOverride>"
				+ "<CorrelationId>CorrelationId</CorrelationId>"
				+ "<TransactionControl>NONE</TransactionControl>"
				+ "</RequestHeader>" + "<m:TFATTDOC>" + "<m:Context>"
				+ "<c:Product>" + productCode + "</c:Product>" + "<c:Event>"
				+ eventCode + "</c:Event>" + "<c:OurReference>"
				+ tiReferanceNo.trim() + "</c:OurReference>"
				+ "<c:BehalfOfBranch>" + solID.trim() + "</c:BehalfOfBranch>"
				+ "</m:Context>" + "<m:ExtraData>" + "<n:REQUSTID>"
				+ requestId.trim() + "</n:REQUSTID>" + "</m:ExtraData>"
				+ "</m:TFATTDOC>" + "</ServiceRequest>";

		logger.info("Final IGT closure Xml==> " + xmlString);
		logger.info(ActionConstants.EXITING_METHOD + "<<getIgtClosureXML");
		return xmlString;
	}

	// Expiry,closure,cancellation Changes Ends

	private String getIsbClosureXML(String requestId, String solID,
			String productCode, String eventCode, String tiReferanceNo) {

		logger.info(ActionConstants.ENTERING_METHOD + "<<getISBClosureXML");
		String xmlString = "<?xml version=\"1.0\" standalone=\"yes\"?>"
				+ "<ServiceRequest xmlns:xsi='http://www.w3.org/2001/XMLSchema-instance' "
				+ "xmlns:m='urn:messages.service.ti.apps.tiplus2.misys.com' "
				+ " xmlns:c='urn:common.service.ti.apps.tiplus2.misys.com' "
				+ "xmlns:n='urn:custom.service.ti.apps.tiplus2.misys.com' "
				+ " xmlns='urn:control.services.tiplus2.misys.com'>"
				+ "<RequestHeader>" + "<Service>TI</Service>"
				+ "<Operation>TFATTDOC</Operation>" + "<Credentials>"
				+ "<Name>Name</Name>" + "<Password>Password</Password>"
				+ "<Certificate>Certificate</Certificate>"
				+ "<Digest>Digest</Digest>" + "</Credentials>"
				+ "<ReplyFormat>FULL</ReplyFormat>" + "<NoRepair>Y</NoRepair>"
				+ "<NoOverride>Y</NoOverride>"
				+ "<CorrelationId>CorrelationId</CorrelationId>"
				+ "<TransactionControl>NONE</TransactionControl>"
				+ "</RequestHeader>" + "<m:TFATTDOC>" + "<m:Context>"
				+ "<c:Product>" + productCode + "</c:Product>" + "<c:Event>"
				+ eventCode + "</c:Event>" + "<c:OurReference>"
				+ tiReferanceNo.trim() + "</c:OurReference>"
				+ "<c:BehalfOfBranch>" + solID.trim() + "</c:BehalfOfBranch>"
				+ "</m:Context>" + "<m:ExtraData>" + "<n:REQUSTID>"
				+ requestId.trim() + "</n:REQUSTID>" + "</m:ExtraData>"
				+ "</m:TFATTDOC>" + "</ServiceRequest>";

		logger.info("Final ISB closure Xml==> " + xmlString);
		logger.info(ActionConstants.EXITING_METHOD + "<<getISbClosureXML");
		return xmlString;
	}

	private String getIsbCancelXML(String requestId, String solID,
			String productCode, String eventCode, String tiReferanceNo) {
		logger.info(ActionConstants.ENTERING_METHOD + "<<getISBCancelXML");
		String xmlString = "<?xml version=\"1.0\" standalone=\"yes\"?>"
				+ "<ServiceRequest xmlns:xsi='http://www.w3.org/2001/XMLSchema-instance' "
				+ "xmlns:m='urn:messages.service.ti.apps.tiplus2.misys.com' "
				+ " xmlns:c='urn:common.service.ti.apps.tiplus2.misys.com' "
				+ "xmlns:n='urn:custom.service.ti.apps.tiplus2.misys.com' "
				+ " xmlns='urn:control.services.tiplus2.misys.com'>"
				+ "<RequestHeader>" + "<Service>TI</Service>"
				+ "<Operation>TFATTDOC</Operation>" + "<Credentials>"
				+ "<Name>Name</Name>" + "<Password>Password</Password>"
				+ "<Certificate>Certificate</Certificate>"
				+ "<Digest>Digest</Digest>" + "</Credentials>"
				+ "<ReplyFormat>FULL</ReplyFormat>" + "<NoRepair>Y</NoRepair>"
				+ "<NoOverride>Y</NoOverride>"
				+ "<CorrelationId>CorrelationId</CorrelationId>"
				+ "<TransactionControl>NONE</TransactionControl>"
				+ "</RequestHeader>" + "<m:TFATTDOC>" + "<m:Context>"
				+ "<c:Product>" + productCode + "</c:Product>" + "<c:Event>"
				+ eventCode + "</c:Event>" + "<c:OurReference>"
				+ tiReferanceNo.trim() + "</c:OurReference>"
				+ "<c:BehalfOfBranch>" + solID.trim() + "</c:BehalfOfBranch>"
				+ "</m:Context>" + "<m:ExtraData>" + "<n:REQUSTID>"
				+ requestId.trim() + "</n:REQUSTID>" + "</m:ExtraData>"
				+ "</m:TFATTDOC>" + "</ServiceRequest>";

		logger.info("Final ISB Cancel Xml==> " + xmlString);
		logger.info(ActionConstants.EXITING_METHOD + "<<getISbCancelXML");
		return xmlString;
	}


	private String getIgtExpireXML(String requestId, String solID, String productCode,
	String eventCode, String tiReferanceNo) {

		String xmlString = "<?xml version=\"1.0\" standalone=\"yes\"?>"
		+ "<ServiceRequest xmlns:xsi='http://www.w3.org/2001/XMLSchema-instance' "
		+ "xmlns:m='urn:messages.service.ti.apps.tiplus2.misys.com' "
		+ " xmlns:c='urn:common.service.ti.apps.tiplus2.misys.com' "
		+ "xmlns:n='urn:custom.service.ti.apps.tiplus2.misys.com' "
		+ " xmlns='urn:control.services.tiplus2.misys.com'>"
		+ "<RequestHeader>" + "<Service>TI</Service>"
		+ "<Operation>TFATTDOC</Operation>" + "<Credentials>"
		+ "<Name>Name</Name>" + "<Password>Password</Password>"
		+ "<Certificate>Certificate</Certificate>"
		+ "<Digest>Digest</Digest>" + "</Credentials>"
		+ "<ReplyFormat>FULL</ReplyFormat>" + "<NoRepair>Y</NoRepair>"
		+ "<NoOverride>Y</NoOverride>"
		+ "<CorrelationId>CorrelationId</CorrelationId>"
		+ "<TransactionControl>NONE</TransactionControl>"
		+ "</RequestHeader>" + "<m:TFATTDOC>" + "<m:Context>"
		+ "<c:Product>" + productCode + "</c:Product>" + "<c:Event>"
		+ eventCode + "</c:Event>" + "<c:OurReference>"
		+ tiReferanceNo.trim() + "</c:OurReference>"
		+ "<c:BehalfOfBranch>" + solID.trim() + "</c:BehalfOfBranch>"
		+ "</m:Context>" + "<m:ExtraData>" + "<n:REQUSTID>"
		+ requestId.trim() + "</n:REQUSTID>" + "</m:ExtraData>"
		+ "</m:TFATTDOC>" + "</ServiceRequest>";

		logger.info("Final ILC Expiry Xml ==> " + xmlString);
		logger.info(ActionConstants.EXITING_METHOD + "<<getIlcExpiryXML");
		return xmlString;
}
	
}