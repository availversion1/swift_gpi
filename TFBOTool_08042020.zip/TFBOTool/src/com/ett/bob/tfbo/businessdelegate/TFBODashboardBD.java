package com.ett.bob.tfbo.businessdelegate;

import org.apache.log4j.Logger;

import com.ett.bob.tfbo.dao.TFBODashboardDAO;
import com.ett.bob.tfbo.model.TFBODashboardVO;
import com.ett.bob.tfbo.util.ActionConstants;

public class TFBODashboardBD {
	private static Logger logger = Logger.getLogger(TFBODashboardBD.class
			.getName());

	public void setDashboard(TFBODashboardVO branchDB) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		TFBODashboardDAO aTFBODashboardDAO = new TFBODashboardDAO();
		try {
			aTFBODashboardDAO.setDashboardAtBranch(branchDB);
			aTFBODashboardDAO.setDashboardAtFBO(branchDB);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		logger.info(ActionConstants.EXITING_METHOD);
	}

}
