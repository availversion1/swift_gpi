package com.ett.bob.tfbo.businessdelegate;

import java.io.File;
import java.io.FileInputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.ett.bob.tfbo.commonutil.CSRFTokenServlet;
import com.ett.bob.tfbo.commonutil.CommonMethods;
import com.ett.bob.tfbo.commonutil.LDAPAuthenticationProcess;
import com.ett.bob.tfbo.dao.TFBOHomeDAO;
import com.ett.bob.tfbo.dao.TFBOUploadDAO;
import com.ett.bob.tfbo.dbutil.DBHelper;
import com.ett.bob.tfbo.model.AlertMessagesVO;
import com.ett.bob.tfbo.model.CustomerProfileManageVO;
import com.ett.bob.tfbo.model.ProfileManagementVO;
import com.ett.bob.tfbo.model.ReportVO;
import com.ett.bob.tfbo.model.TFBOChecklistVO;
import com.ett.bob.tfbo.model.TFBOReminderVO;
import com.ett.bob.tfbo.model.TFBOTransVO;
import com.ett.bob.tfbo.model.UserTransactionVO;
import com.ett.bob.tfbo.util.ActionConstants;
import com.ett.bob.tfbo.workflowutil.TFBOWorkflow;
import com.opensymphony.xwork2.ActionContext;

public class TFBOHomeActionBD {
	private static Logger logger = Logger.getLogger(TFBOHomeActionBD.class
			.getName());

	public byte[] readBytesFromFile(String filePath) throws Exception {
		FileInputStream fileInputStream = null;
		byte[] bytesArray = null;
		try {
			File file = new File(filePath);
			bytesArray = new byte[(int) file.length()];
			// read file into bytes[]
			fileInputStream = new FileInputStream(file);
			fileInputStream.read(bytesArray);

		} finally {
			if (fileInputStream != null) {
				try {
					fileInputStream.close();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}

		}

		return bytesArray;

	}

	public String openThisTransaction(UserTransactionVO userVo)
			throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		TFBOHomeDAO aTFBOHomeDAO = new TFBOHomeDAO();
		String stepName = "";
		String returnPage = "";
		String productName = "";
		String eventName = "";
		try {
			logger.info("requestId-->" + userVo.requestIdGridValue);
			userVo.setRequestId(userVo.requestIdGridValue);
			userVo.setTiReferanceNo(userVo.tiReferanceNoGridValue);
			stepName = getCurrentStep(userVo.requestId);
			productName = getProductName(userVo.requestId);
			eventName = getEventName(userVo.requestId);
			userVo.setProductName(productName);
			userVo.setEventName(eventName);
			setValuesInJsp(userVo);
			returnPage = getReturnPage(userVo, userVo.getProductCode(),
					userVo.getEventCode(), stepName);
			if (!returnPage.equals("viewer")) {
				// if (userVo.getProductCodeGridValue().equalsIgnoreCase("ILC")
				// && userVo.getEventCodeGridValue().equalsIgnoreCase(
				// "ISI")) {
				if (!aTFBOHomeDAO.selectTFBOTranLockStatus(userVo,
						ActionConstants.SELECTTRANSLOCK)) {
					aTFBOHomeDAO.updateTFBOTranLockStatus(userVo,
							ActionConstants.LOCKTRUE);
//					userVo.setTransLockFlag(false);
				} else {
//					userVo.setTransLockFlag(true);
					if(aTFBOHomeDAO
							.selectTFBOTranLockStatus(userVo,
									ActionConstants.SELECTTRANSLOCK,
									userVo.getSessionUserName())){
						returnPage = "TransLockedUser";
					}
					
				}
				// }
			}

			logger.info("returnPage >>-->" + returnPage);
			System.out.println("returnPage >>-->" + returnPage);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		logger.info("returnPage-->" + userVo.getReturnPage());
		return returnPage;
	}

	public Boolean isValidSession(String formToken) {
		logger.info(ActionConstants.ENTERING_METHOD);
		TFBOHomeDAO aTFBOHomeDAO = new TFBOHomeDAO();
		CSRFTokenServlet aCSRFTokenServlet = new CSRFTokenServlet();
		CommonMethods aCommonMethods = new CommonMethods();
		if (!aCSRFTokenServlet.Csrf(formToken)) {
			return false;
		}
		String userName = aTFBOHomeDAO.getSessionUser();
		if (!aCommonMethods.isValueAvailable(userName)) {
			return false;
		}
		logger.info(ActionConstants.ENTERING_METHOD);
		return true;
	}

	public UserTransactionVO isUserMaker(UserTransactionVO userVo) {
		logger.info(ActionConstants.ENTERING_METHOD);
		TFBOHomeDAO aTFBOHomeDAO = new TFBOHomeDAO();
		CommonMethods aCommonMethods = new CommonMethods();
		String userName = aTFBOHomeDAO.getSessionUser();
		userVo.setUserFlag("NA");
		if (aCommonMethods.isValueAvailable(userName)) {
			if (aTFBOHomeDAO.isUserMaker(userName)) {
				userVo.setUserFlag("MAKER");
				logger.info("User Flag-->" + userVo.getUserFlag());
				logger.info(ActionConstants.ENTERING_METHOD);
				return userVo;
			}
		} else {
			userVo.setReturnPage("invalidSession");
		}
		logger.info("User Flag-->" + userVo.getUserFlag());
		logger.info(ActionConstants.ENTERING_METHOD);
		return userVo;
	}

	public UserTransactionVO isUserFbo(UserTransactionVO userVo)
			throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		TFBOHomeDAO aTFBOHomeDAO = new TFBOHomeDAO();
		CommonMethods aCommonMethods = new CommonMethods();
		userVo.setUserFlag("NA");
		if (aCommonMethods.isValueAvailable(userVo.getSessionUserName())) {
			if (aTFBOHomeDAO.isUserFbo(userVo)) {
				userVo.setUserFlag("FBO");
				logger.info("User Flag-->" + userVo.getUserFlag());
				logger.info(ActionConstants.ENTERING_METHOD);
				return userVo;
			}
		} else {
			userVo.setReturnPage("invalidSession");
		}
		logger.info("User Flag-->" + userVo.getUserFlag());
		logger.info(ActionConstants.ENTERING_METHOD);
		return userVo;
	}

	// Changed by onsite team 26122019 starts
	/*
	 * public UserTransactionVO getTransDetails(UserTransactionVO userVo, String
	 * tiReferenceNo) throws Exception {
	 * logger.info(ActionConstants.ENTERING_METHOD); DBHelper aDBHelper = new
	 * DBHelper(); CommonMethods aCommonMethods = new CommonMethods();
	 * List<AlertMessagesVO> errorDetailList = new
	 * LinkedList<AlertMessagesVO>(); TFBOHomeDAO aTFBOHomeDAO = new
	 * TFBOHomeDAO(); try { if (!aDBHelper.isValueAvailableInDB(tiReferenceNo,
	 * ActionConstants.GETVALIDTIREFNO_QUERY)) { errorDetailList =
	 * aCommonMethods.setErrorInList( ActionConstants.ERRORCODE011,
	 * errorDetailList); userVo.setErrorDetailsList(errorDetailList);
	 * logger.info("Error for User validation-->" +
	 * userVo.getErrorDetailsList().size());
	 * logger.info(ActionConstants.EXITING_METHOD + ">>getEventList");
	 * userVo.setAmount(""); userVo.setCustomeCif("");
	 * userVo.setCustomeName(""); userVo.setSolID(""); userVo.setCurrency("");
	 * userVo.setLcType(""); userVo.setSubProductCode("");
	 * userVo.setCurrency(""); userVo.setCustomeCif("");
	 * userVo.setCustomeName(""); userVo.setSolID(""); userVo.setLcType("");
	 * userVo.setSubProductCode(""); userVo.setDevolvementAmount("");
	 * userVo.billReferenceList.clear(); userVo.setTiReferanceNo(""); // ODC-PAY
	 * userVo.setDirect(""); userVo.setMtReceived("");
	 * userVo.setPartPayment("");
	 * 
	 * userVo.setPreshipAccSetteld(""); userVo.setDocumentDispatch(""); //
	 * FOC-CRE userVo.setUsancePeriod(""); // FOC-ADJ
	 * userVo.setFinanceAmount("");
	 * 
	 * 
	 * 
	 * userVo.setConBillRef(""); userVo.setAcceptBillAmt("");
	 * userVo.setBgRefNo(""); userVo.setBillUsancePeriod("");
	 * userVo.setBillrefno(""); userVo.setBillReferenceNo("");
	 * userVo.setRateTaken(""); return userVo; }
	 * aTFBOHomeDAO.getTransDetailsFromDB(userVo, tiReferenceNo); } catch
	 * (Exception e) { e.printStackTrace(); throw e; }
	 * logger.info(ActionConstants.ENTERING_METHOD); return userVo; }
	 */
	public UserTransactionVO getTransDetails(UserTransactionVO userVo,
			String tiReferenceNo) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		DBHelper aDBHelper = new DBHelper();
		CommonMethods aCommonMethods = new CommonMethods();
		List<AlertMessagesVO> errorDetailList = new LinkedList<AlertMessagesVO>();
		TFBOHomeDAO aTFBOHomeDAO = new TFBOHomeDAO();
		try {
			if (!aDBHelper.isValueAvailableInDB(tiReferenceNo.trim(),
					ActionConstants.GETVALIDTIREFNO_QUERY)) {
				errorDetailList = aCommonMethods.setErrorInList(
						ActionConstants.ERRORCODE011, errorDetailList);
				userVo.setErrorDetailsList(errorDetailList);
				logger.info("Error for User validation-->"
						+ userVo.getErrorDetailsList().size());
				System.out.println("Error for User validation-->"
						+ userVo.getErrorDetailsList().size());
				logger.info(ActionConstants.EXITING_METHOD + ">>getEventList");
				userVo.setAmount("");
				userVo.setCustomeCif("");
				userVo.setCustomeName("");
				userVo.setSolID("");
				userVo.setCurrency("");
				userVo.setLcType("");
				userVo.setSubProductCode("");
				userVo.setCurrency("");
				userVo.setCustomeCif("");
				userVo.setCustomeName("");
				userVo.setSolID("");
				userVo.setLcType("");
				userVo.setSubProductCode("");
				userVo.setDevolvementAmount("");
				if (userVo.billReferenceList != null)
					userVo.billReferenceList.clear();// CHANGED BY CHANDRU
				userVo.setTiReferanceNo("");
				// ODC-PAY
				userVo.setDirect("");
				userVo.setMtReceived("");
				userVo.setPartPayment("");

				userVo.setPreshipAccSetteld("");
				userVo.setDocumentDispatch("");
				// FOC-CRE
				userVo.setUsancePeriod("");
				// FOC-ADJ
				userVo.setFinanceAmount("");
				userVo.setConBillRef("");
				userVo.setAcceptBillAmt("");
				userVo.setBgRefNo("");
				userVo.setBillUsancePeriod("");
				userVo.setBillrefno("");
				userVo.setBillReferenceNo("");
				userVo.setRateTaken("");
				userVo.setTenure("");
				userVo.setGuarnteeAmtPrevInv("");
				return userVo;
			}
			aTFBOHomeDAO.getTransDetailsFromDB(userVo, tiReferenceNo);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		logger.info(ActionConstants.ENTERING_METHOD);
		return userVo;
	}

	// Changed by onsite team 26122019 ends
	public String getCustomerName(String customerCif) {
		logger.info(ActionConstants.ENTERING_METHOD);
		String customerName = "";
		TFBOHomeDAO aTFBOHomeDAO = new TFBOHomeDAO();
		try {
			customerName = aTFBOHomeDAO.getCustomerName(customerCif);
		} catch (Exception e) {
			e.printStackTrace();
			logger.info(ActionConstants.ENTERING_METHOD);
			return customerName;
		}
		logger.info(ActionConstants.ENTERING_METHOD);
		return customerName;
	}

	public Boolean isValidScrutinizerVerify(UserTransactionVO userVo)
			throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		TFBOHomeDAO aTFBOHomeDAO = new TFBOHomeDAO();
		if (aTFBOHomeDAO.isValidScrutinizerVerifyRequest(userVo)) {
			logger.info(ActionConstants.ENTERING_METHOD);
			return true;
		}
		logger.info(ActionConstants.ENTERING_METHOD);
		return false;
	}

	// Added on 21-12-2019 after ODC release starts
	public void updateTFBOScrutinizerDetails(UserTransactionVO userVo)
			throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		TFBOHomeDAO aTFBOHomeDAO = new TFBOHomeDAO();
		aTFBOHomeDAO.updateTFBOScrutinizerDetails(userVo);
		logger.info(ActionConstants.ENTERING_METHOD);
	}

	// Added on 21-12-2019 after ODC release starts
	public Boolean isValidTransactionCreation(UserTransactionVO userVo)
			throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		TFBOHomeDAO aTFBOHomeDAO = new TFBOHomeDAO();
		if (aTFBOHomeDAO.isValidTransactionCreationRequest(userVo)) {
			logger.info(ActionConstants.ENTERING_METHOD);
			return true;
		}
		logger.info(ActionConstants.ENTERING_METHOD);
		return false;
	}
	
	public Boolean isValidUserTransaction(UserTransactionVO userVo)
			throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		TFBOHomeDAO aTFBOHomeDAO = new TFBOHomeDAO();
		if (aTFBOHomeDAO.isValidUserTransaction(userVo)) {
			logger.info(ActionConstants.ENTERING_METHOD);
			return true;
		}
		logger.info(ActionConstants.ENTERING_METHOD);
		return false;
	}

	public Boolean isChecklistFilled(UserTransactionVO userVo,
			List<TFBOChecklistVO> aTFBOChecklist) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		TFBOHomeDAO aTFBOHomeDAO = new TFBOHomeDAO();
		List<AlertMessagesVO> errorDetailList = new LinkedList<AlertMessagesVO>();
		errorDetailList = aTFBOHomeDAO.isChecklistFilled(userVo,
				aTFBOChecklist, errorDetailList);
		userVo.setErrorDetailsList(errorDetailList);
		if (!(userVo.getErrorDetailsList().size() == 0)) {
			logger.info(ActionConstants.ENTERING_METHOD);
			return false;
		}
		logger.info(ActionConstants.ENTERING_METHOD);
		return true;
	}

	public Boolean isValidTransactionRequest(UserTransactionVO userVo)
			throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		TFBOHomeDAO aTFBOHomeDAO = new TFBOHomeDAO();
		if (aTFBOHomeDAO.isValidTransactionRequest(userVo)) {
			logger.info(ActionConstants.ENTERING_METHOD);
			return true;
		}
		logger.info(ActionConstants.ENTERING_METHOD);
		return false;
	}

	public List<TFBOTransVO> getTFBOTransList(UserTransactionVO userVo)
			throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		TFBOHomeDAO aTFBOHomeDAO = new TFBOHomeDAO();
		CommonMethods aCommonMethods = new CommonMethods();
		List<TFBOTransVO> transactionList = null;
		try {
			if (!aCommonMethods.isValueAvailable(userVo.getIsTiTransFlag()))
				userVo.setIsTiTransFlag("N");
			// // ADDED BY CHANDRU
			// userVo.setProductCodeFilter(aTFBOHomeDAO.getRequestProdFromDB(userVo.getRequestIdFilter()));
			// // ADDED BY CHANDRU
			aTFBOHomeDAO.updateTIReferenceInTool(userVo);
			logger.info("Product List-->" + userVo.getProductFilter());
			logger.info("Event List-->" + userVo.getEventFilter());
			if (aCommonMethods.isValueAvailable(userVo.getProductFilter())) {
				userVo.setProductCodeFilter(getProductCode(userVo
						.getProductFilter()));
				if (userVo.getProductCodeFilter() != null) {
					userVo.setEventCodeFilter(getEventCode(
							userVo.getProductCodeFilter(),
							userVo.getEventFilter()));
				}
			}
			// CHANGES BY CHANDRU 10012020 STARTS
			/* transactionList = aTFBOHomeDAO.getTFBOTransListFromDB(userVo); */
			/*transactionList = aTFBOHomeDAO.getTFBOTransListFromDBFilter(userVo);*/
			transactionList = aTFBOHomeDAO.getTFBOTransListFromDBFilterForFilter(userVo);
			
			// CHANGES BY CHANDRU 10012020 ENDS
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		logger.info(ActionConstants.ENTERING_METHOD);
		return transactionList;
	}

	public Boolean isValidTransaction(String requestId, String stepName)
			throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		TFBOHomeDAO aTFBOHomeDAO = new TFBOHomeDAO();
		TFBOWorkflow aTFBOWorkflow = new TFBOWorkflow();
		String stepStatus = aTFBOHomeDAO.getCurrentStatus(requestId);
		aTFBOWorkflow.getAssignStatus(stepName);
		if (stepName.trim().equals(ActionConstants.INPUT)) {
			if (aTFBOWorkflow.getAssignStatus(stepName).trim()
					.equals(stepStatus)) {
				logger.info(ActionConstants.ENTERING_METHOD);
				return true;
			}
		}
		if (stepName.trim().equals(ActionConstants.REVIEW)) {
			if (aTFBOWorkflow.getAssignStatus(stepName).trim()
					.equals(stepStatus)) {
				logger.info(ActionConstants.ENTERING_METHOD);
				return true;
			}
		}
		if (stepName.trim().equals(ActionConstants.AUTHORIZE)) {
			if (aTFBOWorkflow.getAssignStatus(stepName).trim()
					.equals(stepStatus)) {
				logger.info(ActionConstants.ENTERING_METHOD);
				return true;
			}
		}
		// pandi for fbo maker  submit starts here
		if (stepName.trim().equals(ActionConstants.FBOMAKER_1)) {
			if (aTFBOWorkflow.getAssignStatus(stepName).trim()
					.equals(stepStatus)) {
				logger.info(ActionConstants.ENTERING_METHOD);
				return true;
			}
		}
		if (stepName.trim().equals(ActionConstants.FBOCHECKER_1)) {
			if (aTFBOWorkflow.getAssignStatus(stepName).trim()
					.equals(stepStatus)) {
				logger.info(ActionConstants.ENTERING_METHOD);
				return true;
			}
		}
		if (stepName.trim().equals(ActionConstants.RELEASE)) {
			if (aTFBOWorkflow.getAssignStatus(stepName).trim()
					.equals(stepStatus)) {
				logger.info(ActionConstants.ENTERING_METHOD);
				return true;
			}
		}
		// pandi for fbo maker  submit ends here
		logger.info(ActionConstants.ENTERING_METHOD);
		return false;
	}

	public UserTransactionVO setValuesInJsp(UserTransactionVO userVo)
			throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		TFBOHomeDAO aTFBOHomeDAO = new TFBOHomeDAO();
		TFBOUploadDAO aTFBOUploadDAO = new TFBOUploadDAO();
		try {
			aTFBOHomeDAO.getTransactionValues(userVo);
			aTFBOHomeDAO.setTransactionValuesInVO(userVo);
			aTFBOUploadDAO.getDocumentList(userVo);
			aTFBOHomeDAO.getMakerChecklist(userVo);
			aTFBOHomeDAO.getCheckerChecklist(userVo);
			aTFBOHomeDAO.getUserCommentList(userVo);
			aTFBOHomeDAO.getCustomerCommentList(userVo);
			aTFBOHomeDAO.getMiscellanousComments(userVo);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		logger.info(ActionConstants.ENTERING_METHOD);
		return userVo;
	}

	public List<String> getProductList() throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		TFBOHomeDAO aTFBOHomeDAO = new TFBOHomeDAO();
		List<String> productList = null;
		productList = aTFBOHomeDAO.getProductListFromDB();
		logger.info(ActionConstants.ENTERING_METHOD);
		return productList;
	}

	public List<String> getEventList(String productCode) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		TFBOHomeDAO aTFBOHomeDAO = new TFBOHomeDAO();
		List<String> eventDetailsList = null;
		try {
			eventDetailsList = aTFBOHomeDAO.getEventListFromDB(productCode);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		logger.info(ActionConstants.ENTERING_METHOD);
		return eventDetailsList;
	}

	public void abortTransaction(UserTransactionVO userVo, String newStatus,
			String stepName) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		TFBOHomeDAO aTFBOHomeDAO = new TFBOHomeDAO();
		CommonMethods aCommonMethods = new CommonMethods();
		aTFBOHomeDAO.insertIntoTFBOStepHist(stepName, newStatus,
				userVo.getRequestId(), userVo.getSessionUserName());
		aTFBOHomeDAO.updateTFBOTransStatus(stepName, newStatus,
				userVo.getRequestId());
		if (aCommonMethods.isValueAvailable(userVo.userComment)) {
			aTFBOHomeDAO.setTFBOUserComments(userVo.requestId,
					userVo.userComment, stepName, userVo.sessionUserName);
		}
		// ADDED BY CHANDRU
		aTFBOHomeDAO
				.updateTFBOTranLockStatus(userVo, ActionConstants.LOCKFALSE);
		// ADDED BY CHANDRU

		logger.info(ActionConstants.ENTERING_METHOD);
	}

	public UserTransactionVO scrutinizerVerifyTransaction(
			UserTransactionVO userVo, String newStatus, String newStepName,
			String stepName) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		TFBOHomeDAO aTFBOHomeDAO = new TFBOHomeDAO();
		CommonMethods aCommonMethods = new CommonMethods();
		DBHelper aDBHelper = new DBHelper();
		TFBOWorkflow aTFBOWorkflow = new TFBOWorkflow();
		String assignStatus = "";
		String newAssignStatus = "";
		String tiReferanceNumber = "";
		newAssignStatus = aTFBOWorkflow.getAssignStatus(newStepName);
		assignStatus = aTFBOWorkflow.getAssignStatus(stepName);
		aTFBOHomeDAO.insertIntoTFBOStepHist(stepName, newStatus,
				userVo.getRequestId(), userVo.getSessionUserName());
		aTFBOHomeDAO.updateTFBOTransStatus(stepName, newStatus,
				userVo.getRequestId());
		aTFBOHomeDAO.updateTFBOEventTableInScrutinizer(userVo);
		aTFBOHomeDAO.updateTFBOTransQueried("0", userVo.getRequestId());
		if (aCommonMethods.isValueAvailable(userVo.userComment)) {
			aTFBOHomeDAO.setTFBOUserComments(userVo.requestId,
					userVo.userComment, stepName, userVo.sessionUserName);
		}
		if (userVo.getFboScrutinizerCheckList() != null)
			aTFBOHomeDAO.updateTFBOTransChecklist(
					userVo.getFboScrutinizerCheckList(), userVo.getRequestId());
		if (Integer.parseInt(aDBHelper.getValueFromDB(userVo.getRequestId(),
				ActionConstants.GETTFBOTRANSRELEASED_QUERY).trim()) == 0) {
			logger.info("Currency in scrutinizerVerifyTransaction-->"
					+ userVo.getCurrency());
			if (!aTFBOHomeDAO.initiateTransactionInTI(userVo)) {
				aTFBOHomeDAO.insertIntoTFBOStepHist(stepName, assignStatus,
						userVo.getRequestId(), ActionConstants.SYSTEMUSER);
				aTFBOHomeDAO.updateTFBOTransStatus(stepName, assignStatus,
						userVo.getRequestId());
				List<AlertMessagesVO> errorDetailList = new LinkedList<AlertMessagesVO>();
				errorDetailList = aCommonMethods.setErrorInList(
						ActionConstants.ERRORCODE999, errorDetailList);
				userVo.setErrorDetailsList(errorDetailList);
				return userVo;
			}
			tiReferanceNumber = aTFBOHomeDAO.getTiReferenceNumber(userVo
					.getRequestId());
			aTFBOHomeDAO.updateTiReferenceNumber(tiReferanceNumber,
					userVo.requestId);
		}
		if (userVo.getSentMailToBranch().equals("true")) {
			aTFBOHomeDAO.sentMailToBranch(userVo);
		}
		if (userVo.getSentMailToCustomer().equals("true")) {
			aTFBOHomeDAO.sentMailToCustomer(userVo);
		}
		if (aCommonMethods.isValueAvailable(userVo.mailToCustomer)) {
			aTFBOHomeDAO.setTFBOCustomerComments(userVo.requestId,
					userVo.mailToCustomer, stepName, userVo.sessionUserName);
		}
		aTFBOHomeDAO.insertIntoTFBOStepHist(newStepName, newAssignStatus,
				userVo.getRequestId(), ActionConstants.SYSTEMUSER);
		aTFBOHomeDAO.updateTFBOTransStatus(newStepName, newAssignStatus,
				userVo.getRequestId());
		aTFBOHomeDAO.updateTFBOTransUser(stepName, userVo.getSessionUserName(),
				userVo.getRequestId());
		// ADDED BY CHANDRU
		aTFBOHomeDAO
				.updateTFBOTranLockStatus(userVo, ActionConstants.LOCKFALSE);
		// ADDED BY CHANDRU
		logger.info(ActionConstants.ENTERING_METHOD);
		return userVo;
	}

	public void scrutinizerRaiseQueryTransaction(UserTransactionVO userVo,
			String newStatus, String newStepName, String stepName)
			throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		TFBOHomeDAO aTFBOHomeDAO = new TFBOHomeDAO();
		CommonMethods aCommonMethods = new CommonMethods();
		TFBOWorkflow aTFBOWorkflow = new TFBOWorkflow();
		String assignStatus = "";
		String rate = "";
		assignStatus = aTFBOWorkflow.getAssignStatus(newStepName);
		aTFBOHomeDAO.insertIntoTFBOStepHist(stepName, newStatus,
				userVo.getRequestId(), userVo.getSessionUserName());
		// Miscellanous changes starts 08-01-2020
		aTFBOHomeDAO.updateRateTakenDetailsInDB(userVo);
		// Miscellanous changes ends 08-01-2020
		aTFBOHomeDAO.updateTFBOTransStatus(stepName, newStatus,
				userVo.getRequestId());
		aTFBOHomeDAO.updateTFBOTransQueried("1", userVo.getRequestId());
		aTFBOHomeDAO.clearTFBOTransUser(newStepName, userVo.getRequestId());
		if (aCommonMethods.isValueAvailable(userVo.userComment)) {
			aTFBOHomeDAO.setTFBOUserComments(userVo.requestId,
					userVo.userComment, stepName, userVo.sessionUserName);
		}
		if (userVo.getFboScrutinizerCheckList() != null)
			aTFBOHomeDAO.updateTFBOTransChecklist(
					userVo.getFboScrutinizerCheckList(), userVo.getRequestId());
		System.out.println("userVo.mailToCustomer >>-->"
				+ userVo.mailToCustomer);
		if (aCommonMethods.isValueAvailable(userVo.mailToCustomer)) {
			System.out.println(">>-->Inside mail to customer <<--<");
			aTFBOHomeDAO.setTFBOCustomerComments(userVo.requestId,
					userVo.mailToCustomer, stepName, userVo.sessionUserName);
		}
		if (aCommonMethods.isValueAvailable(userVo.getSentMailToBranch()))
			if (userVo.getSentMailToBranch().equals("true")) {
				aTFBOHomeDAO.sentMailToBranch(userVo);
			}
		if (aCommonMethods.isValueAvailable(userVo.getSentMailToCustomer()))
			if (userVo.getSentMailToCustomer().equals("true")) {
				aTFBOHomeDAO.sentMailToCustomer(userVo);
			}
		aTFBOHomeDAO.insertIntoTFBOStepHist(newStepName, assignStatus,
				userVo.getRequestId(), ActionConstants.SYSTEMUSER);
		// Inward Remittance changes 23-12-2019 starts
		DBHelper aDBHelper = new DBHelper();
		// FREEZING(SCENARIO) off shore team starts 31122019
		if (userVo.getProductCode().equalsIgnoreCase("IDC")) {
			if (userVo.getEventCode().equalsIgnoreCase("CRE")) {
				if (aCommonMethods.isValueAvailable(userVo.getRateTaken())
						&& userVo.getRateTaken().equalsIgnoreCase("false")) {
					userVo.setToken("");
					userVo.setRate("");
					userVo.setValueK("");
					userVo.setDirect("false");
				}

				// CHANGED BY CHANDRU
				rate = userVo.getRateTaken();
				if (rate.equals("false")) {
					rate = "N";
				} else {
					rate = "Y";
				}
				// ENDS

				aDBHelper.setValueInDB(userVo.getToken(), rate.trim(),
						userVo.getRate(), userVo.getValueK(),
						userVo.getRequestId(),
						ActionConstants.GETUPDATETFBOIDCCRESCRU_QUERY);

//				aTFBOHomeDAO.updateTFBOIdcFlow(userVo.getRequestId(),
//						userVo.getDirect(), userVo.getSubProductCode());

			}
			if (userVo.getEventCode().equalsIgnoreCase("CLP")) {

				if (aCommonMethods.isValueAvailable(userVo.getRateTaken())
						&& userVo.getRateTaken().equalsIgnoreCase("false")) {
					userVo.setToken("");
					userVo.setRate("");
					userVo.setValueK("");
					userVo.setDirect("false");
				}

				// FREEZING(SCENARIO) off shore team ends 06012020
				/*
				 * aDBHelper.setValueInDB(userVo.getToken(),
				 * userVo.getRateTaken() .trim(), userVo.getRate(),
				 * userVo.getValueK(), userVo .getRequestId(),
				 * ActionConstants.GETUPDATETFBOIDCCLPSCRU_QUERY);
				 */

				// CHANGED BY CHANDRU
				rate = userVo.getRateTaken();
				if (rate.equals("false")) {
					rate = "N";
				} else {
					rate = "Y";
				}
				// ENDS

				aDBHelper.setValueInDB(userVo.getDirect(), userVo.getToken(),
						rate.trim(), userVo.getRate(), userVo.getValueK(),
						userVo.getRequestId(),
						ActionConstants.GETUPDATETFBOIDCCLPSCRU_QUERY);
			}
		}
		// FREEZING(SCENARIO) off shore team ends 31122019
		if (userVo.getProductCode().equalsIgnoreCase("CPCI")) {
			if (userVo.getEventCode().equalsIgnoreCase("PCIC")) {

				// rate taken null checking 31122019
				if (aCommonMethods.isValueAvailable(userVo.getRateTaken())) {
					// CHANGED BY CHANDRU
					if (userVo.getRateTaken().trim().equalsIgnoreCase("true")) {
						userVo.setRateTaken("Y");
					} else {
						userVo.setRateTaken("N");
					}
				}
				// ENDS
				aDBHelper.setValueInDB(userVo.getToken(),
						userVo.getRateTaken(), userVo.getRate(),
						userVo.getRateTakenK(), userVo.getRequestId(),
						ActionConstants.GETUPDATETFBOCPCICRESCRU_QUERY);
			}
		}
		// Inward Remittance changes 23-12-2019 ends

		// Issue Fix Offshore Team 30122019 starts
		// Outward Remittance Changes 23/12/2019 start
		if (userVo.getProductCode().equalsIgnoreCase("CPCO")) {
			if (userVo.getEventCode().equalsIgnoreCase("PCOC")) {

				// rate taken null checking 31122019
				if (aCommonMethods.isValueAvailable(userVo.getRateTaken())) {
					// CHANGED BY CHANDRU
					if (userVo.getRateTaken().trim().equalsIgnoreCase("true")) {
						userVo.setRateTaken("Y");
					} else {
						userVo.setRateTaken("N");
					}
				}
				// ENDS

				aDBHelper.setValueInDB(userVo.getToken(),
						userVo.getRateTaken(), userVo.getRate(),
						userVo.getValueK(), userVo.getRequestId(),
						ActionConstants.GETUPDATETFBOCPCOCRESCRU_QUERY);
			}
		}

		// Outward Remittance Changes 23/12/2019 end

		// Pandi For FSA Repayment update token and k+
		if (userVo.getProductCode().equalsIgnoreCase("FSA")) {
			if (userVo.getEventCode().equalsIgnoreCase("RSA")) {
				// System.out.println("userVo.getRateTaken1()--->" +
				// userVo.getRateTaken());

				aDBHelper.setValueInDB(userVo.getToken(),
						userVo.getRateTaken(), userVo.getRate(),
						userVo.getRateTakenK(), userVo.getRequestId(),
						ActionConstants.GETUPDATETFBOFSAREPAYSCRU_QUERY);
			}
		}

		if (userVo.getProductCode().equalsIgnoreCase("FOC")) {
			if (userVo.getEventCode().equalsIgnoreCase("CSA1")) {
				// System.out.println("userVo.getRateTaken1()--->" +
				// userVo.getRateTaken());

				// CHANGED BY CHANDRU
				rate = userVo.getRateTaken();
				if (rate.equals("false")) {
					rate = "N";
				} else {
					rate = "Y";
				}
				// ENDS

				aDBHelper.setValueInDB(userVo.getToken(), rate,
						userVo.getRate(), userVo.getRateTakenK(),
						userVo.getRequestId(),
						ActionConstants.GETUPDATETFBOFOCCRESCRU_QUERY);
			}
		}

		if (userVo.getProductCode().equalsIgnoreCase("FOC")) {
			if (userVo.getEventCode().equalsIgnoreCase("RSA1")) {
				// System.out.println("userVo.getRateTaken1()--->" +
				// userVo.getRateTaken());

				// CHANGED BY CHANDRU
				rate = userVo.getRateTaken();
				if (rate.equals("false")) {
					rate = "N";
				} else {
					rate = "Y";
				}
				// ENDS

				/*
				 * aDBHelper.setValueInDB(userVo.getToken(), rate,
				 * userVo.getRate(), userVo.getRateTakenK(),
				 * userVo.getRequestId(),
				 * ActionConstants.GETUPDATETFBOFOCREPSCRU_QUERY);
				 */
				aDBHelper.setValueInDB(userVo.getToken(), rate,
						userVo.getRate(), userVo.getRateTakenK(),
						userVo.getSenderRefNo(), userVo.getPreshipAccSetteld(),
						userVo.getRequestId(),
						ActionConstants.GETUPDATETFBOFOCREPSCRU_QUERY);
			}
		}

		if (userVo.getProductCode().equalsIgnoreCase("FOC")) {
			if (userVo.getEventCode().equalsIgnoreCase("CRYST")) {
				// System.out.println("userVo.getRateTaken1()--->" +
				// userVo.getRateTaken());

				// CHANGED BY CHANDRU
				rate = userVo.getRateTaken();
				if (rate.equals("false")) {
					rate = "N";
				} else {
					rate = "Y";
				}
				// ENDS

				aDBHelper.setValueInDB(userVo.getToken(), rate,
						userVo.getRate(), userVo.getRateTakenK(),
						userVo.getRequestId(),
						ActionConstants.GETUPDATETFBOFOCRYSTPSCRU_QUERY);
			}
		}

		if (userVo.getProductCode().equalsIgnoreCase("ODC")) {
			if (userVo.getEventCode().equalsIgnoreCase("CRE")) {
				// System.out.println("userVo.getRateTaken1()--->" +
				// userVo.getRateTaken());

				// CHANGED BY CHANDRU
				rate = userVo.getRateTaken();
				if (rate.equals("false")) {
					rate = "N";
				} else {
					rate = "Y";
				}
				// ENDS

				aDBHelper.setValueInDB(userVo.getToken(), rate,
						userVo.getRate(), userVo.getRateTakenK(),
						userVo.getRequestId(),
						ActionConstants.GETUPDATEODCCREATE_QUERY);

//				aTFBOHomeDAO.updateTFBOOdcFlow(userVo.getRequestId(),
//						userVo.getDirect(), userVo.getMtReceived(),
//						userVo.getPartPayment(), userVo.getSubProductCode(),
//						userVo.getFinanceSameDay());

			}
			if (userVo.getEventCode().equalsIgnoreCase("CLP")) {
				// System.out.println("userVo.getRateTaken1()--->" +
				// userVo.getRateTaken());

				// CHANGED BY CHANDRU
				rate = userVo.getRateTaken();
				if (rate.equals("false")) {
					rate = "N";
				} else {
					rate = "Y";
				}
				// ENDS

				aDBHelper.setValueInDB(userVo.getToken(), rate,
						userVo.getRate(), userVo.getRateTakenK(),
						userVo.getRequestId(),
						ActionConstants.GETUPDATEODCPAYMENT_QUERY);
			}
		}

		// Pandi For FSA Repayment update token and k+

		// Issue Fix Offshore Team 30122019 ends

		// STARTS : ADDED BY CHANDRU FOR SCRUTINIZER RAISE QUERY METHOD
		if (userVo.getProductCode().equalsIgnoreCase("ELC")) {

			if (userVo.getEventCode().equalsIgnoreCase("PODP")) {

				rate = userVo.getRateTaken();
				if (rate.equals("false")) {
					rate = "N";
				} else {
					rate = "Y";
				}

				aDBHelper.setValueRateTakenODCInDB(rate, userVo.getRate(),
						userVo.getToken(), userVo.getValueK(),
						userVo.getRequestId(), userVo.getSenderRefno(),
						ActionConstants.GETUPDATERATETAKENDETAILS_ELCPAY_QUERY);
				logger.info(ActionConstants.EXITING_METHOD);
			}
			if (userVo.getEventCode().trim().equalsIgnoreCase("PODA")) {

				rate = userVo.getRateTaken();
				if (rate.equals("false")) {
					rate = "N";
				} else {
					rate = "Y";
				}

				logger.info(ActionConstants.ENTERING_METHOD);

				aDBHelper.setValueRateTakenELCInDB(userVo.getRequestId(),
						userVo.getSenderRefno(),
						ActionConstants.GETUPDATERATETAKENDETAILS_ELCACC_QUERY);
				logger.info(ActionConstants.EXITING_METHOD);
			}
		}

		if (userVo.getProductCode().trim().equalsIgnoreCase("ILC")) {
			if (userVo.getEventCode().trim().equalsIgnoreCase("POCP")) {
				logger.info(ActionConstants.ENTERING_METHOD);

				rate = userVo.getRateTaken();
				if (rate.equals("false")) {
					rate = "N";
				} else {
					rate = "Y";
				}

				aDBHelper.setValueRateTakenLCInDB(rate, userVo.getRate(),
						userVo.getToken(), userVo.getValueK(),
						userVo.getRequestId(),
						ActionConstants.GETUPDATERATETAKENDETAILS_ILCPAY_QUERY);
				logger.info(ActionConstants.EXITING_METHOD);
			}
			if (userVo.getEventCode().trim().equalsIgnoreCase("POCD")) {

				rate = userVo.getRateTaken();
				if (rate.equals("false")) {
					rate = "N";
				} else {
					rate = "Y";
				}

				logger.info(ActionConstants.ENTERING_METHOD);
				aDBHelper.setValueRateTakenLCInDB(rate, userVo.getRate(),
						userVo.getToken(), userVo.getValueK(),
						userVo.getRequestId(),
						ActionConstants.GETUPDATERATETAKENDETAILS_ILCDEV_QUERY);
				logger.info(ActionConstants.EXITING_METHOD);
			}
		}

		if (userVo.getProductCode().equalsIgnoreCase("FEL")) {
			if (userVo.getEventCode().equalsIgnoreCase("CSA4")) {
				rate = userVo.getRateTaken().trim();
				// CHANGED BY CHANDRU
				rate = userVo.getRateTaken();
				if (rate.equals("false")) {
					rate = "N";
				} else {
					rate = "Y";
				}
				// ENDS

				aDBHelper.setValueInDB(rate, userVo.getRate(),
						userVo.getRateTakenK(), userVo.getToken(),
						userVo.getRequestId(),
						ActionConstants.GETUPDATETFBOFELCRESCRU_QUERY);
			}
			if (userVo.getEventCode().equalsIgnoreCase("CRYST")) {

				// CHANGED BY CHANDRU
				rate = userVo.getRateTaken();
				if (rate.equals("false")) {
					rate = "N";
				} else {
					rate = "Y";
				}
				// ENDS

				aDBHelper.setValueInDB(rate, userVo.getRate(),
						userVo.getRateTakenK(), userVo.getToken(),
						userVo.getRequestId(),
						ActionConstants.GETUPDATETFBOFELCRYSTSCRU_QUERY);
			}
			if (userVo.getEventCode().equalsIgnoreCase("RSA4")) {

				rate = userVo.getRateTaken();
				if (rate.equals("false")) {
					rate = "N";
				} else {
					rate = "Y";
				}
				// ENDS

				String preshipAcc = userVo.getPreshipAccSetteld();
				if (preshipAcc.equals("true")) {
					preshipAcc = "Y";
				} else {
					preshipAcc = "N";
				}
				// ENDS

				aDBHelper.setValueInDB(rate, userVo.getRate(),
						userVo.getRateTakenK(), preshipAcc,
						userVo.getSenderRefno(), userVo.getToken(),
						userVo.getRequestId(),
						ActionConstants.GETUPDATETFBOFELRPYSCRU_QUERY);
			}
		}

		/* ADDED BY CHANDRU */
		if (userVo.getProductCode().equalsIgnoreCase("ISB")) {
			if (userVo.getEventCode().equalsIgnoreCase("OIS")) {
				if (userVo.getRateTaken() != null
						&& !userVo.getRateTaken().trim().equals("")) {
					rate = userVo.getRateTaken().trim();
					// CHANGED BY CHANDRU
					if (rate.equals("true")) {
						rate = "Y";
					} else {
						rate = "N";
					}
					// ENDS
				}
				aDBHelper.setValueInDB(rate, userVo.getToken(),
						userVo.getValueK(), userVo.getRate(),
						userVo.getRequestId(),
						ActionConstants.GETUPDATETFBOISBOISSCRU_QUERY);

			}
		}

		if (userVo.getProductCode().equalsIgnoreCase("IGT")) {
			if (userVo.getEventCode().equalsIgnoreCase("OIG")) {
				if (userVo.getRateTaken() != null
						&& !userVo.getRateTaken().trim().equals("")) {
					rate = userVo.getRateTaken().trim();
					// CHANGED BY CHANDRU
					if (rate.equals("true")) {
						rate = "Y";
					} else {
						rate = "N";
					}
					// ENDS
				}
				aDBHelper.setValueInDB(rate, userVo.getToken(),
						userVo.getValueK(), userVo.getRate(),
						userVo.getRequestId(),
						ActionConstants.GETUPDATETFBOIGTOIGSCRU_QUERY);

			}
		}

		/* ADDED BY CHANDRU */

		// ENDS

		aTFBOHomeDAO.updateTFBOTransStatus(newStepName, assignStatus,
				userVo.getRequestId());
		// ADDED BY CHANDRU
		aTFBOHomeDAO
				.updateTFBOTranLockStatus(userVo, ActionConstants.LOCKFALSE);
		// ADDED BY CHANDRU
		logger.info(ActionConstants.ENTERING_METHOD);
	}

	public void fboRaiseQueryTransaction(UserTransactionVO userVo,
			String newStatus, String newStepName, String stepName)
			throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		TFBOHomeDAO aTFBOHomeDAO = new TFBOHomeDAO();
		CommonMethods aCommonMethods = new CommonMethods();
		TFBOWorkflow aTFBOWorkflow = new TFBOWorkflow();
		String assignStatus = "";
		assignStatus = aTFBOWorkflow.getAssignStatus(newStepName);
		aTFBOHomeDAO.insertIntoTFBOStepHist(stepName, newStatus,
				userVo.getRequestId(), userVo.getSessionUserName());
		aTFBOHomeDAO.updateTFBOTransStatus(stepName, newStatus,
				userVo.getRequestId());
		aTFBOHomeDAO.updateTFBOTransQueried("1", userVo.getRequestId());
		aTFBOHomeDAO.clearTFBOTransUser(newStepName, userVo.getRequestId());
		if (aCommonMethods.isValueAvailable(userVo.userComment)) {
			aTFBOHomeDAO.setTFBOUserComments(userVo.requestId,
					userVo.userComment, stepName, userVo.sessionUserName);
		}
		if (aCommonMethods.isValueAvailable(userVo.getSentMailToBranch()))
			if (userVo.getSentMailToBranch().equals("true")) {
				aTFBOHomeDAO.sentMailToBranch(userVo);
			}
		aTFBOHomeDAO.insertIntoTFBOStepHist(newStepName, assignStatus,
				userVo.getRequestId(), ActionConstants.SYSTEMUSER);
		aTFBOHomeDAO.updateTFBOTransStatus(newStepName, assignStatus,
				userVo.getRequestId());
		// ADDED BY CHANDRU
		aTFBOHomeDAO
				.updateTFBOTranLockStatus(userVo, ActionConstants.LOCKFALSE);
		// ADDED BY CHANDRU
		logger.info(ActionConstants.ENTERING_METHOD);
	}

	public void checkerVerifyTransaction(UserTransactionVO userVo,
			String newStatus, String newStepName, String stepName)
			throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		TFBOHomeDAO aTFBOHomeDAO = new TFBOHomeDAO();
		CommonMethods aCommonMethods = new CommonMethods();
		TFBOWorkflow aTFBOWorkflow = new TFBOWorkflow();
		String assignStatus = "";
		assignStatus = aTFBOWorkflow.getAssignStatus(newStepName);
		aTFBOHomeDAO.insertIntoTFBOStepHist(stepName, newStatus,
				userVo.getRequestId(), userVo.getSessionUserName());
		aTFBOHomeDAO.updateTFBOTransStatus(stepName, newStatus,
				userVo.getRequestId());
		aTFBOHomeDAO.updateTFBOTransQueried("0", userVo.getRequestId());
		aTFBOHomeDAO.updateTFBOTransUser(stepName, userVo.getSessionUserName(),
				userVo.getRequestId());
		if (aCommonMethods.isValueAvailable(userVo.userComment)) {
			aTFBOHomeDAO.setTFBOUserComments(userVo.requestId,
					userVo.userComment, stepName, userVo.sessionUserName);
		}
		aTFBOHomeDAO.insertIntoTFBOStepHist(newStepName, assignStatus,
				userVo.getRequestId(), ActionConstants.SYSTEMUSER);
		aTFBOHomeDAO.updateTFBOTransStatus(newStepName, assignStatus,
				userVo.getRequestId());
		// ADDED BY CHANDRU
		aTFBOHomeDAO
				.updateTFBOTranLockStatus(userVo, ActionConstants.LOCKFALSE);
		// ADDED BY CHANDRU
		logger.info(ActionConstants.ENTERING_METHOD);
	}

	public void makerPendTransaction(UserTransactionVO userVo,
			String newStatus, String stepName) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		TFBOHomeDAO aTFBOHomeDAO = new TFBOHomeDAO();
		TFBOWorkflow aTFBOWorkflow = new TFBOWorkflow();
		String assignStatus = "";
		assignStatus = aTFBOWorkflow.getAssignStatus(stepName);
		aTFBOHomeDAO.insertIntoTFBOStepHist(stepName, newStatus,
				userVo.getRequestId(), userVo.getSessionUserName());
		aTFBOHomeDAO.updateTFBOTransStatus(stepName, newStatus,
				userVo.getRequestId());

		aTFBOHomeDAO.updateSubProductInTFBOTrans(userVo.getSubProductCode(),
				userVo.getRequestId());

		/* Dashboard changes 23012020 starts */
		aTFBOHomeDAO.updateValuesInTFBOTrans(userVo.getProductCode(),
				userVo.getSolID(), userVo.getCustomeCif(),
				userVo.getCustomeName(), userVo.getDirect(),
				userVo.getFinanceSameDay(), userVo.getRequestId(),userVo.getAmount(),
				userVo.getCurrency(),userVo.getRateTaken());
		/* Dashboard changes 23012020 ends */
		CommonMethods aCommonMethods = new CommonMethods();
		if (aCommonMethods.isValueAvailable(userVo.getDirect())
				&& userVo.getDirect().equalsIgnoreCase("false")) {
			userVo.setRateTaken("false");
			userVo.setMtReceived("");
			userVo.setToken("");
			userVo.setRate("");
			userVo.setRateTakenK("");
		}
		if (aCommonMethods.isValueAvailable(userVo.userComment)) {
			aTFBOHomeDAO.setTFBOUserComments(userVo.requestId,
					userVo.userComment, stepName, userVo.sessionUserName);
		}
		aTFBOHomeDAO.updateTFBOEventTable(userVo);
		if (userVo.getBranchMakerCheckList() != null)
			aTFBOHomeDAO.updateTFBOTransChecklist(
					userVo.getBranchMakerCheckList(), userVo.getRequestId());
		aTFBOHomeDAO.insertIntoTFBOStepHist(stepName, assignStatus,
				userVo.getRequestId(), ActionConstants.SYSTEMUSER);
		aTFBOHomeDAO.updateTFBOTransStatus(stepName, assignStatus,
				userVo.getRequestId());
		// ADDED BY CHANDRU
		aTFBOHomeDAO
				.updateTFBOTranLockStatus(userVo, ActionConstants.LOCKFALSE);
		// ADDED BY CHANDRU
		logger.info(ActionConstants.ENTERING_METHOD);
	}

	public void makerVerifyTransaction(UserTransactionVO userVo,
			String newStatus, String newStepName, String stepName)
			throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		TFBOHomeDAO aTFBOHomeDAO = new TFBOHomeDAO();
		CommonMethods aCommonMethods = new CommonMethods();
		TFBOWorkflow aTFBOWorkflow = new TFBOWorkflow();
		String assignStatus = "";
		assignStatus = aTFBOWorkflow.getAssignStatus(newStepName);
		aTFBOHomeDAO.insertIntoTFBOStepHist(stepName, newStatus,
				userVo.getRequestId(), userVo.getSessionUserName());
		aTFBOHomeDAO.updateTFBOTransStatus(stepName, newStatus,
				userVo.getRequestId());
		aTFBOHomeDAO.updateSubProductInTFBOTrans(userVo.getSubProductCode(),
				userVo.getRequestId());

		/* Dashboard changes 23012020 starts */
		aTFBOHomeDAO.updateValuesInTFBOTrans(userVo.getProductCode(),
				userVo.getSolID(), userVo.getCustomeCif(),
				userVo.getCustomeName(), userVo.getDirect(),
				userVo.getFinanceSameDay(), userVo.getRequestId(),userVo.getAmount(),
				userVo.getCurrency(),userVo.getRateTaken());

		/* Dashboard changes 23012020 ends */
		if (aCommonMethods.isValueAvailable(userVo.userComment)) {
			aTFBOHomeDAO.setTFBOUserComments(userVo.requestId,
					userVo.userComment, stepName, userVo.sessionUserName);
		}
		if (userVo.getBranchMakerCheckList() != null) {
			aTFBOHomeDAO.updateTFBOTransChecklist(
					userVo.getBranchMakerCheckList(), userVo.getRequestId());
		}
		aTFBOHomeDAO.updateTFBOTransUser(stepName, userVo.getSessionUserName(),
				userVo.getRequestId());
		System.out.println("RATE TAKEN >>--> " + userVo.getRateTaken());
		System.out.println("RATE >>--> " + userVo.getRate());
		System.out.println("TOKEN >>--> " + userVo.getToken());
		System.out.println("K VALUE>>--> " + userVo.getValueK());
		System.out.println("direct >>-->" + userVo.getDirect());
		System.out.println("direct event >>-->" + userVo.getDirectCREEvent());
		/*
		 * if (aCommonMethods.isValueAvailable(userVo.getDirect()) &&
		 * userVo.getDirect().equalsIgnoreCase("false")) {
		 * userVo.setRateTaken("false"); userVo.setMtReceived("");
		 * userVo.setToken(""); userVo.setRate(""); userVo.setRateTakenK(""); }
		 */
		System.out.println("RATE TAKEN >>--> " + userVo.getRateTaken());
		System.out.println("RATE >>--> " + userVo.getRate());
		System.out.println("TOKEN >>--> " + userVo.getToken());
		System.out.println("K VALUE>>--> " + userVo.getValueK());
		System.out.println("direct >>-->" + userVo.getDirect());
		System.out.println("direct event >>-->" + userVo.getDirectCREEvent());
		aTFBOHomeDAO.updateTFBOEventTable(userVo);
		aTFBOHomeDAO.insertIntoTFBOStepHist(newStepName, assignStatus,
				userVo.getRequestId(), ActionConstants.SYSTEMUSER);
		aTFBOHomeDAO.updateTFBOTransStatus(newStepName, assignStatus,
				userVo.getRequestId());
		// ADDED BY CHANDRU
		aTFBOHomeDAO
				.updateTFBOTranLockStatus(userVo, ActionConstants.LOCKFALSE);
		// ADDED BY CHANDRU
		logger.info(ActionConstants.ENTERING_METHOD);
	}

	public String getCurrentStep(String requestID) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		TFBOHomeDAO aTFBOHomeDAO = new TFBOHomeDAO();
		String stepName = "";
		try {
			stepName = aTFBOHomeDAO.getCurrentStepFromDB(requestID);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		logger.info(ActionConstants.ENTERING_METHOD);
		return stepName;
	}

	public String getProductName(String requestID) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		TFBOHomeDAO aTFBOHomeDAO = new TFBOHomeDAO();
		String productName = "";
		try {
			productName = aTFBOHomeDAO.getProductNameFromDB(requestID);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		logger.info(ActionConstants.ENTERING_METHOD + "-->" + productName);
		return productName;
	}

	public String getProductCode(String productName) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		TFBOHomeDAO aTFBOHomeDAO = new TFBOHomeDAO();
		String productCode = "";
		try {
			productCode = aTFBOHomeDAO.getProductCodeFromDB(productName);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		logger.info(ActionConstants.ENTERING_METHOD + "-->" + productName);
		return productCode;
	}

	public String getEventCode(String productCode, String eventName)
			throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		TFBOHomeDAO aTFBOHomeDAO = new TFBOHomeDAO();
		String eventCode = "";
		try {
			eventCode = aTFBOHomeDAO.getEventCodeFromDB(productCode, eventName);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		logger.info(ActionConstants.ENTERING_METHOD + "-->" + eventCode);
		return eventCode;
	}

	public String getEventName(String requestID) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		TFBOHomeDAO aTFBOHomeDAO = new TFBOHomeDAO();
		String eventName = "";
		try {
//			eventName = aTFBOHomeDAO.getCurrentStepFromDB(requestID);--pandi
			eventName = aTFBOHomeDAO.getEventNameFromDB(requestID); //pandi
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		logger.info(ActionConstants.ENTERING_METHOD + "-->" + eventName);
		return eventName;
	}

	public String createNewTransaction(UserTransactionVO userVo,
			String stepName, String stepStatus) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		TFBOHomeDAO aTFBOHomeDAO = new TFBOHomeDAO();
		String returnPage = "";
		String requestID = userVo.getRequestId();
		String userName = userVo.getSessionUserName();
		String productCode = userVo.getProductCode();
		String eventCode = userVo.getEventCode();
		String subProductCode = userVo.getSubProductCode();
		aTFBOHomeDAO.insertIntoTFBOTrans(productCode, eventCode,
				subProductCode, stepName, stepStatus, requestID, userName);
		returnPage = aTFBOHomeDAO.insertIntoTFBOEventTable(returnPage,
				requestID, productCode, eventCode);
		aTFBOHomeDAO.getMakerChecklist(userVo);
		aTFBOHomeDAO.getSolId(userVo);
		returnPage = getReturnPage(userVo, productCode, eventCode, stepName);
		//ADDED BY CHANDRU
		/*aTFBOHomeDAO.updateTFBOTranLockStatus(userVo,
				ActionConstants.LOCKTRUE);*/
		//ADDED BY CHANDRU
		logger.info(ActionConstants.ENTERING_METHOD);
		return returnPage;
	}

	public String getReturnPage(UserTransactionVO userVo, String productCode,
			String eventCode, String stepName) {
		logger.info(ActionConstants.ENTERING_METHOD + ">> getReturnPage");
		TFBOHomeDAO aTFBOHomeDAO = new TFBOHomeDAO();
		String returnPage = "viewer" + productCode.trim() + eventCode.trim();
		try {
			isUserFbo(userVo);
			if (isValidUser(userVo, stepName)) {
				if (isValidTransaction(userVo.requestId, stepName)) {
					returnPage = aTFBOHomeDAO.getReturnPage(userVo,
							productCode, eventCode, stepName);
					return returnPage;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			return returnPage;
		}
		return returnPage;
	}

	public Boolean isValidUser(UserTransactionVO userVo, String stepName)
			throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD + ">> isValidUser");
		TFBOHomeDAO aTFBOHomeDAO = new TFBOHomeDAO();
		CommonMethods aCommonMethods = new CommonMethods();
		List<AlertMessagesVO> errorDetailList = new LinkedList<AlertMessagesVO>();
		String requestID = "";
		logger.info("userName-->" + userVo.getSessionUserName());
		requestID = userVo.getRequestId();
		logger.info("requestID-->" + requestID);
		if (aCommonMethods.isValueAvailable(userVo.getSessionUserName())) {
			if (aTFBOHomeDAO.isUserAllowed(userVo.getSessionUserName(),
					requestID, stepName)) {
				logger.info(ActionConstants.ENTERING_METHOD + ">> isValidUser");
				return true;
			} else {
				errorDetailList = aCommonMethods.setErrorInList(
						ActionConstants.ERRORCODE000, errorDetailList);
				userVo.setErrorDetailsList(errorDetailList);
				logger.info("Error for User validation-->"
						+ userVo.getErrorDetailsList().size());
			}
		}
		logger.info(ActionConstants.EXITING_METHOD + ">> isValidUser");
		return false;
	}

	public String generateRequestID(String productCode) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		TFBOHomeDAO aTFBOHomeDAO = new TFBOHomeDAO();
		String requestID = "";
		requestID = aTFBOHomeDAO.generateRequestID(productCode);
		logger.info(ActionConstants.ENTERING_METHOD);
		return requestID;
	}

	public List<String> getCurrency() throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		TFBOHomeDAO aTFBOHomeDAO = new TFBOHomeDAO();
		List<String> currencyList = null;
		currencyList = aTFBOHomeDAO.getCurrencyList();
		logger.info(ActionConstants.ENTERING_METHOD);
		return currencyList;
	}

	public List<String> getSubProduct(UserTransactionVO userVo)
			throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		TFBOHomeDAO aTFBOHomeDAO = new TFBOHomeDAO();
		List<String> subProduct = null;
		subProduct = aTFBOHomeDAO.getSubProduct(userVo);
		logger.info(ActionConstants.ENTERING_METHOD);
		return subProduct;
	}

	public String getSessionUser() {
		logger.info(ActionConstants.ENTERING_METHOD);
		TFBOHomeDAO aTFBOHomeDAO = new TFBOHomeDAO();
		String userName = "";
		userName = aTFBOHomeDAO.getSessionUser();
		logger.info(ActionConstants.EXITING_METHOD);
		return userName;
	}
	
	public String getSessionSolId() {
		logger.info(ActionConstants.ENTERING_METHOD);
		TFBOHomeDAO aTFBOHomeDAO = new TFBOHomeDAO();
		String solId = "";
		solId = aTFBOHomeDAO.getSessionSolId();
		logger.info(ActionConstants.EXITING_METHOD);
		return solId;
	}

	public String getSessionId(String userName) {
		logger.info(ActionConstants.ENTERING_METHOD);
		TFBOHomeDAO aTFBOHomeDAO = new TFBOHomeDAO();
		String sessionId = "";
		try {
			aTFBOHomeDAO.setSessionUsername(userName);
			sessionId = aTFBOHomeDAO.getSessionId();
		} catch (Exception e) {
			e.printStackTrace();
			logger.info(ActionConstants.EXITING_METHOD);
			return sessionId;
		}
		logger.info(ActionConstants.EXITING_METHOD);
		return sessionId;
	}

	public String setSessionStatus(String sessionId, String loginStatus) {
		logger.info(ActionConstants.ENTERING_METHOD);
		TFBOHomeDAO aTFBOHomeDAO = new TFBOHomeDAO();
		try {
			aTFBOHomeDAO.setSessionStatus(sessionId, loginStatus);
			sessionId = aTFBOHomeDAO.getSessionId();
		} catch (Exception e) {
			e.printStackTrace();
		}
		logger.info(ActionConstants.EXITING_METHOD);
		return sessionId;
	}

	public Boolean validateSessionUser(UserTransactionVO userVo) {
		logger.info(ActionConstants.ENTERING_METHOD + ">>getEventList");
		TFBOHomeActionBD aTFBOHomeActionBD = new TFBOHomeActionBD();
		CommonMethods aCommonMethods = new CommonMethods();
		List<AlertMessagesVO> errorDetailList = new LinkedList<AlertMessagesVO>();
		LDAPAuthenticationProcess aLDAPAuthenticationProcess = new LDAPAuthenticationProcess();
		Map<String, Object> userSession = ActionContext.getContext()
				.getSession();
		DBHelper aDBHelper = new DBHelper();
		String userName = userVo.getUserName();
		String password = userVo.getPassword();
		String sessionId = "";
		String loginStatus = "";
		String tiDate = "";
		logger.info("Loggined User Name -->" + userName);
		logger.info("Loggined User Password -->" + password);
		try {
			if (!aCommonMethods.isValueAvailable(userName)
					|| !aCommonMethods.isValueAvailable(password)) {
				return false;
			}
			sessionId = aTFBOHomeActionBD.getSessionId(userName);
			if (aCommonMethods.isValueAvailable(sessionId)) {
				if (!aLDAPAuthenticationProcess.authenticateUser(userName,
						password)) {
					errorDetailList = aCommonMethods.setErrorInList(
							ActionConstants.ERRORCODE111, errorDetailList);
					userVo.setErrorDetailsList(errorDetailList);
					logger.info("Error for User validation-->"
							+ userVo.getErrorDetailsList().size());
					userSession.clear();
					loginStatus = "LOGINFAILED";
					aTFBOHomeActionBD.setSessionStatus(sessionId, loginStatus);
					return true;//pandi
				}

				if (!aDBHelper.isUserAvailableInTI(userName,
						ActionConstants.GETUSERAVAILABLECHECK_QUERY)) {
					errorDetailList = aCommonMethods.setErrorInList(
							ActionConstants.ERRORCODE111, errorDetailList);
					userVo.setErrorDetailsList(errorDetailList);
					logger.info("Error for User validation-->"
							+ userVo.getErrorDetailsList().size());
					userSession.clear();
					loginStatus = "LOGINFAILED";
					aTFBOHomeActionBD.setSessionStatus(sessionId, loginStatus);
					return false;
				}

				SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy");
				Date date = new Date();
				tiDate = formatter.format(date);
				userSession.put("sessionUserName", userName);
				userSession.put("processDate", tiDate);

				aDBHelper.getUserNameandSolId(userName,
						ActionConstants.GETUSERNAMEANDSOLID, userVo);

				userSession.put("userTeam", userVo.getTeam());
				userSession.put("solId", userVo.getBranch());
				
				// Added by KAMAKSHYA for multiple login starts-->
				int flag = 0;
				System.out.println("localisation START");
				if ((aDBHelper.isUserAvailableInDBLOG(userName,
						ActionConstants.CHECKUSERSTAMP))) {
					if (aDBHelper.isFlagAvailableInDBLOG(userName,
							ActionConstants.CHECKAVALFLAG)) {
						flag = 1;
						aDBHelper.updateDBLOG(userName, flag,
								ActionConstants.UPDATELOGINSTAMP);
						System.out.println("localisation 1");
					} else {
						System.out.println("FLAG IN isUserAvailableInDBLOG==="
								+ flag);
						errorDetailList = aCommonMethods.setErrorInList(
								ActionConstants.ERRORCODE112, errorDetailList);
						userVo.setErrorDetailsList(errorDetailList);
						System.out.println("Error for User validation-->"
								+ userVo.getErrorDetailsList().size());
						userSession.clear();
						loginStatus = "LOGINFAILED";
						aTFBOHomeActionBD.setSessionStatus(sessionId,
								loginStatus);
						System.out.println("localisation 2");
						return false;
					}
				} else {
					flag = 1;
					aDBHelper.isValueInsertDB(userName, flag,
							ActionConstants.INSERTUSERSTAMP);
					System.out.println("localisation 3");
				}// Added by KAMAKSHYA for multiple login ENDS--->

				loginStatus = "LOGINSUCCESSFUL";
				aTFBOHomeActionBD.setSessionStatus(sessionId, loginStatus);
				logger.info("tiDate-->" + tiDate);
			}
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		logger.info(ActionConstants.EXITING_METHOD + ">>getEventList");
		return true;
	}

	public List<String> getBillReference(UserTransactionVO userVo,
			String tiReference) {
		logger.info(ActionConstants.ENTERING_METHOD);
		TFBOHomeDAO aTFBOHomeDAO = new TFBOHomeDAO();
		List<String> billReferenceList = null;
		billReferenceList = aTFBOHomeDAO.getBillReference(userVo, tiReference);
		logger.info(ActionConstants.EXITING_METHOD);
		return billReferenceList;
	}

	public UserTransactionVO getLCDetails(UserTransactionVO userVo,
			String tiReferenceNo) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		DBHelper aDBHelper = new DBHelper();
		CommonMethods aCommonMethods = new CommonMethods();
		List<AlertMessagesVO> errorDetailList = new LinkedList<AlertMessagesVO>();
		TFBOHomeDAO aTFBOHomeDAO = new TFBOHomeDAO();
		List<String> billReference = new ArrayList<String>();
		;
		if (!aDBHelper.isValueAvailableInDB(tiReferenceNo,
				ActionConstants.GETVALIDTIREFNO_QUERY)) {
			errorDetailList = aCommonMethods.setErrorInList(
					ActionConstants.ERRORCODE011, errorDetailList);
			userVo.setErrorDetailsList(errorDetailList);
			logger.info("Error for User validation-->"
					+ userVo.getErrorDetailsList().size());
			logger.info(ActionConstants.EXITING_METHOD + ">>getEventList");
			userVo.setBillReferenceList(billReference);
			return userVo;
		}
		billReference = aTFBOHomeDAO.getBillReference(userVo, tiReferenceNo);
		userVo.setBillReferenceList(billReference);
		logger.info(ActionConstants.ENTERING_METHOD);
		return userVo;
	}

	public void fetchDevolmentAmount(UserTransactionVO userVo) {
		logger.info(ActionConstants.ENTERING_METHOD);
		TFBOHomeDAO aTFBOHomeDAO = new TFBOHomeDAO();
		aTFBOHomeDAO.fetchDevolmentAmount(userVo);
	}

	// Changes for ELC and IGT Starts 25-12-2019

	public void fetchExpiryDate(UserTransactionVO userVo) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		TFBOHomeDAO aTFBOHomeDAO = new TFBOHomeDAO();
		aTFBOHomeDAO.fetchExpiryDate(userVo);
	}

	// Changes for ELC and IGT ends 25-12-2019

	// Changes for acceptance amount fetch starts 08012020
	public void fetchAcceptanceAmount(UserTransactionVO userVo)
			throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		TFBOHomeDAO aTFBOHomeDAO = new TFBOHomeDAO();
		aTFBOHomeDAO.fetchAcceptanceAmount(userVo);
	}
	
	public void fetchIGTBillAmount(UserTransactionVO userVo)
			throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		TFBOHomeDAO aTFBOHomeDAO = new TFBOHomeDAO();
		aTFBOHomeDAO.fetchIGTBillAmount(userVo);
	}

	// Changes for acceptance amount fetch ends 08012020
	// Changes for TAT report start

//	public void generateTATReport(UserTransactionVO userVo) throws Exception {
//		logger.info(ActionConstants.ENTERING_METHOD);
//		TFBOHomeDAO aTFBOHomeDAO = new TFBOHomeDAO();
//		aTFBOHomeDAO.generateTATReport(userVo);
//	}

	// Changes for TAT report end
	/* Changes for branch profile 14012020 starts */
	public void branchMgmtmaker_Verify(ProfileManagementVO profileVo)
			throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		TFBOHomeDAO aTFBOHomeDAO = new TFBOHomeDAO();
		aTFBOHomeDAO.branchMgmtmaker_Verify(profileVo);
	}

	public void branchProfileVerify(ProfileManagementVO profileVo, String solid)
			throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		TFBOHomeDAO aTFBOHomeDAO = new TFBOHomeDAO();
		try {
			aTFBOHomeDAO.branchProfileVerify(profileVo, solid);
			String alpha = profileVo.getAlphaCode();
			System.out.println("alpha -----> " + alpha);
		} catch (Exception e) {
			e.printStackTrace();
			logger.info("TFBOHomeActionBO Excep---->"
					+ ActionConstants.ENTERING_METHOD);
		}
	}

	/* Changes for branch profile 14012020 ends */
	public void fetchCustomerDetails(CustomerProfileManageVO custProfileVo)
			throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		TFBOHomeDAO aTFBOHomeDAO = new TFBOHomeDAO();
		TFBOUploadDAO aTFBOUploadDAO = new TFBOUploadDAO();
		aTFBOHomeDAO.fetchcustomerDetails(custProfileVo);
		aTFBOUploadDAO.getCustDocumentList(custProfileVo);

	}

	public int UpdateCustomerDtails(CustomerProfileManageVO custProfileVo)
			throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		TFBOHomeDAO aTFBOHomeDAO = new TFBOHomeDAO();
		String userName = getSessionUser();
		int resultValue = aTFBOHomeDAO.UpdateCustomerDtails(custProfileVo,
				userName);
		return resultValue;
	}

	public void getBranchProfileDetails(String userName,String custSolid,
			CustomerProfileManageVO custProfileVo) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		TFBOHomeDAO aTFBOHomeDAO = new TFBOHomeDAO();
		TFBOUploadDAO aTFBOUploadDAO = new TFBOUploadDAO();
		String userFlag = null;
		if (aTFBOHomeDAO.isUserMaker(userName)) {
			userFlag = "MAKER";
		}
		if (aTFBOHomeDAO.isUserChecker(userName)) {
			userFlag = "CHECKER";
		}
		// if (userFlag != null
		// && (userFlag.trim().equals("MAKER")
		// || userFlag.trim().equals("CHECKER"))) {
		// aTFBOHomeDAO.getBranchProfileDetails(userName, custSolid,
		// custProfileVo);
		// if (userFlag != null && userFlag.trim().equals("CHECKER")) {
		// aTFBOUploadDAO.getCustVerifyList(custSolid, custProfileVo);
		// }
		// }
		aTFBOHomeDAO
				.getBranchProfileDetails(userName, custSolid, custProfileVo);
		if (userFlag != null && userFlag.trim().equals("CHECKER")) {
			aTFBOUploadDAO.getCustVerifyList(custSolid, custProfileVo);
		}
	}

	// Raise Query starts 17012020
	public void checkerRaiseQueryTransaction(UserTransactionVO userVo,
			String newStatus, String newStepName, String stepName)
			throws Exception {
		System.out.println(ActionConstants.ENTERING_METHOD);
		TFBOHomeDAO aTFBOHomeDAO = new TFBOHomeDAO();
		CommonMethods aCommonMethods = new CommonMethods();
		TFBOWorkflow aTFBOWorkflow = new TFBOWorkflow();
		String assignStatus = "";
		assignStatus = aTFBOWorkflow.getAssignStatus(newStepName);
		aTFBOHomeDAO.insertIntoTFBOStepHist(stepName, newStatus,
				userVo.getRequestId(), userVo.getSessionUserName());
		aTFBOHomeDAO.insertIntoTFBOStepHist(newStepName, assignStatus,
				userVo.getRequestId(), ActionConstants.SYSTEMUSER);
		aTFBOHomeDAO.updateTFBOTransStatus(stepName, newStatus,
				userVo.getRequestId());
		aTFBOHomeDAO.updateTFBOTransStatus(newStepName, assignStatus,
				userVo.getRequestId());
		aTFBOHomeDAO.clearTFBOTransUser(newStepName, userVo.getRequestId());
		if (aCommonMethods.isValueAvailable(userVo.userComment)) {
			aTFBOHomeDAO.setTFBOUserComments(userVo.requestId,
					userVo.userComment, stepName, userVo.sessionUserName);
		}
		// ADDED BY CHANDRU
		aTFBOHomeDAO
				.updateTFBOTranLockStatus(userVo, ActionConstants.LOCKFALSE);
		// ADDED BY CHANDRU
		System.out.println(ActionConstants.ENTERING_METHOD);
	}

	// Raise Query ends 17012020

	// Sub product type drop down filter changes starts 13012020
	public List<String> getSubProductList(String productCode) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		TFBOHomeDAO aTFBOHomeDAO = new TFBOHomeDAO();
		List<String> subProductDetailsList = null;
		try {
			subProductDetailsList = aTFBOHomeDAO
					.getSubProductListFromDB(productCode);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		logger.info(ActionConstants.ENTERING_METHOD);
		return subProductDetailsList;
	}

	// Sub product type drop down filter changes ends 13012020

	public void fetchCustomerDetailsView(CustomerProfileManageVO custProfileVo)
			throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		TFBOHomeDAO aTFBOHomeDAO = new TFBOHomeDAO();
		TFBOUploadDAO aTFBOUploadDAO = new TFBOUploadDAO();
		aTFBOHomeDAO.fetchcustomerDetailsView(custProfileVo);
		aTFBOUploadDAO.getCustDocumentList(custProfileVo);
		
	}

	public void fetchCustomerDetailsVerifyView(
			CustomerProfileManageVO custProfileVo) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		TFBOHomeDAO aTFBOHomeDAO = new TFBOHomeDAO();
		TFBOUploadDAO aTFBOUploadDAO = new TFBOUploadDAO();
		aTFBOHomeDAO.fetchcustomerDetailsView(custProfileVo);
		aTFBOUploadDAO.getCustDocumentList(custProfileVo);
	}

	public void verifyCustomer(String userName,
			CustomerProfileManageVO custProfileVo) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		TFBOHomeDAO aTFBOHomeDAO = new TFBOHomeDAO();
		aTFBOHomeDAO.updateCustomerVerify(userName, custProfileVo);
	}

	// Report 23012020 starts

	public List<String> getProductCodeList() throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD + "<<getProductCodeListBD");
		TFBOHomeDAO aTFBOHomeDAO = new TFBOHomeDAO();
		List<String> productList = null;
		productList = aTFBOHomeDAO.getProductCodeFromDB();
		logger.info(ActionConstants.ENTERING_METHOD);
		return productList;
	}

	public List<String> getUserIdList() throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD + "<<getUserIdListBD");
		TFBOHomeDAO aTFBOHomeDAO = new TFBOHomeDAO();
		List<String> userList = null;
		userList = aTFBOHomeDAO.getUserIdListFromDB();
		logger.info(ActionConstants.ENTERING_METHOD);
		return userList;
	}

	/*
	 * public List<ReportVO> generateSummaryReportInGrid(ReportVO reportVo)
	 * throws Exception { logger.info(ActionConstants.ENTERING_METHOD +
	 * "<<generateSummaryReportInGrid BD"); List<ReportVO> summaryList = new
	 * ArrayList<ReportVO>(); TFBOHomeDAO aTFBOHomeDAO = new TFBOHomeDAO();
	 * summaryList = aTFBOHomeDAO.generateSummaryReportInGrid(reportVo);
	 * logger.info(ActionConstants.EXITING_METHOD +
	 * "<<generateSummaryReportInGrid BD"); return summaryList; }
	 */
//	public List<ReportVO> generateSummaryReportInGrid(ReportVO reportVo)
//			throws Exception {
//		logger.info(ActionConstants.ENTERING_METHOD
//				+ "<<generateSummaryReportInGrid BD");
//		List<ReportVO> summaryList = new ArrayList<ReportVO>();
//		TFBOHomeDAO aTFBOHomeDAO = new TFBOHomeDAO();
//		summaryList = aTFBOHomeDAO.generateSummaryReportInGrid(reportVo);
//		logger.info(ActionConstants.EXITING_METHOD
//				+ "<<generateSummaryReportInGrid BD");
//		return summaryList;
//	}

	/*
	 * public List<ReportVO> generateDetailedTableReport(ReportVO reportVo)
	 * throws Exception { logger.info(ActionConstants.ENTERING_METHOD +
	 * "<<generateDetailedTableReport BD"); List<ReportVO> detailedList = new
	 * ArrayList<ReportVO>(); TFBOHomeDAO aTFBOHomeDAO = new TFBOHomeDAO();
	 * detailedList = aTFBOHomeDAO.generateDetailedTableReport(reportVo);
	 * logger.info(ActionConstants.EXITING_METHOD +
	 * "<<generateDetailedTableReport BD"); return detailedList; }
	 */

	/*
	 * public void generateReportInExcel(ReportVO reportVo) throws Exception {
	 * logger.info(ActionConstants.ENTERING_METHOD +
	 * "<<generateReportInExcel BD"); TFBOHomeDAO aTFBOHomeDAO = new
	 * TFBOHomeDAO(); aTFBOHomeDAO.generateReportInExcel(reportVo);
	 * logger.info(ActionConstants.EXITING_METHOD +
	 * "<<generateReportInExcel BD"); }
	 */
//	public List<ReportVO> generateDetailedReportInGrid(ReportVO reportVo)
//			throws Exception {
//		logger.info(ActionConstants.ENTERING_METHOD
//				+ "<<generateDetailedReportInGrid BD");
//		List<ReportVO> detailedList = new ArrayList<ReportVO>();
//		TFBOHomeDAO aTFBOHomeDAO = new TFBOHomeDAO();
//		detailedList = aTFBOHomeDAO.generateDetailedReportInGrid(reportVo);
//		logger.info(ActionConstants.EXITING_METHOD
//				+ "<<generateDetailedReportInGrid BD");
//		return detailedList;
//	}

//	public void generateSummaryReportInExcel(ReportVO reportVo)
//			throws Exception {
//		logger.info(ActionConstants.ENTERING_METHOD
//				+ "<<generateSummaryReportInExcel BD");
//		TFBOHomeDAO aTFBOHomeDAO = new TFBOHomeDAO();
//		aTFBOHomeDAO.generateSummaryReportInExcel(reportVo);
//		logger.info(ActionConstants.EXITING_METHOD
//				+ "<<generateSummaryReportInExcel BD");
//	}

//	public void generateDetailedReportInExcel(ReportVO reportVo)
//			throws Exception {
//		logger.info(ActionConstants.ENTERING_METHOD
//				+ "<<generateDetailedReportInExcel BD");
//		TFBOHomeDAO aTFBOHomeDAO = new TFBOHomeDAO();
//		aTFBOHomeDAO.generateDetailedReportInExcel(reportVo);
//		logger.info(ActionConstants.EXITING_METHOD
//				+ "<<generateDetailedReportInExcel BD");
//	}

	// Report 23012020 ends
	/*
	 * public void fetchReminderDetails(TFBOReminderVO reminderVo) throws
	 * Exception { System.out
	 * .println("Entering method -->>-->  fetchfetchReminderDetails in BD");
	 * TFBOHomeDAO aTFBOHomeDAO = new TFBOHomeDAO();
	 * 
	 * aTFBOHomeDAO.fetchReminderDetails(reminderVo);
	 * 
	 * }
	 */

	/*
	 * public int sendReminderEmail(TFBOReminderVO reminderVo) throws Exception
	 * { System.out.println("into BD of sendReminderEmail");
	 * 
	 * TFBOHomeDAO aTFBOHomeDAO = new TFBOHomeDAO();
	 * 
	 * try { reminderVo.setRequestId(reminderVo.requestIdGridValue);
	 * reminderVo.setTiReference(reminderVo.tiReferanceNoGridValue);
	 * reminderVo.setProductCode(reminderVo.productCodeGridValue);
	 * reminderVo.setEventCode(reminderVo.eventCodeGridValue);
	 * 
	 * aTFBOHomeDAO.getcustomerDetails(reminderVo); //
	 * reminderVo.setReminderList(custLst); setReminderValuesInVO(reminderVo);
	 * 
	 * }
	 * 
	 * catch (Exception e) { e.printStackTrace(); } return
	 * setReminderValuesInVO(reminderVo);
	 * 
	 * }
	 */

	/*
	 * private int setReminderValuesInVO(TFBOReminderVO reminderVo) throws
	 * Exception {
	 * 
	 * TFBOHomeDAO aTFBOHomeDAO = new TFBOHomeDAO(); if (reminderVo.reminderList
	 * != null) { for (TFBOReminderVO aTFBOReminderVO : reminderVo.reminderList)
	 * { reminderVo.customeCif = aTFBOReminderVO.getCustomeCif();
	 * reminderVo.customeName = aTFBOReminderVO.getCustomeName();
	 * reminderVo.amount = aTFBOReminderVO.getAmount();
	 * 
	 * aTFBOHomeDAO.sentMailtoReminder(reminderVo); } } return
	 * aTFBOHomeDAO.sentMailtoReminder(reminderVo); }
	 */
//	public void fetchReminderDetails(TFBOReminderVO reminderVo,
//			UserTransactionVO userVo) throws Exception {
//
//		CommonMethods aCommonMethods = new CommonMethods();
//		System.out
//				.println("Entering method -->>-->  fetchfetchReminderDetails in BD");
//		if (aCommonMethods.isValueAvailable(userVo.getProductFilter())) {
//			userVo.setProductCode(getProductCode(userVo.getProductFilter()));
//		}
//		TFBOHomeDAO aTFBOHomeDAO = new TFBOHomeDAO();
//
//		aTFBOHomeDAO.fetchReminderDetails(reminderVo, userVo);
//
//	}

	public int sendReminderEmail(TFBOReminderVO reminderVo) throws Exception {
		System.out.println("into BD of sendReminderEmail");

		TFBOHomeDAO aTFBOHomeDAO = new TFBOHomeDAO();
		int value = 0;

		try {
			reminderVo.setRequestId(reminderVo.requestIdGridValue);
			reminderVo.setTiReference(reminderVo.tiReferanceNoGridValue);
			reminderVo.setProductCode(reminderVo.productCodeGridValue);
			reminderVo.setEventCode(reminderVo.eventCodeGridValue);
			reminderVo.setProdDescription(reminderVo.prdDescGridValue);
			reminderVo.setEvtDescription(reminderVo.eventDescGridValue);

			aTFBOHomeDAO.getcustomerDetails(reminderVo);
			// reminderVo.setReminderList(custLst);
			value = setReminderValuesInVO(reminderVo);

		}

		catch (Exception e) {
			value =0;
			e.printStackTrace();
		}
		return value;

	}

	private int setReminderValuesInVO(TFBOReminderVO reminderVo)
			throws Exception {
           int value =0;
		TFBOHomeDAO aTFBOHomeDAO = new TFBOHomeDAO();
		if (reminderVo.reminderList != null) {
			for (TFBOReminderVO aTFBOReminderVO : reminderVo.reminderList) {
				reminderVo.customeCif = aTFBOReminderVO.getCustomeCif();
				reminderVo.customeName = aTFBOReminderVO.getCustomeName();
				reminderVo.amount = aTFBOReminderVO.getAmount();

				value = aTFBOHomeDAO.sentMailtoReminder(reminderVo);
			}
		}
		return value;
	}

	// //KARTHIK MISSLANEOUS 01022020 STARTS
	/*
	 * public void updateMiscellanousComment(String missComment,
	 * UserTransactionVO userVo) { TFBOHomeDAO aTFBOHomeDAO = new TFBOHomeDAO();
	 * 
	 * aTFBOHomeDAO.updateMakerComment(missComment, userVo);
	 * 
	 * }
	 * 
	 * public void updateMiscellcheckerComment(String misscheckerComment,
	 * UserTransactionVO userVo) {
	 * 
	 * TFBOHomeDAO aTFBOHomeDAO = new TFBOHomeDAO();
	 * 
	 * aTFBOHomeDAO.updatecheckerComment(misscheckerComment, userVo); }
	 */
	public void updateMiscellanousComment(String missComment,
			UserTransactionVO userVo) {
		TFBOHomeDAO aTFBOHomeDAO = new TFBOHomeDAO();

		aTFBOHomeDAO.updateMakerComment(missComment, userVo);

	}

	public void updateMiscellcheckerComment(String misscheckerComment,
			UserTransactionVO userVo) {

		TFBOHomeDAO aTFBOHomeDAO = new TFBOHomeDAO();

		aTFBOHomeDAO.updatecheckerComment(misscheckerComment, userVo);
	}

	// //KARTHIK MISSLANEOUS 01022020 ENDS
	
	
	
	public void fbomakerSubmitTransaction(UserTransactionVO userVo,
			String newStatus, String newStepName, String stepName) throws Exception {
		TFBOHomeDAO aTFBOHomeDAO = new TFBOHomeDAO();
		CommonMethods aCommonMethods = new CommonMethods();
		TFBOWorkflow aTFBOWorkflow = new TFBOWorkflow();
		String assignStatus = "";
		
		assignStatus = aTFBOWorkflow.getAssignStatus(newStepName);
		aTFBOHomeDAO.insertIntoTFBOStepHist(stepName, newStatus,
				userVo.getRequestId(), userVo.getSessionUserName());
		aTFBOHomeDAO.updateTFBOTransStatus(stepName, newStatus,
				userVo.getRequestId());
		
		aTFBOHomeDAO.updateTFBOTransUser(stepName, userVo.getSessionUserName(),
				userVo.getRequestId());
		
		
		aTFBOHomeDAO.insertIntoTFBOStepHist(newStepName, assignStatus,
				userVo.getRequestId(), ActionConstants.SYSTEMUSER);
		aTFBOHomeDAO.updateTFBOTransStatus(newStepName, assignStatus,
				userVo.getRequestId());
		
		if (aCommonMethods.isValueAvailable(userVo.userComment)) {
			aTFBOHomeDAO.setTFBOUserComments(userVo.requestId,
					userVo.userComment, stepName, userVo.sessionUserName);

		}
		
		
	}
	
	
	public void fboCheckerSubmitTransaction(UserTransactionVO userVo,
			String newStatus, String newStepName, String stepName) throws Exception {
		TFBOHomeDAO aTFBOHomeDAO = new TFBOHomeDAO();
		CommonMethods aCommonMethods = new CommonMethods();
		TFBOWorkflow aTFBOWorkflow = new TFBOWorkflow();
		String assignStatus = "";
		
		assignStatus = aTFBOWorkflow.getAssignStatus(newStepName);
		aTFBOHomeDAO.insertIntoTFBOStepHist(stepName, newStatus,
				userVo.getRequestId(), userVo.getSessionUserName());
		aTFBOHomeDAO.updateTFBOTransStatus(stepName, newStatus,
				userVo.getRequestId());
		
		aTFBOHomeDAO.updateTFBOTransUser(stepName, userVo.getSessionUserName(),
				userVo.getRequestId());
		
		
		aTFBOHomeDAO.insertIntoTFBOStepHist(newStepName, assignStatus,
				userVo.getRequestId(), ActionConstants.SYSTEMUSER);
		aTFBOHomeDAO.updateTFBOTransStatus(newStepName, assignStatus,
				userVo.getRequestId());
		
		if(aCommonMethods.isValueAvailable(userVo.userComment)) {
				aTFBOHomeDAO.setTFBOUserComments(userVo.requestId,
						userVo.userComment, stepName, userVo.sessionUserName);
			}
		if(aCommonMethods.isValueAvailable(userVo.getSentMailToBranch()))
				if (userVo.getSentMailToBranch().equals("true")) {
					aTFBOHomeDAO.sentMailToBranch(userVo);
				}
	}
	
	
	// Added by Kamakshya for SAC transaction start

		public void validateSACTransaction(UserTransactionVO userVo) throws Exception {
			logger.info(ActionConstants.ENTERING_METHOD);
			DBHelper aDBHelper = new DBHelper();
			CommonMethods aCommonMethods = new CommonMethods();
			List<AlertMessagesVO> errorDetailList = new LinkedList<AlertMessagesVO>();
			String userNameSAC = userVo.getUserNameSAC();
			String requestIDSAC = userVo.getRequestIDSAC();
			try {
//				if(aDBHelper.checkSACTransaction(userNameSAC.trim(), requestIDSAC,
//						ActionConstants.CHECKSACTRN)){
					aDBHelper.updateSACTransaction(userNameSAC, requestIDSAC);
					//SUCCESSFULLY UPDATED MESSAGE - ERRORCODE114
					errorDetailList = aCommonMethods.setErrorInList(
							ActionConstants.ERRORCODE114, errorDetailList);
					userVo.setErrorDetailsList(errorDetailList);
					System.out.println("Inside valid checkSACTransaction");
					
//				}
			}
				
			catch (Exception e) {
				System.out.println("Inside Error");
				errorDetailList = aCommonMethods.setErrorInList(
						ActionConstants.ERRORCODE113, errorDetailList);
				userVo.setErrorDetailsList(errorDetailList);
				e.printStackTrace();
			}
		    
				}

	// Added by Kamakshya for SAC transaction alert end

	//ADDED BY KAMAKSHYA STARTS--> code  to be un comment
		//RESET FLAG TO 0 IN DBLOG AFTER LOGOUT ----// 
		public void logOutSessionUser(UserTransactionVO userVo){
			CommonMethods aCommonMethods = new CommonMethods();
			DBHelper aDBHelper = new DBHelper();
			String userName = userVo.getSessionUserName();
			try {
				int flag = 0;
				aDBHelper.updateDBLOG(userName, flag,
						ActionConstants.UPDATELOGOUTSTAMP);
				aCommonMethods.closeWindow();
//				System.out.println("localisation 4");
			}catch (Exception e) {
				e.printStackTrace();
			}
		}
		//ADDED BY KAMAKSHYA ENDS-->
		
		public String getStepPhaseFromTi(String requestId) throws Exception {
			
			TFBOHomeDAO aTFBOHomeDAO = new TFBOHomeDAO();
			String stepPhase = "";
			try {
				stepPhase = aTFBOHomeDAO.getStepPhaseFromDB(requestId);
			} catch (Exception e) {
				e.printStackTrace();
				throw e;
			}
			logger.info(ActionConstants.ENTERING_METHOD);
			return stepPhase;
		}
		
}
