package com.ett.bob.tfbo.dbutil;

import java.io.InputStream;
import java.util.Properties;

public class PropertyUtil {

	public static Properties getPropertiesValue() throws Exception {
		InputStream aInputStream = null;
		Properties aProperties = new Properties();
		try {
			aInputStream = PropertyUtil.class
					.getClassLoader()
					.getResourceAsStream(
							"com/ett/bob/tfbo/resources/TFBOProperties.properties");
			aProperties.load(aInputStream);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (aInputStream != null) {
				aInputStream.close();
			}
		}
		return aProperties;
	}
}
