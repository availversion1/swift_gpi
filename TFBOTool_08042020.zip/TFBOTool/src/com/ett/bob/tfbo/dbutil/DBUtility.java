package com.ett.bob.tfbo.dbutil;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Properties;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

import org.apache.log4j.Logger;

public class DBUtility {
	private static Logger logger = Logger.getLogger(DBUtility.class.getName());

	public static Connection getGlobalConnection() throws Exception {
		Connection aConnection = null;
		Properties aProperties;
		aProperties = PropertyUtil.getPropertiesValue();
		String isJNDIConn = aProperties.getProperty("isJNDIConn");
		logger.info("isJNDIConn-->" + isJNDIConn);
		if (isJNDIConn.equalsIgnoreCase("true")) {
			Properties bProperties = new Properties();
			// WebSphere
			/*bProperties.put(Context.INITIAL_CONTEXT_FACTORY,
					"com.ibm.websphere.naming.WsnInitialContextFactory");*/
			// WebLogic
			 bProperties.put(Context.INITIAL_CONTEXT_FACTORY,
			 "weblogic.jndi.WLInitialContextFactory");
			Context initialContext = new InitialContext(bProperties);
			DataSource dataSource = (DataSource) initialContext
					.lookup("jdbc/global");
			aConnection = dataSource.getConnection();
		} else {
			String driver = aProperties.getProperty("DriverClass");
			String url = aProperties.getProperty("Url");
			String globalUserName = aProperties.getProperty("GlobalUserName");
			String password = aProperties.getProperty("Password");
			Class.forName(driver);
			aConnection = DriverManager.getConnection(url, globalUserName,
					password);
		}
		logger.info("Exiting getDBConnection method aConnection-->"
				+ aConnection);
		return aConnection;
	}

	public static Connection getZoneConnection() throws Exception {
		Connection aConnection = null;
		Properties aProperties;
		aProperties = PropertyUtil.getPropertiesValue();
		String isJNDIConn = aProperties.getProperty("isJNDIConn");
		if (isJNDIConn.equalsIgnoreCase("true")) {
			Properties bProperties = new Properties();
			// WebSphere
			bProperties.put(Context.INITIAL_CONTEXT_FACTORY,
					"com.ibm.websphere.naming.WsnInitialContextFactory");
			// WebLogic
//			 bProperties.put(Context.INITIAL_CONTEXT_FACTORY,
//			 "weblogic.jndi.WLInitialContextFactory");
			Context initialContext = new InitialContext(bProperties);
			DataSource dataSource = (DataSource) initialContext
					.lookup("jdbc/zone");
			aConnection = dataSource.getConnection();
		} else {
			String driver = aProperties.getProperty("DriverClass");
			String url = aProperties.getProperty("Url");
			String globalUserName = aProperties.getProperty("UserName");
			String password = aProperties.getProperty("Password");
			Class.forName(driver);
			aConnection = DriverManager.getConnection(url, globalUserName,
					password);
		}
		logger.info("Exiting getDBConnection method aConnection-->"
				+ aConnection);
		return aConnection;
	}
	
	
	public static Connection getThemeConnection() throws Exception {
		Connection aConnection = null;
		Properties aProperties;
		aProperties = PropertyUtil.getPropertiesValue();
		String isJNDIConn = aProperties.getProperty("isJNDIConn");
		if (isJNDIConn.equalsIgnoreCase("true")) {
			Properties bProperties = new Properties();
			// WebSphere
//			bProperties.put(Context.INITIAL_CONTEXT_FACTORY,
//					"com.ibm.websphere.naming.WsnInitialContextFactory");
			// WebLogic
			 bProperties.put(Context.INITIAL_CONTEXT_FACTORY,
			 "weblogic.jndi.WLInitialContextFactory");
			Context initialContext = new InitialContext(bProperties);
			DataSource dataSource = (DataSource) initialContext
					.lookup("jdbc/themebridge");
			aConnection = dataSource.getConnection();
		} else {
			String driver = aProperties.getProperty("DriverClass");
			String url = aProperties.getProperty("Url");
			String globalUserName = aProperties.getProperty("ThemeUserName");
			String password = aProperties.getProperty("Password");
			Class.forName(driver);
			aConnection = DriverManager.getConnection(url, globalUserName,
					password);
		}
		logger.info("Exiting getDBConnection method aConnection-->"
				+ aConnection);
		return aConnection;
	}

	public static void surrenderDB(Connection aConnection,
			PreparedStatement aPreparedStatement, ResultSet aResultSet) {
		logger.info("Surrendering DB method");
		try {
			if (aResultSet != null)
				aResultSet.close();
			if (aPreparedStatement != null)
				aPreparedStatement.close();
			if (aConnection != null)
				aConnection.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
