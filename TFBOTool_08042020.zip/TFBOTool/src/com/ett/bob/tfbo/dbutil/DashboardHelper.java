package com.ett.bob.tfbo.dbutil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.LinkedList;
import java.util.List;

import org.apache.log4j.Logger;

import com.ett.bob.tfbo.commonutil.CommonMethods;
import com.ett.bob.tfbo.model.TFBODashboardCountVO;
import com.ett.bob.tfbo.util.ActionConstants;

public class DashboardHelper {
	private static Logger logger = Logger.getLogger(DashboardHelper.class
			.getName());

	public List<TFBODashboardCountVO> getEachRowCount(int sno,
			String lableName, String query) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD + "getValueFromDB");
		List<TFBODashboardCountVO> eachRowCount = new LinkedList<TFBODashboardCountVO>();
		TFBODashboardCountVO aTFBODashboardVO = new TFBODashboardCountVO();
		CommonMethods aCommonMethods = new CommonMethods();
		String resultValue = null;
		String resultValue1 = null;
		String resultValue2 = null;
		String resultValue3 = null;
		String resultValue5 = null;
		String resultValue4 = null;
		Connection aConnection = null;
		ResultSet aResultSet = null;
		PreparedStatement aPreparedStatement = null;
		int ilcCount = 0;
		int elcCount = 0;
		int idcCount = 0;
		int odcCount = 0;
		int felCount = 0;
		int focCount = 0;
		int fsaCount = 0;
		int isbCount = 0;
		int cpcoCount = 0;
		int igtCount = 0;
		// Miscellanous changes starts 08-01-2020
		int corCount = 0;
		// Miscellanous changes ends 08-01-2020
		// Inward Remittance changes 23-12-2019 starts
		int cpciCount = 0;
		// Inward Remittance changes 23-12-2019 ends
		int idcDirectCount = 0;
		int idcIndirectCount = 0;
		int odcIndirectCount = 0;
		int odcDirectMtFull = 0;
		int odcDirectMtNonPart = 0;
		int odcDirectSameDFinYes = 0;
		int odcDirectSameDFinNo = 0;
		int subFullPay = 0;
		int elcFinSameDayYes = 0;
		int elcFinSameDayNo = 0;

		try {
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);
			logger.info("query-->" + query);
			
			aResultSet = aPreparedStatement.executeQuery();
			while (aResultSet.next()) {
				resultValue = aResultSet.getString(1).trim();
				resultValue1 = aResultSet.getString(2);// DIRECT COLUMN
				resultValue2 = aResultSet.getString(4);// MTRECEIVED COLUMN
				resultValue3 = aResultSet.getString(5);// FINSAMEDAY COLUMN
				resultValue4 = aResultSet.getString(6);// PARTPAYMENT COLUMN
				resultValue5 = aResultSet.getString(7);// SUBPRODUCTCODE COLUMN
				if (resultValue.equalsIgnoreCase("ILC")) {
					ilcCount++;
				}
				// Miscellanous changes starts 08-01-2020
				if (resultValue.equalsIgnoreCase("COR")) {
					logger.info("Entering if condition of MIS in each row count==>"
							+ corCount);
					corCount++;
				}
				// Miscellanous changes ends 08-01-2020
				if (resultValue.equalsIgnoreCase("ELC")) {
					elcCount++;
					if (resultValue3 != null
							&& resultValue3.trim().equals("Yes")) {
						elcFinSameDayYes++;
					}else{
						elcFinSameDayNo++;
					}
				}
				/*
				 * if (resultValue.equalsIgnoreCase("IDC")) { idcCount++; }
				 */
				if (resultValue.equalsIgnoreCase("IDC")) {
					idcCount++;
					// CHANGED BY CHANDRU
					if (resultValue1 != null && !resultValue1.trim().equals("")) {
						if (resultValue1.trim().equalsIgnoreCase("true")) {
							idcDirectCount++;
						} else {
							idcIndirectCount++;
						}
					} else {
						idcIndirectCount++;
					}
					// ENDS
				}
				/*
				 * if (resultValue.equalsIgnoreCase("ODC")) { odcCount++; }
				 */
				
				/*COMMENTED ON 07-02-2020*/
				/*if (resultValue.equalsIgnoreCase("ODC")) {
					odcCount++;

					// CHANGED BY CHANDRU
					if (aCommonMethods.isValueAvailable(resultValue1)) {
						if (resultValue1.trim().equalsIgnoreCase("true")) {
							if (aCommonMethods.isValueAvailable(resultValue2)) {
								if (resultValue2.trim().equalsIgnoreCase(
										"Full Amount")) {
									odcDirectMtFull++;
								} else {
									if (aCommonMethods
											.isValueAvailable(resultValue3)) {
										if (resultValue3.trim().equals("Yes")) {
											odcDirectSameDFinYes++;
										} else {
											odcDirectSameDFinNo++;
										}
									} else {
										odcDirectSameDFinNo++;
									}
								}
							} else {
								odcDirectMtNonPart++;
							}
						} else if (resultValue5 != null
								&& resultValue5.trim().equals("FBA")) {
							subFullPay++;
						} else {
							odcIndirectCount++;
						}
					} else {
						odcIndirectCount++;
					}
				}*/
				/*COMMENTED ON 07-02-2020*/
				if (resultValue.equalsIgnoreCase("ODC")) {
					odcCount++;
					// CHANGED BY CHANDRU
					if (aCommonMethods.isValueAvailable(resultValue1)) {
						if (resultValue1.trim().equalsIgnoreCase("true")) {
							if (aCommonMethods.isValueAvailable(resultValue2)) {
								if (resultValue2.trim().equalsIgnoreCase(
										"Full Amount")) {
									odcDirectMtFull++;
								} else {
									if (aCommonMethods
											.isValueAvailable(resultValue3)) {
										if (resultValue3.trim().equals("Yes")) {
											odcDirectSameDFinYes++;
										} else {
											odcDirectMtNonPart++;//NEW CHANGE
										}
									} else {
										odcDirectMtNonPart++;//NEW CHANGE
									}
								}
							} else {
								odcDirectMtNonPart++;
							}
						}
						// NEWLY CHANGE
						else if (aCommonMethods.
								isValueAvailable(resultValue3)) {
							if (resultValue3.equals("Yes")) {
								odcDirectSameDFinYes++;
							}
						}
						//NEWLY CHANGE
						else if (resultValue5 != null
								&& resultValue5.trim().equals("FBA")) {
							subFullPay++;
						} else {
							odcIndirectCount++;
						}
					} else {
						odcIndirectCount++;
					}
				}
				if (resultValue.equalsIgnoreCase("FEL")) {
					felCount++;
				}
				if (resultValue.equalsIgnoreCase("FOC")) {
					focCount++;
				}
				if (resultValue.equalsIgnoreCase("FSA")) {
					fsaCount++;
				}
				if (resultValue.equalsIgnoreCase("ISB")) {
					isbCount++;
				}
				if (resultValue.equalsIgnoreCase("CPCO")) {
					cpcoCount++;
				}
				if (resultValue.equalsIgnoreCase("IGT")) {
					igtCount++;
				}
				// Inward Remittance changes 23-12-2019 starts
				/* if (resultValue.equalsIgnoreCase("CPCI")) { */
				if (resultValue.equalsIgnoreCase("CPCI")
						|| resultValue.equalsIgnoreCase("CPBI")) {
					cpciCount++;
				}

				// Inward Remittance changes 23-12-2019 ends
			}
			aTFBODashboardVO.setIlcCount(ilcCount);
			aTFBODashboardVO.setElcCount(elcCount);
			aTFBODashboardVO.setIdcCount(idcCount);
			aTFBODashboardVO.setOdcCount(odcCount);
			aTFBODashboardVO.setFelCount(felCount);
			aTFBODashboardVO.setFocCount(focCount);
			aTFBODashboardVO.setFsaCount(fsaCount);
			aTFBODashboardVO.setIsbCount(isbCount);
			aTFBODashboardVO.setCpcoCount(cpcoCount);
			aTFBODashboardVO.setIgtCount(igtCount);
			// Inward Remittance changes 23-12-2019 starts
			aTFBODashboardVO.setCpciCount(cpciCount);
			// Inward Remittance changes 23-12-2019 ends
			aTFBODashboardVO.setLableName(lableName);
			aTFBODashboardVO.setSno(sno);
			// Miscellanous changes starts 08-01-2020
			aTFBODashboardVO.setCorCount(corCount);
			// Miscellanous changes ends 08-01-2020
			/*
			 * // CHANGED BY CHANDRU
			 * aTFBODashboardVO.setIdcDirectCount(idcDirectCount);
			 * aTFBODashboardVO.setIdcInDirectCount(idcIndirectCount);
			 */

			// CHANGED BY CHANDRU
			// FOR IDC
			aTFBODashboardVO.setIdcDirectCount(idcDirectCount);
			aTFBODashboardVO.setIdcInDirectCount(idcIndirectCount);

			// FOR ODC
			aTFBODashboardVO.setOdcDirectMtFull(odcDirectMtFull);
			aTFBODashboardVO.setOdcDirectMtNonPart(odcDirectMtNonPart);
			aTFBODashboardVO.setOdcDirectSameDFinNo(odcDirectSameDFinNo);
			aTFBODashboardVO.setOdcDirectSameDFinYes(odcDirectSameDFinYes);
			aTFBODashboardVO.setOdcInDirectCount(odcIndirectCount);
			aTFBODashboardVO.setSubFullPay(subFullPay);
			aTFBODashboardVO.setElcFinSameDayNo(elcFinSameDayNo);
			aTFBODashboardVO.setElcFinSameDayYes(elcFinSameDayYes);
			// CHANGED BY CHANDRU

			// CHANGED BY CHANDRU
			eachRowCount.add(aTFBODashboardVO);

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}
		logger.info(ActionConstants.EXITING_METHOD + "getValueFromDB");
		return eachRowCount;
	}

	public List<TFBODashboardCountVO> getEachRowCountDUMMY(int sno,
			String lableName, String query, String query1, String query2)
			throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD + "getValueFromDB");
		List<TFBODashboardCountVO> eachRowCount = new LinkedList<TFBODashboardCountVO>();
		TFBODashboardCountVO aTFBODashboardVO = new TFBODashboardCountVO();
		TFBODashboardCountVO aTFBODashboardVO1 = new TFBODashboardCountVO();
		String resultValue = null;
		String resultValue1 = null;
		String resultValue2 = null;
		String resultValue3 = null;
		Connection aConnection = null;
		ResultSet aResultSet = null;
		PreparedStatement aPreparedStatement = null;
		int ilcCount = 0;
		int elcCount = 0;
		int idcCount = 0;
		int odcCount = 0;
		int felCount = 0;
		int focCount = 0;
		int fsaCount = 0;
		int isbCount = 0;
		int cpcoCount = 0;
		int igtCount = 0;
		int misDataCount = 0;
//		int misData = 0;
		int corCount = 0;
		int cpciCount = 0;
		int idcDirectCount = 0;
		int idcIndirectCount = 0;
		int odcIndirectCount = 0;
		int odcDirectMtFull = 0;
		int odcDirectSameDFinYes = 0;
		int odcDirectSameDFinNo = 0;
		int odcDirectMtNonPart = 0;
		int subFullPay = 0;
		int elcFinSameDayYes = 0;
		int elcFinSameDayNo = 0;
		
		try {
			
			
			/*aTFBODashboard1 = getCount(query,"ILC");
			ilcCount = aTFBODashboard1.getSno();
			aTFBODashboard1 = getCount(query,"ELC");
			elcCount = aTFBODashboard1.getSno();
			aTFBODashboard1 = getCount(query,"IDC");
			idcIndirectCount = aTFBODashboard1.getIdcInDirectCount();
			aTFBODashboard1 = getCount(query,"ODC");
			odcIndirectCount = aTFBODashboard1.getIdcInDirectCount();
			subFullPay = aTFBODashboard1.getSubFullPay();
			aTFBODashboard1 = getCount(query,"IGT");
			igtCount = aTFBODashboard1.getSno();
			aTFBODashboard1 = getCount(query,"ISB");
			isbCount = aTFBODashboard1.getSno();
			aTFBODashboard1 = getCount(query,"CPCI");
			cpciCount = aTFBODashboard1.getSno();
			aTFBODashboard1 = getCount(query,"CPCO");
			cpcoCount = aTFBODashboard1.getSno();
			aTFBODashboard1 = getCount(query,"FSA");
			fsaCount = aTFBODashboard1.getSno();
			aTFBODashboard1 = getCount(query,"FEL");
			felCount = aTFBODashboard1.getSno();
			aTFBODashboard1 = getCount(query,"FOC");
			focCount = aTFBODashboard1.getSno();
			aTFBODashboard1 = getCount(query,"COR");
			corCount = aTFBODashboard1.getSno();*/
			
			
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);
			logger.info("query-->" + query);
			aResultSet = aPreparedStatement.executeQuery();
			while (aResultSet.next()) {
				resultValue = aResultSet.getString(1).trim();
				resultValue1 = aResultSet.getString(2);// DIRECT COLUMN
				resultValue2 = aResultSet.getString(4);// FBA COLUMN
				resultValue3 = aResultSet.getString(5);// FINANCE SAME DAY
				if (resultValue.equalsIgnoreCase("ILC")) {
					ilcCount++;
				}
				// Miscellanous changes starts 08-01-2020
				if (resultValue.equalsIgnoreCase("COR")) {
					logger.info("Entering if condition of MIS in each row count==>"
							+ corCount);
					corCount++;
				}
				// Miscellanous changes ends 08-01-2020
				if (resultValue.equalsIgnoreCase("ELC")) {
					elcCount++;
					if (resultValue3 != null
							&& resultValue3.trim().equals("Yes")) {
						System.out.println("Finance Same Day - Yes");
					}else{
						elcFinSameDayNo++;
					}
				}
				if (resultValue.equalsIgnoreCase("IDC")) {
					idcCount++;
					// CHANGED BY CHANDRU
					if (resultValue1 != null && !resultValue1.trim().equals("")) {
						if (resultValue1.trim().equalsIgnoreCase("true")) {
							System.out.println("Method Calling");
						} else {
							idcIndirectCount++;
						}
					} else {
						idcIndirectCount++;
					}
					// ENDS
				}
				
				
				if (resultValue.equalsIgnoreCase("ODC")) {
					odcCount++;
					// CHANGED BY CHANDRU
					if (resultValue1 != null && !resultValue1.trim().equals("")) {
						if (resultValue1.trim().equalsIgnoreCase("true")) {
							System.out.println("Direct True");
						} else if (resultValue2 != null
								&& resultValue2.trim().equals("FBA")) {
							subFullPay++;
						}
						// NEW CHANGE
						else if (resultValue3 != null
								&& resultValue3.trim().equals("Yes")) {
							System.out.println("Finance Same Day - Yes");
						}
						// NEW CHANGE
						else {
							odcIndirectCount++;
						}
					}
					// NEW CHANGE
					else if (resultValue3 != null
							&& resultValue3.trim().equals("Yes")) {
						System.out.println("Finance Same Day - Yes");
					}
					// NEW CHANGE
					else if (resultValue2 != null
							&& resultValue2.trim().equals("FBA")) {
						subFullPay++;
					} else {
						odcIndirectCount++;
					}
					// ENDS
					System.out.println("odcIndirectCount--->"
							+ odcIndirectCount);

				}
				
				if (resultValue.equalsIgnoreCase("FEL")) {
					felCount++;
				}
				if (resultValue.equalsIgnoreCase("FOC")) {
					focCount++;
				}
				if (resultValue.equalsIgnoreCase("FSA")) {
					fsaCount++;
				}
				if (resultValue.equalsIgnoreCase("ISB")) {
					isbCount++;
				}
				if (resultValue.equalsIgnoreCase("CPCO")) {
					cpcoCount++;
				}
				if (resultValue.equalsIgnoreCase("IGT")) {
					igtCount++;
				}
				if (resultValue.equalsIgnoreCase("CPCI")
						|| resultValue.equalsIgnoreCase("CPBI")) {
					cpciCount++;
				}
			}
			
			//FOR IDC
			aTFBODashboardVO1 = getEachRowCountForTIIDCCLP(query1);
			idcDirectCount = aTFBODashboardVO1.getIdcCount();
			
			//FOR MISC
			aTFBODashboardVO = getEachRowCountForTFBOMIS(query2);
			misDataCount = aTFBODashboardVO.getMisData();
			
			//FOR ODC
			// odcDirectCount = aTFBODashboardVO1.getOdcCount();
			odcDirectMtFull = aTFBODashboardVO1.getOdcDirectMtFull();
			odcDirectMtNonPart = aTFBODashboardVO1.getOdcDirectMtNonPart();
			odcDirectSameDFinNo = aTFBODashboardVO1.getOdcDirectSameDFinNo();
			odcDirectSameDFinYes = aTFBODashboardVO1.getOdcDirectSameDFinYes();

			//FOR ELC
			elcFinSameDayYes = aTFBODashboardVO1.getElcFinSameDayYes();
			aTFBODashboardVO.setElcFinSameDayYes(elcFinSameDayYes);
			aTFBODashboardVO.setElcFinSameDayNo(elcFinSameDayNo);
			
			
			aTFBODashboardVO.setOdcInDirectCount(odcIndirectCount);
			aTFBODashboardVO.setOdcDirectMtFull(odcDirectMtFull);
			aTFBODashboardVO.setOdcDirectMtNonPart(odcDirectMtNonPart);
			aTFBODashboardVO.setOdcDirectSameDFinNo(odcDirectSameDFinNo);
			aTFBODashboardVO.setOdcDirectSameDFinYes(odcDirectSameDFinYes);
			aTFBODashboardVO.setSubFullPay(subFullPay);

			// CHANGED BY CHANDRU

			aTFBODashboardVO.setIlcCount(ilcCount);
			aTFBODashboardVO.setElcCount(elcCount);
			aTFBODashboardVO.setIdcCount(idcCount);
			aTFBODashboardVO.setOdcCount(odcCount);
			aTFBODashboardVO.setFelCount(felCount);
			aTFBODashboardVO.setFocCount(focCount);
			aTFBODashboardVO.setFsaCount(fsaCount);
			aTFBODashboardVO.setIsbCount(isbCount);
			aTFBODashboardVO.setCpcoCount(cpcoCount);
			aTFBODashboardVO.setIgtCount(igtCount);
			aTFBODashboardVO.setCpciCount(cpciCount);
			if(lableName.equalsIgnoreCase("Transaction Pending for Entry in FBTI"))
				aTFBODashboardVO.setLableName("Transaction Pending for Entry in Baroda Insta");
			else if(lableName.equalsIgnoreCase("Transaction Pending for Approval in FBTI"))
				aTFBODashboardVO.setLableName("Transaction Pending for Approval in Baroda Insta");
			else
				aTFBODashboardVO.setLableName(lableName);
//			aTFBODashboardVO.setLableName(lableName);
			aTFBODashboardVO.setSno(sno);
			aTFBODashboardVO.setCorCount(corCount + misDataCount);
			// CHANGED BY CHANDRU
			aTFBODashboardVO.setIdcDirectCount(idcDirectCount);
			aTFBODashboardVO.setIdcInDirectCount(idcIndirectCount);
			// CHANGED BY CHANDRU
			eachRowCount.add(aTFBODashboardVO);

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}
		logger.info(ActionConstants.EXITING_METHOD + "getValueFromDB");
		return eachRowCount;
	}

	public List<TFBODashboardCountVO> getEachRowCountDUMMYFLAG(int sno,
			String lableName, String query, String query1, String query2,
			String query3, String query4,String query5) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD + "getValueFromDB");
		List<TFBODashboardCountVO> eachRowCount = new LinkedList<TFBODashboardCountVO>();
		TFBODashboardCountVO aTFBODashboardVO = new TFBODashboardCountVO();
		TFBODashboardCountVO aTFBODashboardVO1 = new TFBODashboardCountVO();
		TFBODashboardCountVO aTFBODashboardVO2 = new TFBODashboardCountVO();
		TFBODashboardCountVO aTFBODashboardVO3 = new TFBODashboardCountVO();
		String resultValue = null;
		String resultValue1 = null;
		String resultValue2 = null;
		String resultValue3 = null;
		Connection aConnection = null;
		ResultSet aResultSet = null;
		PreparedStatement aPreparedStatement = null;
		int ilcCount = 0;
		int misDataCount = 0;
		int elcCount = 0;
		int idcCount = 0;
		int odcCount = 0;
		int felCount = 0;
		int focCount = 0;
		int fsaCount = 0;
		int isbCount = 0;
		int cpcoCount = 0;
		int igtCount = 0;
		int corCount = 0;
		int cpciCount = 0;
		int idcDirectCount = 0;
		int idcIndirectCount = 0;
		int idcCheck = 0;
		int odcIndirectCount = 0;
		int subFullPay = 0;
		int odcDirectMtFull = 0;
		int odcDirectMtNonPart = 0;
		int odcDirectSameDFinNo = 0;
		int odcDirectSameDFinYes = 0;
		int mtFullPayQueue = 0;
		int subFullPayQueue = 0;
		int FinSameDayQueue = 0;
		int elcFinSameDayYes = 0;
		int elcFinSameDayNo = 0;
		int elcFinSameDayYesQueue = 0;
		try {
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);
			logger.info("query-->" + query);
			aResultSet = aPreparedStatement.executeQuery();
			while (aResultSet.next()) {
				resultValue = aResultSet.getString(1).trim();
				resultValue1 = aResultSet.getString(2);// DIRECT COLUMN
				resultValue2 = aResultSet.getString(4);//FOR SUBPRODUCTCODE
				resultValue3 = aResultSet.getString(5);//FOR FINSAMEDAY
				
				if (resultValue.equalsIgnoreCase("ILC")) {
					ilcCount++;
				}
				if (resultValue.equalsIgnoreCase("COR")) {
					logger.info("Entering if condition of MIS in each row count==>"
							+ corCount);
					corCount++;
				}
				// Miscellanous changes ends 08-01-2020
				if (resultValue.equalsIgnoreCase("ELC")) {
					elcCount++;
					if (resultValue3 != null
							&& resultValue3.trim().equals("Yes")) {
						System.out.println("Finance Same Day - Yes");
					}else{
						elcFinSameDayNo++;
					}
				}
				if (resultValue.equalsIgnoreCase("IDC")) {
					idcCount++;
					// CHANGED BY CHANDRU
					if (resultValue1 != null && !resultValue1.trim().equals("")) {
						if (resultValue1.trim().equalsIgnoreCase("true")) {
							System.out.println("Method Calling");
						} else {
							idcIndirectCount++;
						}
					} else {
						idcIndirectCount++;
					}
					// ENDS
				}
				

				if (resultValue.equalsIgnoreCase("ODC")) {// subFullPay
					/*
					 * odcCount++; // CHANGED BY CHANDRU if (resultValue1 !=
					 * null && !resultValue1.trim().equals("")) { if
					 * (resultValue1.trim().equalsIgnoreCase("true")) {
					 * System.out.println("Method Calling"); } else if
					 * (resultValue2 != null &&
					 * resultValue2.trim().equals("FBA")) { subFullPay++; } else
					 * { odcIndirectCount++; } } else if (resultValue2 != null
					 * && resultValue2.trim().equals("FBA")) { subFullPay++; }
					 * else { odcIndirectCount++; } // ENDS
					 */

					odcCount++;
					// CHANGED BY CHANDRU
					if (resultValue1 != null && !resultValue1.trim().equals("")) {
						if (resultValue1.trim().equalsIgnoreCase("true")) {
							System.out.println("Direct True");
						} else if (resultValue2 != null
								&& resultValue2.trim().equals("FBA")) {
							subFullPay++;
						}
						// NEW CHANGE
						else if (resultValue3 != null
								&& resultValue3.trim().equals("Yes")) {
							System.out.println("Finance Same Day - Yes");
						}
						// NEW CHANGE
						else {
							odcIndirectCount++;
						}
					}
					// NEW CHANGE
					else if (resultValue3 != null
							&& resultValue3.trim().equals("Yes")) {
						System.out.println("Finance Same Day - Yes");
					}
					// NEW CHANGE
					else if (resultValue2 != null
							&& resultValue2.trim().equals("FBA")) {
						subFullPay++;
					} else {
						odcIndirectCount++;
					}
					// ENDS
					System.out.println("odcIndirectCount--->"
							+ odcIndirectCount);

				}

				if (resultValue.equalsIgnoreCase("FEL")) {
					felCount++;
				}
				if (resultValue.equalsIgnoreCase("FOC")) {
					focCount++;
				}
				if (resultValue.equalsIgnoreCase("FSA")) {
					fsaCount++;
				}
				if (resultValue.equalsIgnoreCase("ISB")) {
					isbCount++;
				}
				if (resultValue.equalsIgnoreCase("CPCO")) {
					cpcoCount++;
				}
				if (resultValue.equalsIgnoreCase("IGT")) {
					igtCount++;
				}
				// Inward Remittance changes 23-12-2019 starts
				/* if (resultValue.equalsIgnoreCase("CPCI")) { */
				if (resultValue.equalsIgnoreCase("CPCI")
						|| resultValue.equalsIgnoreCase("CPBI")) {
					cpciCount++;
				}

				// Inward Remittance changes 23-12-2019 ends
			}

			/*
			 * aTFBODashboardVO = getEachRowCountForTIIDCCLP(query1);
			 * 
			 * idcDirectCount = aTFBODashboardVO.getIdcCount(); //
			 * odcDirectCount = aTFBODashboardVO.getOdcCount();
			 * 
			 * aTFBODashboardVO = getEachRowCountForTIIDCCLP(query2);
			 * 
			 * idcCheck = aTFBODashboardVO.getIdcCount(); // odcCheck =
			 * aTFBODashboardVO.getOdcCount();
			 */
			
			aTFBODashboardVO1 = getEachRowCountForTIIDCCLP(query1);

			idcDirectCount = aTFBODashboardVO1.getIdcCount();
			odcDirectMtFull = aTFBODashboardVO1.getOdcDirectMtFull();
			odcDirectMtNonPart = aTFBODashboardVO1.getOdcDirectMtNonPart();
			odcDirectSameDFinNo = aTFBODashboardVO1.getOdcDirectSameDFinNo();
			odcDirectSameDFinYes = aTFBODashboardVO1.getOdcDirectSameDFinYes();
			elcFinSameDayYes = aTFBODashboardVO1.getElcFinSameDayYes();
			

			aTFBODashboardVO2 = getEachRowCountForTIIDCCLP(query2);

			idcCheck = aTFBODashboardVO2.getIdcCount();
			mtFullPayQueue = aTFBODashboardVO2.getOdcDirectMtFull();
			subFullPayQueue = aTFBODashboardVO2.getSubFullPayQueue();

			//FOR ODC FINANCE SAME DAY QUEUE
			aTFBODashboardVO2 = getEachRowCountForTIDCFinSameDay(query3);
			FinSameDayQueue = aTFBODashboardVO2.getFinSameDayQueue();
			
			//FOR ELC FINANCE SAME DAY QUEUE
			aTFBODashboardVO3 = getEachRowCountForTIDCFinSameDay(query5);
			elcFinSameDayYesQueue = aTFBODashboardVO3.getFinSameDayQueue();
			
			aTFBODashboardVO = getEachRowCountForTFBOMIS(query4);
			misDataCount = aTFBODashboardVO.getMisData();

			

			// STARTS : CHANGED BY CHANDRU
			aTFBODashboardVO.setIdcDirectCount(idcDirectCount);
			aTFBODashboardVO.setIdcInDirectCount(idcIndirectCount);
			aTFBODashboardVO.setIdcCheck(idcCheck);

			// FOR ODC COMPLETED/INPROGRESS
			aTFBODashboardVO.setOdcInDirectCount(odcIndirectCount);
			aTFBODashboardVO.setOdcDirectMtFull(odcDirectMtFull);
			aTFBODashboardVO.setOdcDirectMtNonPart(odcDirectMtNonPart);
			aTFBODashboardVO.setOdcDirectSameDFinNo(odcDirectSameDFinNo);
			aTFBODashboardVO.setOdcDirectSameDFinYes(odcDirectSameDFinYes);
			aTFBODashboardVO.setSubFullPay(subFullPay);

			// FOR ODC QUEUE
			/*
			 * aTFBODashboardVO.setOdcDirectMtFull(mtFullPayQueue);
			 * aTFBODashboardVO.setOdcDirectSameDFinYes(FinSameDayQueue);
			 * aTFBODashboardVO.setSubFullPayQueue(subFullPayQueue);
			 */
			// FOR ODC QUEUE
			aTFBODashboardVO.setMtFullPayQueue(mtFullPayQueue);
			aTFBODashboardVO.setFinSameDayQueue(FinSameDayQueue);
			aTFBODashboardVO.setSubFullPayQueue(subFullPayQueue);

			
			//FOR ELC
			aTFBODashboardVO.setElcFinSameDayNo(elcFinSameDayNo);
			aTFBODashboardVO.setElcFinSameDayYes(elcFinSameDayYes);
			aTFBODashboardVO.setElcFinSameDayQueue(elcFinSameDayYesQueue);
			
			// ENDS : CHANGED BY CHANDRU

			aTFBODashboardVO.setIlcCount(ilcCount);
			aTFBODashboardVO.setElcCount(elcCount);
			aTFBODashboardVO.setIdcCount(idcCount);
			aTFBODashboardVO.setOdcCount(odcCount);
			aTFBODashboardVO.setFelCount(felCount);
			aTFBODashboardVO.setFocCount(focCount);
			aTFBODashboardVO.setFsaCount(fsaCount);
			aTFBODashboardVO.setIsbCount(isbCount);
			aTFBODashboardVO.setCpcoCount(cpcoCount);
			aTFBODashboardVO.setIgtCount(igtCount);
			aTFBODashboardVO.setCpciCount(cpciCount);
			if(lableName.equalsIgnoreCase("Approved-Completed in FBTI"))
				aTFBODashboardVO.setLableName("Approved-Completed in Baroda Insta");
			else 
				aTFBODashboardVO.setLableName(lableName);
//			aTFBODashboardVO.setLableName(lableName);
			aTFBODashboardVO.setSno(sno);
			aTFBODashboardVO.setCorCount(corCount + misDataCount);
			// CHANGED BY CHANDRU
			aTFBODashboardVO.setIdcDirectCount(idcDirectCount);
			aTFBODashboardVO.setIdcInDirectCount(idcIndirectCount);
			aTFBODashboardVO.setIdcCheck(idcCheck);
			// CHANGED BY CHANDRU
			eachRowCount.add(aTFBODashboardVO);

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}
		logger.info(ActionConstants.EXITING_METHOD + "getValueFromDB");
		return eachRowCount;
	}



	public TFBODashboardCountVO getEachRowCountForTIIDCCLP(String query)
			throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD + "getValueFromDB");
		String resultValue = "";
		String resultValue1 = "";
		String resultValue2 = "";
		String resultValue3 = "";
		String resultValue4 = "";
		TFBODashboardCountVO aTFBODashboard = new TFBODashboardCountVO();
		CommonMethods aCommonMethods = new CommonMethods();
		int idcDirectCount = 0;
		int odcDirectMtFull = 0;
		int odcDirectSameDFinYes = 0;
		int odcDirectSameDFinNo = 0;
		int odcDirectMtNonPart = 0;
		int subFullPayQueue = 0;
		int elcFinSameDayYes = 0;
		Connection aConnection = null;
		ResultSet aResultSet = null;
		PreparedStatement aPreparedStatement = null;
		try {
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);
			logger.info("query-->" + query);
			aResultSet = aPreparedStatement.executeQuery();
			while (aResultSet.next()) {
				resultValue = aResultSet.getString(1);
				resultValue1 = aResultSet.getString(2);
				resultValue2 = aResultSet.getString(3);
				resultValue3 = aResultSet.getString(4);
				resultValue4 = aResultSet.getString(5);
				if (resultValue.equals("IDC")) {
					if (aCommonMethods.isValueAvailable(resultValue1)
							&& resultValue1.trim().equals("true")) {
						idcDirectCount++;
					}
				}else if (resultValue.equals("ODC")){
					// CHANGED BY CHANDRU
					if (aCommonMethods.isValueAvailable(resultValue1)
							&& resultValue1.trim().equals("true")) {
						if (aCommonMethods.isValueAvailable(resultValue2)) {
							if (resultValue2.trim().equalsIgnoreCase(
									"Full Amount")) {
								odcDirectMtFull++;
							} else {
								if (aCommonMethods
										.isValueAvailable(resultValue3)) {
									if (resultValue3.trim().equals("Yes")) {
										odcDirectSameDFinYes++;
									} else {
										odcDirectMtNonPart++;//NEW CHANGE
									}
								} else {
									odcDirectMtNonPart++;//NEW CHANGE
								}
							}
						} else {
							odcDirectMtNonPart++;
						}
					}
					// NEWLY CHANGE
					else if (aCommonMethods.isValueAvailable(resultValue3)) {
						if (resultValue3.equals("Yes")) {
							odcDirectSameDFinYes++;
						}
					}
					// NEWLY CHANGE
					else if (aCommonMethods.isValueAvailable(resultValue4)
							&& resultValue4.trim().equals("FBA")) {
						subFullPayQueue++;
					}
				}else{
					if (aCommonMethods.isValueAvailable(resultValue3)) {
						if (resultValue3.equals("Yes")) {
							elcFinSameDayYes++;
						}
					}
				}
			}
			aTFBODashboard.setIdcCount(idcDirectCount);
			aTFBODashboard.setOdcDirectMtFull(odcDirectMtFull);
			aTFBODashboard.setOdcDirectMtNonPart(odcDirectMtNonPart);
			aTFBODashboard.setOdcDirectSameDFinNo(odcDirectSameDFinNo);
			aTFBODashboard.setOdcDirectSameDFinYes(odcDirectSameDFinYes);
			aTFBODashboard.setElcFinSameDayYes(elcFinSameDayYes);
			aTFBODashboard.setSubFullPayQueue(subFullPayQueue);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}
		logger.info(ActionConstants.EXITING_METHOD + "getValueFromDB");
		return aTFBODashboard;
	}

	public TFBODashboardCountVO getEachRowCountForTIDCFinSameDay(String query)
			throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD + "getValueFromDB");
		TFBODashboardCountVO aTFBODashboard = new TFBODashboardCountVO();
		int finSameDayQueue = 0;
		Connection aConnection = null;
		ResultSet aResultSet = null;
		PreparedStatement aPreparedStatement = null;
		try {
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);
			logger.info("query-->" + query);
			aResultSet = aPreparedStatement.executeQuery();
			while (aResultSet.next()) {
				finSameDayQueue = aResultSet.getInt(1);
			}
			aTFBODashboard.setFinSameDayQueue(finSameDayQueue);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}
		logger.info(ActionConstants.EXITING_METHOD + "getValueFromDB");
		return aTFBODashboard;
	}

	
	private TFBODashboardCountVO getEachRowCountForTFBOMIS(String query) {
		List<TFBODashboardCountVO> eachRowCount = new LinkedList<TFBODashboardCountVO>();
		TFBODashboardCountVO aTFBODashboard = new TFBODashboardCountVO();
		String resultValue = null;
		String resultValue1 = null;

		Connection aConnection = null;
		ResultSet aResultSet = null;
		PreparedStatement aPreparedStatement = null;
		int misData = 0;

		try {
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);
			logger.info("query-->" + query);
			aResultSet = aPreparedStatement.executeQuery();
			while (aResultSet.next()) {
				resultValue = aResultSet.getString(1).trim();

				if (resultValue.equalsIgnoreCase("COR")) {
					misData++;
				}
				aTFBODashboard.setMisData(misData);
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}

		return aTFBODashboard;
	}

	/*public TFBODashboardCountVO getCount(String query, String prodCode) {
		Connection conn = null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		TFBODashboardCountVO aTFBODashboard1 = new TFBODashboardCountVO();
		int count = 0;
		int idcIndirectCount = 0;
		int subFullPay = 0;
		int odcIndirectCount = 0;
		String resultValue = "";
		String resultValue1 = "";
		String resultValue2 = "";
		String resultValue3 = "";
		String resultValue4 = "";
		try {
			if (prodCode.equals("ILC"))
				query = query + " AND PRD.CODE79 = 'ILC' "
						+ " AND MAS.REFNO_PFIX = 'ILC' "
						+ " AND TFB.PRODUCTCODE = 'ILC' ";
			else if (prodCode.equals("ELC"))
				query = query + " AND PRD.CODE79 = 'ELC' "
						+ " AND MAS.REFNO_PFIX = 'ELC' "
						+ " AND TFB.PRODUCTCODE = 'ELC' ";
			else if (prodCode.equals("IDC"))
				query = query + " AND PRD.CODE79 = 'IDC' "
						+ " AND MAS.REFNO_PFIX = 'IDC' "
						+ " AND TFB.PRODUCTCODE = 'IDC' ";
			else if (prodCode.equals("ODC"))
				query = query + " AND PRD.CODE79 = 'ODC' "
						+ " AND MAS.REFNO_PFIX = 'ODC' "
						+ " AND TFB.PRODUCTCODE = 'ODC' ";
			else if (prodCode.equals("ISB"))
				query = query + " AND PRD.CODE79 = 'ISB' "
						+ " AND MAS.REFNO_PFIX = 'ISB' "
						+ " AND TFB.PRODUCTCODE = 'ISB' ";
			else if (prodCode.equals("ESB"))
				query = query + " AND PRD.CODE79 = 'ESB' "
						+ " AND MAS.REFNO_PFIX = 'ESB' "
						+ " AND TFB.PRODUCTCODE = 'ESB' ";
			else if (prodCode.equals("CPCI"))
				query = query + " AND PRD.CODE79 IN ('CPCI','CPBI') "
						+ " AND MAS.REFNO_PFIX = 'CPC' "
						+ " AND TFB.PRODUCTCODE = 'CPCI' ";
			else if (prodCode.equals("CPCO"))
				query = query + " AND PRD.CODE79 = 'CPCO' "
						+ " AND MAS.REFNO_PFIX = 'CPC' "
						+ " AND TFB.PRODUCTCODE = 'CPCO' ";
			else if (prodCode.equals("COR"))
				query = query + " AND PRD.CODE79 = 'COR' "
						+ " AND MAS.REFNO_PFIX = 'COR' "
						+ " AND TFB.PRODUCTCODE = 'COR' ";
			else if (prodCode.equals("FEL"))
				query = query + " AND PRD.CODE79 = 'FEL' "
						+ " AND MAS.REFNO_PFIX = 'FEL' "
						+ " AND TFB.PRODUCTCODE = 'FEL' ";
			else if (prodCode.equals("FOC"))
				query = query + " AND PRD.CODE79 = 'FOC' "
						+ " AND MAS.REFNO_PFIX = 'FOC' "
						+ " AND TFB.PRODUCTCODE = 'FOC' ";
			else if (prodCode.equals("FSA"))
				query = query + " AND PRD.CODE79 = 'FSA' "
						+ " AND MAS.REFNO_PFIX = 'FSA' "
						+ " AND TFB.PRODUCTCODE = 'FSA' ";
			else if (prodCode.equals("IGT"))
				query = query + " AND PRD.CODE79 = 'IGT' "
						+ " AND MAS.REFNO_PFIX = 'IGT' "
						+ " AND TFB.PRODUCTCODE = 'IGT' ";
			conn = DBUtility.getZoneConnection();
			pst = conn.prepareStatement(query);
			rs = pst.executeQuery();
			while (rs.next()) {
				resultValue = rs.getString(1).trim();
				resultValue1 = rs.getString(2);// DIRECT COLUMN
				resultValue2 = rs.getString(4);// FBA COLUMN
				resultValue3 = rs.getString(5);// FINANCE SAME DAY
				if (prodCode.equalsIgnoreCase("IDC")) {
					if (resultValue1 != null && !resultValue1.trim().equals("")) {
						if (resultValue1.trim().equalsIgnoreCase("true")) {
							System.out.println("Method Calling");
						} else {
							idcIndirectCount++;
						}
					} else {
						idcIndirectCount++;
					}
				} else if (prodCode.equalsIgnoreCase("ODC")) {
					if (resultValue1 != null && !resultValue1.trim().equals("")) {
						if (resultValue1.trim().equalsIgnoreCase("true")) {
							System.out.println("Direct True");
						} else if (resultValue2 != null
								&& resultValue2.trim().equals("FBA")) {
							subFullPay++;
						} else if (resultValue3 != null
								&& resultValue3.trim().equals("Yes")) {
							System.out.println("Finance Same Day - Yes");
						} else {
							odcIndirectCount++;
						}
					} else if (resultValue3 != null
							&& resultValue3.trim().equals("Yes")) {
						System.out.println("Finance Same Day - Yes");
					} else if (resultValue2 != null
							&& resultValue2.trim().equals("FBA")) {
						subFullPay++;
					} else {
						odcIndirectCount++;
					}
					System.out.println("odcIndirectCount--->"
							+ odcIndirectCount);

				} else {
					count++;
				}
				
				aTFBODashboard1.setIdcInDirectCount(idcIndirectCount);//FOR IDC
				aTFBODashboard1.setOdcInDirectCount(odcIndirectCount);//FOR ODC
				aTFBODashboard1.setSubFullPay(subFullPay);//FOR ODC
				aTFBODashboard1.setSno(count);//FOR ALL PRODUCTS
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBUtility.surrenderDB(conn, pst, rs);
		}
		return aTFBODashboard1;
	}*/

}
