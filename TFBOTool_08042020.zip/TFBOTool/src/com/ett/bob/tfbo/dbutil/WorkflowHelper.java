package com.ett.bob.tfbo.dbutil;

import org.apache.log4j.Logger;

import com.ett.bob.tfbo.commonutil.CommonMethods;
import com.ett.bob.tfbo.util.ActionConstants;

public class WorkflowHelper {
	private static Logger logger = Logger.getLogger(WorkflowHelper.class
			.getName());
	DBHelper aDBHelper = null;

	public String getFirstStepFromDB() throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD + "getFirstStep");
		aDBHelper = new DBHelper();
		String stepName = null;
		try {
			stepName = aDBHelper
					.getValueFromDB(ActionConstants.FIRSTSTEP_QUERY);
			logger.info("stepName-->" + stepName);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		logger.info(ActionConstants.EXITING_METHOD + "getFirstStep");
		return stepName;
	}

	public String getNextStepFromDB(String stepName) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD + "getNextStep");
		aDBHelper = new DBHelper();
		CommonMethods aCommonMethods = new CommonMethods();
		String nextStepID = null;
		String nextStepName = null;
		try {
			nextStepID = aDBHelper.getValueFromDB(stepName,
					ActionConstants.NEXTSTEPID_QUERY);
			if (!aCommonMethods.isValueAvailable(nextStepID)) {
				nextStepName = stepName;
				logger.info(ActionConstants.EXITING_METHOD + "getNextStep");
				return nextStepName;
			}
			nextStepName = aDBHelper.getValueFromDB(nextStepID,
					ActionConstants.GETSTEPNAME_QUERY);
			logger.info("nextStepName-->" + nextStepName);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		logger.info(ActionConstants.EXITING_METHOD + "getNextStep");
		return nextStepName;
	}

	public String getPreviousStepFromDB(String stepName) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD + "getPreviousStep");
		aDBHelper = new DBHelper();
		CommonMethods aCommonMethods = new CommonMethods();
		String previousStepID = null;
		String previousStepName = null;
		try {
			previousStepID = aDBHelper.getValueFromDB(stepName,
					ActionConstants.PREVIOUSSTEPID_QUERY);
			if (!aCommonMethods.isValueAvailable(previousStepID)) {
				previousStepName = stepName;
				logger.info(ActionConstants.EXITING_METHOD + "getPreviousStep");
				return previousStepName;
			}
			previousStepName = aDBHelper.getValueFromDB(previousStepID,
					ActionConstants.GETSTEPNAME_QUERY);
			logger.info("previousStepName-->" + previousStepName);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		logger.info(ActionConstants.EXITING_METHOD + "getPreviousStep");
		return previousStepName;
	}

	public String getAssignStatusFromDB(String stepName) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD + "getAssignStatus");
		aDBHelper = new DBHelper();
		String assignStatus = null;
		try {
			
			assignStatus = aDBHelper.getValueFromDB(stepName,
					ActionConstants.GETASSIGNSTATUS_QUERY);
			logger.info("assignStatus-->" + assignStatus);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		logger.info(ActionConstants.EXITING_METHOD + "getAssignStatus");
		return assignStatus;
	}

	public String getCompletedStatusFromDB(String stepName) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD + "getCompletedStatus");
		aDBHelper = new DBHelper();
		String completedStatus = null;
		try {
			completedStatus = aDBHelper.getValueFromDB(stepName,
					ActionConstants.GETCOMPLETESTATUS_QUERY);
			logger.info("completedStatus-->" + completedStatus);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		logger.info(ActionConstants.EXITING_METHOD + "getCompletedStatus");
		return completedStatus;
	}

	public String getRejectStatusFromDB(String stepName) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD + "getRejectStatus");
		aDBHelper = new DBHelper();
		CommonMethods aCommonMethods = new CommonMethods();
		String rejectStatus = null;
		try {
			rejectStatus = aDBHelper.getValueFromDB(stepName,
					ActionConstants.GETREJECTSTATUS_QUERY);
			if (!aCommonMethods.isValueAvailable(rejectStatus)) {
				rejectStatus = aDBHelper.getValueFromDB(stepName,
						ActionConstants.GETPENDSTATUS_QUERY);
				logger.info(ActionConstants.EXITING_METHOD + "getRejectStatus");
				return rejectStatus;
			}
			logger.info("rejectStatus-->" + rejectStatus);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		logger.info(ActionConstants.EXITING_METHOD + "getRejectStatus");
		return rejectStatus;
	}

	public String getAbortStatusFromDB(String stepName) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD + "getAbortStatus");
		aDBHelper = new DBHelper();
		String abortStatus = null;
		try {
			abortStatus = aDBHelper.getValueFromDB(stepName,
					ActionConstants.GETABORTSTATUS_QUERY);
			logger.info("abortStatus-->" + abortStatus);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		logger.info(ActionConstants.EXITING_METHOD + "getAbortStatus");
		return abortStatus;
	}

	public String getPendStatusFromDB(String stepName) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD + "getPendStatus");
		aDBHelper = new DBHelper();
		String pendStatus = null;
		try {
			pendStatus = aDBHelper.getValueFromDB(stepName,
					ActionConstants.GETPENDSTATUS_QUERY);
			logger.info("pendStatus-->" + pendStatus);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		logger.info(ActionConstants.EXITING_METHOD + "getPendStatus");
		return pendStatus;
	}

	public String getStepTeamFromDB(String stepName) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD + "getStepTeam");
		aDBHelper = new DBHelper();
		String stepTeam = null;
		try {
			stepTeam = aDBHelper.getValueFromDB(stepName,
					ActionConstants.GETSTEPTEAM_QUERY);
			logger.info("stepTeam-->" + stepTeam);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		logger.info(ActionConstants.EXITING_METHOD + "getStepTeam");
		return stepTeam;
	}
}
