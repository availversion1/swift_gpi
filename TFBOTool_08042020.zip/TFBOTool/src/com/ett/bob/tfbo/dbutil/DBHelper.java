package com.ett.bob.tfbo.dbutil;

import java.io.ByteArrayOutputStream;
import java.io.OutputStream;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
//import org.apache.poi.hssf.usermodel.HSSFCell;
//import org.apache.poi.hssf.usermodel.HSSFRow;
//import org.apache.poi.hssf.usermodel.HSSFSheet;
//import org.apache.poi.hssf.usermodel.HSSFWorkbook;
//import org.apache.poi.ss.usermodel.CellStyle;
//import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.struts2.ServletActionContext;

import com.ett.bob.tfbo.commonutil.CommonMethods;
import com.ett.bob.tfbo.model.BrabchProfileMgmt;
import com.ett.bob.tfbo.model.CustomerProfileManageVO;
import com.ett.bob.tfbo.model.DocumentUploadVO;
import com.ett.bob.tfbo.model.ProfileManagementVO;
import com.ett.bob.tfbo.model.ReportVO;
import com.ett.bob.tfbo.model.TFBOChecklistVO;
import com.ett.bob.tfbo.model.TFBOExportCollectionVO;
import com.ett.bob.tfbo.model.TFBOExportLcVO;
import com.ett.bob.tfbo.model.TFBOFinanceExportColVO;
import com.ett.bob.tfbo.model.TFBOFinanceExportLcVO;
import com.ett.bob.tfbo.model.TFBOFinanceStandaloneVO;
import com.ett.bob.tfbo.model.TFBOIdcVO;
import com.ett.bob.tfbo.model.TFBOImportGTVO;
import com.ett.bob.tfbo.model.TFBOImportLcVO;
import com.ett.bob.tfbo.model.TFBOInwardRemittanceVO;
import com.ett.bob.tfbo.model.TFBOMiscellanousVO;
import com.ett.bob.tfbo.model.TFBOOutwardRemittanceVO;
import com.ett.bob.tfbo.model.TFBOReminderVO;
import com.ett.bob.tfbo.model.TFBOSandbyLcVO;
import com.ett.bob.tfbo.model.TFBOTransVO;
import com.ett.bob.tfbo.model.UserCommentVO;
import com.ett.bob.tfbo.model.UserTransactionVO;
import com.ett.bob.tfbo.util.ActionConstants;
import com.opensymphony.xwork2.ActionContext;

public class DBHelper {
	private static Logger logger = Logger.getLogger(DBHelper.class.getName());

	// Changed by onsite team 26122019 starts
	/*
	 * public Boolean isValueAvailableInDB(String value, String query) {
	 * logger.info(ActionConstants.ENTERING_METHOD + "getValueFromDB"); Boolean
	 * resultValue = false; Connection aConnection = null; ResultSet aResultSet
	 * = null; PreparedStatement aPreparedStatement = null; try { aConnection =
	 * DBUtility.getZoneConnection(); aPreparedStatement =
	 * aConnection.prepareStatement(query); logger.info("query-->" + query);
	 * aPreparedStatement.setString(1, value.trim()); aResultSet =
	 * aPreparedStatement.executeQuery(); while (aResultSet.next()) { if
	 * (aResultSet.getInt(1) > 0) resultValue = true; } } catch (Exception e) {
	 * e.printStackTrace(); logger.info(ActionConstants.EXITING_METHOD +
	 * "getValueFromDB"); return resultValue; } finally {
	 * DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet); }
	 * logger.info(ActionConstants.EXITING_METHOD + "getValueFromDB"); return
	 * resultValue; }
	 */
	// ZIGZAG VALUE POPULATION 07012020 STARTS
	// FREEZING(SCENARIO) off shore team starts 31122019
	/*
	 * public List<TFBOIdcVO> getTFBOIImportIDCCLPDetailsFromDB(String
	 * requestId, String query) throws Exception {
	 * logger.info(ActionConstants.ENTERING_METHOD + " requestId->" +
	 * requestId); TFBOIdcVO aTFBOIdcVO = null; Connection aConnection = null;
	 * ResultSet aResultSet = null; PreparedStatement aPreparedStatement = null;
	 * List<TFBOIdcVO> idcPayment = new LinkedList<TFBOIdcVO>(); try {
	 * aConnection = DBUtility.getZoneConnection(); aPreparedStatement =
	 * aConnection.prepareStatement(query); logger.info("query-->" + query);
	 * aPreparedStatement.setString(1, requestId.trim()); aResultSet =
	 * aPreparedStatement.executeQuery(); while (aResultSet.next()) { aTFBOIdcVO
	 * = new TFBOIdcVO(); aTFBOIdcVO.setTiReferanceNo(aResultSet.getString(1));
	 * aTFBOIdcVO.setSolID(aResultSet.getString(2));
	 * aTFBOIdcVO.setBillAmount(aResultSet.getString(3));
	 * aTFBOIdcVO.setRateTaken(aResultSet.getString(4).trim());
	 * aTFBOIdcVO.setPartpay(aResultSet.getString(5));
	 * aTFBOIdcVO.setSubProductCode(aResultSet.getString(6));
	 * aTFBOIdcVO.setRate(aResultSet.getString(7));
	 * aTFBOIdcVO.setValueK(aResultSet.getString(8));
	 * aTFBOIdcVO.setToken(aResultSet.getString(9));
	 * aTFBOIdcVO.setDirect(aResultSet.getString(10));
	 * aTFBOIdcVO.setCustomeCif(aResultSet.getString(11));
	 * aTFBOIdcVO.setCustomeName(aResultSet.getString(12));
	 * aTFBOIdcVO.setCurrency(aResultSet.getString(13));
	 * aTFBOIdcVO.setDirectCREEvent(aResultSet.getString(14));
	 * idcPayment.add(aTFBOIdcVO); } } catch (Exception e) {
	 * e.printStackTrace(); throw e; } finally {
	 * DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet); }
	 * logger.info(ActionConstants.EXITING_METHOD + "  " + idcPayment.size());
	 * return idcPayment; }
	 */

	// FREEZING(SCENARIO) off shore team starts 31122019

	public static String schemaName;

	static {
		try {
			schemaName = PropertyUtil.getPropertiesValue().getProperty(
					"UserName")
					+ ".";
		} catch (Exception e) {

		}
	}

	public List<TFBOIdcVO> getTFBOIImportIDCCLPDetailsFromDB(String requestId,
			String query) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD + " requestId->"
				+ requestId);
		TFBOIdcVO aTFBOIdcVO = null;
		Connection aConnection = null;
		ResultSet aResultSet = null;
		PreparedStatement aPreparedStatement = null;
		List<TFBOIdcVO> idcPayment = new LinkedList<TFBOIdcVO>();
		try {
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);
			logger.info("query-->" + query);
			aPreparedStatement.setString(1, requestId.trim());
			aResultSet = aPreparedStatement.executeQuery();
			while (aResultSet.next()) {
				aTFBOIdcVO = new TFBOIdcVO();
				aTFBOIdcVO.setTiReferanceNo(aResultSet.getString(1));
				aTFBOIdcVO.setSolID(aResultSet.getString(2));
				aTFBOIdcVO.setBillAmount(aResultSet.getString(3));
				// aTFBOIdcVO.setRateTaken(aResultSet.getString(4).trim());

				// ADDED BY CHANDRU
				if (aResultSet.getString(4) != null
						&& !aResultSet.getString(4).trim().equals("")) {
					if (aResultSet.getString(4).trim().equalsIgnoreCase("Y")) {
						aTFBOIdcVO.setRateTaken("true");
					} else {
						aTFBOIdcVO.setRateTaken("false");
					}
				}
				// ENDS

				aTFBOIdcVO.setPartpay(aResultSet.getString(5));
				aTFBOIdcVO.setSubProductCode(aResultSet.getString(6));
				aTFBOIdcVO.setRate(aResultSet.getString(7));
				aTFBOIdcVO.setValueK(aResultSet.getString(8));
				aTFBOIdcVO.setToken(aResultSet.getString(9));
				aTFBOIdcVO.setDirect(aResultSet.getString(10));
				aTFBOIdcVO.setCustomeCif(aResultSet.getString(11));
				aTFBOIdcVO.setCustomeName(aResultSet.getString(12));
				aTFBOIdcVO.setCurrency(aResultSet.getString(13));
				aTFBOIdcVO.setDirectCREEvent(aResultSet.getString(14));
				idcPayment.add(aTFBOIdcVO);
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}
		logger.info(ActionConstants.EXITING_METHOD + "  " + idcPayment.size());
		return idcPayment;
	}

	// FREEZING(SCENARIO) off shore team ends 31122019
	// ZIGZAG VALUE POPULATION 07012020 ENDS

	// FREEZING(SCENARIO) off shore team ends 31122019

	public Boolean isValueAvailableInDB(String value, String query) {
		logger.info(ActionConstants.ENTERING_METHOD + "getValueFromDB");
		Boolean resultValue = false;
		Connection aConnection = null;
		ResultSet aResultSet = null;
		PreparedStatement aPreparedStatement = null;
		try {
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);
			logger.info("query-->" + query);
			aPreparedStatement.setString(1, value);// CHANGED BY CHANDRU
			aResultSet = aPreparedStatement.executeQuery();
			while (aResultSet.next()) {
				if (aResultSet.getInt(1) > 0)
					resultValue = true;
				System.out.println("resultValue" + resultValue);
			}
			System.out.println("resultValue" + resultValue);
		} catch (Exception e) {
			e.printStackTrace();
			logger.info(ActionConstants.EXITING_METHOD + "getValueFromDB");
			return resultValue;
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}
		logger.info(ActionConstants.EXITING_METHOD + "getValueFromDB");
		return resultValue;
	}

	// Changed by onsite team 26122019 ends

	public Boolean isUserAvailableInTI(String value, String query) {
		logger.info(ActionConstants.ENTERING_METHOD + "getValueFromDB");
		Boolean resultValue = false;
		Connection aConnection = null;
		ResultSet aResultSet = null;
		PreparedStatement aPreparedStatement = null;
		try {
			aConnection = DBUtility.getGlobalConnection();
			aPreparedStatement = aConnection.prepareStatement(query);
			logger.info("query-->" + query);
			aPreparedStatement.setString(1, value.trim());
			aResultSet = aPreparedStatement.executeQuery();
			while (aResultSet.next()) {
				if (aResultSet.getInt(1) > 0)
					resultValue = true;
			}
		} catch (Exception e) {
			e.printStackTrace();
			// resultValue=true;//CLOUD ENV(remove for BOB ENV)
			logger.info(ActionConstants.EXITING_METHOD + resultValue);
			return resultValue;
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}
		logger.info(ActionConstants.EXITING_METHOD + resultValue);
		return resultValue;
	}

	public UserTransactionVO getUserNameandSolId(String userName, String query,
			UserTransactionVO userVo) {

		Connection aConnection = null;
		ResultSet aResultSet = null;
		PreparedStatement aPreparedStatement = null;

		try {
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection
					.prepareStatement("SELECT * FROM  (SELECT TU.TEAM,TU.ENQ_BRN FROM "
							+ schemaName
							+ "TEAMUSRENT TU,"
							+ schemaName
							+ "SECAGE88 US WHERE TU.USERKEY = US.SKEY80 AND US.NAME85 = '"
							+ userName.trim()
							+ "'  AND TU.ENQ_BRN  IS NOT NULL ORDER BY US.NAME85 DESC) WHERE ROWNUM = 1");
			logger.info("query-->" + query);
			System.out.println("query-->" + query);
			// aPreparedStatement.setString(1, userName.trim());
			aResultSet = aPreparedStatement.executeQuery();
			while (aResultSet.next()) {
				userVo.setTeam(aResultSet.getString(1));
				userVo.setBranch(aResultSet.getString(2));
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}
		return userVo;
	}

	public List<TFBOImportLcVO> getTFBOIImportLCAMDFromDB(String requestId,
			String query) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD + " requestId->"
				+ requestId);
		TFBOImportLcVO aTFBOIlcIssueVO = null;
		Connection aConnection = null;
		ResultSet aResultSet = null;
		PreparedStatement aPreparedStatement = null;
		List<TFBOImportLcVO> ilcIssue = new LinkedList<TFBOImportLcVO>();
		try {
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);
			logger.info("query-->" + query);
			aPreparedStatement.setString(1, requestId.trim());
			aResultSet = aPreparedStatement.executeQuery();
			while (aResultSet.next()) {
				aTFBOIlcIssueVO = new TFBOImportLcVO();
				aTFBOIlcIssueVO.setTiReferenceNo(aResultSet.getString(1));
				aTFBOIlcIssueVO.setSolID(aResultSet.getString(2));
				aTFBOIlcIssueVO.setCustomeCif(aResultSet.getString(3));
				aTFBOIlcIssueVO.setAmount(aResultSet.getString(4));
				aTFBOIlcIssueVO.setCurrency(aResultSet.getString(5));
				aTFBOIlcIssueVO.setLcType(aResultSet.getString(6));
				aTFBOIlcIssueVO.setSubProductCode(aResultSet.getString(7));
				ilcIssue.add(aTFBOIlcIssueVO);
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}
		logger.info(ActionConstants.EXITING_METHOD + "  " + ilcIssue.size());
		return ilcIssue;
	}

	public List<TFBOImportLcVO> getTFBOIImportLCPOCAFromDB(String requestId,
			String query, UserTransactionVO userVo) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD + " requestId->"
				+ requestId);
		TFBOImportLcVO aTFBOIlcIssueVO = null;
		Connection aConnection = null;
		ResultSet aResultSet = null;
		PreparedStatement aPreparedStatement = null;
		CommonMethods aCommonMethods = new CommonMethods();
		List<TFBOImportLcVO> ilcIssue = new LinkedList<TFBOImportLcVO>();
		try {
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);
			logger.info("query-->" + query);
			aPreparedStatement.setString(1, requestId.trim());
			aResultSet = aPreparedStatement.executeQuery();
			while (aResultSet.next()) {
				aTFBOIlcIssueVO = new TFBOImportLcVO();
				aTFBOIlcIssueVO.setTiReferenceNo(aResultSet.getString(1));
				aTFBOIlcIssueVO.setSolID(aResultSet.getString(2));
				aTFBOIlcIssueVO.setCustomeCif(aResultSet.getString(3));
				aTFBOIlcIssueVO.setClaimAmount(aResultSet.getString(4));
				aTFBOIlcIssueVO.setCurrency(aResultSet.getString(5));
				aTFBOIlcIssueVO.setLcType(aResultSet.getString(6));
				if (aCommonMethods.isValueAvailable(aResultSet.getString(8))
						&& aResultSet.getString(8).equals("Y")) {
					aTFBOIlcIssueVO.setPartAmount(true);
					userVo.setPartAmount(true);
				} else {
					aTFBOIlcIssueVO.setPartAmount(false);
					userVo.setPartAmount(false);
				}
				aTFBOIlcIssueVO.setPayType(aResultSet.getString(9));
				aTFBOIlcIssueVO.setSubProductCode(aResultSet.getString(10));
				userVo.setClaimAmount(aResultSet.getString(4));
				userVo.setPayType(aResultSet.getString(9));
				userVo.setBillReference(aResultSet.getString(11));
				ilcIssue.add(aTFBOIlcIssueVO);
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}
		logger.info(ActionConstants.EXITING_METHOD + "  " + ilcIssue.size());
		return ilcIssue;
	}

	public List<TFBOImportLcVO> getTFBOIImportLCPOCPFromDB(String requestId,
			String query, UserTransactionVO userVo) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD + " requestId->"
				+ requestId);
		TFBOImportLcVO aTFBOIlcIssueVO = null;
		Connection aConnection = null;
		ResultSet aResultSet = null;
		PreparedStatement aPreparedStatement = null;
		CommonMethods aCommonMethods = new CommonMethods();
		List<TFBOImportLcVO> ilcIssue = new LinkedList<TFBOImportLcVO>();
		try {
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);
			logger.info("query-->" + query);
			aPreparedStatement.setString(1, requestId.trim());
			aResultSet = aPreparedStatement.executeQuery();
			while (aResultSet.next()) {
				aTFBOIlcIssueVO = new TFBOImportLcVO();
				aTFBOIlcIssueVO.setTiReferenceNo(aResultSet.getString(1));
				aTFBOIlcIssueVO.setSolID(aResultSet.getString(2));
				aTFBOIlcIssueVO.setCustomeCif(aResultSet.getString(3));
				aTFBOIlcIssueVO.setClaimAmount(aResultSet.getString(4));
				aTFBOIlcIssueVO.setCurrency(aResultSet.getString(5));
				aTFBOIlcIssueVO.setLcType(aResultSet.getString(6));
				if (aCommonMethods.isValueAvailable(aResultSet.getString(8))
						&& aResultSet.getString(8).equals("Y")) {
					aTFBOIlcIssueVO.setPartAmount(true);
					userVo.setPartAmount(true);
				} else {
					aTFBOIlcIssueVO.setPartAmount(false);
					userVo.setPartAmount(false);
				}
				aTFBOIlcIssueVO.setPayType(aResultSet.getString(9));
				userVo.setPayType(aResultSet.getString(9));
				userVo.setClaimAmount(aResultSet.getString(4));
				if (aCommonMethods.isValueAvailable(aResultSet.getString(10))) {
					if (aResultSet.getString(10).equals("Y")) {
						aTFBOIlcIssueVO.setRateTaken(true);
						userVo.setRateTaken("true");
					}
				} else {
					aTFBOIlcIssueVO.setRateTaken(false);
					userVo.setRateTaken("false");
				}
				userVo.setToken(aResultSet.getString(11));
				aTFBOIlcIssueVO.setToken(aResultSet.getString(11));
				aTFBOIlcIssueVO.setValueK(aResultSet.getString(12));
				aTFBOIlcIssueVO.setRate(aResultSet.getString(13));
				aTFBOIlcIssueVO.setSubProductCode(aResultSet.getString(14));
				userVo.setValueK(aResultSet.getString(12));
				userVo.setRate(aResultSet.getString(13));
				userVo.setBillReference(aResultSet.getString(15));
				ilcIssue.add(aTFBOIlcIssueVO);
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}
		logger.info(ActionConstants.EXITING_METHOD + "  " + ilcIssue.size());
		return ilcIssue;
	}

	public List<TFBOImportLcVO> getTFBOIImportLCPOCDFromDB(String requestId,
			String query, UserTransactionVO userVo) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD + " requestId->"
				+ requestId);
		TFBOImportLcVO aTFBOIlcIssueVO = null;
		Connection aConnection = null;
		ResultSet aResultSet = null;
		PreparedStatement aPreparedStatement = null;
		CommonMethods aCommonMethods = new CommonMethods();
		List<TFBOImportLcVO> ilcIssue = new LinkedList<TFBOImportLcVO>();
		try {
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);
			logger.info("query-->" + query);
			aPreparedStatement.setString(1, requestId.trim());
			aResultSet = aPreparedStatement.executeQuery();
			while (aResultSet.next()) {
				aTFBOIlcIssueVO = new TFBOImportLcVO();
				aTFBOIlcIssueVO.setTiReferenceNo(aResultSet.getString(1));
				aTFBOIlcIssueVO.setSolID(aResultSet.getString(2));
				aTFBOIlcIssueVO.setCustomeCif(aResultSet.getString(3));
				userVo.setDevolvementAmount(aResultSet.getString(4));
				aTFBOIlcIssueVO.setCurrency(aResultSet.getString(5));
				aTFBOIlcIssueVO.setLcType(aResultSet.getString(6));

				// Code added by Pandi For Null checking starts here
				if (aCommonMethods.isValueAvailable(aResultSet.getString(8))
						&& aResultSet.getString(8).equals("Y")) {
					aTFBOIlcIssueVO.setRateTaken(true);
					userVo.setRateTaken("true");
				} else {
					aTFBOIlcIssueVO.setRateTaken(false);
					userVo.setRateTaken("false");
				}
				// Code added by Pandi For Null checking ends here
				userVo.setToken(aResultSet.getString(9));
				aTFBOIlcIssueVO.setToken(aResultSet.getString(9));
				aTFBOIlcIssueVO.setValueK(aResultSet.getString(10));
				aTFBOIlcIssueVO.setRate(aResultSet.getString(11));
				aTFBOIlcIssueVO.setSubProductCode(aResultSet.getString(12));
				userVo.setValueK(aResultSet.getString(10));
				userVo.setRate(aResultSet.getString(11));
				userVo.setSubProductCode(aResultSet.getString(12));
				userVo.setBillReference(aResultSet.getString(13));
				ilcIssue.add(aTFBOIlcIssueVO);
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}
		logger.info(ActionConstants.EXITING_METHOD + "  " + ilcIssue.size());
		return ilcIssue;
	}

	public List<TFBOImportLcVO> getTFBOIImportLCISSFromDB(String requestId,
			String query) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD + " requestId->"
				+ requestId);
		TFBOImportLcVO aTFBOIlcIssueVO = null;
		Connection aConnection = null;
		ResultSet aResultSet = null;
		PreparedStatement aPreparedStatement = null;
		List<TFBOImportLcVO> ilcIssue = new LinkedList<TFBOImportLcVO>();
		try {
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);
			logger.info("query-->" + query);
			aPreparedStatement.setString(1, requestId.trim());
			aResultSet = aPreparedStatement.executeQuery();
			while (aResultSet.next()) {
				aTFBOIlcIssueVO = new TFBOImportLcVO();
				aTFBOIlcIssueVO.setTiReferenceNo(aResultSet.getString(1));
				aTFBOIlcIssueVO.setSolID(aResultSet.getString(2));
				aTFBOIlcIssueVO.setCustomeCif(aResultSet.getString(3));
				aTFBOIlcIssueVO.setAmount(aResultSet.getString(4));
				aTFBOIlcIssueVO.setCurrency(aResultSet.getString(5));
				aTFBOIlcIssueVO.setLcType(aResultSet.getString(6));
				aTFBOIlcIssueVO.setUsancePeriod(aResultSet.getString(7));
				aTFBOIlcIssueVO.setSubProductCode(aResultSet.getString(8));
				ilcIssue.add(aTFBOIlcIssueVO);
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}
		logger.info(ActionConstants.EXITING_METHOD + "  " + ilcIssue.size());
		return ilcIssue;
	}

	/*
	 * public List<TFBOExportCollectionVO> getTFBOIODCCREFromDB(String
	 * requestId, String query) throws Exception {
	 * logger.info(ActionConstants.ENTERING_METHOD + " requestId->" +
	 * requestId); TFBOExportCollectionVO aTFBOExportCollectionVO = null;
	 * Connection aConnection = null; ResultSet aResultSet = null;
	 * PreparedStatement aPreparedStatement = null; List<TFBOExportCollectionVO>
	 * odcCreate = new LinkedList<TFBOExportCollectionVO>(); try { aConnection =
	 * DBUtility.getZoneConnection(); aPreparedStatement =
	 * aConnection.prepareStatement(query); logger.info("query-->" + query);
	 * aPreparedStatement.setString(1, requestId.trim()); aResultSet =
	 * aPreparedStatement.executeQuery(); while (aResultSet.next()) {
	 * aTFBOExportCollectionVO = new TFBOExportCollectionVO();
	 * aTFBOExportCollectionVO.setTiReferenceNo(aResultSet .getString(1));
	 * aTFBOExportCollectionVO.setSolID(aResultSet.getString(2));
	 * aTFBOExportCollectionVO.setCustomeCif(aResultSet.getString(3));
	 * aTFBOExportCollectionVO.setAmount(aResultSet.getString(4));
	 * aTFBOExportCollectionVO.setCurrency(aResultSet.getString(5));
	 * aTFBOExportCollectionVO .setUsancePeriod(aResultSet.getString(6));
	 * aTFBOExportCollectionVO.setDirect(aResultSet.getString(7));
	 * aTFBOExportCollectionVO.setMtReceived(aResultSet.getString(8));
	 * aTFBOExportCollectionVO.setPartPayment(aResultSet.getString(9));
	 * aTFBOExportCollectionVO .setProductType(aResultSet.getString(10));
	 * aTFBOExportCollectionVO.setPreshipAccSettled(aResultSet .getString(11));
	 * aTFBOExportCollectionVO.setDocumentDispatch(aResultSet .getString(12));
	 * aTFBOExportCollectionVO.setFinanceSameDay(aResultSet .getString(13));
	 * aTFBOExportCollectionVO.setRateTaken(aResultSet.getString(14));
	 * aTFBOExportCollectionVO.setToken(aResultSet.getString(15));
	 * aTFBOExportCollectionVO.setRateTakenK(aResultSet.getString(16));
	 * aTFBOExportCollectionVO.setRate(aResultSet.getString(17));
	 * aTFBOExportCollectionVO.setSubProductCode(aResultSet .getString(18));
	 * odcCreate.add(aTFBOExportCollectionVO); } } catch (Exception e) {
	 * e.printStackTrace(); throw e; } finally {
	 * DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet); }
	 * logger.info(ActionConstants.EXITING_METHOD + "  " + odcCreate.size());
	 * return odcCreate; }
	 */
	public List<TFBOExportCollectionVO> getTFBOIODCPAYFromDB(String requestId,
			String query) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD + " requestId->"
				+ requestId);
		TFBOExportCollectionVO aTFBOExportCollectionVO = null;
		Connection aConnection = null;
		ResultSet aResultSet = null;
		PreparedStatement aPreparedStatement = null;
		List<TFBOExportCollectionVO> odcCreate = new LinkedList<TFBOExportCollectionVO>();
		try {
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);
			logger.info("query-->" + query);
			aPreparedStatement.setString(1, requestId.trim());
			aResultSet = aPreparedStatement.executeQuery();
			while (aResultSet.next()) {
				aTFBOExportCollectionVO = new TFBOExportCollectionVO();
				aTFBOExportCollectionVO.setTiReferenceNo(aResultSet
						.getString(1));// TIREFERANCE
				aTFBOExportCollectionVO.setSolID(aResultSet.getString(2));// SOLID
				aTFBOExportCollectionVO.setCustomeCif(aResultSet.getString(3));// CUSTOMERCIF
				aTFBOExportCollectionVO.setAmount(aResultSet.getString(4));// AMOUNT
				aTFBOExportCollectionVO.setCurrency(aResultSet.getString(5));// CURRENCY

				aTFBOExportCollectionVO
						.setUsancePeriod(aResultSet.getString(6));// USANCEPERIOD
				aTFBOExportCollectionVO.setDirect(aResultSet.getString(7));// DIRECT
				aTFBOExportCollectionVO.setMtReceived(aResultSet.getString(8));// MT_RECEIVED
				aTFBOExportCollectionVO.setPartPayment(aResultSet.getString(9));// PART_PAYMENT
				aTFBOExportCollectionVO
						.setProductType(aResultSet.getString(10));// PRODUCT_TYPE
				aTFBOExportCollectionVO.setPreshipAccSettled(aResultSet
						.getString(11));// PRESHIP_ACC_SETTELED
				aTFBOExportCollectionVO.setDocumentDispatch(aResultSet
						.getString(12));// DOCUMENT_DISPATCH
				aTFBOExportCollectionVO.setFinanceSameDay(aResultSet
						.getString(13));// FINANCE_SAME_DAY
				// aTFBOExportCollectionVO.setRateTaken(aResultSet.getString(14));

				// ADDED BY CHANDRU
				if (aResultSet.getString(14) != null
						&& !aResultSet.getString(14).trim().equals("")) {
					if (aResultSet.getString(14).equalsIgnoreCase("Y")) {
						aTFBOExportCollectionVO.setRateTaken("true");
					} else {
						aTFBOExportCollectionVO.setRateTaken("false");
					}
				}// RATE_TAKEN
					// ENDS

				aTFBOExportCollectionVO.setToken(aResultSet.getString(15));// TOKEN
				aTFBOExportCollectionVO.setRateTakenK(aResultSet.getString(16));// RATE_TAKEN_K
				aTFBOExportCollectionVO.setRate(aResultSet.getString(17));// vRATE

				aTFBOExportCollectionVO.setFinalPayment(aResultSet
						.getString(18));// FINAL_PAYMENT
				aTFBOExportCollectionVO.setIrexRefNo(aResultSet.getString(19));// IREX_NO
				aTFBOExportCollectionVO.setSubProductCode(aResultSet
						.getString(20));// SUBPRODUCTCODE
				// Rate taken Fix Offshore Team 06012020 starts

				// Rate taken Fix Offshore Team 06012020 ends
				aTFBOExportCollectionVO.setRequestId(aResultSet.getString(21));// REQUESTID
				aTFBOExportCollectionVO
						.setSenderRefno(aResultSet.getString(22));// SENDERREFNO
				odcCreate.add(aTFBOExportCollectionVO);
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}
		logger.info(ActionConstants.EXITING_METHOD + "  " + odcCreate.size());
		return odcCreate;
	}

	public List<TFBOFinanceExportLcVO> getTFBOIFELCREFromDB(String requestId,
			String query) throws Exception {
		TFBOFinanceExportLcVO aTFBOFinanceExportLcVO = null;
		Connection aConnection = null;
		ResultSet aResultSet = null;
		PreparedStatement aPreparedStatement = null;

		List<TFBOFinanceExportLcVO> felCreate = new LinkedList<TFBOFinanceExportLcVO>();
		try {
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);
			logger.info("query-->" + query);
			aPreparedStatement.setString(1, requestId.trim());
			aResultSet = aPreparedStatement.executeQuery();
			while (aResultSet.next()) {
				aTFBOFinanceExportLcVO = new TFBOFinanceExportLcVO();
				aTFBOFinanceExportLcVO.setBillReferenceNo(aResultSet
						.getString(1));
				felCreate.add(aTFBOFinanceExportLcVO);
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}
		logger.info(ActionConstants.EXITING_METHOD + "  " + felCreate.size());
		return felCreate;
	}

	public List<TFBOFinanceExportLcVO> getTFBOFELCREFromDB(String requestId,
			String query) throws Exception {
		TFBOFinanceExportLcVO aTFBOFinanceExportLcVO = null;
		Connection aConnection = null;
		ResultSet aResultSet = null;
		PreparedStatement aPreparedStatement = null;

		List<TFBOFinanceExportLcVO> felCreate = new LinkedList<TFBOFinanceExportLcVO>();
		try {
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);
			logger.info("query-->" + query);
			aPreparedStatement.setString(1, requestId.trim());
			aResultSet = aPreparedStatement.executeQuery();
			while (aResultSet.next()) {
				aTFBOFinanceExportLcVO = new TFBOFinanceExportLcVO();
				aTFBOFinanceExportLcVO.setLCRefNum(aResultSet.getString(1));
				aTFBOFinanceExportLcVO.setSolID(aResultSet.getString(2));
				aTFBOFinanceExportLcVO.setBillReferenceNo(aResultSet
						.getString(3));
				aTFBOFinanceExportLcVO.setFncAmount(aResultSet.getString(4));
				aTFBOFinanceExportLcVO.setAmount(aResultSet.getString(5));
				aTFBOFinanceExportLcVO.setBillTenure(aResultSet.getString(6));
				aTFBOFinanceExportLcVO.setPreshipAcc(aResultSet.getString(7));
				// aTFBOFinanceExportLcVO.setRateTaken(aResultSet.getString(8));

				// ADDED BY CHANDRU
				if (aResultSet.getString(8) != null
						&& !aResultSet.getString(8).trim().equals("")) {
					if (aResultSet.getString(8).equalsIgnoreCase("Y")) {
						aTFBOFinanceExportLcVO.setRateTaken("true");
					} else {
						aTFBOFinanceExportLcVO.setRateTaken("false");
					}
				}
				// ENDS

				aTFBOFinanceExportLcVO.setSubProductCode(aResultSet
						.getString(9));
				aTFBOFinanceExportLcVO.setToken(aResultSet.getString(10));
				aTFBOFinanceExportLcVO.setRateTakenK(aResultSet.getString(11));
				aTFBOFinanceExportLcVO.setRate(aResultSet.getString(12));
				aTFBOFinanceExportLcVO.setCurrency(aResultSet.getString(13));
				aTFBOFinanceExportLcVO.setCustomeCif(aResultSet.getString(14));
				aTFBOFinanceExportLcVO.setCustomeName(aResultSet.getString(15));
				// ADDED BY CHANDRU
				if (aResultSet.getString(16) != null
						&& !aResultSet.getString(16).trim().equals("")) {
					if (aResultSet.getString(16).trim().equalsIgnoreCase("Y")) {
						aTFBOFinanceExportLcVO.setPreshipAcc("true");
					} else {
						aTFBOFinanceExportLcVO.setPreshipAcc("false");
					}
				}

				// ENDS
				felCreate.add(aTFBOFinanceExportLcVO);
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}
		logger.info(ActionConstants.EXITING_METHOD + "  " + felCreate.size());
		return felCreate;
	}

	public String getLCReference(String query) {
		Connection aConnection = null;
		ResultSet aResultSet = null;
		PreparedStatement aPreparedStatement = null;
		String lcReference = "";
		try {
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);
			aResultSet = aPreparedStatement.executeQuery();
			while (aResultSet.next()) {
				lcReference = aResultSet.getString(1);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}
		return lcReference;
	}

	public List<TFBOFinanceExportLcVO> getTFBOFELIADJFromDB(String requestId,
			String query) throws Exception {
		TFBOFinanceExportLcVO aTFBOFinanceExportLcVO = null;
		Connection aConnection = null;
		ResultSet aResultSet = null;
		PreparedStatement aPreparedStatement = null;

		List<TFBOFinanceExportLcVO> felAdjust = new LinkedList<TFBOFinanceExportLcVO>();
		try {
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);
			logger.info("query-->" + query);
			aPreparedStatement.setString(1, requestId.trim());
			aResultSet = aPreparedStatement.executeQuery();
			while (aResultSet.next()) {
				aTFBOFinanceExportLcVO = new TFBOFinanceExportLcVO();
				aTFBOFinanceExportLcVO.setLCRefNum(aResultSet.getString(1));
				aTFBOFinanceExportLcVO.setSolID(aResultSet.getString(2));
				aTFBOFinanceExportLcVO.setFncAmount(aResultSet.getString(3));
				aTFBOFinanceExportLcVO.setCurrency(aResultSet.getString(4));
				aTFBOFinanceExportLcVO.setBillTenure(aResultSet.getString(5));
				aTFBOFinanceExportLcVO.setSubProductCode(aResultSet
						.getString(6));
				aTFBOFinanceExportLcVO.setMaturityDate(aResultSet.getString(7));
				aTFBOFinanceExportLcVO.setCustomeCif(aResultSet.getString(8));
				aTFBOFinanceExportLcVO.setCustomeName(aResultSet.getString(9));
				felAdjust.add(aTFBOFinanceExportLcVO);
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}
		logger.info(ActionConstants.EXITING_METHOD + "  " + felAdjust.size());
		return felAdjust;
	}

	public List<TFBOFinanceExportLcVO> getTFBOFELICRYSTFromDB(String requestId,
			String query) throws Exception {
		TFBOFinanceExportLcVO aTFBOFinanceExportLcVO = null;
		Connection aConnection = null;
		ResultSet aResultSet = null;
		PreparedStatement aPreparedStatement = null;
		List<TFBOFinanceExportLcVO> felCrystalization = new LinkedList<TFBOFinanceExportLcVO>();
		try {
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);
			logger.info("query-->" + query);
			aPreparedStatement.setString(1, requestId.trim());
			aResultSet = aPreparedStatement.executeQuery();
			while (aResultSet.next()) {
				aTFBOFinanceExportLcVO = new TFBOFinanceExportLcVO();
				aTFBOFinanceExportLcVO.setSolID(aResultSet.getString(1));
				aTFBOFinanceExportLcVO.setLCRefNum(aResultSet.getString(2));
				aTFBOFinanceExportLcVO.setCurrency(aResultSet.getString(3));
				aTFBOFinanceExportLcVO.setAmount(aResultSet.getString(4));
				aTFBOFinanceExportLcVO.setFncAmount(aResultSet.getString(5));
				aTFBOFinanceExportLcVO.setBillTenure(aResultSet.getString(6));
				aTFBOFinanceExportLcVO.setCustomeCif(aResultSet.getString(7));
				aTFBOFinanceExportLcVO.setCustomeName(aResultSet.getString(8));
				aTFBOFinanceExportLcVO.setSubProductCode(aResultSet
						.getString(9));
				aTFBOFinanceExportLcVO
						.setFinalPayment(aResultSet.getString(10));
				// aTFBOFinanceExportLcVO.setRateTaken(aResultSet.getString(11));

				// ADDED BY CHANDRU
				if (aResultSet.getString(11) != null
						&& !aResultSet.getString(11).trim().equals("")) {
					if (aResultSet.getString(11).equalsIgnoreCase("Y")) {
						aTFBOFinanceExportLcVO.setRateTaken("true");
					} else {
						aTFBOFinanceExportLcVO.setRateTaken("false");
					}
				}
				// ENDS

				aTFBOFinanceExportLcVO.setToken(aResultSet.getString(12));
				aTFBOFinanceExportLcVO.setRateTakenK(aResultSet.getString(13));
				aTFBOFinanceExportLcVO.setRate(aResultSet.getString(14));
				felCrystalization.add(aTFBOFinanceExportLcVO);
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}
		logger.info(ActionConstants.EXITING_METHOD + "  "
				+ felCrystalization.size());
		return felCrystalization;
	}

	public List<TFBOFinanceExportLcVO> getTFBOFELIRPYFromDB(String requestId,
			String query) throws Exception {
		TFBOFinanceExportLcVO aTFBOFinanceExportLcVO = null;
		Connection aConnection = null;
		ResultSet aResultSet = null;
		PreparedStatement aPreparedStatement = null;
		List<TFBOFinanceExportLcVO> felCrystalization = new LinkedList<TFBOFinanceExportLcVO>();
		try {
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);
			logger.info("query-->" + query);
			aPreparedStatement.setString(1, requestId.trim());
			aResultSet = aPreparedStatement.executeQuery();
			while (aResultSet.next()) {
				aTFBOFinanceExportLcVO = new TFBOFinanceExportLcVO();
				aTFBOFinanceExportLcVO.setSolID(aResultSet.getString(1));
				aTFBOFinanceExportLcVO.setLCRefNum(aResultSet.getString(2));
				aTFBOFinanceExportLcVO.setCurrency(aResultSet.getString(3));
				aTFBOFinanceExportLcVO.setAmount(aResultSet.getString(4));
				aTFBOFinanceExportLcVO.setFncAmount(aResultSet.getString(5));
				aTFBOFinanceExportLcVO.setBillTenure(aResultSet.getString(6));
				aTFBOFinanceExportLcVO.setCustomeCif(aResultSet.getString(7));
				aTFBOFinanceExportLcVO.setCustomeName(aResultSet.getString(8));
				aTFBOFinanceExportLcVO.setSubProductCode(aResultSet
						.getString(9));
				aTFBOFinanceExportLcVO
						.setFinalPayment(aResultSet.getString(10));
				// aTFBOFinanceExportLcVO.setRateTaken(aResultSet.getString(11));

				// ADDED BY CHANDRU
				if (aResultSet.getString(11) != null
						&& !aResultSet.getString(11).trim().equals("")) {
					if (aResultSet.getString(11).equalsIgnoreCase("Y")) {
						aTFBOFinanceExportLcVO.setRateTaken("true");
					} else {
						aTFBOFinanceExportLcVO.setRateTaken("false");
					}
				}
				// ENDS

				aTFBOFinanceExportLcVO.setToken(aResultSet.getString(12));
				aTFBOFinanceExportLcVO.setRateTakenK(aResultSet.getString(13));
				aTFBOFinanceExportLcVO.setRate(aResultSet.getString(14));
				// ADDED BY CHANDRU
				if (aResultSet.getString(15) != null
						&& !aResultSet.getString(15).trim().equals("")) {
					if (aResultSet.getString(15).trim().equalsIgnoreCase("Y")) {
						aTFBOFinanceExportLcVO.setPreshipAcc("true");
					} else {
						aTFBOFinanceExportLcVO.setPreshipAcc("false");
					}
				}
				// ENDS

				// aTFBOFinanceExportLcVO.setPreshipAcc(aResultSet.getString(15));
				aTFBOFinanceExportLcVO.setSenderRefNo(aResultSet.getString(16));
				felCrystalization.add(aTFBOFinanceExportLcVO);
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}
		logger.info(ActionConstants.EXITING_METHOD + "  "
				+ felCrystalization.size());
		return felCrystalization;
	}

	public List<TFBOFinanceExportLcVO> getTFBOFELCREFromDB(String requestId,
			String billRef, String query) throws Exception {
		TFBOFinanceExportLcVO aTFBOFinanceExportLcVO = null;
		Connection aConnection = null;
		ResultSet aResultSet = null;
		PreparedStatement aPreparedStatement = null;
		List<TFBOFinanceExportLcVO> felCreate = new LinkedList<TFBOFinanceExportLcVO>();
		try {
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);
			logger.info("query-->" + query);
			aPreparedStatement.setString(1, billRef.trim());
			aPreparedStatement.setString(2, requestId.trim());
			aResultSet = aPreparedStatement.executeQuery();
			while (aResultSet.next()) {
				aTFBOFinanceExportLcVO = new TFBOFinanceExportLcVO();
				aTFBOFinanceExportLcVO.setAmount(aResultSet.getString(1));
				aTFBOFinanceExportLcVO.setBillTenure(aResultSet.getString(2));
				aTFBOFinanceExportLcVO.setCurrency(aResultSet.getString(3));
				aTFBOFinanceExportLcVO.setLCRefNum(requestId);
				aTFBOFinanceExportLcVO.setSolID(aResultSet.getString(4));
				aTFBOFinanceExportLcVO.setCustomeCif(aResultSet.getString(5));
				aTFBOFinanceExportLcVO.setCustomeName(aResultSet.getString(6));
				// ADDED BY CHANDRU
				if (aResultSet.getString(7) != null
						&& !aResultSet.getString(7).trim().equals("")) {
					if (aResultSet.getString(7).trim().equalsIgnoreCase("Yes")) {
						aTFBOFinanceExportLcVO.setPreshipAcc("true");
					} else {
						aTFBOFinanceExportLcVO.setPreshipAcc("false");
					}
				}
				// ENDS
				felCreate.add(aTFBOFinanceExportLcVO);
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}
		logger.info(ActionConstants.EXITING_METHOD + "  " + felCreate.size());
		return felCreate;
	}

	public List<TFBOFinanceExportLcVO> getTFBOFELADJFromDB(String requestId,
			String query) throws Exception {
		TFBOFinanceExportLcVO aTFBOFinanceExportLcVO = null;
		Connection aConnection = null;
		ResultSet aResultSet = null;
		PreparedStatement aPreparedStatement = null;
		List<TFBOFinanceExportLcVO> felCreate = new LinkedList<TFBOFinanceExportLcVO>();
		try {
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);
			logger.info("query-->" + query);
			aPreparedStatement.setString(1, requestId.trim());
			aResultSet = aPreparedStatement.executeQuery();
			while (aResultSet.next()) {
				aTFBOFinanceExportLcVO = new TFBOFinanceExportLcVO();
				aTFBOFinanceExportLcVO.setFncAmount(aResultSet.getString(1));
				aTFBOFinanceExportLcVO.setCurrency(aResultSet.getString(2));
				aTFBOFinanceExportLcVO.setCustomeCif(aResultSet.getString(3));
				aTFBOFinanceExportLcVO.setCustomeName(aResultSet.getString(4));
				aTFBOFinanceExportLcVO.setBillTenure(aResultSet.getString(5));
				aTFBOFinanceExportLcVO.setSubProductCode(aResultSet
						.getString(6));
				aTFBOFinanceExportLcVO.setSolID(aResultSet.getString(7));
				aTFBOFinanceExportLcVO.setLCRefNum(requestId);
				felCreate.add(aTFBOFinanceExportLcVO);
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}
		logger.info(ActionConstants.EXITING_METHOD + "  " + felCreate.size());
		return felCreate;
	}

	public List<TFBOFinanceExportLcVO> getTFBOFELCRYSTFromDB(String requestId,
			String query) throws Exception {
		TFBOFinanceExportLcVO aTFBOFinanceExportLcVO = null;
		Connection aConnection = null;
		ResultSet aResultSet = null;
		PreparedStatement aPreparedStatement = null;
		List<TFBOFinanceExportLcVO> felCreate = new LinkedList<TFBOFinanceExportLcVO>();
		try {
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);
			logger.info("query-->" + query);
			aPreparedStatement.setString(1, requestId.trim());
			aResultSet = aPreparedStatement.executeQuery();
			while (aResultSet.next()) {
				aTFBOFinanceExportLcVO = new TFBOFinanceExportLcVO();
				aTFBOFinanceExportLcVO.setAmount(aResultSet.getString(1));
				aTFBOFinanceExportLcVO.setCurrency(aResultSet.getString(2));
				aTFBOFinanceExportLcVO.setCustomeCif(aResultSet.getString(3));
				aTFBOFinanceExportLcVO.setCustomeName(aResultSet.getString(4));
				aTFBOFinanceExportLcVO.setBillTenure(aResultSet.getString(5));
				aTFBOFinanceExportLcVO.setSubProductCode(aResultSet
						.getString(6));
				aTFBOFinanceExportLcVO.setSolID(aResultSet.getString(7));
				// ADDED BY CHANDRU
				if (aResultSet.getString(8) != null
						&& !aResultSet.getString(8).trim().equals("")) {
					if (aResultSet.getString(8).trim().equalsIgnoreCase("Y")) {
						aTFBOFinanceExportLcVO.setPreshipAcc("true");
					} else {
						aTFBOFinanceExportLcVO.setPreshipAcc("false");
					}
				}
				// ENDS
				aTFBOFinanceExportLcVO.setLCRefNum(requestId);
				felCreate.add(aTFBOFinanceExportLcVO);
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}
		logger.info(ActionConstants.EXITING_METHOD + "  " + felCreate.size());
		return felCreate;
	}

	public List<TFBOFinanceExportLcVO> getTFBOFELRPYFromDB(String requestId,
			String query) throws Exception {
		TFBOFinanceExportLcVO aTFBOFinanceExportLcVO = null;
		Connection aConnection = null;
		ResultSet aResultSet = null;
		PreparedStatement aPreparedStatement = null;
		List<TFBOFinanceExportLcVO> felCreate = new LinkedList<TFBOFinanceExportLcVO>();
		try {
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);
			logger.info("query-->" + query);
			aPreparedStatement.setString(1, requestId.trim());
			aResultSet = aPreparedStatement.executeQuery();
			while (aResultSet.next()) {
				aTFBOFinanceExportLcVO = new TFBOFinanceExportLcVO();
				aTFBOFinanceExportLcVO.setAmount(aResultSet.getString(1));
				aTFBOFinanceExportLcVO.setCurrency(aResultSet.getString(2));
				aTFBOFinanceExportLcVO.setCustomeCif(aResultSet.getString(3));
				aTFBOFinanceExportLcVO.setCustomeName(aResultSet.getString(4));
				aTFBOFinanceExportLcVO.setBillTenure(aResultSet.getString(5));
				aTFBOFinanceExportLcVO.setSubProductCode(aResultSet
						.getString(6));
				aTFBOFinanceExportLcVO.setSolID(aResultSet.getString(7));
				aTFBOFinanceExportLcVO.setLCRefNum(requestId);
				felCreate.add(aTFBOFinanceExportLcVO);
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}
		logger.info(ActionConstants.EXITING_METHOD + "  " + felCreate.size());
		return felCreate;
	}

	/*
	 * public List<TFBOExportCollectionVO> getTFBOIODCCLPFromDB(String
	 * requestId, String query) throws Exception {
	 * logger.info(ActionConstants.ENTERING_METHOD + " requestId->" +
	 * requestId); TFBOExportCollectionVO aTFBOExportCollectionVO = null;
	 * Connection aConnection = null; ResultSet aResultSet = null;
	 * PreparedStatement aPreparedStatement = null; List<TFBOExportCollectionVO>
	 * odcCreate = new LinkedList<TFBOExportCollectionVO>(); try { aConnection =
	 * DBUtility.getZoneConnection(); aPreparedStatement =
	 * aConnection.prepareStatement(query); logger.info("query-->" + query);
	 * logger.info("query-->" + query); aPreparedStatement.setString(1,
	 * requestId.trim()); aResultSet = aPreparedStatement.executeQuery(); while
	 * (aResultSet.next()) { aTFBOExportCollectionVO = new
	 * TFBOExportCollectionVO();
	 * aTFBOExportCollectionVO.setTiReferenceNo(aResultSet .getString(1));
	 * aTFBOExportCollectionVO.setSolID(aResultSet.getString(2));
	 * aTFBOExportCollectionVO.setCustomeCif(aResultSet.getString(3));
	 * aTFBOExportCollectionVO.setAmount(aResultSet.getString(4));
	 * aTFBOExportCollectionVO.setCurrency(aResultSet.getString(5));
	 * aTFBOExportCollectionVO .setUsancePeriod(aResultSet.getString(6));
	 * aTFBOExportCollectionVO.setDirect(aResultSet.getString(7));
	 * aTFBOExportCollectionVO.setMtReceived(aResultSet.getString(8));
	 * aTFBOExportCollectionVO.setPartPayment(aResultSet.getString(9)); // Rate
	 * taken Fix Offshore Team 06012020 starts
	 * aTFBOExportCollectionVO.setSubProductCode(aResultSet .getString(10)); //
	 * Rate taken Fix Offshore Team 06012020 ends
	 * 
	 * aTFBOExportCollectionVO.setPreshipAccSettled(aResultSet .getString(11));
	 * aTFBOExportCollectionVO.setDocumentDispatch(aResultSet .getString(12));
	 * // Rate taken Fix Offshore Team 06012020 starts
	 * aTFBOExportCollectionVO.setIrexRefNo(aResultSet.getString(13)); // Rate
	 * taken Fix Offshore Team 06012020 ends
	 * 
	 * odcCreate.add(aTFBOExportCollectionVO); } } catch (Exception e) {
	 * e.printStackTrace(); throw e; } finally {
	 * DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet); }
	 * logger.info(ActionConstants.EXITING_METHOD + "  " + odcCreate.size());
	 * return odcCreate; }
	 */
	// Divya 08012020 starts
	public List<TFBOExportCollectionVO> getTFBOIODCCLPFromDB(String requestId,
			String query) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD + " requestId->"
				+ requestId);
		TFBOExportCollectionVO aTFBOExportCollectionVO = null;
		Connection aConnection = null;
		ResultSet aResultSet = null;
		PreparedStatement aPreparedStatement = null;
		List<TFBOExportCollectionVO> odcCreate = new LinkedList<TFBOExportCollectionVO>();
		try {
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);
			logger.info("query-->" + query);
			logger.info("query-->" + query);
			aPreparedStatement.setString(1, requestId.trim());
			aResultSet = aPreparedStatement.executeQuery();
			while (aResultSet.next()) {
				aTFBOExportCollectionVO = new TFBOExportCollectionVO();
				aTFBOExportCollectionVO.setTiReferenceNo(aResultSet
						.getString(1));// MASTER_REF
				aTFBOExportCollectionVO.setSolID(aResultSet.getString(2));// BHALF_BRN
				aTFBOExportCollectionVO.setCustomeCif(aResultSet.getString(3));// CUS_MNM
				// aTFBOExportCollectionVO.setAmount(aResultSet.getString(4));//AMOUNT
				aTFBOExportCollectionVO.setCurrency(aResultSet.getString(5));// CCY
				aTFBOExportCollectionVO
						.setUsancePeriod(aResultSet.getString(6));// USANCEPERIOD
				aTFBOExportCollectionVO.setDirect(aResultSet.getString(7));// DIRECT
				aTFBOExportCollectionVO.setMtReceived(aResultSet.getString(8));// MT_RECEIVED
				aTFBOExportCollectionVO.setPartPayment(aResultSet.getString(9));// PART_PAYMENT
				// Rate taken Fix Offshore Team 06012020 starts
				aTFBOExportCollectionVO.setSubProductCode(aResultSet
						.getString(10));// PRODUCT_TYPE
				// Rate taken Fix Offshore Team 06012020 ends
				aTFBOExportCollectionVO.setPreshipAccSettled(aResultSet
						.getString(11));// PRESHIP_ACC_SETTELED
				aTFBOExportCollectionVO.setDocumentDispatch(aResultSet
						.getString(12));// DOCUMENT_DISPATCH
				aTFBOExportCollectionVO.setFinanceSameDay(aResultSet
						.getString(13));// TFB.FINANCE_SAME_DAY

				// aTFBOExportCollectionVO.setRateTaken(aResultSet.getString(14));//RATE_TAKEN

				// ADDED BY CHANDRU
				if (aResultSet.getString(14) != null
						&& !aResultSet.getString(14).trim().equals("")) {
					if (aResultSet.getString(14).trim().equalsIgnoreCase("Y")) {
						aTFBOExportCollectionVO.setRateTaken("true");
					} else {
						aTFBOExportCollectionVO.setRateTaken("false");
					}
				}
				// ENDS

				aTFBOExportCollectionVO.setShipBillFetch(aResultSet
						.getString(15));// SHIP_BILL_FETCH
				aTFBOExportCollectionVO.setToken(aResultSet.getString(16));// TOKEN
				aTFBOExportCollectionVO.setRateTakenK(aResultSet.getString(17));// RATE_TAKEN_K
				aTFBOExportCollectionVO.setRate(aResultSet.getString(18));// RATE
				// Rate taken Fix Offshore Team 06012020 starts
				aTFBOExportCollectionVO.setIrexRefNo(aResultSet.getString(19));// IREX_NO
				// Rate taken Fix Offshore Team 06012020 ends
				odcCreate.add(aTFBOExportCollectionVO);
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}
		logger.info(ActionConstants.EXITING_METHOD + "  " + odcCreate.size());
		return odcCreate;
	}

	// Divya 08012020 ends
	public List<TFBOFinanceExportColVO> getTFBOIFOCCSA1FromDB(String requestId,
			String query) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD + " requestId->"
				+ requestId);
		TFBOFinanceExportColVO aTFBOFinanceExportColVO = null;
		Connection aConnection = null;
		ResultSet aResultSet = null;
		PreparedStatement aPreparedStatement = null;
		List<TFBOFinanceExportColVO> focCreate = new LinkedList<TFBOFinanceExportColVO>();
		try {
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);
			logger.info("query-->" + query);
			logger.info("query-->" + query);
			aPreparedStatement.setString(1, requestId.trim());
			aResultSet = aPreparedStatement.executeQuery();
			while (aResultSet.next()) {
				aTFBOFinanceExportColVO = new TFBOFinanceExportColVO();
				aTFBOFinanceExportColVO.setTiReferenceNo(aResultSet
						.getString(1));
				aTFBOFinanceExportColVO.setSolID(aResultSet.getString(2));
				aTFBOFinanceExportColVO.setCustomeCif(aResultSet.getString(3));
				aTFBOFinanceExportColVO.setAmount(aResultSet.getString(4));
				aTFBOFinanceExportColVO.setFinanceAmount(aResultSet
						.getString(5));
				aTFBOFinanceExportColVO.setCurrency(aResultSet.getString(6));
				aTFBOFinanceExportColVO
						.setUsancePeriod(aResultSet.getString(7));
				aTFBOFinanceExportColVO.setFOCProductType(aResultSet
						.getString(8));
				aTFBOFinanceExportColVO.setPreshipAccSettled(aResultSet
						.getString(9));
				// aTFBOFinanceExportColVO.setRateTaken(aResultSet.getString(10));

				// ADDED BY CHANDRU
				if (aResultSet.getString(10) != null
						&& !aResultSet.getString(10).trim().equals("")) {
					if (aResultSet.getString(10).equalsIgnoreCase("Y")) {
						aTFBOFinanceExportColVO.setRateTaken("true");
					} else {
						aTFBOFinanceExportColVO.setRateTaken("false");
					}
				}
				// ENDS

				aTFBOFinanceExportColVO.setToken(aResultSet.getString(11));
				aTFBOFinanceExportColVO.setRateTakenK(aResultSet.getString(12));
				aTFBOFinanceExportColVO.setRate(aResultSet.getString(13));
				aTFBOFinanceExportColVO.setSubProductCode(aResultSet
						.getString(14));
				aTFBOFinanceExportColVO.setRequestId(aResultSet.getString(15));
				focCreate.add(aTFBOFinanceExportColVO);
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}
		logger.info(ActionConstants.EXITING_METHOD + "  " + focCreate.size());
		return focCreate;

	}

	public List<TFBOFinanceStandaloneVO> getTFBOIFSACREFromDB(String requestId,
			String query) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD + " requestId->"
				+ requestId);
		TFBOFinanceStandaloneVO aTFBOFinanceStandaloneVO = null;
		Connection aConnection = null;
		ResultSet aResultSet = null;
		PreparedStatement aPreparedStatement = null;
		List<TFBOFinanceStandaloneVO> fsaList = new LinkedList<TFBOFinanceStandaloneVO>();
		try {
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);
			logger.info("query-->" + query);
			logger.info("query-->" + query);
			aPreparedStatement.setString(1, requestId.trim());
			aResultSet = aPreparedStatement.executeQuery();
			while (aResultSet.next()) {
				aTFBOFinanceStandaloneVO = new TFBOFinanceStandaloneVO();
				aTFBOFinanceStandaloneVO.setTiReferenceNo(aResultSet
						.getString(1));
				aTFBOFinanceStandaloneVO.setSolID(aResultSet.getString(2));
				aTFBOFinanceStandaloneVO.setCustomeCif(aResultSet.getString(3));
				aTFBOFinanceStandaloneVO.setAmount(aResultSet.getString(4));
				aTFBOFinanceStandaloneVO.setCurrency(aResultSet.getString(5));
				aTFBOFinanceStandaloneVO.setUsancePeriod(aResultSet
						.getString(6));
				aTFBOFinanceStandaloneVO.setSubProductCode(aResultSet
						.getString(7));
				aTFBOFinanceStandaloneVO.setRateTaken(aResultSet.getString(8));
				aTFBOFinanceStandaloneVO.setToken(aResultSet.getString(9));
				aTFBOFinanceStandaloneVO
						.setRateTakenK(aResultSet.getString(10));
				aTFBOFinanceStandaloneVO.setRate(aResultSet.getString(11));

				aTFBOFinanceStandaloneVO.setRequestId(aResultSet.getString(12));
				fsaList.add(aTFBOFinanceStandaloneVO);
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}
		logger.info(ActionConstants.EXITING_METHOD + "  " + fsaList.size());
		return fsaList;

	}

	public List<TFBOFinanceStandaloneVO> getTFBOIFSAADJFromDB(String requestId,
			String query) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD + " requestId->"
				+ requestId);
		TFBOFinanceStandaloneVO aTFBOFinanceStandaloneVO = null;
		Connection aConnection = null;
		ResultSet aResultSet = null;
		PreparedStatement aPreparedStatement = null;
		List<TFBOFinanceStandaloneVO> fsaList = new LinkedList<TFBOFinanceStandaloneVO>();
		try {
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);
			logger.info("query-->" + query);
			logger.info("query-->" + query);
			aPreparedStatement.setString(1, requestId.trim());
			aResultSet = aPreparedStatement.executeQuery();
			while (aResultSet.next()) {
				aTFBOFinanceStandaloneVO = new TFBOFinanceStandaloneVO();
				aTFBOFinanceStandaloneVO.setTiReferenceNo(aResultSet
						.getString(1));
				aTFBOFinanceStandaloneVO.setSolID(aResultSet.getString(2));
				aTFBOFinanceStandaloneVO.setCustomeCif(aResultSet.getString(3));
				aTFBOFinanceStandaloneVO.setAmount(aResultSet.getString(4));
				aTFBOFinanceStandaloneVO.setCurrency(aResultSet.getString(5));
				aTFBOFinanceStandaloneVO.setUsancePeriod(aResultSet
						.getString(6));
				aTFBOFinanceStandaloneVO.setSubProductCode(aResultSet
						.getString(7));
				aTFBOFinanceStandaloneVO.setRateTaken(aResultSet.getString(8));
				aTFBOFinanceStandaloneVO.setToken(aResultSet.getString(9));
				aTFBOFinanceStandaloneVO
						.setRateTakenK(aResultSet.getString(10));
				aTFBOFinanceStandaloneVO.setRate(aResultSet.getString(11));
				aTFBOFinanceStandaloneVO.setMaturityDate(aResultSet
						.getString(12));
				aTFBOFinanceStandaloneVO.setRequestId(aResultSet.getString(13));
				fsaList.add(aTFBOFinanceStandaloneVO);
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}
		logger.info(ActionConstants.EXITING_METHOD + "  " + fsaList.size());
		return fsaList;
	}

	public List<TFBOFinanceStandaloneVO> getTFBOIFSAJSAFromDB(String masterRef,
			String query) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD + " requestId->"
				+ masterRef);
		TFBOFinanceStandaloneVO aTFBOFinanceStandaloneVO = null;
		Connection aConnection = null;
		ResultSet aResultSet = null;
		PreparedStatement aPreparedStatement = null;
		List<TFBOFinanceStandaloneVO> fsaList = new LinkedList<TFBOFinanceStandaloneVO>();
		try {
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);
			logger.info("query-->" + query);
			logger.info("query-->" + query);
			aPreparedStatement.setString(1, masterRef.trim());
			aResultSet = aPreparedStatement.executeQuery();
			while (aResultSet.next()) {
				aTFBOFinanceStandaloneVO = new TFBOFinanceStandaloneVO();
				aTFBOFinanceStandaloneVO.setTiReferenceNo(aResultSet
						.getString(1));
				aTFBOFinanceStandaloneVO.setSolID(aResultSet.getString(2));
				aTFBOFinanceStandaloneVO.setCurrency(aResultSet.getString(3));
				aTFBOFinanceStandaloneVO.setCustomeCif(aResultSet.getString(4));
				aTFBOFinanceStandaloneVO.setUsancePeriod(aResultSet
						.getString(5));
				aTFBOFinanceStandaloneVO.setAmount(aResultSet.getString(6));
				aTFBOFinanceStandaloneVO.setSubProductCode(aResultSet
						.getString(7));
				fsaList.add(aTFBOFinanceStandaloneVO);
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}
		logger.info(ActionConstants.EXITING_METHOD + "  " + fsaList.size());
		return fsaList;
	}

	public List<TFBOFinanceStandaloneVO> getTFBOIFSARSAFromDB(String masterRef,
			String query) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD + " requestId->"
				+ masterRef);
		TFBOFinanceStandaloneVO aTFBOFinanceStandaloneVO = null;
		Connection aConnection = null;
		ResultSet aResultSet = null;
		PreparedStatement aPreparedStatement = null;
		List<TFBOFinanceStandaloneVO> fsaList = new LinkedList<TFBOFinanceStandaloneVO>();
		try {
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);
			logger.info("query-->" + query);
			logger.info("query-->" + query);
			aPreparedStatement.setString(1, masterRef.trim());
			aResultSet = aPreparedStatement.executeQuery();
			while (aResultSet.next()) {
				aTFBOFinanceStandaloneVO = new TFBOFinanceStandaloneVO();
				aTFBOFinanceStandaloneVO.setTiReferenceNo(aResultSet
						.getString(1));
				aTFBOFinanceStandaloneVO.setSolID(aResultSet.getString(2));
				aTFBOFinanceStandaloneVO.setCurrency(aResultSet.getString(3));
				aTFBOFinanceStandaloneVO.setCustomeCif(aResultSet.getString(4));
				aTFBOFinanceStandaloneVO.setUsancePeriod(aResultSet
						.getString(5));
				aTFBOFinanceStandaloneVO.setSubProductCode(aResultSet
						.getString(6));
				fsaList.add(aTFBOFinanceStandaloneVO);
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}
		logger.info(ActionConstants.EXITING_METHOD + "  " + fsaList.size());
		return fsaList;
	}

	public List<TFBOFinanceStandaloneVO> getTFBOIFSAREPAYFromDB(
			String requestId, String query) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD + " requestId->"
				+ requestId);
		TFBOFinanceStandaloneVO aTFBOFinanceStandaloneVO = null;
		Connection aConnection = null;
		ResultSet aResultSet = null;
		PreparedStatement aPreparedStatement = null;
		List<TFBOFinanceStandaloneVO> fsaList = new LinkedList<TFBOFinanceStandaloneVO>();
		try {
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);
			logger.info("query-->" + query);
			logger.info("query-->" + query);
			aPreparedStatement.setString(1, requestId.trim());
			aResultSet = aPreparedStatement.executeQuery();
			while (aResultSet.next()) {
				aTFBOFinanceStandaloneVO = new TFBOFinanceStandaloneVO();
				aTFBOFinanceStandaloneVO.setTiReferenceNo(aResultSet
						.getString(1));
				aTFBOFinanceStandaloneVO.setSolID(aResultSet.getString(2));
				aTFBOFinanceStandaloneVO.setCustomeCif(aResultSet.getString(3));
				aTFBOFinanceStandaloneVO.setAmount(aResultSet.getString(4));
				aTFBOFinanceStandaloneVO.setCurrency(aResultSet.getString(5));
				aTFBOFinanceStandaloneVO.setUsancePeriod(aResultSet
						.getString(6));
				aTFBOFinanceStandaloneVO.setSubProductCode(aResultSet
						.getString(7));
				aTFBOFinanceStandaloneVO.setRateTaken(aResultSet.getString(8));
				aTFBOFinanceStandaloneVO.setToken(aResultSet.getString(9));
				aTFBOFinanceStandaloneVO
						.setRateTakenK(aResultSet.getString(10));
				aTFBOFinanceStandaloneVO.setRate(aResultSet.getString(11));
				aTFBOFinanceStandaloneVO.setPartLiqu(aResultSet.getString(12));
				aTFBOFinanceStandaloneVO.setPcAmount(aResultSet.getString(13));
				aTFBOFinanceStandaloneVO.setRequestId(aResultSet.getString(14));
				fsaList.add(aTFBOFinanceStandaloneVO);
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}
		logger.info(ActionConstants.EXITING_METHOD + "  " + fsaList.size());
		return fsaList;
	}

	public List<TFBOFinanceExportColVO> getTFBOIFOCADJUSTFromDB(
			String requestId, String query) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD + " requestId->"
				+ requestId);
		TFBOFinanceExportColVO aTFBOFinanceExportColVO = null;
		Connection aConnection = null;
		ResultSet aResultSet = null;
		PreparedStatement aPreparedStatement = null;
		List<TFBOFinanceExportColVO> focCreate = new LinkedList<TFBOFinanceExportColVO>();
		try {
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);
			logger.info("query-->" + query);
			logger.info("query-->" + query);
			aPreparedStatement.setString(1, requestId.trim());
			aResultSet = aPreparedStatement.executeQuery();
			while (aResultSet.next()) {
				aTFBOFinanceExportColVO = new TFBOFinanceExportColVO();
				aTFBOFinanceExportColVO.setTiReferenceNo(aResultSet
						.getString(1));
				aTFBOFinanceExportColVO.setSolID(aResultSet.getString(2));
				aTFBOFinanceExportColVO.setCustomeCif(aResultSet.getString(3));
				aTFBOFinanceExportColVO.setFinanceAmount(aResultSet
						.getString(4));
				aTFBOFinanceExportColVO.setCurrency(aResultSet.getString(5));
				aTFBOFinanceExportColVO
						.setUsancePeriod(aResultSet.getString(6));
				aTFBOFinanceExportColVO.setSubProductCode(aResultSet
						.getString(7));
				aTFBOFinanceExportColVO
						.setMaturityDate(aResultSet.getString(8));
				aTFBOFinanceExportColVO.setRequestId(aResultSet.getString(9));
				focCreate.add(aTFBOFinanceExportColVO);
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}
		logger.info(ActionConstants.EXITING_METHOD + "  " + focCreate.size());
		return focCreate;
	}

	public List<TFBOFinanceExportColVO> getTFBOIFOCREPAYFromDB(
			String requestId, String query) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD + " requestId->"
				+ requestId);
		TFBOFinanceExportColVO aTFBOFinanceExportColVO = null;
		Connection aConnection = null;
		ResultSet aResultSet = null;
		PreparedStatement aPreparedStatement = null;
		List<TFBOFinanceExportColVO> focList = new LinkedList<TFBOFinanceExportColVO>();
		try {
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);
			logger.info("query-->" + query);
			logger.info("query-->" + query);
			aPreparedStatement.setString(1, requestId.trim());
			aResultSet = aPreparedStatement.executeQuery();
			while (aResultSet.next()) {
				aTFBOFinanceExportColVO = new TFBOFinanceExportColVO();
				aTFBOFinanceExportColVO.setTiReferenceNo(aResultSet
						.getString(1));
				aTFBOFinanceExportColVO.setSolID(aResultSet.getString(2));
				aTFBOFinanceExportColVO.setCustomeCif(aResultSet.getString(3));
				aTFBOFinanceExportColVO.setFinanceAmount(aResultSet
						.getString(4));
				aTFBOFinanceExportColVO.setCurrency(aResultSet.getString(5));
				aTFBOFinanceExportColVO
						.setUsancePeriod(aResultSet.getString(6));
				aTFBOFinanceExportColVO.setSubProductCode(aResultSet
						.getString(7));
				aTFBOFinanceExportColVO.setFinalRepay(aResultSet.getString(8));
				// aTFBOFinanceExportColVO.setRateTaken(aResultSet.getString(9));

				// ADDED BY CHANDRU
				if (aResultSet.getString(9) != null
						&& !aResultSet.getString(9).trim().equals("")) {
					if (aResultSet.getString(9).equalsIgnoreCase("Y")) {
						aTFBOFinanceExportColVO.setRateTaken("true");
					} else {
						aTFBOFinanceExportColVO.setRateTaken("false");
					}
				}
				// ENDS

				aTFBOFinanceExportColVO.setToken(aResultSet.getString(10));
				aTFBOFinanceExportColVO.setRateTakenK(aResultSet.getString(11));
				aTFBOFinanceExportColVO.setRate(aResultSet.getString(12));
				aTFBOFinanceExportColVO.setRequestId(aResultSet.getString(13));
				aTFBOFinanceExportColVO.setPreshipAccSettled(aResultSet
						.getString(14));
				aTFBOFinanceExportColVO
						.setSenderRefno(aResultSet.getString(15));
				focList.add(aTFBOFinanceExportColVO);
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}
		logger.info(ActionConstants.EXITING_METHOD + "  " + focList.size());
		return focList;
	}

	public List<TFBOFinanceExportColVO> getTFBOIFOCCRYSTFromDB(
			String requestId, String query) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD + " requestId->"
				+ requestId);
		TFBOFinanceExportColVO aTFBOFinanceExportColVO = null;
		Connection aConnection = null;
		ResultSet aResultSet = null;
		PreparedStatement aPreparedStatement = null;
		List<TFBOFinanceExportColVO> focList = new LinkedList<TFBOFinanceExportColVO>();
		try {
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);
			logger.info("query-->" + query);
			logger.info("query-->" + query);
			aPreparedStatement.setString(1, requestId.trim());
			aResultSet = aPreparedStatement.executeQuery();
			while (aResultSet.next()) {
				aTFBOFinanceExportColVO = new TFBOFinanceExportColVO();
				aTFBOFinanceExportColVO.setTiReferenceNo(aResultSet
						.getString(1));
				aTFBOFinanceExportColVO.setSolID(aResultSet.getString(2));
				aTFBOFinanceExportColVO.setCustomeCif(aResultSet.getString(3));
				aTFBOFinanceExportColVO.setFinanceAmount(aResultSet
						.getString(4));
				aTFBOFinanceExportColVO.setCurrency(aResultSet.getString(5));
				aTFBOFinanceExportColVO
						.setUsancePeriod(aResultSet.getString(6));
				aTFBOFinanceExportColVO.setSubProductCode(aResultSet
						.getString(7));
				aTFBOFinanceExportColVO.setFinalRepay(aResultSet.getString(8));
				// aTFBOFinanceExportColVO.setRateTaken(aResultSet.getString(9));

				// ADDED BY CHANDRU
				if (aResultSet.getString(9) != null
						&& !aResultSet.getString(9).trim().equals("")) {
					if (aResultSet.getString(9).equalsIgnoreCase("Y")) {
						aTFBOFinanceExportColVO.setRateTaken("true");
					} else {
						aTFBOFinanceExportColVO.setRateTaken("false");
					}
				}
				// ENDS

				aTFBOFinanceExportColVO.setToken(aResultSet.getString(10));
				aTFBOFinanceExportColVO.setRateTakenK(aResultSet.getString(11));
				aTFBOFinanceExportColVO.setRate(aResultSet.getString(12));
				aTFBOFinanceExportColVO.setRequestId(aResultSet.getString(13));
				focList.add(aTFBOFinanceExportColVO);
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}
		logger.info(ActionConstants.EXITING_METHOD + "  " + focList.size());
		return focList;
	}

	public List<TFBOFinanceExportColVO> getTFBOIFOCCREFromDB(String requestId,
			String query) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD + " requestId->"
				+ requestId);
		TFBOFinanceExportColVO aTFBOFinanceExportColVO = null;
		Connection aConnection = null;
		ResultSet aResultSet = null;
		PreparedStatement aPreparedStatement = null;
		List<TFBOFinanceExportColVO> focCreate = new LinkedList<TFBOFinanceExportColVO>();
		try {
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);
			logger.info("query-->" + query);
			logger.info("query-->" + query);
			aPreparedStatement.setString(1, requestId.trim());
			aResultSet = aPreparedStatement.executeQuery();
			while (aResultSet.next()) {
				aTFBOFinanceExportColVO = new TFBOFinanceExportColVO();
				aTFBOFinanceExportColVO.setTiReferenceNo(aResultSet
						.getString(1));
				aTFBOFinanceExportColVO.setSolID(aResultSet.getString(2));
				aTFBOFinanceExportColVO.setCustomeCif(aResultSet.getString(3));
				aTFBOFinanceExportColVO.setAmount(aResultSet.getString(4));
				aTFBOFinanceExportColVO
						.setUsancePeriod(aResultSet.getString(5));
				aTFBOFinanceExportColVO.setPreshipAccSettled(aResultSet
						.getString(6));
				focCreate.add(aTFBOFinanceExportColVO);
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}
		logger.info(ActionConstants.EXITING_METHOD + "  " + focCreate.size());
		return focCreate;
	}

	public List<TFBOFinanceExportColVO> getTFBOIFOCADJFromDB(String requestId,
			String query) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD + " requestId->"
				+ requestId);
		TFBOFinanceExportColVO aTFBOFinanceExportColVO = null;
		Connection aConnection = null;
		ResultSet aResultSet = null;
		PreparedStatement aPreparedStatement = null;
		List<TFBOFinanceExportColVO> focList = new LinkedList<TFBOFinanceExportColVO>();
		try {
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);
			logger.info("query-->" + query);
			logger.info("query-->" + query);
			aPreparedStatement.setString(1, requestId.trim());
			aResultSet = aPreparedStatement.executeQuery();
			while (aResultSet.next()) {
				aTFBOFinanceExportColVO = new TFBOFinanceExportColVO();
				aTFBOFinanceExportColVO.setTiReferenceNo(aResultSet
						.getString(1));
				aTFBOFinanceExportColVO.setSolID(aResultSet.getString(2));
				aTFBOFinanceExportColVO.setCurrency(aResultSet.getString(3));
				aTFBOFinanceExportColVO.setCustomeCif(aResultSet.getString(4));
				aTFBOFinanceExportColVO
						.setUsancePeriod(aResultSet.getString(5));
				aTFBOFinanceExportColVO.setFinanceAmount(aResultSet
						.getString(6));
				aTFBOFinanceExportColVO.setSubProductCode(aResultSet
						.getString(7));
				aTFBOFinanceExportColVO.setPreshipAccSettled(aResultSet
						.getString(8));
				focList.add(aTFBOFinanceExportColVO);
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}
		logger.info(ActionConstants.EXITING_METHOD + "  " + focList.size());
		return focList;
	}

	public List<TFBOFinanceExportColVO> getTFBOFOCRPYFromDB(String tiRef,
			String query) {
		Connection aConnection = null;
		ResultSet aResultSet = null;
		PreparedStatement aPreparedStatement = null;
		String preShipAcc = "";
		TFBOFinanceExportColVO aTFBOFinanceExportColVO = null;
		List<TFBOFinanceExportColVO> focList = new LinkedList<TFBOFinanceExportColVO>();
		try {
			aTFBOFinanceExportColVO = new TFBOFinanceExportColVO();
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);
			logger.info("query-->" + query);
			aPreparedStatement.setString(1, tiRef.trim());
			aResultSet = aPreparedStatement.executeQuery();
			while (aResultSet.next()) {
				aTFBOFinanceExportColVO.setPreshipAccSettled(aResultSet
						.getString(1));
				focList.add(aTFBOFinanceExportColVO);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return focList;
	}

	public String setValueFOCCREInDB(String value1, String value2,
			String value3, String value4, String value5, String value6,
			String value7, String value8, String value9, String value10,
			String value11, String value12, String value13, String query)
			throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD + "setValueInDB");
		String resultValue = null;
		Connection aConnection = null;
		ResultSet aResultSet = null;
		PreparedStatement aPreparedStatement = null;
		try {
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);
			logger.info("query-->" + query);
			aPreparedStatement.setString(1, value1.trim());
			aPreparedStatement.setString(2, value2.trim());
			aPreparedStatement.setString(3, value3.trim());
			aPreparedStatement.setString(4, value4.trim());
			aPreparedStatement.setString(5, value5.trim());
			aPreparedStatement.setString(6, value6.trim());
			aPreparedStatement.setString(7, value7.trim());
			aPreparedStatement.setString(8, value8.trim());
			aPreparedStatement.setString(9, value9.trim());
			aPreparedStatement.setString(10, value10.trim());
			aPreparedStatement.setString(11, value11.trim());
			aPreparedStatement.setString(12, value12.trim());
			aPreparedStatement.setString(13, value13.trim());
			aPreparedStatement.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}
		logger.info(ActionConstants.EXITING_METHOD + "setValueInDB");
		return resultValue;
	}

	public String setValueFOCADJInDB(String value1, String value2,
			String value3, String value4, String value5, String value6,
			String value7, String value8, String query) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD + "setValueInDB");
		String resultValue = null;
		Connection aConnection = null;
		ResultSet aResultSet = null;
		PreparedStatement aPreparedStatement = null;
		try {
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);
			logger.info("query-->" + query);
			aPreparedStatement.setString(1, value1.trim());
			aPreparedStatement.setString(2, value2.trim());
			aPreparedStatement.setString(3, value3.trim());
			aPreparedStatement.setString(4, value4.trim());
			aPreparedStatement.setString(5, value5.trim());
			aPreparedStatement.setString(6, value6.trim());
			aPreparedStatement.setString(7, value7.trim());
			aPreparedStatement.setString(8, value8.trim());
			aPreparedStatement.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}
		logger.info(ActionConstants.EXITING_METHOD + "setValueInDB");
		return resultValue;
	}

	public List<String> getListFromDB(String query) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		List<String> valueList = new LinkedList<String>();
		Connection aConnection = null;
		ResultSet aResultSet = null;
		PreparedStatement aPreparedStatement = null;
		try {
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);
			logger.info("query-->" + query);
			aResultSet = aPreparedStatement.executeQuery();
			while (aResultSet.next()) {
				String resultValue = "";
				resultValue = aResultSet.getString(1);
				valueList.add(resultValue);
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}
		logger.info(ActionConstants.EXITING_METHOD + "  " + valueList.size());
		return valueList;
	}

	public List<String> getListFromDB(String value, String query)
			throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD + " value->" + value);
		List<String> valueList = new LinkedList<String>();
		Connection aConnection = null;
		ResultSet aResultSet = null;
		PreparedStatement aPreparedStatement = null;
		try {
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);
			logger.info("query-->" + query);
			aPreparedStatement.setString(1, value.trim());
			aResultSet = aPreparedStatement.executeQuery();
			while (aResultSet.next()) {
				String resultValue = "";
				resultValue = aResultSet.getString(1);
				valueList.add(resultValue);
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}
		logger.info(ActionConstants.EXITING_METHOD + "  " + valueList.size());
		return valueList;
	}

	public List<String> getListFromDB(String value, String value1, String query)
			throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD + " value->" + value);
		List<String> valueList = new LinkedList<String>();
		Connection aConnection = null;
		ResultSet aResultSet = null;
		PreparedStatement aPreparedStatement = null;
		try {
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);
			logger.info("query-->" + query);
			aPreparedStatement.setString(1, value.trim());
			aPreparedStatement.setString(2, value1.trim());
			aResultSet = aPreparedStatement.executeQuery();
			while (aResultSet.next()) {
				String resultValue = "";
				resultValue = aResultSet.getString(1);
				valueList.add(resultValue);
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}
		logger.info(ActionConstants.EXITING_METHOD + "  " + valueList.size());
		return valueList;
	}

	public List<TFBOChecklistVO> getChecklistFromDB(String requestId,
			String subProductCode, String team, String query) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		TFBOChecklistVO aTFBOChecklistVO = null;
		Connection aConnection = null;
		ResultSet aResultSet = null;
		PreparedStatement aPreparedStatement = null;
		List<TFBOChecklistVO> makerChecklist = new LinkedList<TFBOChecklistVO>();
		try {
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);
			logger.info("query-->" + query);
			aPreparedStatement.setString(1, requestId);
			aPreparedStatement.setString(2, team);
			aPreparedStatement.setString(3, subProductCode);
			aResultSet = aPreparedStatement.executeQuery();
			while (aResultSet.next()) {
				aTFBOChecklistVO = new TFBOChecklistVO();
				aTFBOChecklistVO.setChecklistId(aResultSet.getString(1));
				aTFBOChecklistVO.setChecklistDetails(aResultSet.getString(2));
				aTFBOChecklistVO.setChecklistValue(aResultSet.getString(3));
				aTFBOChecklistVO.setChecklistRemarks(aResultSet.getString(4));
				aTFBOChecklistVO.setChecklistHeader(aResultSet.getString(5));

				makerChecklist.add(aTFBOChecklistVO);
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}
		logger.info(ActionConstants.EXITING_METHOD + "  "
				+ makerChecklist.size());
		return makerChecklist;
	}

	public void updateTIReferenceInTool(String query, String updateQuery)
			throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		Connection aConnection = null;
		ResultSet aResultSet = null;
		PreparedStatement aPreparedStatement = null;
		String tiMasterRef = "";
		String tfboMasterRef = "";
		String tfboRequestId = "";
		try {
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);
			logger.info("query-->" + query);
			aResultSet = aPreparedStatement.executeQuery();
			while (aResultSet.next()) {
				tiMasterRef = aResultSet.getString(1);
				tfboMasterRef = aResultSet.getString(2);
				tfboRequestId = aResultSet.getString(3);
				if (!(tiMasterRef.trim().equalsIgnoreCase(tfboMasterRef.trim()))) {
					logger.info("updateQuery-->" + updateQuery);
					aPreparedStatement = aConnection
							.prepareStatement(updateQuery);
					aPreparedStatement.setString(1, tiMasterRef);
					aPreparedStatement.setString(2, tfboRequestId.trim());
					aPreparedStatement.executeUpdate();
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}
	}

	public List<TFBOTransVO> getTransactionListFromDB(String requestId,
			String productCode, String eventCode, String step,
			String stepStatus, String isQueried, String isTiTransFlag,
			String fromDate, String toDate, String subprod, String query)
			throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD + " requestId->"
				+ requestId);
		TFBOTransVO aTFBOTransVO = null;
		Connection aConnection = null;
		ResultSet aResultSet = null;
		PreparedStatement aPreparedStatement = null;
		List<TFBOTransVO> transactionList = new LinkedList<TFBOTransVO>();
		try {
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);
			logger.info("query-->" + query);
			if (isTiTransFlag.equalsIgnoreCase("N")) {

				aPreparedStatement.setString(1, "%" + requestId + "%");
				aPreparedStatement.setString(2, "%" + productCode + "%");
				aPreparedStatement.setString(3, "%" + eventCode + "%");
				aPreparedStatement.setString(4, "%" + step + "%");
				aPreparedStatement.setString(5, "%" + stepStatus + "%");
				aPreparedStatement.setString(6, "%" + isQueried + "%");
				aPreparedStatement.setString(7, fromDate);
				aPreparedStatement.setString(8, toDate);
			}
			// Offshore team Changes04012020 starts

			/*
			 * if (isTiTransFlag.equalsIgnoreCase("Y")) {
			 * aPreparedStatement.setString(1, productCode.trim());
			 * aPreparedStatement.setString(2, stepStatus.trim());
			 * aPreparedStatement.setString(3, step.trim()); }
			 */

			if (isTiTransFlag.equalsIgnoreCase("Y")) {
				aPreparedStatement.setString(1, "%" + requestId + "%");
				aPreparedStatement.setString(2, productCode.trim());
				aPreparedStatement.setString(3, eventCode.trim());
				aPreparedStatement.setString(4, stepStatus.trim());
				aPreparedStatement.setString(5, "%" + isQueried + "%");
				aPreparedStatement.setString(6, fromDate);
				aPreparedStatement.setString(7, toDate);
				aPreparedStatement.setString(8, step.trim());
			}
			// Offshore team Changes 04012020 ends

			aResultSet = aPreparedStatement.executeQuery();
			while (aResultSet.next()) {
				aTFBOTransVO = new TFBOTransVO();
				aTFBOTransVO.setRequestId(aResultSet.getString(1));
				aTFBOTransVO.setTiReferenceNo(aResultSet.getString(2));
				aTFBOTransVO.setProductCode(aResultSet.getString(3));
				aTFBOTransVO.setEventCode(aResultSet.getString(4));
				aTFBOTransVO.setProductCodeDescription(aResultSet.getString(5));
				aTFBOTransVO.setEventCodeDescription(aResultSet.getString(6));
				aTFBOTransVO.setSubProductCode(aResultSet.getString(7));
				aTFBOTransVO.setStep(aResultSet.getString(8));
				aTFBOTransVO.setStepStatus(aResultSet.getString(9));
				aTFBOTransVO.setTransCreatedDate(aResultSet.getString(10));
				aTFBOTransVO.setTransModifiedDate(aResultSet.getString(11));

				transactionList.add(aTFBOTransVO);
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}
		logger.info(ActionConstants.EXITING_METHOD + "  "
				+ transactionList.size());
		return transactionList;
	}

	// karthika 08012020 starts
	public List<TFBOTransVO> getTransactionListFromDB(String requestId,
			String productCode, String eventCode, String step,
			String stepStatus, String isQueried, String isTiTransFlag,
			String fromDate, String toDate, String subProduct,
			String tiReference, String query) throws Exception {
		// Dashboard Changes ends 07-01-2020

		logger.info(ActionConstants.ENTERING_METHOD + " requestId->"
				+ requestId);
		TFBOTransVO aTFBOTransVO = null;
		Connection aConnection = null;
		ResultSet aResultSet = null;
		PreparedStatement aPreparedStatement = null;
		List<TFBOTransVO> transactionList = new LinkedList<TFBOTransVO>();
		try {
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);
			logger.info("query-->" + query);
			if (isTiTransFlag.equalsIgnoreCase("N")) {
				aPreparedStatement.setString(1, "%" + requestId + "%");
				aPreparedStatement.setString(2, "%" + productCode + "%");
				aPreparedStatement.setString(3, "%" + eventCode + "%");
				aPreparedStatement.setString(4, "%" + step + "%");
				aPreparedStatement.setString(5, "%" + stepStatus + "%");
				aPreparedStatement.setString(6, "%" + isQueried + "%");
				aPreparedStatement.setString(7, fromDate);
				aPreparedStatement.setString(8, toDate);

				// Dashboard Changes starts 07-01-2020
				aPreparedStatement.setString(9, "%" + subProduct.trim() + "%");
				aPreparedStatement
						.setString(10, "%" + tiReference.trim() + "%");
				// Dashboard Changes ends 07-01-2020
			}

			// Offshore team Changes 04012020 starts
			/*
			 * if (isTiTransFlag.equalsIgnoreCase("Y")) {
			 * aPreparedStatement.setString(1, productCode.trim());
			 * aPreparedStatement.setString(2, stepStatus.trim());
			 * aPreparedStatement.setString(3, step.trim()); }
			 */
			if (isTiTransFlag.equalsIgnoreCase("Y")) {
				aPreparedStatement.setString(1, "%" + requestId + "%");

				// Dashboard Changes starts 07-01-2020
				/*
				 * aPreparedStatement.setString(2, productCode.trim());
				 * aPreparedStatement.setString(3, eventCode.trim());
				 * aPreparedStatement.setString(4, stepStatus.trim());
				 */
				aPreparedStatement.setString(2, "%" + productCode.trim() + "%");
				aPreparedStatement.setString(3, "%" + eventCode.trim() + "%");
				aPreparedStatement.setString(4, "%" + stepStatus.trim() + "%");

				// Dashboard Changes ends 07-01-2020

				aPreparedStatement.setString(5, "%" + isQueried + "%");
				aPreparedStatement.setString(6, fromDate);
				aPreparedStatement.setString(7, toDate);

				// Dashboard Changes starts 07-01-2020
				/* aPreparedStatement.setString(8, step.trim()); */
				aPreparedStatement.setString(8, "%" + step.trim() + "%");
				// Dashboard Changes ends 07-01-2020

				// Dashboard Changes starts 07-01-2020
				aPreparedStatement.setString(9, "%" + subProduct.trim() + "%");
				aPreparedStatement
						.setString(10, "%" + tiReference.trim() + "%");
				// Dashboard Changes ends 07-01-2020
			}
			// Offshore team Changes 04012020 ends

			aResultSet = aPreparedStatement.executeQuery();

			/*
			 * System.out.println("Final query--->"+aPreparedStatement.
			 * getQueryString());
			 */
			while (aResultSet.next()) {
				aTFBOTransVO = new TFBOTransVO();
				aTFBOTransVO.setRequestId(aResultSet.getString(1));
				aTFBOTransVO.setTiReferenceNo(aResultSet.getString(2));
				aTFBOTransVO.setProductCode(aResultSet.getString(3));
				aTFBOTransVO.setEventCode(aResultSet.getString(4));

				// Offshore team Changes 04012020 starts
				/*
				 * aTFBOTransVO.setSubProductCode(aResultSet.getString(5));
				 * aTFBOTransVO.setStep(aResultSet.getString(6));
				 * aTFBOTransVO.setStepStatus(aResultSet.getString(7));
				 * aTFBOTransVO.setTransCreatedDate(aResultSet.getString(8));
				 * aTFBOTransVO.setTransModifiedDate(aResultSet.getString(9));
				 */

				aTFBOTransVO.setProductCodeDescription(aResultSet.getString(5));
				aTFBOTransVO.setEventCodeDescription(aResultSet.getString(6));
				aTFBOTransVO.setSubProductCode(aResultSet.getString(7));
				aTFBOTransVO.setStep(aResultSet.getString(8));
				aTFBOTransVO.setStepStatus(aResultSet.getString(9));
				aTFBOTransVO.setTransCreatedDate(aResultSet.getString(10));
				aTFBOTransVO.setTransModifiedDate(aResultSet.getString(11));
				// Offshore team Changes 04012020 ends
				transactionList.add(aTFBOTransVO);
			}
			// System.out.println(aTFBOTransVO.getRequestId());
			// System.out.println(aTFBOTransVO.getTiReferenceNo());
			// System.out.println(aTFBOTransVO.getProductCode());
			// System.out.println(aTFBOTransVO.getEventCode());
			// System.out.println(aTFBOTransVO.getProductCodeDescription());
			// System.out.println(aTFBOTransVO.getEventCodeDescription());
			// System.out.println(aTFBOTransVO.getSubProductCode());
			// System.out.println(aTFBOTransVO.getStep());
			// System.out.println(aTFBOTransVO.getStepStatus());
			// System.out.println(aTFBOTransVO.getTransCreatedDate());
			// System.out.println(aTFBOTransVO.getTransModifiedDate());

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}
		logger.info(ActionConstants.EXITING_METHOD + "  "
				+ transactionList.size());
		return transactionList;
	}

	// karthika 08012020 ends

	public List<UserCommentVO> getCommentListFromDB(String requestId,
			String query) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD + " requestId->"
				+ requestId);
		UserCommentVO aUserCommentVO = null;
		Connection aConnection = null;
		ResultSet aResultSet = null;
		PreparedStatement aPreparedStatement = null;
		List<UserCommentVO> userCommentList = new LinkedList<UserCommentVO>();
		try {
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);
			logger.info("query-->" + query);
			aPreparedStatement.setString(1, requestId.trim());
			aResultSet = aPreparedStatement.executeQuery();
			while (aResultSet.next()) {
				aUserCommentVO = new UserCommentVO();
				aUserCommentVO.setCommentDateTime(aResultSet.getString(1));
				aUserCommentVO.setCommentUser(aResultSet.getString(2));
				aUserCommentVO.setCommentStep(aResultSet.getString(3));
				aUserCommentVO.setCommentDetails(aResultSet.getString(4));
				userCommentList.add(aUserCommentVO);
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}
		logger.info(ActionConstants.EXITING_METHOD + "  "
				+ userCommentList.size());
		return userCommentList;
	}

	public List<DocumentUploadVO> getDocumentListFromDB(String requestId,
			String documentFlag) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD + " transID->" + requestId
				+ " documentFlag->" + documentFlag);
		DocumentUploadVO aDocumentUploadVO = null;
		Connection aConnection = null;
		ResultSet aResultSet = null;
		PreparedStatement aPreparedStatement = null;
		List<DocumentUploadVO> documentList = new LinkedList<DocumentUploadVO>();
		try {
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection
					.prepareStatement(ActionConstants.GETDOCUMENTLIST_QUERY);
			logger.info("query-->" + ActionConstants.GETDOCUMENTLIST_QUERY);
			aPreparedStatement.setString(1, documentFlag.trim());
			aPreparedStatement.setString(2, requestId.trim());
			aResultSet = aPreparedStatement.executeQuery();
			while (aResultSet.next()) {
				aDocumentUploadVO = new DocumentUploadVO();
				aDocumentUploadVO.setDocumentID((aResultSet.getString(1)));
				aDocumentUploadVO.setDocumentName((aResultSet.getString(2)));
				aDocumentUploadVO.setDocumentPath((aResultSet.getString(3)));
				aDocumentUploadVO.setDocDesc((aResultSet.getString(4)));
				documentList.add(aDocumentUploadVO);
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}
		logger.info(ActionConstants.EXITING_METHOD + "  " + documentList.size());
		return documentList;
	}

	public String getValueFromDB(String query) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD + "getValueFromDB");
		String resultValue = null;
		Connection aConnection = null;
		ResultSet aResultSet = null;
		PreparedStatement aPreparedStatement = null;
		try {
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);
			logger.info("query-->" + query);
			aResultSet = aPreparedStatement.executeQuery();
			while (aResultSet.next()) {
				resultValue = aResultSet.getString(1);
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}
		logger.info(ActionConstants.EXITING_METHOD + "getValueFromDB");
		return resultValue;
	}

	public UserTransactionVO getDocumentPathFromDB(UserTransactionVO userVo,
			String query) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD + "getValueFromDB");
		Connection aConnection = null;
		ResultSet aResultSet = null;
		PreparedStatement aPreparedStatement = null;
		try {
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);
			logger.info("query-->" + query);
			aPreparedStatement.setString(1, userVo.getDocID().trim());
			aResultSet = aPreparedStatement.executeQuery();
			while (aResultSet.next()) {
				userVo.setDocumentPath(aResultSet.getString(1));
				userVo.setDocumentName(aResultSet.getString(2));
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}
		logger.info(ActionConstants.EXITING_METHOD + "getValueFromDB");
		return userVo;
	}

	public String getValueFromDB(String value, String query) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD + "getValueFromDB");
		String resultValue = "";
		Connection aConnection = null;
		ResultSet aResultSet = null;
		PreparedStatement aPreparedStatement = null;
		try {
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);
			logger.info("query-->" + query);
			aPreparedStatement.setString(1, value);
			aResultSet = aPreparedStatement.executeQuery();
			while (aResultSet.next()) {
				resultValue = aResultSet.getString(1);
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}
		logger.info(ActionConstants.EXITING_METHOD + "getValueFromDB");
		return resultValue;
	}

	public boolean getValueFromDBForLock(UserTransactionVO userVo, String query)
			throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD + "getValueFromDB");
		String resultValue = "";
		String resultValue1 = "";
		Connection aConnection = null;
		ResultSet aResultSet = null;
		PreparedStatement aPreparedStatement = null;
		try {
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);
			logger.info("query-->" + query);
			aPreparedStatement.setString(1, userVo.getRequestId());
			aResultSet = aPreparedStatement.executeQuery();
			while (aResultSet.next()) {
				resultValue = aResultSet.getString(1);
				resultValue1 = aResultSet.getString(2);
			}
			if (resultValue != null && resultValue.equals("1")
					&& resultValue1 != null
					&& !resultValue1.equals(userVo.getSessionUserName())) {
				return true;
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}
		logger.info(ActionConstants.EXITING_METHOD + "getValueFromDB");
		return false;
	}

	public String getValueFromDB(String value1, String value2, String query)
			throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD + "getValueFromDB");
		String resultValue = "";
		Connection aConnection = null;
		ResultSet aResultSet = null;
		PreparedStatement aPreparedStatement = null;
		try {
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);
			logger.info("query-->" + query);
			aPreparedStatement.setString(1, value1.trim());
			aPreparedStatement.setString(2, value2.trim());
			aResultSet = aPreparedStatement.executeQuery();
			while (aResultSet.next()) {
				resultValue = aResultSet.getString(1);
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}
		logger.info(ActionConstants.EXITING_METHOD + "getValueFromDB");
		return resultValue;
	}

	public void deleteTFBOTransChecklist(String requestId, String productCode,
			String eventCode, String query) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD + "setValueInDB");
		Connection aConnection = null;
		ResultSet aResultSet = null;
		PreparedStatement aPreparedStatement = null;
		try {
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);
			logger.info("query-->" + query);
			aPreparedStatement.setString(1, requestId.trim());
			aPreparedStatement.setString(2, productCode.trim());
			aPreparedStatement.setString(3, eventCode.trim());
			aPreparedStatement.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}
		logger.info(ActionConstants.EXITING_METHOD + "setValueInDB");
	}

	public void insertTFBOTransChecklist(String requestId, String productCode,
			String eventCode, String subProductCode, String team, String query)
			throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD + "setValueInDB");
		Connection aConnection = null;
		ResultSet aResultSet = null;
		CallableStatement aCallableStatement = null;
		try {
			aConnection = DBUtility.getZoneConnection();
			aCallableStatement = aConnection.prepareCall(query);
			logger.info("query-->" + query);
			aCallableStatement.setString(1, requestId);
			aCallableStatement.setString(2, productCode);
			aCallableStatement.setString(3, eventCode);
			aCallableStatement.setString(4, subProductCode);
			aCallableStatement.setString(5, team);
			aCallableStatement.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			DBUtility.surrenderDB(aConnection, aCallableStatement, aResultSet);
		}
		logger.info(ActionConstants.EXITING_METHOD + "setValueInDB");
	}

	// Pandi IDC Direct Checklist list starts here
	public void insertTFBOTransChecklist_Direct(String requestId,
			String productCode, String eventCode, String subProductCode,
			String team, String direct, String query) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD + "setValueInDB");
		Connection aConnection = null;
		ResultSet aResultSet = null;
		CallableStatement aCallableStatement = null;
		try {
			aConnection = DBUtility.getZoneConnection();
			aCallableStatement = aConnection.prepareCall(query);
			System.out.println("query-->" + query);
			aCallableStatement.setString(1, requestId);
			aCallableStatement.setString(2, productCode);
			aCallableStatement.setString(3, eventCode);
			aCallableStatement.setString(4, subProductCode);
			aCallableStatement.setString(5, team);
			aCallableStatement.setString(6, direct);
			aCallableStatement.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			DBUtility.surrenderDB(aConnection, aCallableStatement, aResultSet);
		}
		logger.info(ActionConstants.EXITING_METHOD + "setValueInDB");
	}

	// Pandi IDC Direct Checklist list ends here

	public void setValueInDB(String value1, String query) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD + "setValueInDB");
		Connection aConnection = null;
		ResultSet aResultSet = null;
		PreparedStatement aPreparedStatement = null;
		try {
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);
			logger.info("query-->" + query);
			aPreparedStatement.setString(1, value1);
			aPreparedStatement.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}
		logger.info(ActionConstants.EXITING_METHOD + "setValueInDB");
	}

	public void setValueInDB(String value1, String value2, String query)
			throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD + "setValueInDB");
		Connection aConnection = null;
		ResultSet aResultSet = null;
		PreparedStatement aPreparedStatement = null;
		try {
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);
			logger.info("query-->" + query);
			aPreparedStatement.setString(1, value1);
			aPreparedStatement.setString(2, value2);
			aPreparedStatement.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}
		logger.info(ActionConstants.EXITING_METHOD + "setValueInDB");
	}

	/*
	 * public void setValueODCCREInDB(String value1, String value2, String
	 * value3, String value4, String value5, String value6, String value7,
	 * String value8, String value9, String value10, String value11, String
	 * value12, String value13, String value14, String value15, String value16,
	 * String value17, String query) throws Exception {
	 * logger.info(ActionConstants.ENTERING_METHOD + "setValueInDB"); Connection
	 * aConnection = null; ResultSet aResultSet = null; PreparedStatement
	 * aPreparedStatement = null; try { aConnection =
	 * DBUtility.getZoneConnection(); aPreparedStatement =
	 * aConnection.prepareStatement(query); logger.info("query-->" + query);
	 * aPreparedStatement.setString(1, value1); aPreparedStatement.setString(2,
	 * value2); aPreparedStatement.setString(3, value3);
	 * aPreparedStatement.setString(4, value4); aPreparedStatement.setString(5,
	 * value5); aPreparedStatement.setString(6, value6);
	 * aPreparedStatement.setString(7, value7); aPreparedStatement.setString(8,
	 * value8); aPreparedStatement.setString(9, value9);
	 * aPreparedStatement.setString(10, value10);
	 * aPreparedStatement.setString(11, value11);
	 * aPreparedStatement.setString(12, value12);
	 * aPreparedStatement.setString(13, value13);
	 * aPreparedStatement.setString(14, value14);
	 * aPreparedStatement.setString(15, value15);
	 * aPreparedStatement.setString(16, value16);
	 * aPreparedStatement.setString(17, value17.trim());
	 * aPreparedStatement.executeUpdate(); } catch (Exception e) {
	 * e.printStackTrace(); throw e; } finally {
	 * DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet); }
	 * logger.info(ActionConstants.EXITING_METHOD + "setValueInDB"); }
	 * 
	 * public void setValueODCPAYInDB(String value1, String value2, String
	 * value3, String value4, String value5, String value6, String value7,
	 * String value8, String value9, String value10, String value11, String
	 * value12, String value13, String value14, String value15, String query)
	 * throws Exception { logger.info(ActionConstants.ENTERING_METHOD +
	 * "setValueInDB"); Connection aConnection = null; ResultSet aResultSet =
	 * null; PreparedStatement aPreparedStatement = null; try { aConnection =
	 * DBUtility.getZoneConnection(); aPreparedStatement =
	 * aConnection.prepareStatement(query); logger.info("query-->" + query);
	 * aPreparedStatement.setString(1, value1); aPreparedStatement.setString(2,
	 * value2); aPreparedStatement.setString(3, value3);
	 * aPreparedStatement.setString(4, value4); aPreparedStatement.setString(5,
	 * value5); aPreparedStatement.setString(6, value6);
	 * aPreparedStatement.setString(7, value7); aPreparedStatement.setString(8,
	 * value8); aPreparedStatement.setString(9, value9);
	 * aPreparedStatement.setString(10, value10);
	 * aPreparedStatement.setString(11, value11);
	 * aPreparedStatement.setString(12, value12);
	 * aPreparedStatement.setString(13, value13);
	 * aPreparedStatement.setString(14, value14);
	 * aPreparedStatement.setString(15, value15.trim());
	 * aPreparedStatement.executeUpdate(); } catch (Exception e) {
	 * e.printStackTrace(); throw e; } finally {
	 * DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet); }
	 * logger.info(ActionConstants.EXITING_METHOD + "setValueInDB"); }
	 */

	// Rate taken Fix Offshore Team 06012020 starts
	public void setValueODCCREInDB(String value1, String value2, String value3,
			String value4, String value5, String value6, String value7,
			String value8, String value9, String value10, String value11,
			String value12, String value13, String value14, String value15,
			String value16, String value17, String value18, String value19, String value20, String query)
			throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD + "setValueInDB");
		Connection aConnection = null;
		ResultSet aResultSet = null;
		PreparedStatement aPreparedStatement = null;
		System.out.println("value1 >>-->" + value1);
		System.out.println("value2 >>-->" + value2);
		System.out.println("value3 >>-->" + value3);
		System.out.println("value4 >>-->" + value4);
		System.out.println("value5 >>-->" + value5);
		System.out.println("value6 >>-->" + value6);
		System.out.println("value7 >>-->" + value7);
		System.out.println("value8 >>-->" + value8);
		System.out.println("value9 >>-->" + value9);
		System.out.println("value10 >>-->" + value10);
		System.out.println("value11 >>-->" + value11);
		System.out.println("value12 >>-->" + value12);
		System.out.println("value13 >>-->" + value13);
		System.out.println("value14 >>-->" + value14);
		System.out.println("value15 >>-->" + value15);
		System.out.println("value16 >>-->" + value16);
		System.out.println("value17 >>-->" + value17);
		System.out.println("value18 >>-->" + value18);
		System.out.println("query >>-->" + query);
		try {
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);
			logger.info("query-->" + query);
			aPreparedStatement.setString(1, value1);
			aPreparedStatement.setString(2, value2);
			aPreparedStatement.setString(3, value3);
			aPreparedStatement.setString(4, value4);
			aPreparedStatement.setString(5, value5);
			aPreparedStatement.setString(6, value6);
			aPreparedStatement.setString(7, value7);
			aPreparedStatement.setString(8, value8);
			aPreparedStatement.setString(9, value9);
			aPreparedStatement.setString(10, value10);
			aPreparedStatement.setString(11, value11);
			aPreparedStatement.setString(12, value12);
			aPreparedStatement.setString(13, value13);
			aPreparedStatement.setString(14, value14);
			aPreparedStatement.setString(15, value15);
			aPreparedStatement.setString(16, value16);
			aPreparedStatement.setString(17, value17);
			aPreparedStatement.setString(18, value18);
			aPreparedStatement.setString(19, value19);
			aPreparedStatement.setString(20, value20.trim());
			aPreparedStatement.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}
		logger.info(ActionConstants.EXITING_METHOD + "setValueInDB");
	}

	public void setValueODCPAYInDB(String value1, String value2, String value3,
			String value4, String value5, String value6, String value7,
			String value8, String value9, String value10, String value11,
			String value12, String value13, String value14, String value15,
			String value16, String value17, String value19, String value18,
			String query) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD + "setValueInDB");
		Connection aConnection = null;
		ResultSet aResultSet = null;
		PreparedStatement aPreparedStatement = null;
		try {
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);
			logger.info("query-->" + query);
			aPreparedStatement.setString(1, value1);
			aPreparedStatement.setString(2, value2);
			aPreparedStatement.setString(3, value3);
			aPreparedStatement.setString(4, value4);
			aPreparedStatement.setString(5, value5);
			aPreparedStatement.setString(6, value6);
			aPreparedStatement.setString(7, value7);
			aPreparedStatement.setString(8, value8);
			aPreparedStatement.setString(9, value9);
			aPreparedStatement.setString(10, value10);
			aPreparedStatement.setString(11, value11);
			aPreparedStatement.setString(12, value12);
			aPreparedStatement.setString(13, value13);
			aPreparedStatement.setString(14, value14);
			aPreparedStatement.setString(15, value15);
			aPreparedStatement.setString(16, value16);
			aPreparedStatement.setString(17, value17);
			aPreparedStatement.setString(18, value19);
			aPreparedStatement.setString(19, value18.trim());
			aPreparedStatement.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}
		logger.info(ActionConstants.EXITING_METHOD + "setValueInDB");
	}

	public void setUpdateCustomerName(String custName, String requestId,
			String query) {
		logger.info(ActionConstants.ENTERING_METHOD + "setValueInDB");
		Connection aConnection = null;
		ResultSet aResultSet = null;
		PreparedStatement aPreparedStatement = null;
		try {
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);
			logger.info("query-->" + query);
			aPreparedStatement.setString(1, custName);
			aPreparedStatement.setString(1, requestId);

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}
		logger.info(ActionConstants.EXITING_METHOD + "setUpdateCustomerName");
	}

	// Rate taken Fix Offshore Team 06012020 ends

	public void setValueInDB(String value1, String value2, String value3,
			String query) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD + "setValueInDB");
		Connection aConnection = null;
		ResultSet aResultSet = null;
		PreparedStatement aPreparedStatement = null;
		try {
			if (value2 != null)
				value2 = value2.trim();
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);
			logger.info("query-->" + query);
			aPreparedStatement.setString(1, value1);
			aPreparedStatement.setString(2, value2);
			aPreparedStatement.setString(3, value3.trim());
			aPreparedStatement.executeUpdate();
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}
		logger.info(ActionConstants.EXITING_METHOD + "setValueInDB");
	}

	public void setValueInDB(String value1, String value2, String value3,
			String value4, String query) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD + "setValueInDB");
		Connection aConnection = null;
		ResultSet aResultSet = null;
		PreparedStatement aPreparedStatement = null;
		try {
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);
			logger.info("query-->" + query);
			aPreparedStatement.setString(1, value1);
			aPreparedStatement.setString(2, value2);
			aPreparedStatement.setString(3, value3);
			aPreparedStatement.setString(4, value4.trim());
			aPreparedStatement.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}
		logger.info(ActionConstants.EXITING_METHOD + "setValueInDB");
	}

	public void setValueInDB(String value1, String value2, String value3,
			String value4, String value5, String query) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD + "setValueInDB");
		Connection aConnection = null;
		ResultSet aResultSet = null;
		PreparedStatement aPreparedStatement = null;
		try {
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);
			logger.info("query-->" + query);
			aPreparedStatement.setString(1, value1);
			aPreparedStatement.setString(2, value2);
			aPreparedStatement.setString(3, value3);
			aPreparedStatement.setString(4, value4);
			aPreparedStatement.setString(5, value5);
			aPreparedStatement.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}
		logger.info(ActionConstants.EXITING_METHOD + "setValueInDB");
	}

	public void setODCPAYUpdate(String value1, String value2, String value3,
			String query) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD + "setValueInDB");
		Connection aConnection = null;
		ResultSet aResultSet = null;
		PreparedStatement aPreparedStatement = null;
		try {
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);
			logger.info("query-->" + query);
			aPreparedStatement.setString(1, value1);
			aPreparedStatement.setString(2, value2);
			aPreparedStatement.setString(3, value3);
			aPreparedStatement.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}
		logger.info(ActionConstants.EXITING_METHOD + "setValueInDB");
	}

	public void setValueInDB(String value1, String value2, String value3,
			String value4, String value5, String value6, String query)
			throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD + "setValueInDB");
		Connection aConnection = null;
		ResultSet aResultSet = null;
		PreparedStatement aPreparedStatement = null;
		try {
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);
			logger.info("query-->" + query);
			aPreparedStatement.setString(1, value1);
			aPreparedStatement.setString(2, value2);
			aPreparedStatement.setString(3, value3);
			aPreparedStatement.setString(4, value4);
			aPreparedStatement.setString(5, value5);
			aPreparedStatement.setString(6, value6.trim());
			aPreparedStatement.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}
		logger.info(ActionConstants.EXITING_METHOD + "setValueInDB");
	}

	public void setValueInDB(String value1, String value2, String value3,
			String value4, String value5, String value6, String value7,
			String query) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD + "setValueInDB");
		Connection aConnection = null;
		ResultSet aResultSet = null;
		PreparedStatement aPreparedStatement = null;
		try {
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);
			logger.info("query-->" + query);
			aPreparedStatement.setString(1, value1);
			aPreparedStatement.setString(2, value2);
			aPreparedStatement.setString(3, value3);
			aPreparedStatement.setString(4, value4);
			aPreparedStatement.setString(5, value5);
			aPreparedStatement.setString(6, value6);
			aPreparedStatement.setString(7, value7.trim());
			aPreparedStatement.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}
		logger.info(ActionConstants.EXITING_METHOD + "setValueInDB");
	}

	public void setValueInDB(String value1, String value2, String value3,
			String value4, String value5, boolean value6, String value7,
			String value8, String query) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD + "setValueInDB");
		Connection aConnection = null;
		ResultSet aResultSet = null;
		PreparedStatement aPreparedStatement = null;
		try {
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);
			logger.info("query-->" + query);
			aPreparedStatement.setString(1, value1);
			aPreparedStatement.setString(2, value2);
			aPreparedStatement.setString(3, value3);
			aPreparedStatement.setString(4, value4);
			aPreparedStatement.setString(5, value5);
			if (value6)
				aPreparedStatement.setString(6, "Y");
			else
				aPreparedStatement.setString(6, "N");
			aPreparedStatement.setString(7, value7);
			aPreparedStatement.setString(8, value8.trim());
			aPreparedStatement.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}
		logger.info(ActionConstants.EXITING_METHOD + "setValueInDB");
	}

	public void setValueInDB(String value1, String value2, String value3,
			String value4, String value5, boolean value6, String value7,
			String value8, String value9, String value10, String value11,
			String value12, String query) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD + "setValueInDB");
		Connection aConnection = null;
		ResultSet aResultSet = null;
		PreparedStatement aPreparedStatement = null;
		try {
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);
			logger.info("query-->" + query);
			aPreparedStatement.setString(1, value1);
			aPreparedStatement.setString(2, value2);
			aPreparedStatement.setString(3, value3);
			aPreparedStatement.setString(4, value4);
			aPreparedStatement.setString(5, value5);
			if (value6)
				aPreparedStatement.setString(6, "Y");
			else
				aPreparedStatement.setString(6, "N");
			aPreparedStatement.setString(7, value7);
			if (value8.equalsIgnoreCase("true"))
				aPreparedStatement.setString(8, "Y");
			else
				aPreparedStatement.setString(8, "N");
			aPreparedStatement.setString(9, value9);
			aPreparedStatement.setString(10, value10);
			aPreparedStatement.setString(11, value11);
			aPreparedStatement.setString(12, value12.trim());
			aPreparedStatement.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}
		logger.info(ActionConstants.EXITING_METHOD + "setValueInDB");
	}

	public void setValueInDB(String value1, String value2, String value3,
			String value4, String value5, String value6, String value7,
			String value8, String value9, String value10, String value11,
			String value12, String query) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD + "setValueInDB");
		Connection aConnection = null;
		ResultSet aResultSet = null;
		PreparedStatement aPreparedStatement = null;
		try {
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);
			logger.info("query-->" + query);
			aPreparedStatement.setString(1, value1.trim());
			aPreparedStatement.setString(2, value2.trim());
			aPreparedStatement.setString(3, value3.trim());
			aPreparedStatement.setString(4, value4.trim());
			aPreparedStatement.setString(5, value5.trim());
			aPreparedStatement.setString(6, value6.trim());
			aPreparedStatement.setString(7, value7.trim());
			aPreparedStatement.setString(8, value8.trim());
			aPreparedStatement.setString(9, value9.trim());
			aPreparedStatement.setString(10, value10.trim());
			aPreparedStatement.setString(11, value11.trim());
			aPreparedStatement.setString(12, value12.trim());
			aPreparedStatement.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}
		logger.info(ActionConstants.EXITING_METHOD + "setValueInDB");
	}

	public void setValueInDB(String value1, String value2, String value3,
			String value4, String value5, String value6, String value7,
			String value8, String value9, String value10, String value11,
			String query) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD + "setValueInDB");
		Connection aConnection = null;
		ResultSet aResultSet = null;
		PreparedStatement aPreparedStatement = null;
		try {
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);
			logger.info("query-->" + query);
			aPreparedStatement.setString(1, value1.trim());
			aPreparedStatement.setString(2, value2.trim());
			aPreparedStatement.setString(3, value3.trim());
			aPreparedStatement.setString(4, value4.trim());
			aPreparedStatement.setString(5, value5.trim());
			aPreparedStatement.setString(6, value6.trim());
			aPreparedStatement.setString(7, value7.trim());
			aPreparedStatement.setString(8, value8.trim());
			aPreparedStatement.setString(9, value9.trim());
			aPreparedStatement.setString(10, value10.trim());
			aPreparedStatement.setString(11, value11.trim());
			aPreparedStatement.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}
		logger.info(ActionConstants.EXITING_METHOD + "setValueInDB");
	}

	public List<String> getBillReferenceFromDB(String tiReferanceNo,
			String ProdCode) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD + "setValueInDB");
		List<String> billReference = new ArrayList<String>();
		Connection aConnection = null;
		ResultSet aResultSet = null;
		PreparedStatement aPreparedStatement = null;
		String query = null;
		try {
			aConnection = DBUtility.getZoneConnection();
			if (ProdCode.equals("FEL"))
				query = "SELECT BEV.REFNO_PFIX||LPAD(BEV.REFNO_SERL,3,0) FROM "
						+ schemaName
						+ "MASTER MAS,"
						+ schemaName
						+ "BASEEVENT BEV WHERE MAS.KEY97   =BEV.MASTER_KEY AND BEV.REFNO_PFIX = 'DPR' AND TRIM(MAS.MASTER_REF)= '"
						+ tiReferanceNo.trim() + "'";
			else if (ProdCode.equals("ILC"))
				query = "Select Bev.Refno_Pfix||Lpad(Bev.Refno_Serl,3,0) As Event_Ref From "
						+ schemaName
						+ "Master Mas,"
						+ schemaName
						+ "Baseevent Bev,"
						+ schemaName
						+ "Lcpayment Lcp, "
						+ schemaName
						+ "Clmrecd clm WHERE MAS.KEY97    = BEV.MASTER_KEY And Bev.Refno_Pfix = 'CLM' And Bev.Key97 = Lcp.Key97 And  Bev.Key97 = Clm.Key97 And Pay_Sts IN ('Y','Z') AND  Lcp.Nextout_Ev is null And Mas.Master_Ref = '"
						+ tiReferanceNo.trim() + "'";
			else if (ProdCode.equals("ISB"))
				query = "SELECT BEV.REFNO_PFIX||LPAD(BEV.REFNO_SERL,3,0) FROM "
						+ schemaName
						+ "MASTER MAS,"
						+ schemaName
						+ "BASEEVENT BEV WHERE MAS.KEY97   =BEV.MASTER_KEY AND BEV.REFNO_PFIX = 'CLM' AND TRIM(MAS.MASTER_REF)= '"
						+ tiReferanceNo.trim() + "'";
			else if (ProdCode.equals("ELC"))
				query = "SELECT BEV.REFNO_PFIX || LPAD(BEV.REFNO_SERL,3,0) FROM "
						+ schemaName
						+ "MASTER MAS,"
						+ schemaName
						+ "BASEEVENT BEV,"
						+ schemaName
						+ "Lcpayment Lcp,"
						+ schemaName
						+ "DOCSPRE doc WHERE MAS.KEY97=BEV.MASTER_KEY  AND Bev.Key97=Lcp.Key97 AND Bev.Key97=doc.Key97 AND BEV.REFNO_PFIX='DPR' AND TRIM(MAS.MASTER_REF)='"
						+ tiReferanceNo.trim()
						+ "' AND Lcp.Nextout_Ev IS NULL ";
			else if (ProdCode.equals("IGT"))
				query = "Select Bev.Refno_Pfix||Lpad(Bev.Refno_Serl,3,0) As Event_Ref From "
						+ schemaName
						+ "Master Mas,"
						+ schemaName
						+ "Baseevent Bev,"
						+ schemaName
						+ "Lcpayment Lcp, "
						+ schemaName
						+ "Clmrecd clm WHERE MAS.KEY97    = BEV.MASTER_KEY And Bev.Refno_Pfix = 'CLM' And Bev.Key97 = Lcp.Key97 And  Bev.Key97 = Clm.Key97 And Pay_Sts IN ('Y','Z') and  Lcp.Nextout_Ev is null And Mas.Master_Ref = '"
						+ tiReferanceNo.trim() + "'";
			aPreparedStatement = aConnection.prepareStatement(query);
			logger.info("query-->" + query);
			// aPreparedStatement.setString(1, tiReferanceNo.trim());
			aResultSet = aPreparedStatement.executeQuery();
			while (aResultSet.next()) {
				billReference.add(aResultSet.getString(1));
				logger.info("bill reference in getBillReferenceFromDB >>-->"
						+ billReference);
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}
		return billReference;
	}

	public void setValueInDBILCPOCD(String value1, String value2,
			String value3, String value4, String value5, String value6,
			String value7, String value8, String value9, String value10,
			String gETUPDATETFBOELCADVNEW_QUERY) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD + "setValueInDB");
		Connection aConnection = null;
		ResultSet aResultSet = null;
		PreparedStatement aPreparedStatement = null;
		try {
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection
					.prepareStatement(gETUPDATETFBOELCADVNEW_QUERY);
			logger.info("query-->" + gETUPDATETFBOELCADVNEW_QUERY);
			aPreparedStatement.setString(1, value1);
			aPreparedStatement.setString(2, value2);
			aPreparedStatement.setString(3, value3);
			aPreparedStatement.setString(4, value4);
			aPreparedStatement.setString(5, value5);
			if (value6.equals("true"))
				aPreparedStatement.setString(6, "Y");
			else
				aPreparedStatement.setString(6, "N");
			aPreparedStatement.setString(7, value7);
			aPreparedStatement.setString(8, value8);
			aPreparedStatement.setString(9, value9);
			aPreparedStatement.setString(10, value10.trim());
			aPreparedStatement.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}
		logger.info(ActionConstants.EXITING_METHOD + "setValueInDB");
	}

	public List<TFBOImportLcVO> getTFBOIImportLCCRCFromDB(String requestId,
			String query, UserTransactionVO userVo) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD + " requestId->"
				+ requestId);
		TFBOImportLcVO aTFBOIlcIssueVO = null;
		Connection aConnection = null;
		ResultSet aResultSet = null;
		PreparedStatement aPreparedStatement = null;
		List<TFBOImportLcVO> ilcIssue = new LinkedList<TFBOImportLcVO>();
		try {
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);
			logger.info("query-->" + query);
			aPreparedStatement.setString(1, requestId.trim());
			aResultSet = aPreparedStatement.executeQuery();
			while (aResultSet.next()) {
				aTFBOIlcIssueVO = new TFBOImportLcVO();
				aTFBOIlcIssueVO.setTiReferenceNo(aResultSet.getString(1));
				aTFBOIlcIssueVO.setSolID(aResultSet.getString(2));
				aTFBOIlcIssueVO.setCustomeCif(aResultSet.getString(3));
				aTFBOIlcIssueVO.setBillAmount(aResultSet.getString(4));
				aTFBOIlcIssueVO.setCurrency(aResultSet.getString(5));
				aTFBOIlcIssueVO.setLcType(aResultSet.getString(6));
				aTFBOIlcIssueVO.setBillUsancePeriod(aResultSet.getString(8));
				userVo.setBillAmount(aResultSet.getString(4));
				userVo.setBillUsancePeriod(aResultSet.getString(8));
				aTFBOIlcIssueVO.setSubProductCode(aResultSet.getString(9));
				ilcIssue.add(aTFBOIlcIssueVO);
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}
		logger.info(ActionConstants.EXITING_METHOD + "  " + ilcIssue.size());
		return ilcIssue;
	}

	public void setValueInDB(String value1, String value2, String value3,
			String value4, String value5, String value6, String value7,
			String value8, String value9, String value10,
			String gETUPDATETFBOELCADVNEW_QUERY) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD + "setValueInDB");
		Connection aConnection = null;
		ResultSet aResultSet = null;
		PreparedStatement aPreparedStatement = null;
		try {
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection
					.prepareStatement(gETUPDATETFBOELCADVNEW_QUERY);
			logger.info("query-->" + gETUPDATETFBOELCADVNEW_QUERY);
			aPreparedStatement.setString(1, value1);
			aPreparedStatement.setString(2, value2);
			aPreparedStatement.setString(3, value3);
			aPreparedStatement.setString(4, value4);
			aPreparedStatement.setString(5, value5);
			aPreparedStatement.setString(6, value6);
			aPreparedStatement.setString(7, value7);
			aPreparedStatement.setString(8, value8);
			aPreparedStatement.setString(9, value9);
			aPreparedStatement.setString(10, value10.trim());
			aPreparedStatement.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}
		logger.info(ActionConstants.EXITING_METHOD + "setValueInDB");
	}

	public List<TFBOExportLcVO> getTFBOExportLCADEFromDB(String requestId,
			String query) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD + " requestId->"
				+ requestId);
		TFBOExportLcVO aTFBOExportLcVO = null;
		Connection aConnection = null;
		ResultSet aResultSet = null;
		PreparedStatement aPreparedStatement = null;
		List<TFBOExportLcVO> elcAdvise = new LinkedList<TFBOExportLcVO>();
		try {
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);
			logger.info("query-->" + query);
			aPreparedStatement.setString(1, requestId.trim());
			aResultSet = aPreparedStatement.executeQuery();
			while (aResultSet.next()) {
				aTFBOExportLcVO = new TFBOExportLcVO();
				if (aResultSet.getString(1) != null) {
					aTFBOExportLcVO.setTiReferenceNo(aResultSet.getString(1));
				}
				aTFBOExportLcVO.setSolID(aResultSet.getString(2));
				aTFBOExportLcVO.setCustomeCif(aResultSet.getString(3));
				aTFBOExportLcVO.setAmount(aResultSet.getString(4));
				aTFBOExportLcVO.setCurrency(aResultSet.getString(5));
				aTFBOExportLcVO.setLcType(aResultSet.getString(6));
				if (aResultSet.getString(7) != null) {
					aTFBOExportLcVO.setUsancePeriod(aResultSet.getString(7));
				}
				aTFBOExportLcVO.setLCreceivedSWIFT(aResultSet.getString(8));
				if (aResultSet.getString(9) != null) {
					aTFBOExportLcVO.setSenderRefno(aResultSet.getString(9));
				}
				aTFBOExportLcVO.setSubProductCode(aResultSet.getString(10));
				elcAdvise.add(aTFBOExportLcVO);
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}
		logger.info(ActionConstants.EXITING_METHOD + "  " + elcAdvise.size());
		return elcAdvise;
	}

	public void setValueInDB_TRANS(String value1, String value2, String value3,
			String value4, String value5, String value6, String value7,
			String value8, String value9, String value10, String query) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD + "setValueInDB");
		Connection aConnection = null;
		ResultSet aResultSet = null;
		PreparedStatement aPreparedStatement = null;
		try {
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);
			logger.info("query-->" + query);
			aPreparedStatement.setString(1, value1);
			aPreparedStatement.setString(2, value2);
			aPreparedStatement.setString(3, value3);
			aPreparedStatement.setString(4, value4);
			aPreparedStatement.setString(5, value5);
			aPreparedStatement.setString(6, value6);
			aPreparedStatement.setString(7, value7);
			aPreparedStatement.setString(8, value8);
			aPreparedStatement.setString(9, value9);
			aPreparedStatement.setString(10, value10.trim());
			aPreparedStatement.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}
		logger.info(ActionConstants.EXITING_METHOD + "setValueInDB");
	}

	public void setValueFOCADJInDB(String value1, String value2, String value3,
			String value4, String value5, String value6, String value7,
			String value8, String value9, String query) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD + "setValueInDB");
		Connection aConnection = null;
		ResultSet aResultSet = null;
		PreparedStatement aPreparedStatement = null;
		try {
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);
			logger.info("query-->" + query);
			aPreparedStatement.setString(1, value1);
			aPreparedStatement.setString(2, value2);
			aPreparedStatement.setString(3, value3);
			aPreparedStatement.setString(4, value4);
			aPreparedStatement.setString(5, value5);
			aPreparedStatement.setString(6, value6);
			aPreparedStatement.setString(7, value7);
			aPreparedStatement.setString(8, value8);
			aPreparedStatement.setString(9, value9.trim());
			aPreparedStatement.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}
		logger.info(ActionConstants.EXITING_METHOD + "setValueInDB");
	}

	public void setValueFelCreInDB(String value1, String value2, String value3,
			String value4, String value5, String value6, String value7,
			String value8, String value9, String value10, String value11,
			String value12, String value13, String query) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD + "setValueInDB");
		Connection aConnection = null;
		ResultSet aResultSet = null;
		PreparedStatement aPreparedStatement = null;
		try {
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);
			logger.info("query-->" + query);
			aPreparedStatement.setString(1, value1);
			aPreparedStatement.setString(2, value2);
			aPreparedStatement.setString(3, value3);
			aPreparedStatement.setString(4, value4);
			aPreparedStatement.setString(5, value5);
			aPreparedStatement.setString(6, value6);
			aPreparedStatement.setString(7, value7);
			aPreparedStatement.setString(8, value8);
			aPreparedStatement.setString(9, value9);
			aPreparedStatement.setString(10, value10);
			aPreparedStatement.setString(11, value11);
			aPreparedStatement.setString(12, value12);
			aPreparedStatement.setString(13, value13.trim());
			aPreparedStatement.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}
		logger.info(ActionConstants.EXITING_METHOD + "setValueInDB");
	}

	public List<TFBOExportLcVO> getTFBOExportLCAMDFromDB(String requestId,
			String query) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD + " requestId->"
				+ requestId);
		TFBOExportLcVO aTFBOEAmendVO = null;
		Connection aConnection = null;
		ResultSet aResultSet = null;
		PreparedStatement aPreparedStatement = null;
		List<TFBOExportLcVO> elcAmend = new LinkedList<TFBOExportLcVO>();
		try {
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);
			logger.info("query-->" + query);
			aPreparedStatement.setString(1, requestId.trim());
			aResultSet = aPreparedStatement.executeQuery();
			while (aResultSet.next()) {
				aTFBOEAmendVO = new TFBOExportLcVO();
				aTFBOEAmendVO.setTiReferenceNo(aResultSet.getString(1));
				aTFBOEAmendVO.setSolID(aResultSet.getString(2));
				aTFBOEAmendVO.setCustomeCif(aResultSet.getString(3));
				aTFBOEAmendVO.setAmount(aResultSet.getString(4));
				aTFBOEAmendVO.setCurrency(aResultSet.getString(5));
				aTFBOEAmendVO.setLcType(aResultSet.getString(6));
				aTFBOEAmendVO.setSenderRefno(aResultSet.getString(7));
				aTFBOEAmendVO.setSubProductCode(aResultSet.getString(8));
				elcAmend.add(aTFBOEAmendVO);
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}
		logger.info(ActionConstants.EXITING_METHOD + "  " + elcAmend.size());
		return elcAmend;

	}

	public void setValueInDB(String customeCif, String customeName,
			String billAmount, String currency, String direct, String partpay,
			String prdType, String solID, String billUsancePeriod,
			String rateTaken, String token, String valueK, String rate,
			String requestId, String query) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD + "setValueInDB");
		Connection aConnection = null;
		ResultSet aResultSet = null;
		PreparedStatement aPreparedStatement = null;
		// SOLID=?,CUSTOMERCIF=?,
		// CURRENCY=?,BILLAMT=?,USANCEPERIOD=?,RATE_TKN=?,DIRECT=?,PART_PAY=?,TOKEN=?,PROD_TYPE=?,RATE=?,K=?,CUST_NAME=?
		// WHERE TRIM(REQUESTID)=?";
		try {
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);
			logger.info("query-->" + query);
			System.out.println("CURRENCY >>-->" + currency);
			aPreparedStatement.setString(1, solID);
			aPreparedStatement.setString(2, customeCif);
			aPreparedStatement.setString(3, currency);
			aPreparedStatement.setString(4, billAmount);
			aPreparedStatement.setString(5, billUsancePeriod);
			aPreparedStatement.setString(6, rateTaken);
			aPreparedStatement.setString(7, direct);
			aPreparedStatement.setString(8, partpay);
			aPreparedStatement.setString(9, token);
			aPreparedStatement.setString(10, prdType);
			aPreparedStatement.setString(11, rate);
			aPreparedStatement.setString(12, valueK);
			aPreparedStatement.setString(13, customeName);
			aPreparedStatement.setString(14, requestId.trim());
			aPreparedStatement.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}
		logger.info(ActionConstants.EXITING_METHOD + "setValueInDB");

	}

	public void setFOCCREValueInDB(String value1, String value2, String value3,
			String value4, String value5, String value6, String value7,
			String value8, String value9, String value10, String value11,
			String preShipAcc, String value12, String query) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD + "setValueInDB");
		Connection aConnection = null;
		ResultSet aResultSet = null;
		PreparedStatement aPreparedStatement = null;
		try {
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);
			logger.info("query-->" + query);
			aPreparedStatement.setString(1, value1.trim());
			aPreparedStatement.setString(2, value2.trim());
			aPreparedStatement.setString(3, value3.trim());
			aPreparedStatement.setString(4, value4.trim());
			aPreparedStatement.setString(5, value5.trim());
			aPreparedStatement.setString(6, value6.trim());
			aPreparedStatement.setString(7, value7.trim());
			aPreparedStatement.setString(8, value8.trim());
			aPreparedStatement.setString(9, value9.trim());
			aPreparedStatement.setString(10, value10.trim());
			aPreparedStatement.setString(11, value11.trim());
			aPreparedStatement.setString(12, preShipAcc.trim());
			aPreparedStatement.setString(13, value12.trim());
			aPreparedStatement.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}
		logger.info(ActionConstants.EXITING_METHOD + "setValueInDB");
	}

	// //FREEZING(SCENARIO) off shore team starts 07012020
	public List<TFBOIdcVO> getTFBOIImportIDCCREFromDB(String requestId,
			String query) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD + " requestId->"
				+ requestId);
		TFBOIdcVO aTFBOIdcVO = null;
		Connection aConnection = null;
		ResultSet aResultSet = null;
		PreparedStatement aPreparedStatement = null;
		List<TFBOIdcVO> idcCreate = new LinkedList<TFBOIdcVO>();
		try {
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);
			logger.info("query-->" + query);
			aPreparedStatement.setString(1, requestId.trim());
			aResultSet = aPreparedStatement.executeQuery();
			while (aResultSet.next()) {
				aTFBOIdcVO = new TFBOIdcVO();
				aTFBOIdcVO.setTiReferanceNo(aResultSet.getString(1));
				aTFBOIdcVO.setSolID(aResultSet.getString(2));
				aTFBOIdcVO.setCustomeCif(aResultSet.getString(3));
				aTFBOIdcVO.setCurrency(aResultSet.getString(4));
				aTFBOIdcVO.setBillAmount(aResultSet.getString(5));
				aTFBOIdcVO.setBillUsancePeriod(aResultSet.getString(6));
				/* aTFBOIdcVO.setRateTaken(aResultSet.getString(7)); */
				// aTFBOIdcVO.setRateTaken(aResultSet.getString(7));

				// ADDED BY CHANDRU
				if (aResultSet.getString(7) != null
						&& !aResultSet.getString(7).trim().equals("")) {
					if (aResultSet.getString(7).trim().equalsIgnoreCase("Y")) {
						aTFBOIdcVO.setRateTaken("true");
					} else {
						aTFBOIdcVO.setRateTaken("false");
					}
				}
				// ENDS

				aTFBOIdcVO.setDirect(aResultSet.getString(8));
				aTFBOIdcVO.setPartpay(aResultSet.getString(9));
				aTFBOIdcVO.setToken(aResultSet.getString(10));
				aTFBOIdcVO.setSubProductCode(aResultSet.getString(11));
				aTFBOIdcVO.setRate(aResultSet.getString(12));
				aTFBOIdcVO.setValueK(aResultSet.getString(13));
				aTFBOIdcVO.setCustomeName(aResultSet.getString(14));
				idcCreate.add(aTFBOIdcVO);
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}
		logger.info(ActionConstants.EXITING_METHOD + "  " + idcCreate.size());
		return idcCreate;
	}

	// FREEZING(SCENARIO) off shore team starts 07012020
	/*
	 * requestId, solID, billAmount, rateTaken, partpay, prdType, rate,
	 * valueK,token,
	 */
	/*
	 * public void setValueIdcPayInDB(String requestId, String solID, String
	 * billAmount, String rateTaken, String partpay, String prdType, String
	 * rate, String valueK, String token, String query) throws Exception {
	 * logger.info(ActionConstants.ENTERING_METHOD + "setValueInDB"); Connection
	 * aConnection = null; ResultSet aResultSet = null; PreparedStatement
	 * aPreparedStatement = null; try { aConnection =
	 * DBUtility.getZoneConnection(); aPreparedStatement =
	 * aConnection.prepareStatement(query); logger.info("query-->" + query);
	 * aPreparedStatement.setString(1, solID); aPreparedStatement.setString(2,
	 * billAmount); aPreparedStatement.setString(3, rateTaken);
	 * aPreparedStatement.setString(4, partpay); aPreparedStatement.setString(5,
	 * prdType); aPreparedStatement.setString(6, prdType);
	 * aPreparedStatement.setString(7, rate); aPreparedStatement.setString(8,
	 * valueK); aPreparedStatement.setString(9, token);
	 * aPreparedStatement.setString(9, requestId.trim());
	 * aPreparedStatement.executeUpdate(); } catch (Exception e) {
	 * e.printStackTrace(); throw e; } finally {
	 * DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet); }
	 * logger.info(ActionConstants.EXITING_METHOD + "setValueInDB"); }
	 */
	// FREEZING(SCENARIO) off shore team starts 31122019
	public void setValueIdcPayInDB(String requestId, String solID,
			String billAmount, String rateTaken, String partpay,
			String prdType, String rate, String valueK, String customerCif,
			String customerName, String Token, String currency,
			String directFlagCreateEvent, String direct, String query)
			throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD + "setValueInDB");
		Connection aConnection = null;
		ResultSet aResultSet = null;
		PreparedStatement aPreparedStatement = null;
		try {
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);
			System.out.println("SolID >>-->" + solID);
			System.out.println("billamouny >>-->" + billAmount);
			System.out.println("ratetaken >>-->" + rateTaken);
			System.out.println("partamount >>-->" + partpay);
			System.out.println("prdtype >>-->" + prdType);
			System.out.println("rate >>-->" + rate);
			System.out.println("valueK >>->" + valueK);
			System.out.println("customerCif >>-->" + customerCif);
			System.out.println("customerCif >>-->" + customerName);
			System.out.println("customerCif >>-->" + Token);
			System.out.println("customerCif >>-->" + currency);
			System.out.println("customerCif >>-->" + directFlagCreateEvent);
			System.out.println("direct >>-->" + direct);
			System.out.println("requestId >>-->" + requestId);

			logger.info("query-->" + query);
			aPreparedStatement.setString(1, solID);
			aPreparedStatement.setString(2, billAmount);
			aPreparedStatement.setString(3, rateTaken);
			aPreparedStatement.setString(4, partpay);
			aPreparedStatement.setString(5, prdType);
			aPreparedStatement.setString(6, rate);
			aPreparedStatement.setString(7, valueK);
			aPreparedStatement.setString(8, customerCif);
			aPreparedStatement.setString(9, customerName);
			aPreparedStatement.setString(10, Token);
			aPreparedStatement.setString(11, currency);
			aPreparedStatement.setString(12, directFlagCreateEvent);
			aPreparedStatement.setString(13, direct);
			aPreparedStatement.setString(14, requestId.trim());
			aPreparedStatement.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}
		logger.info(ActionConstants.EXITING_METHOD + "setValueInDB");
	}

	// FREEZING(SCENARIO) off shore team ends 31122019
	public void setValueInDB(String requestId, String solID, String customeCif,
			String currency, String acceptBillAmt, String billUsancePeriod,
			String prdType, String customeName, String query) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD + "setValueInDB");
		Connection aConnection = null;
		ResultSet aResultSet = null;
		PreparedStatement aPreparedStatement = null;
		try {
			// UPDATE TFBO_IDC_ACCEPT SET SOLID=?,CUSTOMERCIF=?,
			// CURRENCY=?,ACPT_BILL_AMT=?,USANCEPERIOD=?,PROD_TYPE=?,CUST_NAME=?
			// WHERE TRIM(REQUESTID)=?";
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);
			logger.info("query-->" + query);
			aPreparedStatement.setString(1, solID);
			aPreparedStatement.setString(2, customeCif);
			aPreparedStatement.setString(3, currency);
			aPreparedStatement.setString(4, acceptBillAmt);
			aPreparedStatement.setString(5, billUsancePeriod);
			aPreparedStatement.setString(6, prdType);
			aPreparedStatement.setString(7, customeName);
			aPreparedStatement.setString(8, requestId.trim());
			aPreparedStatement.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}
		logger.info(ActionConstants.EXITING_METHOD + "setValueInDB");
	}

	public void setValueInELCAMDDB(String solID, String customeCif,
			String acceptBillAmt, String currency, String lcType,
			String senderRefno, String usancePeriod, String requestId,
			String query) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD + "setValueInDB");
		Connection aConnection = null;
		ResultSet aResultSet = null;
		PreparedStatement aPreparedStatement = null;
		try {
			// UPDATE TFBO_IDC_ACCEPT SET SOLID=?,CUSTOMERCIF=?,
			// CURRENCY=?,ACPT_BILL_AMT=?,USANCEPERIOD=?,PROD_TYPE=?,CUST_NAME=?
			// WHERE TRIM(REQUESTID)=?";
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);
			logger.info("query-->" + query);
			aPreparedStatement.setString(1, solID);
			aPreparedStatement.setString(2, customeCif);

			aPreparedStatement.setString(3, acceptBillAmt);
			aPreparedStatement.setString(4, currency);
			aPreparedStatement.setString(5, lcType);
			aPreparedStatement.setString(6, senderRefno);
			aPreparedStatement.setString(7, usancePeriod);
			aPreparedStatement.setString(8, requestId.trim());
			aPreparedStatement.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}
		logger.info(ActionConstants.EXITING_METHOD + "setValueInDB");
	}

	public List<TFBOIdcVO> getTFBOIImportIDCCACFromDB(String requestId,
			String query) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD + " requestId->"
				+ requestId);
		TFBOIdcVO aTFBOIdcVO = null;
		Connection aConnection = null;
		ResultSet aResultSet = null;
		PreparedStatement aPreparedStatement = null;
		List<TFBOIdcVO> idcCreate = new LinkedList<TFBOIdcVO>();
		try {
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);
			logger.info("query-->" + query);
			aPreparedStatement.setString(1, requestId.trim());
			aResultSet = aPreparedStatement.executeQuery();
			while (aResultSet.next()) {
				aTFBOIdcVO = new TFBOIdcVO();
				aTFBOIdcVO.setTiReferanceNo(aResultSet.getString(1));
				aTFBOIdcVO.setSolID(aResultSet.getString(2));
				aTFBOIdcVO.setCustomeCif(aResultSet.getString(3));
				aTFBOIdcVO.setCurrency(aResultSet.getString(4));
				logger.info("aTFBOIdcVO.setCurrency====>"
						+ aTFBOIdcVO.getCurrency());
				aTFBOIdcVO.setAcceptBillAmt(aResultSet.getString(5));
				aTFBOIdcVO.setBillUsancePeriod(aResultSet.getString(6));
				aTFBOIdcVO.setSubProductCode(aResultSet.getString(7));
				logger.info("aTFBOIdcVO.setPrdType====>"
						+ aTFBOIdcVO.getSubProductCode());
				idcCreate.add(aTFBOIdcVO);
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}
		logger.info(ActionConstants.EXITING_METHOD + "  " + idcCreate.size());
		return idcCreate;
	}

	/*
	 * public List<TFBOIdcVO> getTFBOIImportIDCCLPFromDB(String requestId,
	 * String query) throws Exception {
	 * logger.info(ActionConstants.ENTERING_METHOD + " requestId->" +
	 * requestId); // SELECT MAS.MASTER_REF,MAS.BHALF_BRN, PTY.CUS_MNM, //
	 * (MAS.AMOUNT/POWER(10,C8PF.C8CED)) AS //
	 * AMOUNT,MAS.CCY,TFB.RATE_TKN,TFB.PART_PAY, // TFB.PROD_TYPE,TFB.RATE,TFB.K
	 * TFBOIdcVO aTFBOIdcVO = null; Connection aConnection = null; ResultSet
	 * aResultSet = null; PreparedStatement aPreparedStatement = null;
	 * List<TFBOIdcVO> idcPayment = new LinkedList<TFBOIdcVO>(); try {
	 * aConnection = DBUtility.getZoneConnection(); aPreparedStatement =
	 * aConnection.prepareStatement(query); logger.info("query-->" + query);
	 * aPreparedStatement.setString(1, requestId.trim()); aResultSet =
	 * aPreparedStatement.executeQuery(); while (aResultSet.next()) { aTFBOIdcVO
	 * = new TFBOIdcVO(); aTFBOIdcVO.setTiReferanceNo(aResultSet.getString(1));
	 * aTFBOIdcVO.setSolID(aResultSet.getString(2));
	 * aTFBOIdcVO.setCustomeCif(aResultSet.getString(3));
	 * aTFBOIdcVO.setBillAmount(aResultSet.getString(4));
	 * aTFBOIdcVO.setCurrency(aResultSet.getString(5));
	 * aTFBOIdcVO.setRateTaken(aResultSet.getString(6));
	 * aTFBOIdcVO.setPartpay(aResultSet.getString(7));
	 * aTFBOIdcVO.setSubProductCode(aResultSet.getString(8));
	 * aTFBOIdcVO.setRate(aResultSet.getString(9));
	 * aTFBOIdcVO.setValueK(aResultSet.getString(10));
	 * aTFBOIdcVO.setToken(aResultSet.getString(11));
	 * idcPayment.add(aTFBOIdcVO); } } catch (Exception e) {
	 * e.printStackTrace(); throw e; } finally {
	 * DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet); }
	 * logger.info(ActionConstants.EXITING_METHOD + "  " + idcPayment.size());
	 * return idcPayment; }
	 */
	// ZIGZAG VALUE POPULATION 07012020 STARTS
	// FREEZING(SCENARIO) off shore team starts 31122019
	/*
	 * public List<TFBOIdcVO> getTFBOIImportIDCCLPFromDB(String requestId,
	 * String query) throws Exception {
	 * logger.info(ActionConstants.ENTERING_METHOD + " requestId->" +
	 * requestId); TFBOIdcVO aTFBOIdcVO = null; Connection aConnection = null;
	 * ResultSet aResultSet = null; PreparedStatement aPreparedStatement = null;
	 * List<TFBOIdcVO> idcPayment = new LinkedList<TFBOIdcVO>(); try {
	 * aConnection = DBUtility.getZoneConnection(); aPreparedStatement =
	 * aConnection.prepareStatement(query); logger.info("query-->" + query);
	 * aPreparedStatement.setString(1, requestId.trim()); aResultSet =
	 * aPreparedStatement.executeQuery(); while (aResultSet.next()) { aTFBOIdcVO
	 * = new TFBOIdcVO(); aTFBOIdcVO.setTiReferanceNo(aResultSet.getString(1));
	 * aTFBOIdcVO.setSolID(aResultSet.getString(2));
	 * aTFBOIdcVO.setRateTaken(aResultSet.getString(3).trim());
	 * aTFBOIdcVO.setSubProductCode(aResultSet.getString(4));
	 * aTFBOIdcVO.setRate(aResultSet.getString(5));
	 * aTFBOIdcVO.setValueK(aResultSet.getString(6));
	 * aTFBOIdcVO.setToken(aResultSet.getString(7));
	 * aTFBOIdcVO.setDirect(aResultSet.getString(8));
	 * aTFBOIdcVO.setDirectCREEvent(aResultSet.getString(8));
	 * System.out.println("Getting direct from create event==>" +
	 * aTFBOIdcVO.getDirectCREEvent());
	 * aTFBOIdcVO.setCustomeCif(aResultSet.getString(9));
	 * aTFBOIdcVO.setCustomeName(aResultSet.getString(10));
	 * aTFBOIdcVO.setPartpay(aResultSet.getString(11));
	 * aTFBOIdcVO.setCurrency(aResultSet.getString(12));
	 * idcPayment.add(aTFBOIdcVO); } } catch (Exception e) {
	 * e.printStackTrace(); throw e; } finally {
	 * DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet); }
	 * logger.info(ActionConstants.EXITING_METHOD + "  " + idcPayment.size());
	 * return idcPayment; }
	 */
	public List<TFBOIdcVO> getTFBOIImportIDCCLPFromDB(String requestId,
			String query) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD + " requestId->"
				+ requestId);
		TFBOIdcVO aTFBOIdcVO = null;
		Connection aConnection = null;
		ResultSet aResultSet = null;
		PreparedStatement aPreparedStatement = null;
		List<TFBOIdcVO> idcPayment = new LinkedList<TFBOIdcVO>();
		try {
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);
			logger.info("query-->" + query);
			aPreparedStatement.setString(1, requestId.trim());
			aResultSet = aPreparedStatement.executeQuery();
			while (aResultSet.next()) {
				aTFBOIdcVO = new TFBOIdcVO();
				aTFBOIdcVO.setTiReferanceNo(aResultSet.getString(1));
				aTFBOIdcVO.setSolID(aResultSet.getString(2));
				aTFBOIdcVO.setRateTaken(aResultSet.getString(3).trim());
				aTFBOIdcVO.setSubProductCode(aResultSet.getString(4));
				aTFBOIdcVO.setRate(aResultSet.getString(5));
				aTFBOIdcVO.setValueK(aResultSet.getString(6));
				aTFBOIdcVO.setToken(aResultSet.getString(7));
				/* aTFBOIdcVO.setDirect(aResultSet.getString(8)); */
				aTFBOIdcVO.setDirectCREEvent(aResultSet.getString(8));
				aTFBOIdcVO.setCustomeCif(aResultSet.getString(9));
				aTFBOIdcVO.setCustomeName(aResultSet.getString(10));
				aTFBOIdcVO.setPartpay(aResultSet.getString(11));
				aTFBOIdcVO.setCurrency(aResultSet.getString(12));
				idcPayment.add(aTFBOIdcVO);
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}
		logger.info(ActionConstants.EXITING_METHOD + "  " + idcPayment.size());
		return idcPayment;
	}

	// ZIGZAG VALUE POPULATION 07012020 STARTS

	// FREEZING(SCENARIO) off shore team ends 31122019

	public List<TFBOIdcVO> getTFBOIImportIDCCLPTIFetchFromDB(String requestId,
			String query) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD + " requestId->"
				+ requestId);
		// SELECT MAS.MASTER_REF,MAS.BHALF_BRN, PTY.CUS_MNM,
		// (MAS.AMOUNT/POWER(10,C8PF.C8CED)) AS
		// AMOUNT,MAS.CCY,TFB.RATE_TKN,TFB.PART_PAY,
		// TFB.PROD_TYPE,TFB.RATE,TFB.K.
		// "SELECT MAS.MASTER_REF,TFB.SOLID,TFB.
		// RATE_TKN,TFB.PROD_TYPE,TFB.RATE,TFB.K,TFB.TOKEN,TFB.DIRECT,TFB.CUSTOMERCIF,
		// TFB.CUST_NAME,TFB.PART_PAY,TFB.CURRENCY
		TFBOIdcVO aTFBOIdcVO = null;
		Connection aConnection = null;
		ResultSet aResultSet = null;
		PreparedStatement aPreparedStatement = null;
		List<TFBOIdcVO> idcPayment = new LinkedList<TFBOIdcVO>();
		try {
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);
			logger.info("query-->" + query);
			aPreparedStatement.setString(1, requestId.trim());
			aResultSet = aPreparedStatement.executeQuery();
			while (aResultSet.next()) {
				aTFBOIdcVO = new TFBOIdcVO();
				aTFBOIdcVO.setTiReferanceNo(aResultSet.getString(1));
				aTFBOIdcVO.setSolID(aResultSet.getString(2));
				aTFBOIdcVO.setCustomeCif(aResultSet.getString(3));
				aTFBOIdcVO.setBillAmount(aResultSet.getString(4));
				aTFBOIdcVO.setCurrency(aResultSet.getString(5));
				aTFBOIdcVO.setRateTaken(aResultSet.getString(6));
				aTFBOIdcVO.setPartpay(aResultSet.getString(7));
				aTFBOIdcVO.setSubProductCode(aResultSet.getString(8));
				aTFBOIdcVO.setRate(aResultSet.getString(9));
				aTFBOIdcVO.setValueK(aResultSet.getString(10));
				aTFBOIdcVO.setToken(aResultSet.getString(11));
				idcPayment.add(aTFBOIdcVO);
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}
		logger.info(ActionConstants.EXITING_METHOD + "  " + idcPayment.size());
		return idcPayment;
	}

	public void setValuesInDB(String solID, String lcRefNum, String amount,
			String billReferenceNo, String requestId, String fncAmount,
			String billTenure, String preshipAcc, String rateTaken,
			String subProductCode, String token, String rateTakenK,
			String rate, String Currency, String gETUPDATETFBOFECCRENEW_QUERY)
			throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD + "setValueInDB");
		Connection aConnection = null;
		ResultSet aResultSet = null;
		PreparedStatement aPreparedStatement = null;
		try {
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection
					.prepareStatement(gETUPDATETFBOFECCRENEW_QUERY);
			aPreparedStatement.setString(1, solID);
			aPreparedStatement.setString(2, lcRefNum);
			aPreparedStatement.setString(3, amount);
			aPreparedStatement.setString(4, billReferenceNo);
			aPreparedStatement.setString(5, fncAmount);
			aPreparedStatement.setString(6, billTenure);
			aPreparedStatement.setString(7, preshipAcc);
			aPreparedStatement.setString(8, rateTaken);
			aPreparedStatement.setString(9, subProductCode);
			aPreparedStatement.setString(10, token);
			aPreparedStatement.setString(11, rateTakenK);
			aPreparedStatement.setString(12, rate);
			aPreparedStatement.setString(13, Currency);
			aPreparedStatement.setString(14, requestId.trim());
			aPreparedStatement.execute();
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}
	}

	// STARTS : ADDED BY CHANDRU FOR FEL CREATE UPDATE

	public void setValuesInDB(String solID, String lcRefNum, String amount,
			String billReferenceNo, String requestId, String fncAmount,
			String billTenure, String preshipAcc, String rateTaken,
			String subProductCode, String token, String rateTakenK,
			String rate, String Currency, String customerId, String custName,
			String gETUPDATETFBOFECCRENEW_QUERY) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD + "setValueInDB");
		Connection aConnection = null;
		ResultSet aResultSet = null;
		PreparedStatement aPreparedStatement = null;
		try {
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection
					.prepareStatement(gETUPDATETFBOFECCRENEW_QUERY);
			aPreparedStatement.setString(1, solID);
			aPreparedStatement.setString(2, lcRefNum);
			aPreparedStatement.setString(3, amount);
			aPreparedStatement.setString(4, billReferenceNo);
			aPreparedStatement.setString(5, fncAmount);
			aPreparedStatement.setString(6, billTenure);
			aPreparedStatement.setString(7, preshipAcc);
			aPreparedStatement.setString(8, rateTaken);
			aPreparedStatement.setString(9, subProductCode);
			aPreparedStatement.setString(10, token);
			aPreparedStatement.setString(11, rateTakenK);
			aPreparedStatement.setString(12, rate);
			aPreparedStatement.setString(13, Currency);
			aPreparedStatement.setString(14, customerId);
			aPreparedStatement.setString(15, custName.trim());
			aPreparedStatement.setString(16, requestId.trim());
			aPreparedStatement.execute();
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}
	}

	public void setValuesInDB(String solID, String lcRefNum, String amount,
			String billReferenceNo, String requestId, String fncAmount,
			String billTenure, String preshipAcc, String rateTaken,
			String subProductCode, String token, String rateTakenK,
			String rate, String Currency, String customerId, String custName,
			String preShipAccId, String gETUPDATETFBOFECCRENEW_QUERY)
			throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD + "setValueInDB");
		Connection aConnection = null;
		ResultSet aResultSet = null;
		PreparedStatement aPreparedStatement = null;
		try {
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection
					.prepareStatement(gETUPDATETFBOFECCRENEW_QUERY);
			aPreparedStatement.setString(1, solID);
			aPreparedStatement.setString(2, lcRefNum);
			aPreparedStatement.setString(3, amount);
			aPreparedStatement.setString(4, billReferenceNo);
			aPreparedStatement.setString(5, fncAmount);
			aPreparedStatement.setString(6, billTenure);
			aPreparedStatement.setString(7, preshipAcc);
			aPreparedStatement.setString(8, rateTaken);
			aPreparedStatement.setString(9, subProductCode);
			aPreparedStatement.setString(10, token);
			aPreparedStatement.setString(11, rateTakenK);
			aPreparedStatement.setString(12, rate);
			aPreparedStatement.setString(13, Currency);
			aPreparedStatement.setString(14, customerId);
			aPreparedStatement.setString(15, custName.trim());
			aPreparedStatement.setString(16, requestId.trim());
			aPreparedStatement.execute();
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}
	}

	// ENDS : ADDED BY CHANDRU FOR FEL CREATE UPDATE

	public void setValueInFSAREPAYDB(String value1, String value2,
			String value3, String value4, String value5, String value6,
			String value7, String value8, String value9, String value10,
			String value11, String value12, String value13, String Query)
			throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD + "setValueInDB");
		Connection aConnection = null;
		ResultSet aResultSet = null;
		PreparedStatement aPreparedStatement = null;
		try {
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(Query);
			logger.info("query-->" + Query);
			aPreparedStatement.setString(1, value1.trim());
			aPreparedStatement.setString(2, value2.trim());
			aPreparedStatement.setString(3, value3.trim());
			aPreparedStatement.setString(4, value4.trim());
			aPreparedStatement.setString(5, value5.trim());
			aPreparedStatement.setString(6, value6.trim());
			aPreparedStatement.setString(7, value7.trim());
			aPreparedStatement.setString(8, value8.trim());
			aPreparedStatement.setString(9, value9.trim());
			aPreparedStatement.setString(10, value10.trim());
			aPreparedStatement.setString(11, value11.trim());
			aPreparedStatement.setString(12, value12.trim());
			aPreparedStatement.setString(13, value13.trim());
			aPreparedStatement.execute();
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}
		logger.info(ActionConstants.EXITING_METHOD + "setValueInDB");
	}

	public String getDevolmentAmount(String billReference, String tiReference,
			String query, UserTransactionVO userVo) throws Exception {
		Connection aConnection = null;
		ResultSet aResultSet = null;
		PreparedStatement aPreparedStatement = null;
		String devolvementAmount = "";
		System.out.println("TiReference >>--> " + tiReference);
		System.out.println("billreference >>--> " + billReference);
		query = "SELECT "
				+ schemaName
				+ "THEME_GENIUS_PKG.CONVAMT(BEV.CCY,bev.amount) AS amount FROM "
				+ schemaName
				+ "master  mas,"
				+ schemaName
				+ "baseevent   bev  WHERE mas.key97 = bev.master_key AND bev.refno_pfix = 'CLM' AND mas.master_ref = '"
				+ tiReference.trim()
				+ "' and BEV.REFNO_PFIX||LPAD(BEV.REFNO_SERL,3,0)='"
				+ billReference + "'";
		try {
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);
			logger.info("query-->" + query);
			// aPreparedStatement.setString(1, tiReference.trim());
			// aPreparedStatement.setString(2, billReference.trim());
			aResultSet = aPreparedStatement.executeQuery();
			while (aResultSet.next()) {
				devolvementAmount = aResultSet.getString(1);
				userVo.setDevolvementAmount(devolvementAmount);
				userVo.setBillReference(billReference);
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}
		System.out.println("get devolvement amount >>-->"
				+ userVo.getDevolvementAmount());
		System.out.println("get bill reference >>-->"
				+ userVo.getBillReference());
		return devolvementAmount;

	}

	public List<TFBOExportLcVO> getTFBOExportLCDOPTranDetailsFromDB(
			String requestId, String query) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD + " requestId->"
				+ requestId);
		TFBOExportLcVO aTFBOELCDPOVO = null;
		Connection aConnection = null;
		ResultSet aResultSet = null;
		PreparedStatement aPreparedStatement = null;
		List<TFBOExportLcVO> elcDPO = new LinkedList<TFBOExportLcVO>();
		try {
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);
			logger.info("query-->" + query);
			aPreparedStatement.setString(1, requestId.trim());
			aResultSet = aPreparedStatement.executeQuery();
			while (aResultSet.next()) {
				aTFBOELCDPOVO = new TFBOExportLcVO();
				aTFBOELCDPOVO.setTiReferenceNo(aResultSet.getString(1));
				aTFBOELCDPOVO.setSolID(aResultSet.getString(2));
				aTFBOELCDPOVO.setCustomeCif(aResultSet.getString(3));
				aTFBOELCDPOVO.setCurrency(aResultSet.getString(5));
				aTFBOELCDPOVO.setLcType(aResultSet.getString(6));
				aTFBOELCDPOVO.setSubProductCode(aResultSet.getString(8).trim());
				elcDPO.add(aTFBOELCDPOVO);
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}
		logger.info(ActionConstants.EXITING_METHOD + "  " + elcDPO.size());
		return elcDPO;
	}

	public List<TFBOExportLcVO> getTFBOExportLCDOPFromDB(String requestId,
			String query) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD + " requestId->"
				+ requestId);
		TFBOExportLcVO aTFBOELCDPOVO = null;
		Connection aConnection = null;
		ResultSet aResultSet = null;
		PreparedStatement aPreparedStatement = null;
		List<TFBOExportLcVO> elcDPO = new LinkedList<TFBOExportLcVO>();
		try {
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);
			logger.info("query-->" + query);
			aPreparedStatement.setString(1, requestId.trim());
			aResultSet = aPreparedStatement.executeQuery();
			while (aResultSet.next()) {
				aTFBOELCDPOVO = new TFBOExportLcVO();
				aTFBOELCDPOVO.setTiReferenceNo(aResultSet.getString(1));
				aTFBOELCDPOVO.setSolID(aResultSet.getString(2));
				if (aResultSet.getString(3) != null) {
					if (aResultSet.getString(3).trim().equalsIgnoreCase("Yes")) {
						aTFBOELCDPOVO.setPreshipAccSetteld("true");
					} else {
						aTFBOELCDPOVO.setPreshipAccSetteld("false");
					}
				}
				aTFBOELCDPOVO.setAmount(aResultSet.getString(4));
				aTFBOELCDPOVO.setCurrency(aResultSet.getString(5));
				aTFBOELCDPOVO.setUsancePeriod(aResultSet.getString(6));
				aTFBOELCDPOVO.setLcType(aResultSet.getString(7));
				aTFBOELCDPOVO.setCustomeCif(aResultSet.getString(8));
				aTFBOELCDPOVO.setSubProductCode(aResultSet.getString(9));

				if (aResultSet.getString(10) != null) {
					if (aResultSet.getString(10).trim().equalsIgnoreCase("Y")) {
						aTFBOELCDPOVO.setFinSameDay("Yes");
					} else {
						aTFBOELCDPOVO.setFinSameDay("No");
					}
				}
				if (aResultSet.getString(11) != null
						&& !aResultSet.getString(11).trim().equals("")) {
					if (aResultSet.getString(11).equalsIgnoreCase("Y")) {
						aTFBOELCDPOVO.setRateTaken("true");
					} else {
						aTFBOELCDPOVO.setRateTaken("false");
					}
				}

				aTFBOELCDPOVO.setToken(aResultSet.getString(12));
				aTFBOELCDPOVO.setValueK(aResultSet.getString(13));
				aTFBOELCDPOVO.setRate(aResultSet.getString(14));

				elcDPO.add(aTFBOELCDPOVO);
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}
		logger.info(ActionConstants.EXITING_METHOD + "  " + elcDPO.size());
		return elcDPO;
	}

	/*
	 * public void setValueInDBELCDOP(String solID, String preshipAccSettled,
	 * String amount, String currency, String usancePeriod, String lcType,
	 * String custCif, String requestId,String finSameDay, String query) throws
	 * Exception { logger.info(ActionConstants.ENTERING_METHOD +
	 * "setValueInDB"); Connection aConnection = null; ResultSet aResultSet =
	 * null; PreparedStatement aPreparedStatement = null; try { aConnection =
	 * DBUtility.getZoneConnection(); aPreparedStatement =
	 * aConnection.prepareStatement(query); logger.info("query-->" + query);
	 * aPreparedStatement.setString(1, solID); aPreparedStatement.setString(2,
	 * preshipAccSettled); aPreparedStatement.setString(3, amount);
	 * aPreparedStatement.setString(4, currency); if (usancePeriod == null ||
	 * usancePeriod.isEmpty()) aPreparedStatement.setString(5, "");
	 * aPreparedStatement.setString(5, usancePeriod);
	 * aPreparedStatement.setString(6, lcType); aPreparedStatement.setString(7,
	 * custCif); aPreparedStatement.setString(8, finSameDay);
	 * aPreparedStatement.setString(9, requestId.trim());
	 * aPreparedStatement.executeUpdate(); } catch (Exception e) {
	 * e.printStackTrace(); throw e; } finally {
	 * DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet); }
	 * logger.info(ActionConstants.EXITING_METHOD + "setValueInDB"); }
	 */
	public void setValueInDBELCDOP(String solID, String preshipAccSettled,
			String amount, String currency, String usancePeriod, String lcType,
			String custCif, String requestId, String finSameDay,
			String rateTaken, String token, String valueK, String rate,
			String query) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD + "setValueInDB");
		Connection aConnection = null;
		ResultSet aResultSet = null;
		PreparedStatement aPreparedStatement = null;
		try {
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);
			logger.info("query-->" + query);
			aPreparedStatement.setString(1, solID);
			aPreparedStatement.setString(2, preshipAccSettled);
			aPreparedStatement.setString(3, amount);
			aPreparedStatement.setString(4, currency);
			if (usancePeriod == null || usancePeriod.isEmpty())
				aPreparedStatement.setString(5, "");
			aPreparedStatement.setString(5, usancePeriod);
			aPreparedStatement.setString(6, lcType);
			aPreparedStatement.setString(7, custCif);
			aPreparedStatement.setString(8, finSameDay);
			aPreparedStatement.setString(9, rateTaken);
			aPreparedStatement.setString(10, token);
			aPreparedStatement.setString(11, valueK);
			aPreparedStatement.setString(12, rate);
			aPreparedStatement.setString(13, requestId.trim());
			aPreparedStatement.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}
		logger.info(ActionConstants.EXITING_METHOD + "setValueInDB");
	}

	public void setValueInDB(String solID, String lcRefNum, String currency,
			String amount, String fncAmount, String billTenure,
			String customeCif, String customeName, String subProductCode,
			String finalPayment, String getRateTaken, String token,
			String getRateTakenK, String rate, String requestId,
			String gETUPDATETFBOFELCRYSTNEW_QUERY) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD + "setValueInDB");
		Connection aConnection = null;
		ResultSet aResultSet = null;
		PreparedStatement aPreparedStatement = null;
		try {
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection
					.prepareStatement(gETUPDATETFBOFELCRYSTNEW_QUERY);
			logger.info("query-->" + gETUPDATETFBOFELCRYSTNEW_QUERY);
			aPreparedStatement.setString(1, solID);
			aPreparedStatement.setString(2, lcRefNum);
			aPreparedStatement.setString(3, currency);
			aPreparedStatement.setString(4, amount);
			aPreparedStatement.setString(5, fncAmount);
			aPreparedStatement.setString(6, billTenure);
			aPreparedStatement.setString(7, customeCif);
			aPreparedStatement.setString(8, customeName);
			aPreparedStatement.setString(9, subProductCode);
			aPreparedStatement.setString(10, finalPayment);
			aPreparedStatement.setString(11, getRateTaken);
			aPreparedStatement.setString(12, token);
			aPreparedStatement.setString(13, getRateTakenK);
			aPreparedStatement.setString(14, rate);
			aPreparedStatement.setString(15, requestId.trim());
			aPreparedStatement.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}
		logger.info(ActionConstants.EXITING_METHOD + "setValueInDB");
	}

	public void setValueInDB(String solID, String lcRefNum, String currency,
			String amount, String fncAmount, String billTenure,
			String customeCif, String customeName, String subProductCode,
			String finalPayment, String getRateTaken, String token,
			String getRateTakenK, String rate, String requestId,
			String preShipAccId, String gETUPDATETFBOFELCRYSTNEW_QUERY)
			throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD + "setValueInDB");
		Connection aConnection = null;
		ResultSet aResultSet = null;
		PreparedStatement aPreparedStatement = null;
		try {
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection
					.prepareStatement(gETUPDATETFBOFELCRYSTNEW_QUERY);
			logger.info("query-->" + gETUPDATETFBOFELCRYSTNEW_QUERY);
			aPreparedStatement.setString(1, solID);
			aPreparedStatement.setString(2, lcRefNum);
			aPreparedStatement.setString(3, currency);
			aPreparedStatement.setString(4, amount);
			aPreparedStatement.setString(5, fncAmount);
			aPreparedStatement.setString(6, billTenure);
			aPreparedStatement.setString(7, customeCif);
			aPreparedStatement.setString(8, customeName);
			aPreparedStatement.setString(9, subProductCode);
			aPreparedStatement.setString(10, finalPayment);
			aPreparedStatement.setString(11, getRateTaken);
			aPreparedStatement.setString(12, token);
			aPreparedStatement.setString(13, getRateTakenK);
			aPreparedStatement.setString(14, rate);
			aPreparedStatement.setString(15, preShipAccId);
			aPreparedStatement.setString(16, requestId.trim());
			aPreparedStatement.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}
		logger.info(ActionConstants.EXITING_METHOD + "setValueInDB");
	}

	// Changed by onsite team 26122019 starts
	/*
	 * public List<TFBOInwardRemittanceVO> getTFBOInwardRemittanceFromDB( String
	 * requestId, String query) throws Exception {
	 * logger.info(ActionConstants.ENTERING_METHOD + " requestId->" +
	 * requestId); TFBOInwardRemittanceVO aTFBOInwardRemittanceVO = null;
	 * Connection aConnection = null; ResultSet aResultSet = null;
	 * PreparedStatement aPreparedStatement = null; List<TFBOInwardRemittanceVO>
	 * inwardRemittanceCreate = new LinkedList<TFBOInwardRemittanceVO>(); try {
	 * aConnection = DBUtility.getZoneConnection(); aPreparedStatement =
	 * aConnection.prepareStatement(query); logger.info("query-->" + query);
	 * aPreparedStatement.setString(1, requestId.trim()); aResultSet =
	 * aPreparedStatement.executeQuery(); while (aResultSet.next()) {
	 * aTFBOInwardRemittanceVO = new TFBOInwardRemittanceVO();
	 * aTFBOInwardRemittanceVO.setTiReferenceNo(aResultSet .getString(1));
	 * aTFBOInwardRemittanceVO.setSolID(aResultSet.getString(2));
	 * aTFBOInwardRemittanceVO.setCustomeCif(aResultSet.getString(3));
	 * aTFBOInwardRemittanceVO.setAmount(aResultSet.getString(4));
	 * aTFBOInwardRemittanceVO.setCurrency(aResultSet.getString(5));
	 * 
	 * if (aResultSet.getString(6).equalsIgnoreCase("Yes")) {
	 * aTFBOInwardRemittanceVO.setDummyIrex("true"); } else {
	 * aTFBOInwardRemittanceVO.setDummyIrex("false"); }
	 * aTFBOInwardRemittanceVO.setProductType(aResultSet.getString(7));
	 * 
	 * if (aResultSet.getString(8).equalsIgnoreCase("Yes")) {
	 * aTFBOInwardRemittanceVO.setPreshipAccSettled("true"); } else {
	 * aTFBOInwardRemittanceVO.setPreshipAccSettled("false"); }
	 * 
	 * if (aResultSet.getString(9).equalsIgnoreCase("Yes")) {
	 * aTFBOInwardRemittanceVO.setRateTaken("true"); } else {
	 * aTFBOInwardRemittanceVO.setRateTaken("false"); }
	 * aTFBOInwardRemittanceVO.setToken(aResultSet.getString(10));
	 * aTFBOInwardRemittanceVO.setRateTakenK(aResultSet.getString(11));
	 * aTFBOInwardRemittanceVO.setRate(aResultSet.getString(12));
	 * aTFBOInwardRemittanceVO.setSubProductCode(aResultSet .getString(13));
	 * inwardRemittanceCreate.add(aTFBOInwardRemittanceVO); } } catch (Exception
	 * e) { e.printStackTrace(); throw e; } finally {
	 * DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet); }
	 * logger.info(ActionConstants.EXITING_METHOD + "  " +
	 * inwardRemittanceCreate.size()); return inwardRemittanceCreate; }
	 */
	public List<TFBOInwardRemittanceVO> getTFBOInwardRemittanceFromDB(
			String requestId, String query) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD + " requestId->"
				+ requestId);
		TFBOInwardRemittanceVO aTFBOInwardRemittanceVO = null;
		Connection aConnection = null;
		ResultSet aResultSet = null;
		PreparedStatement aPreparedStatement = null;
		List<TFBOInwardRemittanceVO> inwardRemittanceCreate = new LinkedList<TFBOInwardRemittanceVO>();
		try {
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);
			logger.info("query-->" + query);
			aPreparedStatement.setString(1, requestId.trim());
			aResultSet = aPreparedStatement.executeQuery();
			while (aResultSet.next()) {
				aTFBOInwardRemittanceVO = new TFBOInwardRemittanceVO();
				aTFBOInwardRemittanceVO.setTiReferenceNo(aResultSet
						.getString(1));
				aTFBOInwardRemittanceVO.setSolID(aResultSet.getString(2));
				aTFBOInwardRemittanceVO.setCustomeCif(aResultSet.getString(3));
				aTFBOInwardRemittanceVO.setAmount(aResultSet.getString(4));
				aTFBOInwardRemittanceVO.setCurrency(aResultSet.getString(5));

				if (aResultSet.getString(6) != null
						&& !aResultSet.getString(6).trim().equals("")) {
					if (aResultSet.getString(6).equalsIgnoreCase("Yes")) {
						aTFBOInwardRemittanceVO.setDummyIrex("true");
					} else {
						aTFBOInwardRemittanceVO.setDummyIrex("false");
					}
				}

				aTFBOInwardRemittanceVO.setProductType(aResultSet.getString(7));

				if (aResultSet.getString(8) != null
						&& !aResultSet.getString(8).trim().equals("")) {
					if (aResultSet.getString(8).equalsIgnoreCase("Yes")) {
						aTFBOInwardRemittanceVO.setPreshipAccSettled("true");
					} else {
						aTFBOInwardRemittanceVO.setPreshipAccSettled("false");
					}
				}

				if (aResultSet.getString(9) != null
						&& !aResultSet.getString(9).trim().equals("")) {
					if (aResultSet.getString(9).equalsIgnoreCase("Y")) {
						aTFBOInwardRemittanceVO.setRateTaken("true");
					} else {
						aTFBOInwardRemittanceVO.setRateTaken("false");
					}
				}

				aTFBOInwardRemittanceVO.setToken(aResultSet.getString(10));
				aTFBOInwardRemittanceVO.setRateTakenK(aResultSet.getString(11));
				aTFBOInwardRemittanceVO.setRate(aResultSet.getString(12));
				aTFBOInwardRemittanceVO.setSubProductCode(aResultSet
						.getString(13));
				inwardRemittanceCreate.add(aTFBOInwardRemittanceVO);
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}
		logger.info(ActionConstants.EXITING_METHOD + "  "
				+ inwardRemittanceCreate.size());
		return inwardRemittanceCreate;
	}

	// Changed by onsite team 26122019 ends
	public void setValueInwardRemittanceInDB(String value1, String value2,
			String value3, String value4, String value5, String value6,
			String value7, String value8, String value9, String value10,
			String value11, String value12, String query) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD + "setValueInDB");
		Connection aConnection = null;
		ResultSet aResultSet = null;
		PreparedStatement aPreparedStatement = null;
		try {
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);
			logger.info("query-->" + query);
			aPreparedStatement.setString(1, value1);
			aPreparedStatement.setString(2, value2);
			aPreparedStatement.setString(3, value3);
			aPreparedStatement.setString(4, value4);
			aPreparedStatement.setString(5, value5);
			aPreparedStatement.setString(6, value6);
			aPreparedStatement.setString(7, value7);
			aPreparedStatement.setString(8, value8);
			aPreparedStatement.setString(9, value9);
			aPreparedStatement.setString(10, value10);
			aPreparedStatement.setString(11, value11);
			aPreparedStatement.setString(12, value12.trim());
			aPreparedStatement.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}
		logger.info(ActionConstants.EXITING_METHOD + "setValueInDB");
	}

	public void setValueInDBCpcoCreate(String solID, String tiReferanceNo,
			String amount, String customeCif, String customeName,
			String currency, String bankPay, String rateTaken,
			String subProductCode, String token, String valueK, String rate,
			String requestId, String gETUPDATETFBOCPCPCRE_QUERY)
			throws Exception {
		Connection aConnection = null;
		ResultSet aResultSet = null;
		PreparedStatement aPreparedStatement = null;
		try {
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection
					.prepareStatement(gETUPDATETFBOCPCPCRE_QUERY);
			aPreparedStatement.setString(1, solID);
			aPreparedStatement.setString(2, tiReferanceNo);
			aPreparedStatement.setString(3, amount);
			aPreparedStatement.setString(4, customeCif);
			aPreparedStatement.setString(5, customeName);
			aPreparedStatement.setString(6, currency);
			if (bankPay.equalsIgnoreCase("true"))
				aPreparedStatement.setString(7, "Y");
			else
				aPreparedStatement.setString(7, "N");
			if (rateTaken.equalsIgnoreCase("true"))
				aPreparedStatement.setString(8, "Y");
			else
				aPreparedStatement.setString(8, "N");
			aPreparedStatement.setString(9, subProductCode);
			aPreparedStatement.setString(10, token);
			aPreparedStatement.setString(11, valueK);
			aPreparedStatement.setString(12, rate);
			aPreparedStatement.setString(13, requestId.trim());
			aPreparedStatement.execute();
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}
	}

	public List<TFBOOutwardRemittanceVO> getTFBOCPCOCREFromDB(String requestId,
			String query) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD + " requestId->"
				+ requestId);
		TFBOOutwardRemittanceVO aTFBOOutwardRemittanceVO = null;
		Connection aConnection = null;
		ResultSet aResultSet = null;
		PreparedStatement aPreparedStatement = null;
		List<TFBOOutwardRemittanceVO> cpcoCreate = new LinkedList<TFBOOutwardRemittanceVO>();
		try {
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);
			logger.info("query-->" + query);
			aPreparedStatement.setString(1, requestId.trim());
			aResultSet = aPreparedStatement.executeQuery();
			while (aResultSet.next()) {
				aTFBOOutwardRemittanceVO = new TFBOOutwardRemittanceVO();
				aTFBOOutwardRemittanceVO.setTiRefNo(aResultSet.getString(1));
				aTFBOOutwardRemittanceVO.setSolID(aResultSet.getString(2));
				aTFBOOutwardRemittanceVO.setCustomeCif(aResultSet.getString(3));
				aTFBOOutwardRemittanceVO.setAmount(aResultSet.getString(4));
				aTFBOOutwardRemittanceVO.setCurrency(aResultSet.getString(5));
				// aTFBOOutwardRemittanceVO.setRateTaken(aResultSet.getString(6));
				// ADDED BY CHANDRU
				if (aResultSet.getString(6) != null
						&& !aResultSet.getString(6).trim().equals("")) {
					if (aResultSet.getString(6).equalsIgnoreCase("Y")) {
						aTFBOOutwardRemittanceVO.setRateTaken("true");
					} else {
						aTFBOOutwardRemittanceVO.setRateTaken("false");
					}
				}
				// ENDS
				aTFBOOutwardRemittanceVO.setToken(aResultSet.getString(7));
				aTFBOOutwardRemittanceVO.setValueK(aResultSet.getString(8));
				aTFBOOutwardRemittanceVO.setRate(aResultSet.getString(9));
				aTFBOOutwardRemittanceVO.setBankpayment(aResultSet
						.getString(10));
				aTFBOOutwardRemittanceVO.setSubProductCode(aResultSet
						.getString(11));
				cpcoCreate.add(aTFBOOutwardRemittanceVO);
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}
		logger.info(ActionConstants.EXITING_METHOD + "  " + cpcoCreate.size());
		return cpcoCreate;
	}

	public List<TFBOOutwardRemittanceVO> getTFBOCPCOCreFromDB(String requestId,
			String query) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD + " requestId->"
				+ requestId);
		TFBOOutwardRemittanceVO aTFBOOutwardRemittanceVO = null;
		Connection aConnection = null;
		ResultSet aResultSet = null;
		PreparedStatement aPreparedStatement = null;
		List<TFBOOutwardRemittanceVO> cpcoCreate = new LinkedList<TFBOOutwardRemittanceVO>();
		try {
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);
			logger.info("query-->" + query);
			aPreparedStatement.setString(1, requestId.trim());
			aResultSet = aPreparedStatement.executeQuery();
			while (aResultSet.next()) {
				aTFBOOutwardRemittanceVO = new TFBOOutwardRemittanceVO();
				aTFBOOutwardRemittanceVO.setSolID(aResultSet.getString(1));
				aTFBOOutwardRemittanceVO.setCustomeCif(aResultSet.getString(2));
				aTFBOOutwardRemittanceVO.setAmount(aResultSet.getString(3));
				aTFBOOutwardRemittanceVO.setCurrency(aResultSet.getString(4));
				aTFBOOutwardRemittanceVO.setSubProductCode(aResultSet
						.getString(5));
				cpcoCreate.add(aTFBOOutwardRemittanceVO);
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}
		logger.info(ActionConstants.EXITING_METHOD + "  " + cpcoCreate.size());
		return cpcoCreate;
	}

	public List<TFBOOutwardRemittanceVO> getTFBOCPCOCREFromDB(String requestId,
			String billRef, String query) throws Exception {
		TFBOOutwardRemittanceVO aTFBOOutwardRemittanceVO = null;
		Connection aConnection = null;
		ResultSet aResultSet = null;
		PreparedStatement aPreparedStatement = null;
		List<TFBOOutwardRemittanceVO> cpcoCreate = new LinkedList<TFBOOutwardRemittanceVO>();
		try {
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);
			logger.info("query-->" + query);
			aPreparedStatement.setString(1, requestId);
			aPreparedStatement.setString(2, billRef);
			aResultSet = aPreparedStatement.executeQuery();
			while (aResultSet.next()) {
				aTFBOOutwardRemittanceVO = new TFBOOutwardRemittanceVO();
				aTFBOOutwardRemittanceVO.setSolID(aResultSet.getString(1));
				aTFBOOutwardRemittanceVO.setCustomeCif(aResultSet.getString(2));
				aTFBOOutwardRemittanceVO.setAmount(aResultSet.getString(3));
				aTFBOOutwardRemittanceVO.setCurrency(aResultSet.getString(4));
				aTFBOOutwardRemittanceVO.setSubProductCode(aResultSet
						.getString(5));
				cpcoCreate.add(aTFBOOutwardRemittanceVO);
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}
		logger.info(ActionConstants.EXITING_METHOD + "  " + cpcoCreate.size());
		return cpcoCreate;
	}

	public void setISBIISSInDB(String requestId, String solID,
			String customeCif, String customeName, String amount,
			String currency, String rateTaken, String billUsancePeriod,
			String billrefno, String bgRefNo, String subproduct, String query)
			throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD + "setISBIISSInDB");
		Connection aConnection = null;
		ResultSet aResultSet = null;
		PreparedStatement aPreparedStatement = null;
		try {
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);
			logger.info("query-->" + query);
			aPreparedStatement.setString(1, solID);
			aPreparedStatement.setString(2, customeCif);
			aPreparedStatement.setString(3, customeName);
			aPreparedStatement.setString(4, amount);
			aPreparedStatement.setString(5, currency);
			aPreparedStatement.setString(6, rateTaken);
			aPreparedStatement.setString(7, billUsancePeriod);
			aPreparedStatement.setString(8, billrefno);
			aPreparedStatement.setString(9, bgRefNo);
			aPreparedStatement.setString(10, subproduct);
			aPreparedStatement.setString(11, requestId.trim());
			aPreparedStatement.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}
		logger.info(ActionConstants.EXITING_METHOD + "setISBIISSInDB");
	}

	// Changed by onsite team 26122019 starts
	/*
	 * public void setISB_AJ_AD_CR_InDB(String requestId, String solID, String
	 * tiReferanceNo, String customeCif, String customeName, String amount,
	 * String currency, String billUsancePeriod, String billrefno, String
	 * bgRefNo, String subproduct, String query) throws Exception {
	 * logger.info(ActionConstants.ENTERING_METHOD + "setISB_AJ_AD_InDB");
	 * Connection aConnection = null; ResultSet aResultSet = null;
	 * PreparedStatement aPreparedStatement = null; try { aConnection =
	 * DBUtility.getZoneConnection(); aPreparedStatement =
	 * aConnection.prepareStatement(query); logger.info("query-->" + query);
	 * aPreparedStatement.setString(1, solID); aPreparedStatement.setString(2,
	 * tiReferanceNo); aPreparedStatement.setString(3, customeCif);
	 * aPreparedStatement.setString(4, customeName);
	 * aPreparedStatement.setString(5, amount); aPreparedStatement.setString(6,
	 * currency); aPreparedStatement.setString(7, billUsancePeriod);
	 * aPreparedStatement.setString(8, billrefno);
	 * aPreparedStatement.setString(9, bgRefNo);
	 * aPreparedStatement.setString(10, subproduct);
	 * aPreparedStatement.setString(10, requestId.trim());
	 * aPreparedStatement.executeUpdate(); } catch (Exception e) {
	 * e.printStackTrace(); throw e; } finally {
	 * DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet); }
	 * logger.info(ActionConstants.EXITING_METHOD + "setISB_AJ_AD_InDB"); }
	 */
	public void setISB_AJ_AD_CR_InDB(String requestId, String solID,
			String tiReferanceNo, String customeCif, String customeName,
			String amount, String currency, String billUsancePeriod,
			String billrefno, String bgRefNo, String subproduct, String query)
			throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD + "setISB_AJ_AD_InDB");
		Connection aConnection = null;
		ResultSet aResultSet = null;
		PreparedStatement aPreparedStatement = null;
		try {
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);
			logger.info("query-->" + query);
			aPreparedStatement.setString(1, solID);
			aPreparedStatement.setString(2, tiReferanceNo);
			aPreparedStatement.setString(3, customeCif);
			aPreparedStatement.setString(4, customeName);
			aPreparedStatement.setString(5, amount);
			aPreparedStatement.setString(6, currency);
			aPreparedStatement.setString(7, billUsancePeriod);
			aPreparedStatement.setString(8, billrefno);
			aPreparedStatement.setString(9, bgRefNo);
			aPreparedStatement.setString(10, subproduct);
			aPreparedStatement.setString(11, requestId.trim());// CHANGED BY
																// CHANDRU
			aPreparedStatement.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}
		logger.info(ActionConstants.EXITING_METHOD + "setISB_AJ_AD_InDB");
	}

	// Changed by onsite team 26122019 ends

	public void setISBOISInDB(String requestId, String solID,
			String tiReferanceNo, String conBillRef, String customeCif,
			String customeName, String amount, String currency,
			String billUsancePeriod, String billrefno, String bgRefNo,
			String subproduct, String billref, String rateToken, String token,
			String valueK, String rate, String query) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD + "setISBOISInDB");
		Connection aConnection = null;
		ResultSet aResultSet = null;
		PreparedStatement aPreparedStatement = null;
		try {
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);
			logger.info("query-->" + query);
			aPreparedStatement.setString(1, solID);
			aPreparedStatement.setString(2, tiReferanceNo);
			aPreparedStatement.setString(3, conBillRef);
			aPreparedStatement.setString(4, customeCif);
			aPreparedStatement.setString(5, customeName);
			aPreparedStatement.setString(6, amount);
			aPreparedStatement.setString(7, currency);
			aPreparedStatement.setString(8, billUsancePeriod);
			aPreparedStatement.setString(9, billrefno);
			aPreparedStatement.setString(10, bgRefNo);
			aPreparedStatement.setString(11, subproduct);
			aPreparedStatement.setString(12, billref);
			// ADDED BY CHANDRU
			aPreparedStatement.setString(13, rateToken);
			aPreparedStatement.setString(14, token);
			aPreparedStatement.setString(15, valueK);
			aPreparedStatement.setString(16, rate);
			// ADDED BY CHANDRU
			aPreparedStatement.setString(17, requestId.trim());
			aPreparedStatement.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}
		logger.info(ActionConstants.EXITING_METHOD + "setISB_AJ_AD_InDB");
	}

	public List<TFBOSandbyLcVO> getTFBOISBISSFromDB(String requestId,
			String query) throws Exception {

		logger.info(ActionConstants.ENTERING_METHOD + " requestId->"
				+ requestId);
		TFBOSandbyLcVO aTFBOSandbyLcVO = null;
		Connection aConnection = null;
		ResultSet aResultSet = null;
		PreparedStatement aPreparedStatement = null;
		List<TFBOSandbyLcVO> isbIss = new LinkedList<TFBOSandbyLcVO>();
		try {
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);
			logger.info("query-->" + query);
			aPreparedStatement.setString(1, requestId.trim());
			aResultSet = aPreparedStatement.executeQuery();
			while (aResultSet.next()) {
				aTFBOSandbyLcVO = new TFBOSandbyLcVO();
				aTFBOSandbyLcVO.setTiReferanceNo(aResultSet.getString(1));
				aTFBOSandbyLcVO.setSolID(aResultSet.getString(2));
				aTFBOSandbyLcVO.setCustomeCif(aResultSet.getString(3));
				aTFBOSandbyLcVO.setCustomeName(aResultSet.getString(4));
				aTFBOSandbyLcVO.setAmount(aResultSet.getString(5));
				aTFBOSandbyLcVO.setCurrency(aResultSet.getString(6));
				// aTFBOSandbyLcVO.setRateTaken(aResultSet.getString(7));

				// ADDED BY CHANDRU
				if (aResultSet.getString(7) != null
						&& !aResultSet.getString(7).trim().equals("")) {
					if (aResultSet.getString(7).equalsIgnoreCase("Y")) {
						aTFBOSandbyLcVO.setRateTaken("true");
					} else {
						aTFBOSandbyLcVO.setRateTaken("false");
					}
				}
				// ENDS

				aTFBOSandbyLcVO.setBillUsancePeriod(aResultSet.getString(8));
				aTFBOSandbyLcVO.setBillrefno(aResultSet.getString(9));
				aTFBOSandbyLcVO.setBgRefNo(aResultSet.getString(10));
				aTFBOSandbyLcVO.setSubProductCode(aResultSet.getString(11));
				isbIss.add(aTFBOSandbyLcVO);
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}
		logger.info(ActionConstants.EXITING_METHOD + "  " + isbIss.size());
		return isbIss;

	}

	public List<TFBOSandbyLcVO> getTFBOISB_AJ_AD_CR_FrmDB(String requestId,
			String query) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD + " requestId->"
				+ requestId);
		TFBOSandbyLcVO aTFBOSandbyLcVO = null;
		Connection aConnection = null;
		ResultSet aResultSet = null;
		PreparedStatement aPreparedStatement = null;
		List<TFBOSandbyLcVO> isballEvent = new LinkedList<TFBOSandbyLcVO>();
		try {
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);
			logger.info("query-->" + query);
			aPreparedStatement.setString(1, requestId.trim());
			aResultSet = aPreparedStatement.executeQuery();
			while (aResultSet.next()) {
				aTFBOSandbyLcVO = new TFBOSandbyLcVO();
				aTFBOSandbyLcVO.setTiReferanceNo(aResultSet.getString(1));
				aTFBOSandbyLcVO.setSolID(aResultSet.getString(2));
				aTFBOSandbyLcVO.setCustomeCif(aResultSet.getString(3));
				aTFBOSandbyLcVO.setCustomeName(aResultSet.getString(4));
				aTFBOSandbyLcVO.setAmount(aResultSet.getString(5));
				aTFBOSandbyLcVO.setCurrency(aResultSet.getString(6));
				aTFBOSandbyLcVO.setBillUsancePeriod(aResultSet.getString(7));
				aTFBOSandbyLcVO.setBillrefno(aResultSet.getString(8));
				aTFBOSandbyLcVO.setBgRefNo(aResultSet.getString(9));
				aTFBOSandbyLcVO.setSubProductCode(aResultSet.getString(10));
				isballEvent.add(aTFBOSandbyLcVO);
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}
		logger.info(ActionConstants.EXITING_METHOD + "  " + isballEvent.size());
		return isballEvent;
	}

	// Changed by onsite team 26122019 starts
	/*
	 * public List<TFBOSandbyLcVO> getTFBOISBOISFrmDB(String requestId, String
	 * query) throws Exception { logger.info(ActionConstants.ENTERING_METHOD +
	 * " requestId->" + requestId); TFBOSandbyLcVO aTFBOSandbyLcVO = null;
	 * Connection aConnection = null; ResultSet aResultSet = null;
	 * PreparedStatement aPreparedStatement = null; List<TFBOSandbyLcVO>
	 * isboisList = new LinkedList<TFBOSandbyLcVO>(); try { aConnection =
	 * DBUtility.getZoneConnection(); aPreparedStatement =
	 * aConnection.prepareStatement(query); logger.info("query-->" + query);
	 * aPreparedStatement.setString(1, requestId.trim()); aResultSet =
	 * aPreparedStatement.executeQuery(); while (aResultSet.next()) {
	 * aTFBOSandbyLcVO = new TFBOSandbyLcVO();
	 * aTFBOSandbyLcVO.setTiReferanceNo(aResultSet.getString(1));
	 * aTFBOSandbyLcVO.setSolID(aResultSet.getString(2));
	 * aTFBOSandbyLcVO.setConBillRef(aResultSet.getString(3));
	 * aTFBOSandbyLcVO.setCustomeCif(aResultSet.getString(4));
	 * aTFBOSandbyLcVO.setCustomeName(aResultSet.getString(5));
	 * aTFBOSandbyLcVO.setAmount(aResultSet.getString(6));
	 * aTFBOSandbyLcVO.setCurrency(aResultSet.getString(7));
	 * aTFBOSandbyLcVO.setBillUsancePeriod(aResultSet.getString(8));
	 * aTFBOSandbyLcVO.setBillrefno(aResultSet.getString(9));
	 * aTFBOSandbyLcVO.setBgRefNo(aResultSet.getString(10));
	 * aTFBOSandbyLcVO.setSubProductCode(aResultSet.getString(11));
	 * isboisList.add(aTFBOSandbyLcVO); } } catch (Exception e) {
	 * e.printStackTrace(); throw e; } finally {
	 * DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet); }
	 * logger.info(ActionConstants.EXITING_METHOD + "  " + isboisList.size());
	 * return isboisList; }
	 */
	public List<TFBOSandbyLcVO> getTFBOISBOISFrmDB(String requestId,
			String query) throws Exception {

		logger.info(ActionConstants.ENTERING_METHOD + " requestId->"
				+ requestId);
		TFBOSandbyLcVO aTFBOSandbyLcVO = null;
		Connection aConnection = null;
		ResultSet aResultSet = null;
		PreparedStatement aPreparedStatement = null;
		List<TFBOSandbyLcVO> isboisList = new LinkedList<TFBOSandbyLcVO>();
		// "SELECT TRANS.TIREFERANCE,OIS.SOLID,OIS.CUSTOMERCIF,OIS.CUST_NAME,OIS.AMOUNT,OIS.CURRENCY,OIS.TENURE,OIS.BILLREFNO,OIS.BGREFNO,OIS.PROD_TYPE FROM TFBO_TRANS TRANS,TFBO_ISB_OUTSTDCLM OIS WHERE TRANS.REQUESTID = OIS.REQUESTID AND TRIM(TRANS.REQUESTID)=?";
		try {
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);
			logger.info("query-->" + query);
			aPreparedStatement.setString(1, requestId.trim());
			aResultSet = aPreparedStatement.executeQuery();
			while (aResultSet.next()) {
				aTFBOSandbyLcVO = new TFBOSandbyLcVO();
				aTFBOSandbyLcVO.setTiReferanceNo(aResultSet.getString(1));
				aTFBOSandbyLcVO.setSolID(aResultSet.getString(2));
				// aTFBOSandbyLcVO.setConBillRef(aResultSet.getString(3));//CHANGED
				// BY CHANDRU
				aTFBOSandbyLcVO.setCustomeCif(aResultSet.getString(3));
				aTFBOSandbyLcVO.setCustomeName(aResultSet.getString(4));
				aTFBOSandbyLcVO.setAmount(aResultSet.getString(5));
				aTFBOSandbyLcVO.setCurrency(aResultSet.getString(6));
				aTFBOSandbyLcVO.setBillUsancePeriod(aResultSet.getString(7));
				aTFBOSandbyLcVO.setBillrefno(aResultSet.getString(8));
				aTFBOSandbyLcVO.setBgRefNo(aResultSet.getString(9));
				aTFBOSandbyLcVO.setSubProductCode(aResultSet.getString(10));
				aTFBOSandbyLcVO.setBillreference(aResultSet.getString(11));
				if (aResultSet.getString(12) != null
						&& !aResultSet.getString(12).trim().equals("")) {
					if (aResultSet.getString(12).trim().equals("Y"))
						aTFBOSandbyLcVO.setRateTaken("true");
					else
						aTFBOSandbyLcVO.setRateTaken("false");
				}
				aTFBOSandbyLcVO.setToken(aResultSet.getString(13));
				aTFBOSandbyLcVO.setValueK(aResultSet.getString(14));
				aTFBOSandbyLcVO.setRate(aResultSet.getString(15));
				isboisList.add(aTFBOSandbyLcVO);
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}
		logger.info(ActionConstants.EXITING_METHOD + "  " + isboisList.size());
		return isboisList;

	}

	public List<TFBOSandbyLcVO> getTFBOISBOISTransFrmDB(String requestId,
			String query) throws Exception {

		logger.info(ActionConstants.ENTERING_METHOD + " requestId->"
				+ requestId);
		TFBOSandbyLcVO aTFBOSandbyLcVO = null;
		Connection aConnection = null;
		ResultSet aResultSet = null;
		PreparedStatement aPreparedStatement = null;
		List<TFBOSandbyLcVO> isboisList = new LinkedList<TFBOSandbyLcVO>();
		// "SELECT TRANS.TIREFERANCE,OIS.SOLID,OIS.CUSTOMERCIF,OIS.CUST_NAME,OIS.AMOUNT,OIS.CURRENCY,OIS.TENURE,OIS.BILLREFNO,OIS.BGREFNO,OIS.PROD_TYPE FROM TFBO_TRANS TRANS,TFBO_ISB_OUTSTDCLM OIS WHERE TRANS.REQUESTID = OIS.REQUESTID AND TRIM(TRANS.REQUESTID)=?";
		try {
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);
			logger.info("query-->" + query);
			aPreparedStatement.setString(1, requestId.trim());
			aResultSet = aPreparedStatement.executeQuery();
			while (aResultSet.next()) {
				aTFBOSandbyLcVO = new TFBOSandbyLcVO();
				aTFBOSandbyLcVO.setTiReferanceNo(aResultSet.getString(1));
				aTFBOSandbyLcVO.setSolID(aResultSet.getString(2));
				// aTFBOSandbyLcVO.setConBillRef(aResultSet.getString(3));//CHANGED
				// BY CHANDRU
				aTFBOSandbyLcVO.setCustomeCif(aResultSet.getString(3));
				aTFBOSandbyLcVO.setCustomeName(aResultSet.getString(4));
				aTFBOSandbyLcVO.setAmount(aResultSet.getString(5));
				aTFBOSandbyLcVO.setCurrency(aResultSet.getString(6));
				aTFBOSandbyLcVO.setBillUsancePeriod(aResultSet.getString(7));
				aTFBOSandbyLcVO.setBillrefno(aResultSet.getString(8));
				aTFBOSandbyLcVO.setBgRefNo(aResultSet.getString(9));
				aTFBOSandbyLcVO.setSubProductCode(aResultSet.getString(10));
				/* aTFBOSandbyLcVO.setBillreference(aResultSet.getString(11)); */
				isboisList.add(aTFBOSandbyLcVO);
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}
		logger.info(ActionConstants.EXITING_METHOD + "  " + isboisList.size());
		return isboisList;

	}

	// Changed by onsite team 26122019 ends

	public List<TFBOImportGTVO> getTFBOImportGTAMDFromDB(String requestId,
			String query) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD + " requestId->"
				+ requestId);
		TFBOImportGTVO aTFBOImportGTVO = null;
		Connection aConnection = null;
		ResultSet aResultSet = null;
		PreparedStatement aPreparedStatement = null;
		List<TFBOImportGTVO> igtAmend = new LinkedList<TFBOImportGTVO>();
		try {
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);
			logger.info("query-->" + query);
			aPreparedStatement.setString(1, requestId.trim());
			aResultSet = aPreparedStatement.executeQuery();
			while (aResultSet.next()) {
				aTFBOImportGTVO = new TFBOImportGTVO();
				aTFBOImportGTVO.setTiReferenceNo(aResultSet.getString(1));
				aTFBOImportGTVO.setSolID(aResultSet.getString(2));
				aTFBOImportGTVO.setCustomeCif(aResultSet.getString(3));
				aTFBOImportGTVO.setAmount(aResultSet.getString(4));
				aTFBOImportGTVO.setCurrency(aResultSet.getString(5));
				aTFBOImportGTVO.setTenure(aResultSet.getString(6));
				aTFBOImportGTVO.setSubProductCode(aResultSet.getString(7)
						.trim());
				igtAmend.add(aTFBOImportGTVO);
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}
		logger.info(ActionConstants.EXITING_METHOD + "  " + igtAmend.size());
		return igtAmend;
	}

	public String getGuaranteeAmt(String tiReferenceNo,String billReference, String query)
			throws Exception {
		Connection aConnection = null;
		PreparedStatement aPreparedStatement = null;
		ResultSet aResultSet = null;
		String guranteeAmt = "";
		query = "Select  nvl(sum("
				+ schemaName
				+ "Theme_Genius_Pkg.Convamt(bev.ccy, Bev.Amount)),0) From "
				+ schemaName
				+ "Master Mas, "
				+ schemaName
				+ "Baseevent Bev Where Mas.Key97 = Bev.Master_Key And  Bev.Refno_Pfix||LPAD(Bev.REFNO_SERL,3,0)= '"+ billReference +"' And  Mas.Refno_Pfix = 'IGT' and mas.master_ref ='"
				+ tiReferenceNo + "'";
		System.out.println("query >>-->" + query);
		try {
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);
			// aPreparedStatement.setString(1, tiReferenceNo.trim());
			aResultSet = aPreparedStatement.executeQuery();
			while (aResultSet.next()) {
				guranteeAmt = aResultSet.getString(1);
				System.out.println("guranteeAmt >>-->" + guranteeAmt);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}
		System.out.println("guranteeAmt >>-->" + guranteeAmt);
		return guranteeAmt;
	}

	public List<TFBOImportGTVO> getTFBOImportGTOIGFromDB(String requestId,
			String query) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD + " requestId->"
				+ requestId);
		TFBOImportGTVO aTFBOImportGTVO = null;
		Connection aConnection = null;
		ResultSet aResultSet = null;
		PreparedStatement aPreparedStatement = null;
		List<TFBOImportGTVO> igtAmend = new LinkedList<TFBOImportGTVO>();
		try {
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);
			logger.info("query-->" + query);
			aPreparedStatement.setString(1, requestId.trim());
			aResultSet = aPreparedStatement.executeQuery();
			while (aResultSet.next()) {
				aTFBOImportGTVO = new TFBOImportGTVO();
				aTFBOImportGTVO.setTiReferenceNo(aResultSet.getString(1));
				aTFBOImportGTVO.setSolID(aResultSet.getString(2));
				aTFBOImportGTVO.setCustomeCif(aResultSet.getString(3));
				aTFBOImportGTVO.setAmount(aResultSet.getString(4));
				aTFBOImportGTVO.setCurrency(aResultSet.getString(5));
				aTFBOImportGTVO.setTenure(aResultSet.getString(6));
				aTFBOImportGTVO.setSubProductCode(aResultSet.getString(7));
//				aTFBOImportGTVO.setGuarnteeAmtPrevInv(aResultSet.getString(8));
				aTFBOImportGTVO.setReqInvAmt(aResultSet.getString(9));
				// ADDED BY CHANDRU
				if (aResultSet.getString(10).equals("Y")) {
					aTFBOImportGTVO.setPartInvocation("true");
				} else {
					aTFBOImportGTVO.setPartInvocation("false");
				}
				// ENDS
				igtAmend.add(aTFBOImportGTVO);
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}
		logger.info(ActionConstants.EXITING_METHOD + "  " + igtAmend.size());
		return igtAmend;
	}

	public void setValueInDBELCPODA(String tiReferanceNo, String solID,
			String custCif, String customeName, String acceptanceAmount,
			String lcType, String currency, String billReference,
			String subprodtype, String requestId, String query)
			throws Exception {
		Connection aConnection = null;
		PreparedStatement aPreparedStatement = null;
		logger.info("query >>-->" + query);
		try {
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);
			aPreparedStatement.setString(1, solID);
			aPreparedStatement.setString(2, acceptanceAmount);
			aPreparedStatement.setString(3, custCif);
			aPreparedStatement.setString(4, lcType);
			aPreparedStatement.setString(5, currency);
			aPreparedStatement.setString(6, subprodtype);
			aPreparedStatement.setString(7, billReference);
			// aPreparedStatement.setString(8, tiReferanceNo);
			aPreparedStatement.setString(8, requestId);
			aPreparedStatement.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, null);
		}
	}

	public void setValueInDBELCPODP(String tiReferanceNo, String solID,
			String custCif, String customeName, String acceptanceAmount,
			String lcType, String currency, String billReference,
			String subprodtype, String rateTaken, String token, String K,
			String rate, String requestId, String query) throws Exception {
		Connection aConnection = null;
		PreparedStatement aPreparedStatement = null;
		logger.info("query >>-->" + query);
		try {
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);
			aPreparedStatement.setString(1, solID);
			aPreparedStatement.setString(2, acceptanceAmount);
			aPreparedStatement.setString(3, custCif);
			aPreparedStatement.setString(4, lcType);
			aPreparedStatement.setString(5, currency);
			aPreparedStatement.setString(6, subprodtype);
			aPreparedStatement.setString(7, billReference);
			logger.info("rateTaken >>-->" + rateTaken);
			if (rateTaken.equals("true")) {
				aPreparedStatement.setString(8, "Y");
			} else {
				aPreparedStatement.setString(8, "N");
			}
			aPreparedStatement.setString(9, token);
			aPreparedStatement.setString(10, K);
			aPreparedStatement.setString(11, rate);
			aPreparedStatement.setString(12, requestId);
			aPreparedStatement.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, null);
		}
	}

	public void setValueInDBIGTIIG(String tiReferanceNo, String solID,
			String customeCif, String customeName, String amount,
			String currency, String subProductCode, String tenure,
			String requestId, String expiryDate, String query) throws Exception {
		Connection aConnection = null;
		PreparedStatement aPreparedStatement = null;
		logger.info("query >>-->" + query);
		try {
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);
			aPreparedStatement.setString(1, solID);
			aPreparedStatement.setString(2, amount);
			aPreparedStatement.setString(3, customeCif);
			aPreparedStatement.setString(4, currency);
			aPreparedStatement.setString(5, tenure);
			aPreparedStatement.setString(6, expiryDate);
			aPreparedStatement.setString(7, requestId);
			aPreparedStatement.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, null);
		}
	}

	public void setValueInDBIGTNAIG(String tiReferanceNo, String solID,
			String customeCif, String customeName, String amount,
			String currency, String subProductCode, String tenure,
			String requestId, String query) throws Exception {
		Connection aConnection = null;
		PreparedStatement aPreparedStatement = null;
		logger.info("query >>-->" + query);
		try {
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);
			aPreparedStatement.setString(1, solID);
			aPreparedStatement.setString(2, amount);
			aPreparedStatement.setString(3, customeCif);
			aPreparedStatement.setString(4, currency);
			aPreparedStatement.setString(5, tenure);
			aPreparedStatement.setString(6, requestId);
			aPreparedStatement.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, null);
		}
	}

	public void setValueInDBIGTLIG(String tiReferanceNo, String solID,
			String customeCif, String customeName, String amount,
			String currency, String subProductCode, String tenure,
			String partInvocation, String requestId, String guarnteeAmtPrevInv,
			String reqInvAmt, String query) throws Exception {
		Connection aConnection = null;
		PreparedStatement aPreparedStatement = null;

		logger.info("query >>-->" + query);
		query = "update TFBO_IGT_Claim set solid = '" + solID.trim()
				+ "', amount = '" + amount.trim() + "', customercif = '"
				+ customeCif.trim() + "', currency = '" + currency.trim()
				+ "', TENURE = '" + tenure.trim() + "', isPartInvocation='"
				+ partInvocation.trim() + "', GuaranteePrevInvoAmt='"
				+ guarnteeAmtPrevInv.trim() + "', reqinvoamt='"
				+ reqInvAmt.trim() + "' where requestid = '" + requestId.trim()
				+ "'";
		try {
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);
			aPreparedStatement.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, null);
		}
	}

	/* changes for rate taken starts 010120 */
	public void setValueInDBIGTOIG(String tiReferanceNo, String solID,
			String customeCif, String customeName, String amount,
			String currency, String subProductCode, String tenure,
			String partInvocation, String requestId, String guarnteeAmtPrevInv,
			String reqInvAmt, String rateTaken, String valueK, String token,
			String rate, String billref, String query) throws Exception {
		Connection aConnection = null;
		PreparedStatement aPreparedStatement = null;
		System.out.println("currency >>-->" + currency);
		logger.info("query >>-->" + query);
		// update TFBO_IGT_Payment set solid = ?, amount = ?, customercif = ?,
		// currency = ?, TENURE = ?, isPartInvocation=?, GuaranteePrevInvoAmt=?,
		// reqinvoamt=?,ratetaken=?,valueK=?,token=?,rate=?,billreference = ?
		// where requestid = ?"
		try {
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);
			aPreparedStatement.setString(1, solID.trim());
			aPreparedStatement.setString(2, amount.trim());
			aPreparedStatement.setString(3, customeCif.trim());
			aPreparedStatement.setString(4, currency);
			aPreparedStatement.setString(5, tenure.trim());
			if (partInvocation.trim().equals("true"))
				aPreparedStatement.setString(6, "Y");
			else
				aPreparedStatement.setString(6, "N");
			aPreparedStatement.setString(7, guarnteeAmtPrevInv.trim());
			aPreparedStatement.setString(8, reqInvAmt.trim());
			if (rateTaken.trim().equals("true"))
				aPreparedStatement.setString(9, "Y");
			else
				aPreparedStatement.setString(9, "N");
			/*
			 * if (valueK.trim().equals("true"))
			 * aPreparedStatement.setString(10, "Y"); else
			 * aPreparedStatement.setString(10, "N");
			 */
			aPreparedStatement.setString(10, valueK.trim());
			aPreparedStatement.setString(11, token.trim());
			aPreparedStatement.setString(12, rate.trim());
			aPreparedStatement.setString(13, billref);
			aPreparedStatement.setString(14, requestId.trim());
			aPreparedStatement.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, null);
		}
	}

	/* changes for rate taken starts 010120 */
	// changes for ELC and IGT Starts here

	public List<TFBOImportGTVO> getTFBOGTIIGFromDB(String requestId,
			String query) throws Exception {

		Connection aConnection = null;
		PreparedStatement aPreparedStatement = null;
		ResultSet aResultset = null;
		List<TFBOImportGTVO> importGTVOList = new LinkedList<TFBOImportGTVO>();
		TFBOImportGTVO importGTVO = null;
		logger.info("query >>-->" + query);
		try {
			importGTVO = new TFBOImportGTVO();
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);
			aPreparedStatement.setString(1, requestId.trim());
			aResultset = aPreparedStatement.executeQuery();
			while (aResultset.next()) {
				importGTVO.setTiReferenceNo(aResultset.getString(1));
				importGTVO.setSolID(aResultset.getString(2));
				importGTVO.setCustomeCif(aResultset.getString(3));
				importGTVO.setAmount(aResultset.getString(4));
				importGTVO.setCurrency(aResultset.getString(5));
				importGTVO.setTenure(aResultset.getString(6));
				importGTVO.setExpiryDate(aResultset.getString(7));
				importGTVO.setSubProductCode(aResultset.getString(8));
				importGTVOList.add(importGTVO);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, null);
		}
		return importGTVOList;
	}

	public List<TFBOImportGTVO> getTFBOGTNAIGFromDB(String requestId,
			String query) throws Exception {

		Connection aConnection = null;
		PreparedStatement aPreparedStatement = null;
		ResultSet aResultset = null;
		List<TFBOImportGTVO> importGTVOList = new LinkedList<TFBOImportGTVO>();
		TFBOImportGTVO importGTVO = null;
		logger.info("query >>-->" + query);
		try {
			importGTVO = new TFBOImportGTVO();
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);
			aPreparedStatement.setString(1, requestId.trim());
			aResultset = aPreparedStatement.executeQuery();
			while (aResultset.next()) {
				importGTVO.setTiReferenceNo(aResultset.getString(1));
				importGTVO.setSolID(aResultset.getString(2));
				importGTVO.setCustomeCif(aResultset.getString(3));
				importGTVO.setAmount(aResultset.getString(4));
				importGTVO.setCurrency(aResultset.getString(5));
				importGTVO.setTenure(aResultset.getString(6));
				importGTVO.setSubProductCode(aResultset.getString(7));
				importGTVOList.add(importGTVO);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, null);
		}
		return importGTVOList;
	}

	public List<TFBOImportGTVO> getTFBOGTLIGFromDB(String requestId,
			String query) throws Exception {

		Connection aConnection = null;
		PreparedStatement aPreparedStatement = null;
		ResultSet aResultset = null;
		List<TFBOImportGTVO> importGTVOList = new LinkedList<TFBOImportGTVO>();
		TFBOImportGTVO importGTVO = null;
		// "SELECT TRANS.TIREFERANCE,IIG.SOLID,IIG.CUSTOMERCIF,IIG.AMOUNT,IIG.CURRENCY,IIG.TENURE,TRANS.SUBPRODUCTCODE,IIG.isPartInvocation,IIG.GuaranteePrevInvoAmt,IIG.reqinvoamt FROM TFBO_TRANS TRANS,TFBO_IGT_CLAIM IIG WHERE TRANS.REQUESTID=IIG.REQUESTID AND TRIM(TRANS.REQUESTID)=?";
		logger.info("query >>-->" + query);
		try {
			importGTVO = new TFBOImportGTVO();
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);
			aPreparedStatement.setString(1, requestId.trim());
			aResultset = aPreparedStatement.executeQuery();
			while (aResultset.next()) {
				importGTVO.setTiReferenceNo(aResultset.getString(1));
				importGTVO.setSolID(aResultset.getString(2));
				importGTVO.setCustomeCif(aResultset.getString(3));
				importGTVO.setAmount(aResultset.getString(4));
				importGTVO.setCurrency(aResultset.getString(5));
				importGTVO.setTenure(aResultset.getString(6));
				importGTVO.setSubProductCode(aResultset.getString(7));
				if (aResultset.getString(8).equals("Y"))
					importGTVO.setPartInvocation("true");
				else
					importGTVO.setPartInvocation("false");
				importGTVO.setGuarnteeAmtPrevInv(aResultset.getString(9));
				importGTVO.setReqInvAmt(aResultset.getString(10));
				importGTVOList.add(importGTVO);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, null);
		}
		return importGTVOList;
	}

	/* changes for rate taken starts 010120 */
	public List<TFBOImportGTVO> getTFBOGTOIGFromDB(String requestId,
			String query) throws Exception {

		Connection aConnection = null;
		PreparedStatement aPreparedStatement = null;
		ResultSet aResultset = null;
		List<TFBOImportGTVO> importGTVOList = new LinkedList<TFBOImportGTVO>();
		TFBOImportGTVO importGTVO = null;
		logger.info("query >>-->" + query);
		try {
			importGTVO = new TFBOImportGTVO();
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);
			aPreparedStatement.setString(1, requestId.trim());
			aResultset = aPreparedStatement.executeQuery();
			while (aResultset.next()) {
				importGTVO.setTiReferenceNo(aResultset.getString(1));
				importGTVO.setSolID(aResultset.getString(2));
				importGTVO.setCustomeCif(aResultset.getString(3));
				importGTVO.setAmount(aResultset.getString(4));
				importGTVO.setCurrency(aResultset.getString(5));
				importGTVO.setTenure(aResultset.getString(6));
				importGTVO.setSubProductCode(aResultset.getString(7));
				if (aResultset.getString(8).trim().equals("Y"))
					importGTVO.setPartInvocation("true");
				else
					importGTVO.setPartInvocation("false");
				importGTVO.setGuarnteeAmtPrevInv(aResultset.getString(9));
				importGTVO.setReqInvAmt(aResultset.getString(10));
				if (aResultset.getString(11).trim().equals("Y"))
					importGTVO.setRateTaken("true");
				else
					importGTVO.setRateTaken("false");
				/*
				 * if (aResultset.getString(12).equals("Y"))
				 * importGTVO.setValueK("true"); else
				 * importGTVO.setValueK("false");
				 */
				importGTVO.setValueK(aResultset.getString(12));
				importGTVO.setToken(aResultset.getString(13));
				importGTVO.setRate(aResultset.getString(14));
				importGTVO.setBillreference(aResultset.getString(15));
				importGTVOList.add(importGTVO);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, null);
		}
		return importGTVOList;
	}

	/* changes for rate taken ends 010120 */
	public List<TFBOExportLcVO> getTFBOExportLCPODAFromDB(String requestId,
			String query) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD + " requestId->"
				+ requestId);
		TFBOExportLcVO aTFBOEPODAVO = null;
		Connection aConnection = null;
		ResultSet aResultSet = null;
		PreparedStatement aPreparedStatement = null;
		List<TFBOExportLcVO> elcAmend = new LinkedList<TFBOExportLcVO>();
		try {
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);
			logger.info("query-->" + query);
			aPreparedStatement.setString(1, requestId.trim());
			aResultSet = aPreparedStatement.executeQuery();
			while (aResultSet.next()) {
				aTFBOEPODAVO = new TFBOExportLcVO();
				aTFBOEPODAVO.setTiReferenceNo(aResultSet.getString(1));
				aTFBOEPODAVO.setSolID(aResultSet.getString(2));
				aTFBOEPODAVO.setCustomeCif(aResultSet.getString(3));
				aTFBOEPODAVO.setAcceptanceAmount(aResultSet.getString(4));
				aTFBOEPODAVO.setCurrency(aResultSet.getString(5));
				aTFBOEPODAVO.setLcType(aResultSet.getString(6));
				aTFBOEPODAVO.setBillReference(aResultSet.getString(7));
				aTFBOEPODAVO.setSubProductCode(aResultSet.getString(8));
				aTFBOEPODAVO.setSenderRefno(aResultSet.getString(9));
				elcAmend.add(aTFBOEPODAVO);
			}
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}
		logger.info(ActionConstants.EXITING_METHOD + "  " + elcAmend.size());
		return elcAmend;

	}

	public List<TFBOExportLcVO> getTFBOExportLCPODPFromDB(String requestId,
			String query) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD + " requestId->"
				+ requestId);
		TFBOExportLcVO aTFBOEPODAVO = null;
		Connection aConnection = null;
		ResultSet aResultSet = null;
		PreparedStatement aPreparedStatement = null;
		List<TFBOExportLcVO> elcAmend = new LinkedList<TFBOExportLcVO>();
		CommonMethods aCommonMethods = new CommonMethods();
		try {
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);
			logger.info("query-->" + query);
			aPreparedStatement.setString(1, requestId.trim());
			aResultSet = aPreparedStatement.executeQuery();
			while (aResultSet.next()) {
				aTFBOEPODAVO = new TFBOExportLcVO();
				aTFBOEPODAVO.setTiReferenceNo(aResultSet.getString(1));
				aTFBOEPODAVO.setSolID(aResultSet.getString(2));
				aTFBOEPODAVO.setCustomeCif(aResultSet.getString(3));
				aTFBOEPODAVO.setAcceptanceAmount(aResultSet.getString(4));
				aTFBOEPODAVO.setCurrency(aResultSet.getString(5));
				aTFBOEPODAVO.setLcType(aResultSet.getString(6));
				aTFBOEPODAVO.setBillReference(aResultSet.getString(7));
				aTFBOEPODAVO.setSubProductCode(aResultSet.getString(8));

				if (aCommonMethods.isValueAvailable(aResultSet.getString(10))) {
					if (aResultSet.getString(10).trim().equals("Y")) {
						aTFBOEPODAVO.setRateTaken("true");
					} else {
						aTFBOEPODAVO.setRateTaken("false");
					}
				}
				aTFBOEPODAVO.setToken(aResultSet.getString(11));
				aTFBOEPODAVO.setValueK(aResultSet.getString(12));
				aTFBOEPODAVO.setRate(aResultSet.getString(13));
				aTFBOEPODAVO.setSenderRefno(aResultSet.getString(14));
				elcAmend.add(aTFBOEPODAVO);
			}
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}
		logger.info(ActionConstants.EXITING_METHOD + "  " + elcAmend.size());
		return elcAmend;

	}

	// changes for ELC and IGT Ends here
	// Rate taken Fix Offshore Team 30122019 starts

	public void setValueRateTakenLCInDB(String rateTaken, String rate,
			String token, String valueK, String requestId, String query) {
		Connection aConnection = null;
		ResultSet aResultSet = null;
		PreparedStatement aPreparedStatement = null;
		try {
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);
			aPreparedStatement.setString(1, rateTaken);
			aPreparedStatement.setString(2, token);
			aPreparedStatement.setString(3, valueK);
			aPreparedStatement.setString(4, rate);
			aPreparedStatement.setString(5, requestId);
			aPreparedStatement.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}

	}

	public void setValueRateTakenODCInDB(String rateTaken, String rate,
			String token, String valueK, String requestId, String sendref,
			String query) {
		Connection aConnection = null;
		ResultSet aResultSet = null;
		PreparedStatement aPreparedStatement = null;
		try {
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);
			aPreparedStatement.setString(1, rateTaken);
			aPreparedStatement.setString(2, token);
			aPreparedStatement.setString(3, valueK);
			aPreparedStatement.setString(4, rate);
			aPreparedStatement.setString(5, sendref);
			aPreparedStatement.setString(6, requestId);
			aPreparedStatement.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}

	}

	public void setValueRateTakenELCInDB(String requestId, String sendref,
			String query) {
		Connection aConnection = null;
		ResultSet aResultSet = null;
		PreparedStatement aPreparedStatement = null;
		try {
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);

			aPreparedStatement.setString(1, sendref);
			aPreparedStatement.setString(2, requestId.trim());
			aPreparedStatement.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}

	}

	// Rate taken Fix Offshore Team 30122019 ends
	// code changes for checklist by pandi starts 06012020
	public void insertTFBOTransChecklist_pocp(String requestId,
			String productCode, String eventCode, String subProductCode,
			String team, String lcType, String query) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD + "setValueInDB");
		Connection aConnection = null;
		ResultSet aResultSet = null;
		CallableStatement aCallableStatement = null;
		try {
			aConnection = DBUtility.getZoneConnection();
			aCallableStatement = aConnection.prepareCall(query);
			logger.info("query-->" + query);
			aCallableStatement.setString(1, requestId);
			aCallableStatement.setString(2, productCode);
			aCallableStatement.setString(3, eventCode);
			aCallableStatement.setString(4, subProductCode);
			aCallableStatement.setString(5, team);
			aCallableStatement.setString(6, lcType);
			aCallableStatement.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			DBUtility.surrenderDB(aConnection, aCallableStatement, aResultSet);
		}
		logger.info(ActionConstants.EXITING_METHOD + "setValueInDB");
	}

	// code changes for checklist by pandi ends 06012020

	// pandi starts here 07012020
	// public List<TFBOTransVO> getTransactionListFromDB_CPCI(String requestId,
	// String productCode, String eventCode, String step,
	// String stepStatus, String isTiTransFlag, String fromDate,
	// String toDate, String query) throws Exception {
	// logger.info(ActionConstants.ENTERING_METHOD + " requestId->"
	// + requestId);
	// TFBOTransVO aTFBOTransVO = null;
	// Connection aConnection = null;
	// ResultSet aResultSet = null;
	// PreparedStatement aPreparedStatement = null;
	// List<TFBOTransVO> transactionList = new LinkedList<TFBOTransVO>();
	// try {
	// aConnection = DBUtility.getZoneConnection();
	// aPreparedStatement = aConnection.prepareStatement(query);
	// logger.info("query-->" + query);
	// if (isTiTransFlag.equalsIgnoreCase("N")) {
	//
	// aPreparedStatement.setString(1, "%" + requestId + "%");
	// aPreparedStatement.setString(2, "%" + productCode + "%");
	// aPreparedStatement.setString(3, "%" + eventCode + "%");
	// aPreparedStatement.setString(4, "%" + step + "%");
	// aPreparedStatement.setString(5, "%" + stepStatus + "%");
	// aPreparedStatement.setString(6, fromDate);
	// aPreparedStatement.setString(7, toDate);
	// }
	// // Offshore team Changes 04012020 starts
	// /*
	// * if (isTiTransFlag.equalsIgnoreCase("Y")) {
	// * aPreparedStatement.setString(1, productCode.trim());
	// * aPreparedStatement.setString(2, stepStatus.trim());
	// * aPreparedStatement.setString(3, step.trim()); }
	// */
	// if (isTiTransFlag.equalsIgnoreCase("Y")) {
	// aPreparedStatement.setString(1, "%" + requestId + "%");
	// aPreparedStatement.setString(2, productCode.trim());
	// aPreparedStatement.setString(3, eventCode.trim());
	// aPreparedStatement.setString(4, step.trim());
	// aPreparedStatement.setString(5, stepStatus.trim());
	// aPreparedStatement.setString(6, fromDate);
	// aPreparedStatement.setString(7, toDate);
	//
	// }
	// // Offshore team Changes 04012020 ends
	//
	// aResultSet = aPreparedStatement.executeQuery();
	// while (aResultSet.next()) {
	// aTFBOTransVO = new TFBOTransVO();
	// aTFBOTransVO.setRequestId(aResultSet.getString(1));
	// aTFBOTransVO.setTiReferenceNo(aResultSet.getString(2));
	// aTFBOTransVO.setProductCode(aResultSet.getString(3));
	// aTFBOTransVO.setEventCode(aResultSet.getString(4));
	// aTFBOTransVO.setSubProductCode(aResultSet.getString(5));
	// aTFBOTransVO.setProductCodeDescription(aResultSet.getString(6));
	// aTFBOTransVO.setEventCodeDescription(aResultSet.getString(7));
	// aTFBOTransVO.setStep(aResultSet.getString(8));
	// aTFBOTransVO.setStepStatus(aResultSet.getString(9));
	// aTFBOTransVO.setTransCreatedDate(aResultSet.getString(10));
	// aTFBOTransVO.setTransModifiedDate(aResultSet.getString(11));
	//
	// transactionList.add(aTFBOTransVO);
	// }
	// } catch (Exception e) {
	// e.printStackTrace();
	// throw e;
	// } finally {
	// DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
	// }
	// logger.info(ActionConstants.EXITING_METHOD + "  "
	// + transactionList.size());
	// return transactionList;
	// }

	// pandi ends here 07012020
	// Rate taken Fix Offshore Team 06012020 starts
	public List<TFBOExportCollectionVO> getTFBOIODCCREFromDB(String requestId,
			String query) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD + " requestId->"
				+ requestId);
		TFBOExportCollectionVO aTFBOExportCollectionVO = null;
		Connection aConnection = null;
		ResultSet aResultSet = null;
		PreparedStatement aPreparedStatement = null;
		List<TFBOExportCollectionVO> odcCreate = new LinkedList<TFBOExportCollectionVO>();
		try {
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);
			logger.info("query-->" + query);

			aPreparedStatement.setString(1, requestId.trim());
			aResultSet = aPreparedStatement.executeQuery();
			while (aResultSet.next()) {
				aTFBOExportCollectionVO = new TFBOExportCollectionVO();
				aTFBOExportCollectionVO.setTiReferenceNo(aResultSet
						.getString(1));
				aTFBOExportCollectionVO.setSolID(aResultSet.getString(2));
				aTFBOExportCollectionVO.setCustomeCif(aResultSet.getString(3));
				aTFBOExportCollectionVO.setAmount(aResultSet.getString(4));
				aTFBOExportCollectionVO.setCurrency(aResultSet.getString(5));
				aTFBOExportCollectionVO
						.setUsancePeriod(aResultSet.getString(6));
				aTFBOExportCollectionVO.setDirect(aResultSet.getString(7));
				aTFBOExportCollectionVO.setMtReceived(aResultSet.getString(8));
				aTFBOExportCollectionVO.setPartPayment(aResultSet.getString(9));
				aTFBOExportCollectionVO.setSubProductCode(aResultSet
						.getString(10));
				aTFBOExportCollectionVO.setPreshipAccSettled(aResultSet
						.getString(11));
				aTFBOExportCollectionVO.setDocumentDispatch(aResultSet
						.getString(12));
				aTFBOExportCollectionVO.setFinanceSameDay(aResultSet
						.getString(13));
				// aTFBOExportCollectionVO.setRateTaken(aResultSet.getString(14));

				// ADDED BY CHANDRU
				if (aResultSet.getString(14) != null
						&& !aResultSet.getString(14).trim().equals("")) {
					if (aResultSet.getString(14).equalsIgnoreCase("Y")) {
						aTFBOExportCollectionVO.setRateTaken("true");
					} else {
						aTFBOExportCollectionVO.setRateTaken("false");
					}
				}
				// ENDS

				aTFBOExportCollectionVO.setShipBillFetch(aResultSet
						.getString(15));

				aTFBOExportCollectionVO.setToken(aResultSet.getString(16));
				aTFBOExportCollectionVO.setRateTakenK(aResultSet.getString(17));
				aTFBOExportCollectionVO.setRate(aResultSet.getString(18));
				aTFBOExportCollectionVO.setIrexRefNo(aResultSet.getString(19));
				aTFBOExportCollectionVO.setFinAmount(aResultSet.getString(20));
				aTFBOExportCollectionVO.setFinCurrency(aResultSet.getString(21));
				// aTFBOExportCollectionVO.setCustomeName(aResultSet.getString(20));

				System.out.println(aTFBOExportCollectionVO.getTiReferenceNo());
				System.out.println(aTFBOExportCollectionVO.getSolID());
				System.out.println(aTFBOExportCollectionVO.getCustomeCif());
				System.out.println(aTFBOExportCollectionVO.getAmount());
				System.out.println(aTFBOExportCollectionVO.getCurrency());
				System.out.println(aTFBOExportCollectionVO.getUsancePeriod());
				System.out.println(aTFBOExportCollectionVO.getDirect());
				System.out.println(aTFBOExportCollectionVO.getMtReceived());
				System.out.println(aTFBOExportCollectionVO.getPartPayment());
				System.out.println(aTFBOExportCollectionVO.getSubProductCode());
				System.out.println(aTFBOExportCollectionVO
						.getPreshipAccSettled());
				System.out.println(aTFBOExportCollectionVO
						.getDocumentDispatch());
				System.out.println(aTFBOExportCollectionVO.getFinanceSameDay());
				System.out.println(aTFBOExportCollectionVO.getRateTaken());
				System.out.println(aTFBOExportCollectionVO.getShipBillFetch());
				System.out.println(aTFBOExportCollectionVO.getToken());
				System.out.println(aTFBOExportCollectionVO.getRateTakenK());
				System.out.println(aTFBOExportCollectionVO.getRate());
				System.out.println(aTFBOExportCollectionVO.getIrexRefNo());

				odcCreate.add(aTFBOExportCollectionVO);
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}
		logger.info(ActionConstants.EXITING_METHOD + "  " + odcCreate.size());
		return odcCreate;
	}

	// Rate taken Fix Offshore Team 06012020 ends

	public String getAcceptanceAmount(UserTransactionVO userVo)
			throws Exception {
		String billReference = userVo.getBillReference();
		String tiReference = userVo.getTiReferanceNo();
		logger.info("Enterring >>-->" + ActionConstants.ENTERING_METHOD);
		Connection aConnection = null;
		ResultSet aResultSet = null;
		PreparedStatement aPreparedStatement = null;
		String acceptanceAmount = "";
		logger.info("devolvementAmount >>-->" + acceptanceAmount);
		String query = "SELECT "
				+ schemaName
				+ "THEME_GENIUS_PKG.CONVAMT(BEV.CCY,bev.amount) AS amount FROM "
				+ schemaName
				+ "master  mas,"
				+ schemaName
				+ "baseevent   bev  WHERE mas.key97 = bev.master_key AND mas.master_ref = '"
				+ tiReference.trim()
				+ "' and BEV.REFNO_PFIX||LPAD(BEV.REFNO_SERL,3,0)='"
				+ billReference.trim() + "'";
		logger.info("query >>-->" + query);
		try {
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);
			aResultSet = aPreparedStatement.executeQuery();
			while (aResultSet.next()) {
				acceptanceAmount = aResultSet.getString(1);
				logger.info("devolvementAmount >>-->" + acceptanceAmount);
			}

		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}
		return acceptanceAmount;

	}

	// CHANGES FOR ODC CAC 08012020 NY SAI STARTS HERE
	public List<TFBOExportCollectionVO> getTFBOIODCCACFromDB(String requestId,
			String query) throws Exception {
		System.out.println("ENTERING INTO getTFBOIODCCACFromDB");
		logger.info(ActionConstants.ENTERING_METHOD + " requestId->"
				+ requestId);
		TFBOExportCollectionVO aTFBOExportCollectionVO = null;
		Connection aConnection = null;
		ResultSet aResultSet = null;
		PreparedStatement aPreparedStatement = null;
		List<TFBOExportCollectionVO> odcCac = new LinkedList<TFBOExportCollectionVO>();
		try {
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);
			logger.info("query-->" + query);
			logger.info("query-->" + query);
			aPreparedStatement.setString(1, requestId.trim());
			aResultSet = aPreparedStatement.executeQuery();
			while (aResultSet.next()) {
				aTFBOExportCollectionVO = new TFBOExportCollectionVO();
				aTFBOExportCollectionVO.setTiReferenceNo(aResultSet
						.getString(1));
				aTFBOExportCollectionVO.setSolID(aResultSet.getString(2));
				aTFBOExportCollectionVO.setCustomeCif(aResultSet.getString(3));
				aTFBOExportCollectionVO.setCurrency(aResultSet.getString(4));
				aTFBOExportCollectionVO.setAcceptBillAmt(aResultSet
						.getString(5));
				aTFBOExportCollectionVO
						.setUsancePeriod(aResultSet.getString(6));
				aTFBOExportCollectionVO.setSubProductCode(aResultSet
						.getString(7));
				odcCac.add(aTFBOExportCollectionVO);
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}
		System.out.println("ENTERING INTO getTFBOIODCCACFromDB");
		System.out.println(ActionConstants.EXITING_METHOD + "  "
				+ odcCac.size());
		return odcCac;
	}

	public void setValueODCACCEPTInDB(String value1, String value2,
			String value3, String value4, String value5, String value6,
			String value7, String value8, String query) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD + "setValueInDB");
		Connection aConnection = null;
		ResultSet aResultSet = null;
		PreparedStatement aPreparedStatement = null;
		try {
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);
			logger.info("query-->" + query);
			aPreparedStatement.setString(1, value1);
			aPreparedStatement.setString(2, value2);
			aPreparedStatement.setString(3, value3);
			aPreparedStatement.setString(4, value4);
			aPreparedStatement.setString(5, value5);
			aPreparedStatement.setString(6, value6);
			aPreparedStatement.setString(7, value7);
			aPreparedStatement.setString(8, value8.trim());
			aPreparedStatement.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}
		logger.info(ActionConstants.EXITING_METHOD + "setValueInDB");
	}

	// CHANGES FOR ODC CAC 08012020 NY SAI ENDS HERE
	// CHANGES BY CHANDRU 10012020 STARTS
	// public List<TFBOTransVO> getTransactionListFromDBFilter(String query)
	// throws Exception {
	//
	// TFBOTransVO aTFBOTransVO = null;
	// Connection aConnection = null;
	// ResultSet aResultSet = null;
	// PreparedStatement aPreparedStatement = null;
	// List<TFBOTransVO> transactionList = new LinkedList<TFBOTransVO>();
	// try {
	// aConnection = DBUtility.getZoneConnection();
	// aPreparedStatement = aConnection.prepareStatement(query);
	// logger.info("query-->" + query);
	// aResultSet = aPreparedStatement.executeQuery();
	// while (aResultSet.next()) {
	// aTFBOTransVO = new TFBOTransVO();
	// aTFBOTransVO.setRequestId(aResultSet.getString(1));
	// aTFBOTransVO.setTiReferenceNo(aResultSet.getString(2));
	// aTFBOTransVO.setProductCode(aResultSet.getString(3));
	// aTFBOTransVO.setEventCode(aResultSet.getString(4));
	// aTFBOTransVO.setProductCodeDescription(aResultSet.getString(5));
	// aTFBOTransVO.setEventCodeDescription(aResultSet.getString(6));
	// aTFBOTransVO.setSubProductCode(aResultSet.getString(7));
	// aTFBOTransVO.setStep(aResultSet.getString(8));
	// aTFBOTransVO.setStepStatus(aResultSet.getString(9));
	// aTFBOTransVO.setTransCreatedDate(aResultSet.getString(10));
	// aTFBOTransVO.setTransModifiedDate(aResultSet.getString(11));
	// transactionList.add(aTFBOTransVO);
	// }
	//
	// } catch (Exception e) {
	// e.printStackTrace();
	// throw e;
	// } finally {
	// DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
	// }
	// logger.info(ActionConstants.EXITING_METHOD + "  "
	// + transactionList.size());
	// return transactionList;
	// }

	// CHANGES BY CHANDRU 10012020 ENDS

	/* Dashboard changes 23012020 starts */

	public List<TFBOTransVO> getTransactionListFromDBFilter(String query)
			throws Exception {

		TFBOTransVO aTFBOTransVO = null;
		Connection aConnection = null;
		ResultSet aResultSet = null;
		PreparedStatement aPreparedStatement = null;
		List<TFBOTransVO> transactionList = new LinkedList<TFBOTransVO>();

		/* Dashboard changes 23012020 starts */
		CommonMethods aCommonMethods = new CommonMethods();
		/* Dashboard changes 23012020 ends */

		try {
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);
			logger.info("query-->" + query);
			aResultSet = aPreparedStatement.executeQuery();
			while (aResultSet.next()) {
				aTFBOTransVO = new TFBOTransVO();
				aTFBOTransVO.setRequestId(aResultSet.getString(1));
				aTFBOTransVO.setTiReferenceNo(aResultSet.getString(2));
				aTFBOTransVO.setProductCode(aResultSet.getString(3));
				aTFBOTransVO.setEventCode(aResultSet.getString(4));
				aTFBOTransVO.setProductCodeDescription(aResultSet.getString(5));
				aTFBOTransVO.setEventCodeDescription(aResultSet.getString(6));
				aTFBOTransVO.setSubProductCode(aResultSet.getString(7));

				/* Dashboard changes 23012020 starts */
				aTFBOTransVO.setSolIdGrid(aResultSet.getString(8));
				aTFBOTransVO.setCustomerCifGrid(aResultSet.getString(9));
				aTFBOTransVO.setCustomerNameGrid(aResultSet.getString(10));
				aTFBOTransVO.setLastModifiedUserGrid(aResultSet.getString(11));

				if (aCommonMethods.isValueAvailable(aResultSet.getString(12))) {

					if (aResultSet.getString(12).equalsIgnoreCase("true")) {
						aTFBOTransVO.setDirectGrid("Yes");
					}

					if (aResultSet.getString(12).equalsIgnoreCase("false")) {
						aTFBOTransVO.setDirectGrid("No");
					}
				}
				aTFBOTransVO.setFinanceSameDayGrid(aResultSet.getString(13));
				/* Dashboard changes 23012020 ends */

				/* Dashboard changes 23012020 starts */
				/*
				 * aTFBOTransVO.setStep(aResultSet.getString(8));
				 * aTFBOTransVO.setStepStatus(aResultSet.getString(9));
				 * aTFBOTransVO.setTransCreatedDate(aResultSet.getString(10));
				 * aTFBOTransVO.setTransModifiedDate(aResultSet.getString(11));
				 */

				aTFBOTransVO.setStep(aResultSet.getString(14));
				aTFBOTransVO.setStepStatus(aResultSet.getString(15));
				aTFBOTransVO.setTransCreatedDate(aResultSet.getString(16));
				aTFBOTransVO.setTransModifiedDate(aResultSet.getString(17));
				aTFBOTransVO.setAmount(aResultSet.getString(18));//muthu
				aTFBOTransVO.setCurrency(aResultSet.getString(19));//muthu
				aTFBOTransVO.setNoAmend(aResultSet.getString(20));//pandi
				aTFBOTransVO.setBranchAlpha(aResultSet.getString(21));//pandi
				aTFBOTransVO.setRateTaken(aResultSet.getString(22));
              
				/* Dashboard changes 23012020 ends */

				transactionList.add(aTFBOTransVO);
			}

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}
		logger.info(ActionConstants.EXITING_METHOD + "  "
				+ transactionList.size());
		return transactionList;
	}

	public List<TFBOTransVO> getTransactionListFromDBFilterForIDCDirect(
			String query) throws Exception {

		TFBOTransVO aTFBOTransVO = null;
		Connection aConnection = null;
		ResultSet aResultSet = null;
		PreparedStatement aPreparedStatement = null;
		List<TFBOTransVO> transactionList = new LinkedList<TFBOTransVO>();
		try {
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);
			logger.info("query-->" + query);
			aResultSet = aPreparedStatement.executeQuery();
			while (aResultSet.next()) {
				aTFBOTransVO = new TFBOTransVO();
				aTFBOTransVO.setRequestId(aResultSet.getString(1));
				aTFBOTransVO.setTiReferenceNo(aResultSet.getString(2));
				aTFBOTransVO.setProductCode(aResultSet.getString(3));
				aTFBOTransVO.setEventCode(aResultSet.getString(4));
				aTFBOTransVO.setProductCodeDescription(aResultSet.getString(5));
				aTFBOTransVO.setEventCodeDescription(aResultSet.getString(6));
				aTFBOTransVO.setSubProductCode(aResultSet.getString(7));
				aTFBOTransVO.setStep(aResultSet.getString(8));
				aTFBOTransVO.setStepStatus(aResultSet.getString(9));
				aTFBOTransVO.setTransCreatedDate(aResultSet.getString(10));
				aTFBOTransVO.setTransModifiedDate(aResultSet.getString(11));
				transactionList.add(aTFBOTransVO);
			}

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}
		logger.info(ActionConstants.EXITING_METHOD + "  "
				+ transactionList.size());
		return transactionList;
	}

	/* Dashboard changes 23012020 ends */
	// karthik 13012020 starts

	public List<TFBOFinanceExportLcVO> getTFBOFELPSA4DetailsFromDB(
			String requestId, String query) throws Exception {

		TFBOFinanceExportLcVO aTFBOFinanceExportLcVO = null;
		Connection aConnection = null;
		ResultSet aResultSet = null;
		PreparedStatement aPreparedStatement = null;
		List<TFBOFinanceExportLcVO> felPsa4 = new LinkedList<TFBOFinanceExportLcVO>();
		try {
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);
			logger.info("query-->" + query);
			aPreparedStatement.setString(1, requestId.trim());
			aResultSet = aPreparedStatement.executeQuery();
			while (aResultSet.next()) {
				aTFBOFinanceExportLcVO = new TFBOFinanceExportLcVO();
				aTFBOFinanceExportLcVO.setLCRefNum(aResultSet.getString(1));
				aTFBOFinanceExportLcVO.setSolID(aResultSet.getString(2));
				aTFBOFinanceExportLcVO.setCustomeCif(aResultSet.getString(3));
				aTFBOFinanceExportLcVO.setCustomeName(aResultSet.getString(4));
				aTFBOFinanceExportLcVO.setAmount(aResultSet.getString(5));
				aTFBOFinanceExportLcVO.setCurrency(aResultSet.getString(6));
				aTFBOFinanceExportLcVO.setSubProductCode(aResultSet
						.getString(7));
				aTFBOFinanceExportLcVO.setUserRemark(aResultSet.getString(8));

				felPsa4.add(aTFBOFinanceExportLcVO);
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}
		logger.info(ActionConstants.EXITING_METHOD + "  " + felPsa4.size());
		return felPsa4;
	}

	public List<TFBOIdcVO> getTFBOImportIDCCCODetailsFromDB(String requestId,
			String query) throws Exception {

		logger.info(ActionConstants.ENTERING_METHOD + " requestId->");
		TFBOIdcVO aTFBOIdcVO = null;
		Connection aConnection = null;
		ResultSet aResultSet = null;
		PreparedStatement aPreparedStatement = null;
		List<TFBOIdcVO> idcCcolist = new LinkedList<TFBOIdcVO>();

		try {
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);
			logger.info("query-->" + query);
			aPreparedStatement.setString(1, requestId.trim());
			aResultSet = aPreparedStatement.executeQuery();
			while (aResultSet.next()) {
				aTFBOIdcVO = new TFBOIdcVO();
				aTFBOIdcVO.setTiReferanceNo(aResultSet.getString(1));
				aTFBOIdcVO.setSolID(aResultSet.getString(2));
				aTFBOIdcVO.setCustomeCif(aResultSet.getString(3));
				aTFBOIdcVO.setCustomeName(aResultSet.getString(4));
				aTFBOIdcVO.setAmount(aResultSet.getString(5));
				aTFBOIdcVO.setCurrency(aResultSet.getString(6));
				aTFBOIdcVO.setSubProductCode(aResultSet.getString(7));
				aTFBOIdcVO.setUserRemark(aResultSet.getString(8));
				idcCcolist.add(aTFBOIdcVO);
				System.out.println("-----Remark cmd----"
						+ aTFBOIdcVO.getUserRemark());
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}
		logger.info(ActionConstants.EXITING_METHOD + "  " + idcCcolist.size());
		return idcCcolist;
	}

	public List<TFBOFinanceExportColVO> getTFBOFOCPSA1FromDB(String requestId,
			String query) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD + " requestId->"
				+ requestId);
		TFBOFinanceExportColVO aTFBOFinanceExportColVO = null;
		Connection aConnection = null;
		ResultSet aResultSet = null;
		PreparedStatement aPreparedStatement = null;
		List<TFBOFinanceExportColVO> focList = new LinkedList<TFBOFinanceExportColVO>();
		try {
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);
			logger.info("query-->" + query);
			logger.info("query-->" + query);
			aPreparedStatement.setString(1, requestId.trim());
			aResultSet = aPreparedStatement.executeQuery();
			while (aResultSet.next()) {
				aTFBOFinanceExportColVO = new TFBOFinanceExportColVO();
				aTFBOFinanceExportColVO.setTiReferenceNo(aResultSet
						.getString(1));
				aTFBOFinanceExportColVO.setSolID(aResultSet.getString(2));
				aTFBOFinanceExportColVO.setCustomeCif(aResultSet.getString(3));
				aTFBOFinanceExportColVO.setCustomeName(aResultSet.getString(4));
				aTFBOFinanceExportColVO.setAmount(aResultSet.getString(5));
				aTFBOFinanceExportColVO.setCurrency(aResultSet.getString(6));
				aTFBOFinanceExportColVO.setSubProductCode(aResultSet
						.getString(7));
				aTFBOFinanceExportColVO.setUserRemark(aResultSet.getString(8));
				focList.add(aTFBOFinanceExportColVO);
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}
		logger.info(ActionConstants.EXITING_METHOD + "  " + focList.size());
		return focList;
	}

	public List<TFBOExportCollectionVO> getTFBOIODCCCOFromDB(String requestId,
			String query) throws Exception {

		logger.info(ActionConstants.ENTERING_METHOD + " requestId->"
				+ requestId);
		TFBOExportCollectionVO aTFBOExportCollectionVO = null;
		Connection aConnection = null;
		ResultSet aResultSet = null;
		PreparedStatement aPreparedStatement = null;
		List<TFBOExportCollectionVO> odcCcolist = new LinkedList<TFBOExportCollectionVO>();
		try {
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);
			logger.info("query-->" + query);
			aPreparedStatement.setString(1, requestId.trim());
			aResultSet = aPreparedStatement.executeQuery();
			while (aResultSet.next()) {
				aTFBOExportCollectionVO = new TFBOExportCollectionVO();
				aTFBOExportCollectionVO.setTiReferenceNo(aResultSet
						.getString(1));
				aTFBOExportCollectionVO.setSolID(aResultSet.getString(2));
				aTFBOExportCollectionVO.setCustomeCif(aResultSet.getString(3));
				aTFBOExportCollectionVO.setCustomeName(aResultSet.getString(4));
				aTFBOExportCollectionVO.setAmount(aResultSet.getString(5));
				aTFBOExportCollectionVO.setCurrency(aResultSet.getString(6));
				aTFBOExportCollectionVO.setSubProductCode(aResultSet
						.getString(7));
				aTFBOExportCollectionVO.setUserRemark(aResultSet.getString(8));
				odcCcolist.add(aTFBOExportCollectionVO);
				System.out.println("-----Remark cmd----"
						+ aTFBOExportCollectionVO.getUserRemark());
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}
		logger.info(ActionConstants.EXITING_METHOD + "  " + odcCcolist.size());
		return odcCcolist;
	}

	/*
	 * public void setValueInLILCCOIDB(String solID, String customeCif, String
	 * customeName, String amount, String currency, String lcType, String
	 * userRemark, String requestId, String query) {
	 * logger.info(ActionConstants.ENTERING_METHOD + "setValueInDB"); Connection
	 * aConnection = null; ResultSet aResultSet = null; PreparedStatement
	 * aPreparedStatement = null; System.out.println("solID " + solID +
	 * "customeCif " + customeCif + "amount " + amount + " userRemark-----===="
	 * + userRemark); try { aConnection = DBUtility.getZoneConnection();
	 * aPreparedStatement = aConnection.prepareStatement(query);
	 * logger.info("query-->" + query); aPreparedStatement.setString(1, solID);
	 * aPreparedStatement.setString(2, customeCif);
	 * aPreparedStatement.setString(3, customeName);
	 * aPreparedStatement.setString(4, amount); aPreparedStatement.setString(5,
	 * currency); aPreparedStatement.setString(6, lcType);
	 * aPreparedStatement.setString(7, userRemark);
	 * aPreparedStatement.setString(8, requestId);
	 * aPreparedStatement.executeUpdate();
	 * System.out.println("solID------------ " + solID + "customeCif " +
	 * customeCif + "amount " + amount + " userRemark---------" + userRemark);
	 * 
	 * } catch (Exception e) { e.printStackTrace(); } finally {
	 * DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet); }
	 * logger.info(ActionConstants.EXITING_METHOD + "setValueInDB");
	 * 
	 * }
	 */

	public void setValueInLILCCOIDB(String solID, String customeCif,
			String customeName, String amount, String currency, String lcType,
			String userRemark, String requestId, String query) {
		logger.info(ActionConstants.ENTERING_METHOD + "setValueInDB");
		Connection aConnection = null;
		ResultSet aResultSet = null;
		PreparedStatement aPreparedStatement = null;
		System.out.println("solID " + solID + "customeCif " + customeCif
				+ "amount " + amount + " userRemark-----====" + userRemark);
		try {
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);
			logger.info("query-->" + query);
			aPreparedStatement.setString(1, solID);
			aPreparedStatement.setString(2, customeCif);
			aPreparedStatement.setString(3, customeName);
			aPreparedStatement.setString(4, amount);
			aPreparedStatement.setString(5, currency);
			aPreparedStatement.setString(6, lcType);
			aPreparedStatement.setString(7, userRemark);
			aPreparedStatement.setString(8, requestId);
			aPreparedStatement.executeUpdate();
			System.out.println("solID------------ " + solID + "customeCif "
					+ customeCif + "amount " + amount + " userRemark---------"
					+ userRemark);

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}
		logger.info(ActionConstants.EXITING_METHOD + "setValueInDB");

	}

	/*
	 * public List<TFBOImportLcVO> getTFBOIImportLCCOIFromDB(String requestId,
	 * String query, UserTransactionVO userVo) throws Exception {
	 * 
	 * logger.info(ActionConstants.ENTERING_METHOD + " requestId->" +
	 * requestId); TFBOImportLcVO aTFBOIlcIssueVO = null; Connection aConnection
	 * = null; ResultSet aResultSet = null; PreparedStatement aPreparedStatement
	 * = null; List<TFBOImportLcVO> ilcIssue = new LinkedList<TFBOImportLcVO>();
	 * try { aConnection = DBUtility.getZoneConnection(); aPreparedStatement =
	 * aConnection.prepareStatement(query); logger.info("query-->" + query);
	 * aPreparedStatement.setString(1, requestId.trim()); aResultSet =
	 * aPreparedStatement.executeQuery(); while (aResultSet.next()) {
	 * aTFBOIlcIssueVO = new TFBOImportLcVO();
	 * aTFBOIlcIssueVO.setTiReferenceNo(aResultSet.getString(1));
	 * aTFBOIlcIssueVO.setSolID(aResultSet.getString(2));
	 * aTFBOIlcIssueVO.setCustomeCif(aResultSet.getString(3));
	 * aTFBOIlcIssueVO.setAmount(aResultSet.getString(4));
	 * aTFBOIlcIssueVO.setCurrency(aResultSet.getString(5));
	 * aTFBOIlcIssueVO.setLcType(aResultSet.getString(6));
	 * aTFBOIlcIssueVO.setSubProductCode(aResultSet.getString(7));
	 * aTFBOIlcIssueVO.setUserRemark(aResultSet.getString(8));
	 * ilcIssue.add(aTFBOIlcIssueVO); System.out.println("-----Remark cmd----" +
	 * aTFBOIlcIssueVO.getUserRemark()); } } catch (Exception e) {
	 * e.printStackTrace(); throw e; } finally {
	 * DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet); }
	 * logger.info(ActionConstants.EXITING_METHOD + "  " + ilcIssue.size());
	 * return ilcIssue;
	 * 
	 * }
	 */
	public List<TFBOImportLcVO> getTFBOIImportLCCOIFromDB(String requestId,
			String query, UserTransactionVO userVo) throws Exception {

		logger.info(ActionConstants.ENTERING_METHOD + " requestId->"
				+ requestId);
		TFBOImportLcVO aTFBOIlcIssueVO = null;
		Connection aConnection = null;
		ResultSet aResultSet = null;
		PreparedStatement aPreparedStatement = null;
		List<TFBOImportLcVO> ilcIssue = new LinkedList<TFBOImportLcVO>();
		try {
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);
			logger.info("query-->" + query);
			aPreparedStatement.setString(1, requestId.trim());
			aResultSet = aPreparedStatement.executeQuery();
			while (aResultSet.next()) {
				aTFBOIlcIssueVO = new TFBOImportLcVO();
				aTFBOIlcIssueVO.setTiReferenceNo(aResultSet.getString(1));
				aTFBOIlcIssueVO.setSolID(aResultSet.getString(2));
				aTFBOIlcIssueVO.setCustomeCif(aResultSet.getString(3));
				aTFBOIlcIssueVO.setAmount(aResultSet.getString(4));
				aTFBOIlcIssueVO.setCurrency(aResultSet.getString(5));
				aTFBOIlcIssueVO.setLcType(aResultSet.getString(6));
				aTFBOIlcIssueVO.setSubProductCode(aResultSet.getString(7));
				aTFBOIlcIssueVO.setUserRemark(aResultSet.getString(8));
				ilcIssue.add(aTFBOIlcIssueVO);
				System.out.println("-----Remark cmd----"
						+ aTFBOIlcIssueVO.getUserRemark());
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}
		logger.info(ActionConstants.EXITING_METHOD + "  " + ilcIssue.size());
		return ilcIssue;

	}

	/*
	 * public List<TFBOExportLcVO> getTFBOExportLCCOEFromDB(String requestId,
	 * String query, UserTransactionVO userVo) throws Exception {
	 * logger.info(ActionConstants.ENTERING_METHOD + " requestId->" +
	 * requestId); TFBOExportLcVO aTFBOIecIssueVO = null; Connection aConnection
	 * = null; ResultSet aResultSet = null; PreparedStatement aPreparedStatement
	 * = null; List<TFBOExportLcVO> ilcIssue = new LinkedList<TFBOExportLcVO>();
	 * try { aConnection = DBUtility.getZoneConnection(); aPreparedStatement =
	 * aConnection.prepareStatement(query); logger.info("query-->" + query);
	 * aPreparedStatement.setString(1, requestId.trim()); aResultSet =
	 * aPreparedStatement.executeQuery(); while (aResultSet.next()) {
	 * aTFBOIecIssueVO = new TFBOExportLcVO();
	 * aTFBOIecIssueVO.setTiReferenceNo(aResultSet.getString(1));
	 * aTFBOIecIssueVO.setSolID(aResultSet.getString(2));
	 * aTFBOIecIssueVO.setCustomeCif(aResultSet.getString(3));
	 * aTFBOIecIssueVO.setAmount(aResultSet.getString(4));
	 * aTFBOIecIssueVO.setCurrency(aResultSet.getString(5));
	 * aTFBOIecIssueVO.setLcType(aResultSet.getString(6));
	 * aTFBOIecIssueVO.setSubProductCode(aResultSet.getString(7));
	 * aTFBOIecIssueVO.setUserRemark(aResultSet.getString(8));
	 * ilcIssue.add(aTFBOIecIssueVO); System.out.println("-----Remark cmd----" +
	 * aTFBOIecIssueVO.getUserRemark()); } } catch (Exception e) {
	 * e.printStackTrace(); throw e; } finally {
	 * DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet); }
	 * logger.info(ActionConstants.EXITING_METHOD + "  " + ilcIssue.size());
	 * return ilcIssue; }
	 */

	public List<TFBOExportLcVO> getTFBOExportLCCOEFromDB(String requestId,
			String query, UserTransactionVO userVo) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD + " requestId->"
				+ requestId);
		TFBOExportLcVO aTFBOIecIssueVO = null;
		Connection aConnection = null;
		ResultSet aResultSet = null;
		PreparedStatement aPreparedStatement = null;
		List<TFBOExportLcVO> ilcIssue = new LinkedList<TFBOExportLcVO>();
		try {
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);
			logger.info("query-->" + query);
			aPreparedStatement.setString(1, requestId.trim());
			aResultSet = aPreparedStatement.executeQuery();
			while (aResultSet.next()) {
				aTFBOIecIssueVO = new TFBOExportLcVO();
				aTFBOIecIssueVO.setTiReferenceNo(aResultSet.getString(1));
				aTFBOIecIssueVO.setSolID(aResultSet.getString(2));
				aTFBOIecIssueVO.setCustomeCif(aResultSet.getString(3));
				aTFBOIecIssueVO.setAmount(aResultSet.getString(4));
				aTFBOIecIssueVO.setCurrency(aResultSet.getString(5));
				aTFBOIecIssueVO.setLcType(aResultSet.getString(6));
				aTFBOIecIssueVO.setSubProductCode(aResultSet.getString(7));
				aTFBOIecIssueVO.setUserRemark(aResultSet.getString(8));
				ilcIssue.add(aTFBOIecIssueVO);
				System.out.println("-----Remark cmd----"
						+ aTFBOIecIssueVO.getUserRemark());
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}
		logger.info(ActionConstants.EXITING_METHOD + "  " + ilcIssue.size());
		return ilcIssue;
	}

	public List<TFBOExportLcVO> getTFBOExportLCCOETranDetailsFromDB(
			String requestId, String query) throws Exception {

		logger.info(ActionConstants.ENTERING_METHOD + " requestId->"
				+ requestId);
		TFBOExportLcVO aTFBOIelcCoeVO = null;
		Connection aConnection = null;
		ResultSet aResultSet = null;
		PreparedStatement aPreparedStatement = null;
		List<TFBOExportLcVO> elcCoe = new LinkedList<TFBOExportLcVO>();
		try {
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);
			logger.info("query-->" + query);
			aPreparedStatement.setString(1, requestId.trim());
			aResultSet = aPreparedStatement.executeQuery();
			while (aResultSet.next()) {
				aTFBOIelcCoeVO = new TFBOExportLcVO();
				aTFBOIelcCoeVO.setTiReferenceNo(aResultSet.getString(1));
				aTFBOIelcCoeVO.setSolID(aResultSet.getString(2));
				aTFBOIelcCoeVO.setCustomeCif(aResultSet.getString(3));
				aTFBOIelcCoeVO.setAmount(aResultSet.getString(4));
				aTFBOIelcCoeVO.setCurrency(aResultSet.getString(5));
				aTFBOIelcCoeVO.setLcType(aResultSet.getString(6));
				aTFBOIelcCoeVO.setUsancePeriod(aResultSet.getString(7));
				aTFBOIelcCoeVO.setSubProductCode(aResultSet.getString(8));
				elcCoe.add(aTFBOIelcCoeVO);
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}
		logger.info(ActionConstants.EXITING_METHOD + "  " + elcCoe.size());
		return elcCoe;
	}

	// karthik 13012020 starts
	/*
	 * public List<TFBOFinanceExportLcVO> getTFBOFELPSA4FromDB(String requestId,
	 * String query) throws Exception {
	 * 
	 * logger.info(ActionConstants.ENTERING_METHOD + " requestId->" +
	 * requestId); TFBOFinanceExportLcVO aTFBOFinanceExportLcVO = null;
	 * Connection aConnection = null; ResultSet aResultSet = null;
	 * PreparedStatement aPreparedStatement = null; List<TFBOFinanceExportLcVO>
	 * felPsa4 = new LinkedList<TFBOFinanceExportLcVO>(); try { aConnection =
	 * DBUtility.getZoneConnection(); aPreparedStatement =
	 * aConnection.prepareStatement(query); logger.info("query-->" + query);
	 * aPreparedStatement.setString(1, requestId.trim()); aResultSet =
	 * aPreparedStatement.executeQuery(); while (aResultSet.next()) {
	 * aTFBOFinanceExportLcVO = new TFBOFinanceExportLcVO();
	 * aTFBOFinanceExportLcVO.setRequestId(aResultSet.getString(1));
	 * aTFBOFinanceExportLcVO.setSolID(aResultSet.getString(2));
	 * aTFBOFinanceExportLcVO.setCustomeCif(aResultSet.getString(3));
	 * aTFBOFinanceExportLcVO.setAmount(aResultSet.getString(4));
	 * aTFBOFinanceExportLcVO.setCurrency(aResultSet.getString(5));
	 * aTFBOFinanceExportLcVO.setLcType(aResultSet.getString(6));
	 * aTFBOFinanceExportLcVO.setSenderRefNo(aResultSet.getString(7));
	 * aTFBOFinanceExportLcVO.setSubProductCode(aResultSet
	 * .getString(8).trim()); felPsa4.add(aTFBOFinanceExportLcVO); } } catch
	 * (Exception e) { e.printStackTrace(); throw e; } finally {
	 * DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet); }
	 * logger.info(ActionConstants.EXITING_METHOD + "  " + felPsa4.size());
	 * return felPsa4; }
	 */
	public List<TFBOFinanceExportLcVO> getTFBOFELPSA4FromDB(String requestId,
			String query) throws Exception {

		logger.info(ActionConstants.ENTERING_METHOD + " requestId->"
				+ requestId);
		TFBOFinanceExportLcVO aTFBOFinanceExportLcVO = null;
		Connection aConnection = null;
		ResultSet aResultSet = null;
		PreparedStatement aPreparedStatement = null;
		List<TFBOFinanceExportLcVO> felPsa4 = new LinkedList<TFBOFinanceExportLcVO>();
		try {
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);
			logger.info("query-->" + query);
			aPreparedStatement.setString(1, requestId.trim());
			aResultSet = aPreparedStatement.executeQuery();

			while (aResultSet.next()) {
				aTFBOFinanceExportLcVO = new TFBOFinanceExportLcVO();
				aTFBOFinanceExportLcVO.setLCRefNum(aResultSet.getString(1));
				aTFBOFinanceExportLcVO.setSolID(aResultSet.getString(2));
				aTFBOFinanceExportLcVO.setAmount(aResultSet.getString(3));
				aTFBOFinanceExportLcVO.setCurrency(aResultSet.getString(4));
				aTFBOFinanceExportLcVO.setCustomeCif(aResultSet.getString(5));
				aTFBOFinanceExportLcVO.setCustomeName(aResultSet.getString(6));
				aTFBOFinanceExportLcVO.setSubProductCode(aResultSet
						.getString(7));

				felPsa4.add(aTFBOFinanceExportLcVO);

			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}
		logger.info(ActionConstants.EXITING_METHOD + "  " + felPsa4.size());
		return felPsa4;
	}

	/*
	 * public List<TFBOExportCollectionVO> getTFBOODCCCOFRromDB(String
	 * requestId, String query) throws Exception {
	 * 
	 * System.out.println("ENTERING INTO getTFBOIODCCOCFromDB");
	 * logger.info(ActionConstants.ENTERING_METHOD + " requestId->" +
	 * requestId); TFBOExportCollectionVO aTFBOExportCollectionVO = null;
	 * Connection aConnection = null; ResultSet aResultSet = null;
	 * PreparedStatement aPreparedStatement = null; List<TFBOExportCollectionVO>
	 * odcCco = new LinkedList<TFBOExportCollectionVO>(); try { aConnection =
	 * DBUtility.getZoneConnection(); aPreparedStatement =
	 * aConnection.prepareStatement(query); logger.info("query-->" + query);
	 * logger.info("query-->" + query); aPreparedStatement.setString(1,
	 * requestId.trim()); aResultSet = aPreparedStatement.executeQuery(); while
	 * (aResultSet.next()) { aTFBOExportCollectionVO = new
	 * TFBOExportCollectionVO();
	 * aTFBOExportCollectionVO.setTiReferenceNo(aResultSet .getString(1));
	 * aTFBOExportCollectionVO.setSolID(aResultSet.getString(2));
	 * aTFBOExportCollectionVO.setCustomeCif(aResultSet.getString(3));
	 * aTFBOExportCollectionVO.setAmount(aResultSet.getString(4));
	 * aTFBOExportCollectionVO.setCurrency(aResultSet.getString(5));
	 * aTFBOExportCollectionVO.setSubProductCode(aResultSet .getString(6));
	 * 
	 * odcCco.add(aTFBOExportCollectionVO); } } catch (Exception e) {
	 * e.printStackTrace(); throw e; } finally {
	 * DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet); }
	 * System.out.println("ENTERING INTO getTFBOIODCCOCFromDB");
	 * System.out.println(ActionConstants.EXITING_METHOD + "  " +
	 * odcCco.size()); return odcCco; }
	 */
	public List<TFBOExportCollectionVO> getTFBOODCCCOFRromDB(String requestId,
			String query) throws Exception {

		System.out.println("ENTERING INTO getTFBOIODCCOCFromDB");
		logger.info(ActionConstants.ENTERING_METHOD + " requestId->"
				+ requestId);
		TFBOExportCollectionVO aTFBOExportCollectionVO = null;
		Connection aConnection = null;
		ResultSet aResultSet = null;
		PreparedStatement aPreparedStatement = null;
		List<TFBOExportCollectionVO> odcCco = new LinkedList<TFBOExportCollectionVO>();
		try {
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);
			logger.info("query-->" + query);
			logger.info("query-->" + query);
			aPreparedStatement.setString(1, requestId.trim());
			aResultSet = aPreparedStatement.executeQuery();
			while (aResultSet.next()) {
				aTFBOExportCollectionVO = new TFBOExportCollectionVO();
				aTFBOExportCollectionVO.setTiReferenceNo(aResultSet
						.getString(1));
				aTFBOExportCollectionVO.setSolID(aResultSet.getString(2));
				aTFBOExportCollectionVO.setCustomeCif(aResultSet.getString(3));
				aTFBOExportCollectionVO.setCustomeName(aResultSet.getString(4));
				aTFBOExportCollectionVO.setAmount(aResultSet.getString(5));
				aTFBOExportCollectionVO.setCurrency(aResultSet.getString(6));
				aTFBOExportCollectionVO.setSubProductCode(aResultSet
						.getString(7));

				odcCco.add(aTFBOExportCollectionVO);
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}
		System.out.println("ENTERING INTO getTFBOIODCCOCFromDB");
		System.out.println(ActionConstants.EXITING_METHOD + "  "
				+ odcCco.size());
		return odcCco;
	}

	/*
	 * public List<TFBOIdcVO> getTFBOIImportIDCCCOFromDB(String requestId,
	 * String query) throws Exception {
	 * 
	 * logger.info(ActionConstants.ENTERING_METHOD + " requestId->" +
	 * requestId); TFBOIdcVO aTFBOIdcVO = null; Connection aConnection = null;
	 * ResultSet aResultSet = null; PreparedStatement aPreparedStatement = null;
	 * List<TFBOIdcVO> idcCco = new LinkedList<TFBOIdcVO>(); try { aConnection =
	 * DBUtility.getZoneConnection(); aPreparedStatement =
	 * aConnection.prepareStatement(query); logger.info("query-->" + query);
	 * aPreparedStatement.setString(1, requestId.trim()); aResultSet =
	 * aPreparedStatement.executeQuery(); while (aResultSet.next()) { aTFBOIdcVO
	 * = new TFBOIdcVO(); aTFBOIdcVO.setTiReferanceNo(aResultSet.getString(1));
	 * aTFBOIdcVO.setSolID(aResultSet.getString(2));
	 * aTFBOIdcVO.setCustomeCif(aResultSet.getString(3));
	 * aTFBOIdcVO.setCustomeName(aResultSet.getString(4));
	 * aTFBOIdcVO.setBillAmount(aResultSet.getString(5));
	 * aTFBOIdcVO.setCurrency(aResultSet.getString(6));
	 * aTFBOIdcVO.setSubProductCode(aResultSet.getString(7));
	 * idcCco.add(aTFBOIdcVO); } } catch (Exception e) { e.printStackTrace();
	 * throw e; } finally { DBUtility.surrenderDB(aConnection,
	 * aPreparedStatement, aResultSet); }
	 * logger.info(ActionConstants.EXITING_METHOD + "  " + idcCco.size());
	 * return idcCco; }
	 */

	public List<TFBOIdcVO> getTFBOIImportIDCCCOFromDB(String requestId,
			String query) throws Exception {

		logger.info(ActionConstants.ENTERING_METHOD + " requestId->"
				+ requestId);
		TFBOIdcVO aTFBOIdcVO = null;
		Connection aConnection = null;
		ResultSet aResultSet = null;
		PreparedStatement aPreparedStatement = null;
		List<TFBOIdcVO> idcCco = new LinkedList<TFBOIdcVO>();
		try {
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);
			logger.info("query-->" + query);
			aPreparedStatement.setString(1, requestId.trim());
			aResultSet = aPreparedStatement.executeQuery();
			while (aResultSet.next()) {
				aTFBOIdcVO = new TFBOIdcVO();
				aTFBOIdcVO.setTiReferanceNo(aResultSet.getString(1));
				aTFBOIdcVO.setSolID(aResultSet.getString(2));
				aTFBOIdcVO.setCustomeCif(aResultSet.getString(3));
				aTFBOIdcVO.setCustomeName(aResultSet.getString(4));
				aTFBOIdcVO.setCurrency(aResultSet.getString(5));
				aTFBOIdcVO.setAmount(aResultSet.getString(6));
				aTFBOIdcVO.setSubProductCode(aResultSet.getString(7));
				idcCco.add(aTFBOIdcVO);
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}
		logger.info(ActionConstants.EXITING_METHOD + "  " + idcCco.size());
		return idcCco;
	}

	/*
	 * public List<TFBOFinanceExportColVO> getTFBOIFOCPSA1FromDB(String
	 * requestId, String query) throws Exception {
	 * logger.info(ActionConstants.ENTERING_METHOD + " requestId->" +
	 * requestId); TFBOFinanceExportColVO aTFBOFinanceExportColVO = null;
	 * Connection aConnection = null; ResultSet aResultSet = null;
	 * PreparedStatement aPreparedStatement = null; List<TFBOFinanceExportColVO>
	 * focList = new LinkedList<TFBOFinanceExportColVO>(); try { aConnection =
	 * DBUtility.getZoneConnection(); aPreparedStatement =
	 * aConnection.prepareStatement(query); logger.info("query-->" + query);
	 * logger.info("query-->" + query); aPreparedStatement.setString(1,
	 * requestId.trim()); aResultSet = aPreparedStatement.executeQuery(); while
	 * (aResultSet.next()) { aTFBOFinanceExportColVO = new
	 * TFBOFinanceExportColVO();
	 * aTFBOFinanceExportColVO.setTiReferenceNo(aResultSet .getString(1));
	 * aTFBOFinanceExportColVO.setSolID(aResultSet.getString(2));
	 * aTFBOFinanceExportColVO.setCurrency(aResultSet.getString(3));
	 * aTFBOFinanceExportColVO.setCustomeCif(aResultSet.getString(4));
	 * aTFBOFinanceExportColVO .setUsancePeriod(aResultSet.getString(5));
	 * aTFBOFinanceExportColVO.setAmount(aResultSet.getString(6));
	 * aTFBOFinanceExportColVO.setSubProductCode(aResultSet .getString(7));
	 * focList.add(aTFBOFinanceExportColVO); } } catch (Exception e) {
	 * e.printStackTrace(); throw e; } finally {
	 * DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet); }
	 * logger.info(ActionConstants.EXITING_METHOD + "  " + focList.size());
	 * return focList; }
	 */
	public List<TFBOFinanceExportColVO> getTFBOIFOCPSA1FromDB(String requestId,
			String query) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD + " requestId->"
				+ requestId);
		TFBOFinanceExportColVO aTFBOFinanceExportColVO = null;
		Connection aConnection = null;
		ResultSet aResultSet = null;
		PreparedStatement aPreparedStatement = null;
		List<TFBOFinanceExportColVO> focList = new LinkedList<TFBOFinanceExportColVO>();
		try {
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);
			logger.info("query-->" + query);
			logger.info("query-->" + query);
			aPreparedStatement.setString(1, requestId.trim());
			aResultSet = aPreparedStatement.executeQuery();
			while (aResultSet.next()) {
				aTFBOFinanceExportColVO = new TFBOFinanceExportColVO();
				aTFBOFinanceExportColVO.setTiReferenceNo(aResultSet
						.getString(1));
				aTFBOFinanceExportColVO.setSolID(aResultSet.getString(2));
				aTFBOFinanceExportColVO.setCurrency(aResultSet.getString(3));
				aTFBOFinanceExportColVO.setCustomeCif(aResultSet.getString(4));
				aTFBOFinanceExportColVO.setCustomeName(aResultSet.getString(5));
				aTFBOFinanceExportColVO.setAmount(aResultSet.getString(6));
				aTFBOFinanceExportColVO.setSubProductCode(aResultSet
						.getString(7));
				focList.add(aTFBOFinanceExportColVO);
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}
		logger.info(ActionConstants.EXITING_METHOD + "  " + focList.size());
		return focList;
	}

	// karthik 13012020 ends
	// Miscellanous changes starts 08-01-2020

	/*
	 * public List<TFBOMiscellanousVO> getTFBOMISTIReferenceDetailsFromDB(
	 * String subProductCode, String requestId, String query) throws Exception {
	 * logger.info(ActionConstants.ENTERING_METHOD +
	 * " << getTFBOMISTIReferenceDetailsFromDB"); logger.info(
	 * "Getting requestId in getTFBOMISTIReferenceDetailsFromDB method==> " +
	 * requestId); TFBOMiscellanousVO aTFBOMiscellanousVO = null; Connection
	 * aConnection = null; ResultSet aResultSet = null; PreparedStatement
	 * aPreparedStatement = null; List<TFBOMiscellanousVO> miscellanousList =
	 * new LinkedList<TFBOMiscellanousVO>(); try { aConnection =
	 * DBUtility.getZoneConnection(); aPreparedStatement =
	 * aConnection.prepareStatement(query); logger.info("query-->" + query);
	 * aPreparedStatement.setString(1, requestId.trim()); aResultSet =
	 * aPreparedStatement.executeQuery(); while (aResultSet.next()) {
	 * aTFBOMiscellanousVO = new TFBOMiscellanousVO(); //
	 * aTFBOMiscellanousVO.setTiReferenceNo(aResultSet.getString(1));
	 * aTFBOMiscellanousVO.setMasReferanceNo(aResultSet.getString(1));
	 * aTFBOMiscellanousVO.setSolID(aResultSet.getString(2));
	 * aTFBOMiscellanousVO.setCustomeCif(aResultSet.getString(3));
	 * aTFBOMiscellanousVO.setAmount(aResultSet.getString(4));
	 * aTFBOMiscellanousVO.setCurrency(aResultSet.getString(5));
	 * aTFBOMiscellanousVO.setSubProductCode(subProductCode);
	 * miscellanousList.add(aTFBOMiscellanousVO); } } catch (Exception e) {
	 * e.printStackTrace(); throw e; } finally {
	 * DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet); }
	 * logger.info(ActionConstants.EXITING_METHOD + "  " +
	 * miscellanousList.size()); return miscellanousList; }
	 */
	public List<TFBOMiscellanousVO> getTFBOMISTIReferenceDetailsFromDB(
			String subProductCode, String requestId, String query)
			throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD
				+ " << getTFBOMISTIReferenceDetailsFromDB");
		logger.info("Getting requestId in getTFBOMISTIReferenceDetailsFromDB method==> "
				+ requestId);
		TFBOMiscellanousVO aTFBOMiscellanousVO = null;
		Connection aConnection = null;
		ResultSet aResultSet = null;
		PreparedStatement aPreparedStatement = null;
		List<TFBOMiscellanousVO> miscellanousList = new LinkedList<TFBOMiscellanousVO>();
		try {
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);
			logger.info("query-->" + query);
			System.out.println("query-->" + query);
			aPreparedStatement.setString(1, requestId.trim());
			aResultSet = aPreparedStatement.executeQuery();
			while (aResultSet.next()) {
				aTFBOMiscellanousVO = new TFBOMiscellanousVO();
				aTFBOMiscellanousVO.setMasReferanceNo(aResultSet.getString(1));
				aTFBOMiscellanousVO.setSolID(aResultSet.getString(2));
				aTFBOMiscellanousVO.setCustomeCif(aResultSet.getString(3));
				aTFBOMiscellanousVO.setAmount(aResultSet.getString(4));
				aTFBOMiscellanousVO.setCurrency(aResultSet.getString(5));
				aTFBOMiscellanousVO.setSubProductCode(subProductCode);
				miscellanousList.add(aTFBOMiscellanousVO);
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}
		logger.info(ActionConstants.EXITING_METHOD + "  "
				+ miscellanousList.size());
		return miscellanousList;
	}

	/*
	 * public void setValueMiscellanousInDB(String value1, String value2, String
	 * value3, String value4, String value5, String value6, String value7,
	 * String value8, String value9, String value10, String value11, String
	 * value12, String masReferanceNo, String value13, String query) throws
	 * Exception { logger.info(ActionConstants.ENTERING_METHOD +
	 * "setValueMiscellanousInDB"); Connection aConnection = null; ResultSet
	 * aResultSet = null; PreparedStatement aPreparedStatement = null; try {
	 * aConnection = DBUtility.getZoneConnection(); aPreparedStatement =
	 * aConnection.prepareStatement(query); logger.info("query-->" + query);
	 * aPreparedStatement.setString(1, value1); aPreparedStatement.setString(2,
	 * value2); aPreparedStatement.setString(3, value3);
	 * aPreparedStatement.setString(4, value4); aPreparedStatement.setString(5,
	 * value5); aPreparedStatement.setString(6, value6);
	 * aPreparedStatement.setString(7, value7); aPreparedStatement.setString(8,
	 * value8); aPreparedStatement.setString(9, value9);
	 * aPreparedStatement.setString(10, value10);
	 * aPreparedStatement.setString(11, value11);
	 * aPreparedStatement.setString(12, value12);
	 * aPreparedStatement.setString(13, masReferanceNo);
	 * aPreparedStatement.setString(14, value13.trim());
	 * aPreparedStatement.executeUpdate(); } catch (Exception e) {
	 * e.printStackTrace(); throw e; } finally {
	 * DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet); }
	 * logger.info(ActionConstants.EXITING_METHOD + "setValueMiscellanousInDB");
	 * }
	 */
	public void setValueMiscellanousInDB(String value1, String value2,
			String value3, String value4, String value5, String value6,
			String value7, String value8, String value9, String value10,
			String value11, String value12, String value13, String query)
			throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD
				+ "setValueMiscellanousInDB");
		Connection aConnection = null;
		ResultSet aResultSet = null;
		PreparedStatement aPreparedStatement = null;
		try {
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);
			logger.info("query-->" + query);
			aPreparedStatement.setString(1, value1);
			aPreparedStatement.setString(2, value2);
			aPreparedStatement.setString(3, value3);
			aPreparedStatement.setString(4, value4);
			aPreparedStatement.setString(5, value5);
			aPreparedStatement.setString(6, value6);
			aPreparedStatement.setString(7, value7);
			aPreparedStatement.setString(8, value8);
			aPreparedStatement.setString(9, value9);
			aPreparedStatement.setString(10, value10);
			aPreparedStatement.setString(11, value11);
			aPreparedStatement.setString(12, value12);
			aPreparedStatement.setString(13, value13.trim());
			aPreparedStatement.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}
		logger.info(ActionConstants.EXITING_METHOD + "setValueMiscellanousInDB");
	}

	// public List<TFBOMiscellanousVO> getTFBOMiscellanousFromDB(String
	// requestId,
	// String query) throws Exception {
	// logger.info(ActionConstants.ENTERING_METHOD + " requestId->"
	// + requestId);
	// TFBOMiscellanousVO aTFBOMiscellanousVO = null;
	// Connection aConnection = null;
	// ResultSet aResultSet = null;
	// PreparedStatement aPreparedStatement = null;
	// List<TFBOMiscellanousVO> miscellanousCreate = new
	// LinkedList<TFBOMiscellanousVO>();
	// CommonMethods aCommonMethods = new CommonMethods();
	// try {
	// aConnection = DBUtility.getZoneConnection();
	// aPreparedStatement = aConnection.prepareStatement(query);
	// logger.info("query-->" + query);
	// aPreparedStatement.setString(1, requestId.trim());
	// aResultSet = aPreparedStatement.executeQuery();
	// while (aResultSet.next()) {
	// aTFBOMiscellanousVO = new TFBOMiscellanousVO();
	// aTFBOMiscellanousVO.setTiReferenceNo(aResultSet.getString(1));
	// aTFBOMiscellanousVO.setSolID(aResultSet.getString(2));
	// aTFBOMiscellanousVO.setCustomeCif(aResultSet.getString(3));
	// aTFBOMiscellanousVO.setAmount(aResultSet.getString(4));
	// aTFBOMiscellanousVO.setCurrency(aResultSet.getString(5));
	//
	// if (aCommonMethods.isValueAvailable(aResultSet.getString(6))) {
	//
	// if (aResultSet.getString(6).equalsIgnoreCase("Yes")) {
	// aTFBOMiscellanousVO.setRateTaken("true");
	// } else {
	// aTFBOMiscellanousVO.setRateTaken("false");
	// }
	// }
	//
	// aTFBOMiscellanousVO.setToken(aResultSet.getString(7));
	// aTFBOMiscellanousVO.setRateTakenK(aResultSet.getString(8));
	// aTFBOMiscellanousVO.setRate(aResultSet.getString(9));
	// aTFBOMiscellanousVO.setSubProductCode(aResultSet.getString(10));
	// aTFBOMiscellanousVO.setOdiSubProductType(aResultSet
	// .getString(11));
	// aTFBOMiscellanousVO.setRemarks(aResultSet.getString(12));
	// miscellanousCreate.add(aTFBOMiscellanousVO);
	// }
	// } catch (Exception e) {
	// e.printStackTrace();
	// throw e;
	// } finally {
	// DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
	// }
	// logger.info(ActionConstants.EXITING_METHOD + "  "
	// + miscellanousCreate.size());
	// return miscellanousCreate;
	// }
	public List<TFBOMiscellanousVO> getTFBOMiscellanousFromDB(String requestId,
			String query) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD + " requestId->"
				+ requestId);
		TFBOMiscellanousVO aTFBOMiscellanousVO = null;
		Connection aConnection = null;
		ResultSet aResultSet = null;
		PreparedStatement aPreparedStatement = null;
		List<TFBOMiscellanousVO> miscellanousCreate = new LinkedList<TFBOMiscellanousVO>();
		CommonMethods aCommonMethods = new CommonMethods();
		try {
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);
			logger.info("query-->" + query);
			aPreparedStatement.setString(1, requestId.trim());
			aResultSet = aPreparedStatement.executeQuery();
			while (aResultSet.next()) {
				aTFBOMiscellanousVO = new TFBOMiscellanousVO();
				aTFBOMiscellanousVO.setTiReferenceNo(aResultSet.getString(1));
				aTFBOMiscellanousVO.setMasReferanceNo(aResultSet.getString(2));
				aTFBOMiscellanousVO.setSolID(aResultSet.getString(3));
				aTFBOMiscellanousVO.setCustomeCif(aResultSet.getString(4));
				aTFBOMiscellanousVO.setAmount(aResultSet.getString(5));
				aTFBOMiscellanousVO.setCurrency(aResultSet.getString(6));
				
				System.out.println("rate token values for Misc=="+aResultSet.getString(7)
									+" "+aResultSet.getString(8)+" "+aResultSet.getString(9));
				
				if (aCommonMethods.isValueAvailable(aResultSet.getString(7))) {

					if (aResultSet.getString(7).equalsIgnoreCase("Yes")) {
						aTFBOMiscellanousVO.setRateTaken("true");
					} else {
						aTFBOMiscellanousVO.setRateTaken("false");
					}
				}

				aTFBOMiscellanousVO.setToken(aResultSet.getString(8));
				aTFBOMiscellanousVO.setRateTakenK(aResultSet.getString(9));
				aTFBOMiscellanousVO.setRate(aResultSet.getString(10));
				aTFBOMiscellanousVO.setSubProductCode(aResultSet.getString(11));
				aTFBOMiscellanousVO.setOdiSubProductType(aResultSet.getString(12));
				aTFBOMiscellanousVO.setRemarks(aResultSet.getString(13));
				miscellanousCreate.add(aTFBOMiscellanousVO);
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}
		logger.info(ActionConstants.EXITING_METHOD + "  "
				+ miscellanousCreate.size());
		return miscellanousCreate;
	}

	// Miscellanous changes ends 08-01-2020

	// Changes for Tat report starts

//	public void setTatReports(String value1, String value2, String query,
//			String query1, UserTransactionVO userVo) throws Exception {
//		logger.info(ActionConstants.ENTERING_METHOD);
//
//		// Sheet 1 Code
//		Connection aConnection = null;
//		PreparedStatement aPreparedStatement = null;
//		ResultSet aResultSet = null;
//
//		// Sheet 2 Code
//		/*
//		 * Connection aConnection1 = null; PreparedStatement aPreparedStatement1
//		 * = null; ResultSet aResultSet1 = null;
//		 */
//
//		String subProdCode = "";
//		String tot = "";
//		String daysCount1 = "";
//		String daysPer1 = "";
//		String daysCount2 = "";
//		String daysPer2 = "";
//		String daysCount3 = "";
//		String daysPer3 = "";
//		String daysCount4 = "";
//		String daysPer4 = "";
//
//		try {
//
//			// Sheet 1 Code
//			aConnection = DBUtility.getZoneConnection();
//			aPreparedStatement = aConnection.prepareStatement(query);
//
//			// Sheet 2 Code
//			/*
//			 * aConnection1 = DBUtility.getZoneConnection(); aPreparedStatement1
//			 * = aConnection.prepareStatement(query1);
//			 */
//
//			logger.info("Value 1" + value1);
//			logger.info("Value 2" + value2);
//			// Sheet 1 Code
//			aPreparedStatement.setString(1, value1);
//			aPreparedStatement.setString(2, value2);
//			aPreparedStatement.setString(3, value1);
//			aPreparedStatement.setString(4, value2);
//
//			// Sheet 2 Code
//			/*
//			 * aPreparedStatement1.setString(1, value1);
//			 * aPreparedStatement1.setString(2, value2);
//			 * aPreparedStatement1.setString(3, value1);
//			 * aPreparedStatement1.setString(4, value2);
//			 */
//
//			// Sheet 1 Code
//			aResultSet = aPreparedStatement.executeQuery();
//
//			// Sheet 2 Code
//			/* aResultSet1 = aPreparedStatement1.executeQuery(); */
//
//			logger.info("-----query------>" + query);
//			// logger.info("-----query 1---->" +query1);
//
//			HttpServletResponse response = (HttpServletResponse) ActionContext
//					.getContext().get(ServletActionContext.HTTP_RESPONSE);
//			// Sheet 1 Code
//			HSSFWorkbook wb = new HSSFWorkbook();
//			HSSFSheet sheet = wb.createSheet();
//			HSSFRow row = sheet.createRow(0);
//			CellStyle style = wb.createCellStyle();
//			style.setWrapText(true);
//
//			sheet.addMergedRegion(new CellRangeAddress(0, // first row (0-based)
//					0, // last row (0-based)
//					0, // first column (0-based)
//					9 // last column (0-based)
//			));
//
//			row = sheet.createRow(0);
//			HSSFCell cell = row.createCell(0);
//			cell = row.createCell(0);
//			cell.setCellValue("TAT REPORT");
//			row = sheet.createRow(1);
//			cell = row.createCell(0);
//			cell.setCellStyle(style);
//
//			cell.setCellValue("TAT of the Forex Products(From initiation by the branch till transaction is completed where there was no query)");
//			cell = row.createCell(1);
//			cell.setCellValue("TOTAL");
//
//			cell = row.createCell(2);
//			cell.setCellValue("0-1 Day");
//			sheet.addMergedRegion(new CellRangeAddress(1, 1, 2, 3));
//
//			cell = row.createCell(4);
//			cell.setCellValue("2 Days");
//			sheet.addMergedRegion(new CellRangeAddress(1, 1, 4, 5));
//
//			cell = row.createCell(6);
//			cell.setCellValue("3 Days");
//			sheet.addMergedRegion(new CellRangeAddress(1, 1, 6, 7));
//
//			cell = row.createCell(8);
//			cell.setCellValue("4 Days and Above");
//			sheet.addMergedRegion(new CellRangeAddress(1, 1, 8, 9));
//
//			row = sheet.createRow(2);
//			sheet.addMergedRegion(new CellRangeAddress(1, 2, 0, 0));
//			cell = row.createCell(0);
//			sheet.addMergedRegion(new CellRangeAddress(1, 2, 1, 1));
//			cell = row.createCell(2);
//			cell.setCellValue("No.of txn approved");
//
//			cell = row.createCell(3);
//			cell.setCellValue("% of total applications received");
//			cell = row.createCell(4);
//			cell.setCellValue("No.of txn approved");
//			cell = row.createCell(5);
//			cell.setCellValue("% of total applications received");
//			cell = row.createCell(6);
//			cell.setCellValue("No.of txn approved");
//			cell = row.createCell(7);
//			cell.setCellValue("% of total applications received");
//			cell = row.createCell(8);
//			cell.setCellValue("No.of txn approved");
//			cell = row.createCell(9);
//			cell.setCellValue("% of total applications received");
//
//			int i = 3;
//
//			// Sheet 2 Code
//			/*
//			 * HSSFSheet sheet1 = wb.createSheet(); HSSFRow row1 =
//			 * sheet1.createRow(0);
//			 * 
//			 * sheet1.addMergedRegion(new CellRangeAddress( 0, //first row
//			 * (0-based) 0, //last row (0-based) 0, //first column (0-based) 9
//			 * //last column (0-based) ));
//			 * 
//			 * row1 = sheet1.createRow(0); HSSFCell cell1 = row1.createCell(0);
//			 * cell1 = row1.createCell(0); cell1.setCellValue("TAT REPORT");
//			 * row1 = sheet1.createRow(1); cell1 = row1.createCell(0);
//			 * cell1.setCellStyle(style);
//			 * 
//			 * cell1.setCellValue(
//			 * "TAT of the Forex Products(From initiation by the branch till transaction is completed where there was no query)"
//			 * ); cell1 = row1.createCell(1); cell1.setCellValue("TOTAL");
//			 * 
//			 * cell1 = row1.createCell(2); cell1.setCellValue("0-1 Day");
//			 * sheet1.addMergedRegion(new CellRangeAddress(1,1,2,3));
//			 * 
//			 * cell1 = row1.createCell(4); cell1.setCellValue("2 Days");
//			 * sheet1.addMergedRegion(new CellRangeAddress(1,1,4,5));
//			 * 
//			 * cell1 = row1.createCell(6); cell1.setCellValue("3 Days");
//			 * sheet1.addMergedRegion(new CellRangeAddress(1,1,6,7));
//			 * 
//			 * cell1 = row1.createCell(8);
//			 * cell1.setCellValue("4 Days and Above");
//			 * sheet1.addMergedRegion(new CellRangeAddress(1,1,8,9));
//			 * 
//			 * row1 = sheet1.createRow(2); sheet1.addMergedRegion(new
//			 * CellRangeAddress(1,2,0,0)); cell1 = row1.createCell(0);
//			 * sheet1.addMergedRegion(new CellRangeAddress(1,2,1,1)); cell1 =
//			 * row1.createCell(2); cell1.setCellValue("No.of txn approved");
//			 * cell1 = row1.createCell(3);
//			 * cell1.setCellValue("% of total applications received"); cell1 =
//			 * row1.createCell(4); cell1.setCellValue("No.of txn approved");
//			 * cell1 = row1.createCell(5);
//			 * cell1.setCellValue("% of total applications received"); cell1 =
//			 * row1.createCell(6); cell1.setCellValue("No.of txn approved");
//			 * cell1= row1.createCell(7);
//			 * cell1.setCellValue("% of total applications received"); cell1 =
//			 * row1.createCell(8); cell1.setCellValue("No.of txn approved");
//			 * cell1 = row1.createCell(9);
//			 * cell1.setCellValue("% of total applications received");
//			 */
//
//			// Sheet 1 Code
//			while (aResultSet.next()) {
//				logger.info("ENTERING WHILE LOOP----------" + subProdCode);
//				subProdCode = aResultSet.getString(1);
//				userVo.setSubProdCode(subProdCode);
//				logger.info("subProdCode----------" + subProdCode);
//				tot = aResultSet.getString(2);
//				userVo.setTot(tot);
//				daysCount1 = aResultSet.getString(3);
//				userVo.setDaysCount1(daysCount1);
//				daysPer1 = aResultSet.getString(4);
//				userVo.setDaysPer1(daysPer1);
//				daysCount2 = aResultSet.getString(5);
//				userVo.setDaysCount2(daysCount2);
//				daysPer2 = aResultSet.getString(6);
//				userVo.setDaysPer2(daysPer2);
//				daysCount3 = aResultSet.getString(7);
//				userVo.setDaysCount3(daysCount3);
//				daysPer3 = aResultSet.getString(8);
//				userVo.setDaysPer3(daysPer3);
//				daysCount4 = aResultSet.getString(9);
//				userVo.setDaysCount4(daysCount4);
//				daysPer4 = aResultSet.getString(10);
//				userVo.setDaysPer4(daysPer4);
//				row = sheet.createRow(i);
//
//				cell = row.createCell(0);
//				cell.setCellValue(subProdCode);
//				cell = row.createCell(1);
//				cell.setCellValue(tot);
//				cell = row.createCell(2);
//				cell.setCellValue(daysCount1);
//				cell = row.createCell(3);
//				cell.setCellValue(daysPer1);
//				cell = row.createCell(4);
//				cell.setCellValue(daysCount2);
//				cell = row.createCell(5);
//				cell.setCellValue(daysPer2);
//				cell = row.createCell(6);
//				cell.setCellValue(daysCount3);
//				cell = row.createCell(7);
//				cell.setCellValue(daysPer3);
//				cell = row.createCell(8);
//				cell.setCellValue(daysCount4);
//				cell = row.createCell(9);
//				cell.setCellValue(daysPer4);
//
//				// Sheet 2 Code
//				/*
//				 * row1 = sheet1.createRow(i); cell1 = row1.createCell(0);
//				 * cell1.setCellValue(subProdCode); cell1 = row1.createCell(1);
//				 * cell1.setCellValue(tot); cell1 = row1.createCell(2);
//				 * cell1.setCellValue(daysCount1); cell1 = row1.createCell(3);
//				 * cell1.setCellValue(daysPer1); cell1 = row1.createCell(4);
//				 * cell1.setCellValue(daysCount2); cell1 = row1.createCell(5);
//				 * cell1.setCellValue(daysPer2); cell1 = row1.createCell(6);
//				 * cell1.setCellValue(daysCount3); cell1 = row1.createCell(7);
//				 * cell1.setCellValue(daysPer3); cell1 = row1.createCell(8);
//				 * cell1.setCellValue(daysCount4); cell1 = row1.createCell(9);
//				 * cell1.setCellValue(daysPer4);
//				 */
//				i++;
//
//			}
//			// int j=3;
//
//			// Sheet 2 Code
//			/*
//			 * while(aResultSet1.next()) {
//			 * 
//			 * row1 = sheet1.createRow(j);
//			 * 
//			 * cell1 = row1.createCell(0);
//			 * 
//			 * cell1.setCellValue(aResultSet1.getString(1)); cell1 =
//			 * row1.createCell(1); cell1.setCellValue(aResultSet1.getString(2));
//			 * cell1 = row1.createCell(2);
//			 * cell1.setCellValue(aResultSet1.getString(3)); cell1 =
//			 * row1.createCell(3); cell1.setCellValue(aResultSet1.getString(4));
//			 * cell1 = row1.createCell(4);
//			 * cell1.setCellValue(aResultSet1.getString(5)); cell1 =
//			 * row1.createCell(5); cell1.setCellValue(aResultSet1.getString(6));
//			 * cell1 = row1.createCell(6);
//			 * cell1.setCellValue(aResultSet1.getString(7)); cell1 =
//			 * row1.createCell(7); cell1.setCellValue(aResultSet1.getString(8));
//			 * cell1 = row1.createCell(8);
//			 * cell1.setCellValue(aResultSet1.getString(9)); cell1 =
//			 * row1.createCell(9);
//			 * cell1.setCellValue(aResultSet1.getString(10)); j++;
//			 * 
//			 * 
//			 * }
//			 */
//
//			ByteArrayOutputStream outByteStream = new ByteArrayOutputStream();
//			// ByteArrayOutputStream outByteStream1 = new
//			// ByteArrayOutputStream();
//
//			wb.write(outByteStream);
//			// wb.write(outByteStream1);
//
//			byte[] outArray = outByteStream.toByteArray();
//			// byte [] outArray1 = outByteStream1.toByteArray();
//
//			response.setContentType("application/ms-excel");
//			response.setContentLength(outArray.length);
//			// response.setContentLength(outArray1.length);
//
//			response.setHeader("Expires:", "0"); // eliminates browser caching
//			response.setHeader("Content-Disposition",
//					"attachment; filename=Tatreport.xls");
//			OutputStream outStream = response.getOutputStream();
//			logger.info("Before write" + outArray.length);
//			outStream.write(outArray);
//			// outStream.write(outArray1);
//			logger.info("After write");
//			outStream.flush();
//		} catch (Exception e) {
//			e.printStackTrace();
//			throw e;
//		} finally {
//			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
//			// DBUtility.surrenderDB(aConnection1, aPreparedStatement1,
//			// aResultSet1);
//		}
//		logger.info(ActionConstants.EXITING_METHOD);
//	}

	// Changes Tat report ends

	/* Changes for branch profile 14012020 starts */

	public void insertBranchProfile(String query, ProfileManagementVO profileVo)
			throws Exception {
		System.out.println(ActionConstants.ENTERING_METHOD);

		Connection aConnection = null;
		PreparedStatement aPreparedStatement = null;

		try {
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);

			aPreparedStatement.setString(1, profileVo.getSolID());
			aPreparedStatement.setString(2, profileVo.getAlphaCode());
			aPreparedStatement.setString(3, profileVo.getSwiftCode());
			aPreparedStatement.setString(4, profileVo.getBRPhoneSTD());
			aPreparedStatement.setString(5, profileVo.getMobileNo());
			aPreparedStatement.setString(6, profileVo.getBranchAddr());

			System.out.println("profileVo.getSolID in insertBranchProfile"
					+ profileVo.getSolID());
			System.out.println("profileVo.getAlphaCode in insertBranchProfile"
					+ profileVo.getAlphaCode());
			System.out.println("profileVo.mobile in insertBranchProfile"
					+ profileVo.getBRPhoneSTD());
			System.out.println("profileVo.getBranchAddr in insertBranchProfile"
					+ profileVo.getBranchAddr());

			aPreparedStatement.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, null);
		}
	}

	public void updateBranchProfile(String query, ProfileManagementVO profileVo)
			throws Exception {
		System.out.println(ActionConstants.ENTERING_METHOD);

		Connection aConnection = null;
		PreparedStatement aPreparedStatement = null;

		int count = 0;
		query = "UPDATE BRANCH_PROFILE SET ALPHA_CODE='"
				+ profileVo.getAlphaCode() + "',SWIFT_CODE='"
				+ profileVo.getSwiftCode() + "',BR_PHONE='"
				+ profileVo.getBRPhoneSTD() + "',MOB_NO='"
				+ profileVo.getMobileNo() + "',BRANCH_ADDRESS='"
				+ profileVo.getBranchAddr() + "'" + "where SOL_ID='"
				+ profileVo.getSolID() + "'";
		System.out.println("query to update >>--> " + query);
		try {
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);

			/*
			 * aPreparedStatement.setString(1, profileVo.getAlphaCode());
			 * aPreparedStatement.setString(2, profileVo.getSwiftCode());
			 * aPreparedStatement.setString(3, profileVo.getBRPhoneSTD());
			 * aPreparedStatement.setString(4, profileVo.getMobileNo());
			 * aPreparedStatement.setString(5, profileVo.getBranchAddr());
			 * aPreparedStatement.setString(6, profileVo.getSolID());
			 */

			System.out.println("getSolID in updateBranchProfile"
					+ profileVo.getSolID());
			System.out.println("getAlphaCode in updateBranchProfile"
					+ profileVo.getAlphaCode());
			System.out.println("BRPhoneSTD in updateBranchProfile"
					+ profileVo.getBRPhoneSTD());
			System.out.println("getBranchAddr in updateBranchProfile"
					+ profileVo.getBranchAddr());
			System.out.println("getMobileNo in updateBranchProfile"
					+ profileVo.getMobileNo());

			count = aPreparedStatement.executeUpdate();
			if (count != 0) {
				System.out.println("enterred in to loop");
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, null);
		}
	}

	public List<BrabchProfileMgmt> getBranchProfileListFromDBFilter(String solid)
			throws Exception {
		BrabchProfileMgmt ProfileSolid = null;
		Connection aConnection = null;

		ResultSet aResultSet = null;
		String query = "";
		PreparedStatement aPreparedStatement = null;
		String sol_id_check = getBranchID(solid);
		System.out.println("sol_id_check====" + sol_id_check);
		System.out.println("solid====" + solid);

		if (sol_id_check.equals(solid)) {
			// query = ActionConstants.GET_FROM_BRANCH_PROFILE ;
			System.out.println("sol_id matches with BRANCH_PROFILE");
			query = "SELECT ALPHA_CODE,BRANCH_ADDRESS,BR_PHONE,SWIFT_CODE,MOB_NO FROM BRANCH_PROFILE WHERE SOL_ID='"
					+ solid.trim() + "'";
			System.out.println("query FOR GET_FROM_BRANCH_PROFILE======"
					+ query);
		} else {
			System.out.println("sol_id not matches with BRANCH_PROFILE");
			/* query = ActionConstants.BRANCHPROFILE_MGMT_QUERY ; */
			query = "SELECT trim(BM.ALPHA) AS ALPHA_CODE , HVBADFF AS BRANCH_ADDRESS,trim(BM.PHONE) AS PHONE ,TRIM(CA.CASWB||CA.CACNAS||CA.CASWL||CA.CASWBR) as SWIFTCODE,'' AS MOB_NO "
					+ " FROM "
					+ schemaName
					+ "HVPF HV,"
					+ schemaName
					+ "BRANCH_MASTER BM,"
					+ schemaName
					+ "CAPF CA "
					+ "WHERE HV.HVBRNM =BM.SOL_ID and HV.HVBRNM=CA.CABRNM "
					+ "and TRIM(HV.HVBRNM)='" + solid.trim() + "'";

			System.out.println("query FOR BRANCHPROFILE_MGMT_QUERY======"
					+ query);
		}
		List<BrabchProfileMgmt> branchProfileSolid = new LinkedList<BrabchProfileMgmt>();
		try {
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);
			// aPreparedStatement.setString(1, solid.trim());
			System.out.println("query-->" + query);
			aResultSet = aPreparedStatement.executeQuery();
			while (aResultSet.next()) {
				System.out.println("aResultSet.next() HAS VALUES");
				ProfileSolid = new BrabchProfileMgmt();
				ProfileSolid.setAlphaCode(aResultSet.getString(1));
				ProfileSolid.setBranchAddr(aResultSet.getString(2));
				ProfileSolid.setBRPhoneSTD(aResultSet.getString(3));
				ProfileSolid.setSwiftCode(aResultSet.getString(4));
				ProfileSolid.setMobileNo(aResultSet.getString(5));

				logger.info("ProfileSolid.setAlphaCode==="
						+ aResultSet.getString(1));
				logger.info("ProfileSolid.setBranchAddr==="
						+ aResultSet.getString(2));
				logger.info("ProfileSolid.setBRPhoneSTD==="
						+ aResultSet.getString(3));
				logger.info("ProfileSolid.setSwiftCode==="
						+ aResultSet.getString(4));
				logger.info("ProfileSolid.setMobileNo==="
						+ aResultSet.getString(5));

				branchProfileSolid.add(ProfileSolid);
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}
		logger.info(ActionConstants.EXITING_METHOD + "  "
				+ branchProfileSolid.size());

		return branchProfileSolid;
	}

	public String getBranchID(String SOL_ID) throws Exception {

		System.out.println("Entering into getBranchID");
		Connection aConnection = null;
		PreparedStatement aPreparedStatement = null;
		ResultSet rs = null;
		String query = "SELECT TRIM(SOL_ID) AS SOL_ID FROM BRANCH_PROFILE where SOL_ID='"
				+ SOL_ID + "'";
		String result = "";
		try {
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);

			// aPreparedStatement.setString(1,SOL_ID);
			System.out.println("getSolID from BRANCH_PROFILE==" + SOL_ID);
			rs = aPreparedStatement.executeQuery();
			System.out.println("TEST SUCCESS==" + query);

			while (rs.next()) {
				result = rs.getString("SOL_ID");
				System.out.println("Sol_id from getBranchID====" + result);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, null);
		}
		return result;
	}

	/* Changes for branch profile 14012020 ends */

	/*
	 * public int UpdateCustomerDtails(CustomerProfileManageVO custProfileVo,
	 * String userName, String query) {
	 * 
	 * logger.info(ActionConstants.ENTERING_METHOD + "getValueFromDB"); //
	 * List<CustomerProfileManageVO> custProfileList = new //
	 * LinkedList<CustomerProfileManageVO>(); String custID =
	 * custProfileVo.getCustID(); String custName = custProfileVo.getCustName();
	 * String operAccSol = custProfileVo.getOperSolID(); String operAccNo =
	 * custProfileVo.getOperAccNo(); String operAlphaCode =
	 * custProfileVo.getAlphaCode(); String lineOfActivity =
	 * custProfileVo.getLineofActivity(); String rateMarFrom =
	 * custProfileVo.getRateMarginFrom(); String rateMarTo =
	 * custProfileVo.getRateMarginTo(); String emailID =
	 * custProfileVo.getEmailID(); String mobileNo =
	 * custProfileVo.getMobileNo(); Connection aConnection = null;
	 * PreparedStatement aPreparedStatement = null; int resultValue = 0; try {
	 * aConnection = DBUtility.getZoneConnection(); aPreparedStatement =
	 * aConnection.prepareStatement(query); aPreparedStatement.setString(1,
	 * custID); aPreparedStatement.setString(2, custName);
	 * aPreparedStatement.setString(3, operAccNo);
	 * aPreparedStatement.setString(4, operAccSol);
	 * aPreparedStatement.setString(5, operAlphaCode);
	 * aPreparedStatement.setString(6, lineOfActivity);
	 * aPreparedStatement.setString(7, rateMarFrom);
	 * aPreparedStatement.setString(8, rateMarTo);
	 * aPreparedStatement.setString(9, emailID);
	 * aPreparedStatement.setString(10, mobileNo);
	 * aPreparedStatement.setString(11, userName); resultValue =
	 * aPreparedStatement.executeUpdate(); } catch (Exception e) {
	 * e.printStackTrace(); } finally { DBUtility.surrenderDB(aConnection,
	 * aPreparedStatement, null); } logger.info(ActionConstants.EXITING_METHOD +
	 * "getValueFromDB"); return resultValue;
	 * 
	 * }
	 */

	public int UpdateCustomerDtails(CustomerProfileManageVO custProfileVo,
			String userName, String query) {

		logger.info(ActionConstants.ENTERING_METHOD + "getValueFromDB");
		// List<CustomerProfileManageVO> custProfileList = new
		// LinkedList<CustomerProfileManageVO>();
		String custID = custProfileVo.getCustID();
		String custName = custProfileVo.getCustName();
		String operAccSol = custProfileVo.getOperSolID();
		String operAccNo = custProfileVo.getOperAccNo();
		String operAlphaCode = custProfileVo.getAlphaCode();
		String lineOfActivity = custProfileVo.getLineofActivity();
		String rateMarFrom = custProfileVo.getRateMarginFrom();
		String rateMarTo = custProfileVo.getRateMarginTo();
		String emailID = custProfileVo.getEmailID();
		String mobileNo = custProfileVo.getMobileNo();
		String solId = custProfileVo.getBranchsolID();
		Connection aConnection = null;
		PreparedStatement aPreparedStatement = null;
		int resultValue = 0;
		try {
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);
			aPreparedStatement.setString(1, custID);
			aPreparedStatement.setString(2, custName);
			aPreparedStatement.setString(3, operAccNo);
			aPreparedStatement.setString(4, operAccSol);
			aPreparedStatement.setString(5, operAlphaCode);
			aPreparedStatement.setString(6, lineOfActivity);
			aPreparedStatement.setString(7, rateMarFrom);
			aPreparedStatement.setString(8, rateMarTo);
			aPreparedStatement.setString(9, emailID);
			aPreparedStatement.setString(10, mobileNo);
			aPreparedStatement.setString(11, userName);
			aPreparedStatement.setString(12, solId.trim());
			resultValue = aPreparedStatement.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, null);
		}
		logger.info(ActionConstants.EXITING_METHOD + "getValueFromDB");
		return resultValue;

	}

	public List<DocumentUploadVO> getCustDocumentListFromDB(String requestId,
			String documentFlag) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD + " transID->" + requestId
				+ " documentFlag->" + documentFlag);
		DocumentUploadVO aDocumentUploadVO = null;
		Connection aConnection = null;
		ResultSet aResultSet = null;
		PreparedStatement aPreparedStatement = null;
		List<DocumentUploadVO> documentList = new LinkedList<DocumentUploadVO>();
		try {
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection
					.prepareStatement(ActionConstants.GETDOCUMENTLISTCUST);
			logger.info("query-->" + ActionConstants.GETDOCUMENTLISTCUST);
			aPreparedStatement.setString(1, documentFlag.trim());
			aPreparedStatement.setString(2, requestId.trim());
			aResultSet = aPreparedStatement.executeQuery();
			while (aResultSet.next()) {
				aDocumentUploadVO = new DocumentUploadVO();
				aDocumentUploadVO.setDocumentID((aResultSet.getString(1)));
				aDocumentUploadVO.setDocumentName((aResultSet.getString(2)));
				aDocumentUploadVO.setDocumentPath((aResultSet.getString(3)));
				aDocumentUploadVO.setDocDesc((aResultSet.getString(4)));
				documentList.add(aDocumentUploadVO);
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}
		logger.info(ActionConstants.EXITING_METHOD + "  " + documentList.size());
		return documentList;
	}

	public List<CustomerProfileManageVO> getBranchProfileDetails(String solID,
			CustomerProfileManageVO custProfileVo, String query) {

		logger.info(ActionConstants.ENTERING_METHOD + "getValueFromDB");
		List<CustomerProfileManageVO> custProfileList = new LinkedList<CustomerProfileManageVO>();
		Connection aConnection = null;
		PreparedStatement aPreparedStatement = null;
		ResultSet aResultSet = null;
		CustomerProfileManageVO custProVO = null;
		try {
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);
			aResultSet = aPreparedStatement.executeQuery();
			while (aResultSet.next()) {
				custProVO = new CustomerProfileManageVO();
				custProVO.setBranchsolID(aResultSet.getString(1));
				custProVO.setBranchalphaCode(aResultSet.getString(2));
				custProVO.setBranchswiftCode(aResultSet.getString(3));
				custProVO.setBranchPhone(aResultSet.getString(4));
				custProVO.setBranchMobileNo(aResultSet.getString(5));
				custProVO.setBranchAddress(aResultSet.getString(6));
				custProfileList.add(custProVO);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}
		logger.info(ActionConstants.EXITING_METHOD + "getValueFromDB");
		return custProfileList;

	}

	public List<CustomerProfileManageVO> fetchcustomerDetails(String query) {

		logger.info(ActionConstants.ENTERING_METHOD + "getValueFromDB");
		List<CustomerProfileManageVO> custProfileList = new LinkedList<CustomerProfileManageVO>();
		String custName = "";
		String emailID = "";
		Connection aConnection = null;
		ResultSet aResultSet = null;
		PreparedStatement aPreparedStatement = null;
		CustomerProfileManageVO custProVO = null;
		try {
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);
			logger.info("query-->" + query);
			aResultSet = aPreparedStatement.executeQuery();
			while (aResultSet.next()) {
				custName = aResultSet.getString(1);
				emailID = aResultSet.getString(2);
				custProVO = new CustomerProfileManageVO();
				custProVO.setCustName(custName);
				custProVO.setEmailID(emailID);
				custProfileList.add(custProVO);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}
		logger.info(ActionConstants.EXITING_METHOD + "getValueFromDB");
		return custProfileList;

	}

	public String getBranchIDfromTI(String query) {

		logger.info(ActionConstants.ENTERING_METHOD + "getValueFromDB");
		Connection aConnection = null;
		ResultSet aResultSet = null;
		PreparedStatement aPreparedStatement = null;
		String flag = "";
		try {
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);
			logger.info("query-->" + query);
			aResultSet = aPreparedStatement.executeQuery();
			while (aResultSet.next()) {
				flag = aResultSet.getString(1).trim();
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}
		logger.info(ActionConstants.EXITING_METHOD + "getValueFromDB");
		return flag;

	}

	public boolean checkCustomerAvailable(String query) {

		logger.info(ActionConstants.ENTERING_METHOD + "getValueFromDB");
		Connection aConnection = null;
		ResultSet aResultSet = null;
		PreparedStatement aPreparedStatement = null;
		boolean flag = false;
		try {
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);
			logger.info("query-->" + query);
			aResultSet = aPreparedStatement.executeQuery();
			while (aResultSet.next()) {
				flag = true;
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}
		logger.info(ActionConstants.EXITING_METHOD + "getValueFromDB");
		return flag;

	}

	// Expiry,closure,cancellation Changes Starts
	public List<TFBOImportLcVO> getTFBOIImportLCEXPFromDB(String requestId,
			String query) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD + " requestId->"
				+ requestId);
		TFBOImportLcVO aTFBOIlcIssueVO = null;
		Connection aConnection = null;
		ResultSet aResultSet = null;
		PreparedStatement aPreparedStatement = null;
		List<TFBOImportLcVO> ilcIssue = new LinkedList<TFBOImportLcVO>();
		try {
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);
			logger.info("query-->" + query);
			aPreparedStatement.setString(1, requestId.trim());
			aResultSet = aPreparedStatement.executeQuery();
			while (aResultSet.next()) {
				aTFBOIlcIssueVO = new TFBOImportLcVO();
				aTFBOIlcIssueVO.setTiReferenceNo(aResultSet.getString(1));
				aTFBOIlcIssueVO.setSolID(aResultSet.getString(2));
				aTFBOIlcIssueVO.setCustomeCif(aResultSet.getString(3));
				aTFBOIlcIssueVO.setAmount(aResultSet.getString(4));
				aTFBOIlcIssueVO.setCurrency(aResultSet.getString(5));
				aTFBOIlcIssueVO.setLcType(aResultSet.getString(6));
				aTFBOIlcIssueVO.setSubProductCode(aResultSet.getString(7));
				ilcIssue.add(aTFBOIlcIssueVO);
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}
		logger.info(ActionConstants.EXITING_METHOD + "  " + ilcIssue.size());
		return ilcIssue;
	}

	public List<TFBOExportLcVO> getTFBOIExportLCEXPFromDB(String requestId,
			String query) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD + " requestId->"
				+ requestId);
		TFBOExportLcVO aTFBOElcIssueVO = null;
		Connection aConnection = null;
		ResultSet aResultSet = null;
		PreparedStatement aPreparedStatement = null;
		List<TFBOExportLcVO> elcIssue = new LinkedList<TFBOExportLcVO>();
		try {
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);
			logger.info("query-->" + query);
			aPreparedStatement.setString(1, requestId.trim());
			aResultSet = aPreparedStatement.executeQuery();
			while (aResultSet.next()) {
				aTFBOElcIssueVO = new TFBOExportLcVO();
				aTFBOElcIssueVO.setTiReferenceNo(aResultSet.getString(1));
				aTFBOElcIssueVO.setSolID(aResultSet.getString(2));
				aTFBOElcIssueVO.setCustomeCif(aResultSet.getString(3));
				aTFBOElcIssueVO.setAmount(aResultSet.getString(4));
				aTFBOElcIssueVO.setCurrency(aResultSet.getString(5));
				aTFBOElcIssueVO.setLcType(aResultSet.getString(6));
				aTFBOElcIssueVO.setSubProductCode(aResultSet.getString(7));
				elcIssue.add(aTFBOElcIssueVO);
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}
		logger.info(ActionConstants.EXITING_METHOD + "  " + elcIssue.size());
		return elcIssue;
	}

	public List<TFBOImportGTVO> getTFBOIGTCANFromDB(String requestId,
			String query) throws Exception {

		Connection aConnection = null;
		PreparedStatement aPreparedStatement = null;
		ResultSet aResultset = null;
		List<TFBOImportGTVO> importGTVOList = new LinkedList<TFBOImportGTVO>();
		TFBOImportGTVO importGTVO = null;
		logger.info("query >>-->" + query);
		try {
			importGTVO = new TFBOImportGTVO();
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);
			aPreparedStatement.setString(1, requestId.trim());
			aResultset = aPreparedStatement.executeQuery();
			while (aResultset.next()) {
				importGTVO.setTiReferenceNo(aResultset.getString(1));
				importGTVO.setSolID(aResultset.getString(2));
				importGTVO.setCustomeCif(aResultset.getString(3));
				importGTVO.setAmount(aResultset.getString(4));
				importGTVO.setCurrency(aResultset.getString(5));
				importGTVO.setTenure(aResultset.getString(6));
				importGTVO.setSubProductCode(aResultset.getString(7));
				importGTVOList.add(importGTVO);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, null);
		}
		return importGTVOList;
	}

	public List<TFBOImportGTVO> getTFBOIGTKIGFromDB(String requestId,
			String query) throws Exception {

		Connection aConnection = null;
		PreparedStatement aPreparedStatement = null;
		ResultSet aResultset = null;
		List<TFBOImportGTVO> importGTVOList = new LinkedList<TFBOImportGTVO>();
		TFBOImportGTVO importGTVO = null;
		logger.info("query >>-->" + query);
		try {
			importGTVO = new TFBOImportGTVO();
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);
			aPreparedStatement.setString(1, requestId.trim());
			aResultset = aPreparedStatement.executeQuery();
			while (aResultset.next()) {
				importGTVO.setTiReferenceNo(aResultset.getString(1));
				importGTVO.setSolID(aResultset.getString(2));
				importGTVO.setCustomeCif(aResultset.getString(3));
				importGTVO.setAmount(aResultset.getString(4));
				importGTVO.setCurrency(aResultset.getString(5));
				importGTVO.setTenure(aResultset.getString(6));
				importGTVO.setSubProductCode(aResultset.getString(7));
				importGTVOList.add(importGTVO);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, null);
		}
		return importGTVOList;
	}

	// Expiry,closure,cancellation Changes Ends

	public List<CustomerProfileManageVO> fetchcustomerDetailsFromProfile(
			String query) {

		logger.info(ActionConstants.ENTERING_METHOD + "getValueFromDB");
		List<CustomerProfileManageVO> custProfileList = new LinkedList<CustomerProfileManageVO>();

		Connection aConnection = null;
		ResultSet aResultSet = null;
		PreparedStatement aPreparedStatement = null;
		CustomerProfileManageVO custProVO = null;
		try {
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);
			logger.info("query-->" + query);
			aResultSet = aPreparedStatement.executeQuery();
			while (aResultSet.next()) {
				custProVO = new CustomerProfileManageVO();
				custProVO.setCustName(aResultSet.getString(1));
				custProVO.setOperAccNo(aResultSet.getString(2));
				custProVO.setOperSolID(aResultSet.getString(3));
				custProVO.setAlphaCode(aResultSet.getString(4));
				custProVO.setLineofActivity(aResultSet.getString(5));
				custProVO.setRateMarginFrom(aResultSet.getString(6));
				custProVO.setRateMarginTo(aResultSet.getString(7));
				custProVO.setEmailID(aResultSet.getString(8));
				custProVO.setMobileNo(aResultSet.getString(9));
				custProVO.setCustSolId(aResultSet.getString(10));
				custProfileList.add(custProVO);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}
		logger.info(ActionConstants.EXITING_METHOD + "getValueFromDB");
		return custProfileList;

	}

	public int UpdateCustomerVerifyDtails(
			CustomerProfileManageVO custProfileVo, String query, String userName) {

		String custID = custProfileVo.getCustID();
		Connection aConnection = null;
		PreparedStatement aPreparedStatement = null;
		int resultValue = 0;
		try {
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);
			aPreparedStatement.setString(1, userName);
			aPreparedStatement.setString(2, custID.trim());
			resultValue = aPreparedStatement.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, null);
		}
		logger.info(ActionConstants.EXITING_METHOD + "getValueFromDB");
		return resultValue;

	}

	public List<CustomerProfileManageVO> getCustVerifyListFromDB(
			String requestId, String custSolid) throws Exception {
		CustomerProfileManageVO custVerifyVO = null;
		Connection aConnection = null;
		ResultSet aResultSet = null;
		PreparedStatement aPreparedStatement = null;
		List<CustomerProfileManageVO> custVerifyList = new LinkedList<CustomerProfileManageVO>();
		int seqNo = 0;
		try {
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection
					.prepareStatement(ActionConstants.GETCUSTVERIFYLIST);
			aPreparedStatement.setString(1, custSolid.trim());
			aResultSet = aPreparedStatement.executeQuery();
			while (aResultSet.next()) {
				seqNo++;
				custVerifyVO = new CustomerProfileManageVO();
				custVerifyVO.setSeqNo(seqNo);
				custVerifyVO.setCustID(aResultSet.getString(1));
				custVerifyVO.setCustName((aResultSet.getString(2)));
				custVerifyList.add(custVerifyVO);
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}
		logger.info(ActionConstants.EXITING_METHOD + "  "
				+ custVerifyList.size());
		return custVerifyList;
	}

	// Report 23012020 starts

	/*
	 * public List<String> getCodeListFromDB(String query) throws Exception {
	 * logger.info(ActionConstants.ENTERING_METHOD + "<<getCodeListFromDB");
	 * List<String> valueList = new LinkedList<String>(); Connection aConnection
	 * = null; ResultSet aResultSet = null; PreparedStatement aPreparedStatement
	 * = null; try { aConnection = DBUtility.getZoneConnection();
	 * aPreparedStatement = aConnection.prepareStatement(query);
	 * logger.info("query-->" + query); aResultSet =
	 * aPreparedStatement.executeQuery(); while (aResultSet.next()) { String
	 * resultValue = ""; resultValue = aResultSet.getString(1);
	 * valueList.add(resultValue); } } catch (Exception e) {
	 * e.printStackTrace(); throw e; } finally {
	 * DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet); }
	 * logger.info(ActionConstants.EXITING_METHOD + "  " + valueList.size());
	 * return valueList; }
	 */
	public List<String> getCodeListFromDB(String query) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD + "<<getCodeListFromDB");
		List<String> valueList = new LinkedList<String>();
		Connection aConnection = null;
		ResultSet aResultSet = null;
		PreparedStatement aPreparedStatement = null;
		try {
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);
			logger.info("Product code query-->" + query);
			aResultSet = aPreparedStatement.executeQuery();
			while (aResultSet.next()) {
				String resultValue = "";
				resultValue = aResultSet.getString(1);
				valueList.add(resultValue);
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}
		logger.info("Size of the list==> " + valueList.size());
		logger.info(ActionConstants.EXITING_METHOD + "<<getCodeListFromDB");

		return valueList;
	}

	/*
	 * public List<String> getUserIdListFromDB(String query) throws Exception {
	 * logger.info(ActionConstants.ENTERING_METHOD + "<<getUserIdListFromDB");
	 * List<String> valueList = new LinkedList<String>(); Connection aConnection
	 * = null; ResultSet aResultSet = null; PreparedStatement aPreparedStatement
	 * = null; try { aConnection = DBUtility.getZoneConnection();
	 * aPreparedStatement = aConnection.prepareStatement(query);
	 * logger.info("query-->" + query); aResultSet =
	 * aPreparedStatement.executeQuery(); while (aResultSet.next()) { String
	 * resultValue = ""; resultValue = aResultSet.getString(1);
	 * valueList.add(resultValue); } } catch (Exception e) {
	 * e.printStackTrace(); throw e; } finally {
	 * DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet); }
	 * logger.info(ActionConstants.EXITING_METHOD + "  " + valueList.size());
	 * return valueList; }
	 */
	public List<String> getUserIdListFromDB(String query) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD + "<<getUserIdListFromDB");
		List<String> valueList = new LinkedList<String>();
		Connection aConnection = null;
		ResultSet aResultSet = null;
		PreparedStatement aPreparedStatement = null;
		try {
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);
			logger.info("Getting user id query-->" + query);
			aResultSet = aPreparedStatement.executeQuery();
			while (aResultSet.next()) {
				String resultValue = "";
				resultValue = aResultSet.getString(1);
				valueList.add(resultValue);
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}
		logger.info("Size of the List==>" + valueList.size());
		logger.info(ActionConstants.EXITING_METHOD + "<<getUserIdListFromDB");
		return valueList;
	}

	/*
	 * public List<ReportVO> generateSummaryReportInGrid(String query, ReportVO
	 * reportVo) throws Exception { logger.info(ActionConstants.ENTERING_METHOD
	 * + "<<generateSummaryReportInGrid DB Helper");
	 * 
	 * List<ReportVO> list = null; Connection aConnection = null;
	 * PreparedStatement aPreparedStatement = null; ResultSet aResultSet = null;
	 * 
	 * try { list = new ArrayList<ReportVO>();
	 * 
	 * aConnection = DBUtility.getZoneConnection(); aPreparedStatement =
	 * aConnection.prepareStatement(query);
	 * 
	 * aResultSet = aPreparedStatement.executeQuery();
	 * 
	 * while (aResultSet.next()) { reportVo = new ReportVO();
	 * reportVo.setTransType(aResultSet.getString(1));
	 * reportVo.setFrequencyRange(aResultSet.getString(2));
	 * reportVo.setCountSummary(aResultSet.getString(3)); list.add(reportVo); }
	 * } catch (Exception e) { e.printStackTrace(); throw e; } finally {
	 * DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet); }
	 * logger.info(ActionConstants.EXITING_METHOD +
	 * "<<generateSummaryReportInGrid DB Helper"); return list;
	 * 
	 * }
	 */
	public List<ReportVO> generateSummaryReportInGrid(String query,
			ReportVO reportVo) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD
				+ "<<generateSummaryReportInGrid DB Helper");

		List<ReportVO> summaryReportList = null;
		Connection aConnection = null;
		PreparedStatement aPreparedStatement = null;
		ResultSet aResultSet = null;

		try {
			summaryReportList = new ArrayList<ReportVO>();

			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);

			aResultSet = aPreparedStatement.executeQuery();

			while (aResultSet.next()) {
				reportVo = new ReportVO();
				reportVo.setTransType(aResultSet.getString(1));
				reportVo.setFrequencyRange(aResultSet.getString(2));
				reportVo.setCountSummary(aResultSet.getString(4));
				summaryReportList.add(reportVo);
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}
		logger.info(ActionConstants.EXITING_METHOD
				+ "<<generateSummaryReportInGrid DB Helper");
		return summaryReportList;

	}

	/*
	 * public List<ReportVO> generateDetailedTableReport(String query, ReportVO
	 * reportVo) throws Exception { logger.info(ActionConstants.ENTERING_METHOD
	 * + "<<generateDetailedTableReport DB Helper");
	 * 
	 * List<ReportVO> list = null; Connection aConnection = null;
	 * PreparedStatement aPreparedStatement = null; ResultSet aResultSet = null;
	 * 
	 * try { list = new ArrayList<ReportVO>();
	 * 
	 * aConnection = DBUtility.getZoneConnection(); aPreparedStatement =
	 * aConnection.prepareStatement(query);
	 * 
	 * aResultSet = aPreparedStatement.executeQuery(); while (aResultSet.next())
	 * { reportVo = new ReportVO(); reportVo.setsNo(1);
	 * reportVo.setRequestType(aResultSet.getString(1));
	 * reportVo.setSubProduct(aResultSet.getString(2));
	 * reportVo.setRequestId(aResultSet.getString(3));
	 * reportVo.setFinacleTranNo(aResultSet.getString(4));
	 * reportVo.setTransTime(aResultSet.getString(5));
	 * reportVo.setSolid(aResultSet.getString(6));
	 * reportVo.setBranchAlpha(aResultSet.getString(7));
	 * reportVo.setCustomerName(aResultSet.getString(8));
	 * reportVo.setCurrencyDetailed(aResultSet.getString(9));
	 * reportVo.setTransAmt(aResultSet.getString(10));
	 * reportVo.setStatus(aResultSet.getString(11));
	 * reportVo.setStatusChangeBy(aResultSet.getString(12));
	 * reportVo.setStatusChangeTime(aResultSet.getString(13));
	 * reportVo.setRequestCycle(aResultSet.getString(14));
	 * reportVo.setSenderRefNo(""); reportVo.setDummyIrex("");
	 * reportVo.setIfPcfc(""); reportVo.setAmendNo(""); reportVo.setUnderLc("");
	 * reportVo.setDocDisNonDis("");
	 * 
	 * list.add(reportVo);
	 * 
	 * } } catch (Exception e) { e.printStackTrace(); throw e; } finally {
	 * DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet); }
	 * logger.info(ActionConstants.EXITING_METHOD +
	 * "<<generateDetailedTableReport DB Helper"); return list;
	 * 
	 * }
	 */
	/*
	 * public void generateSummaryReportInExcel(String query) throws Exception {
	 * logger.info(ActionConstants.ENTERING_METHOD +
	 * "<<generateSummaryReportInExcel DB Helper");
	 * 
	 * Connection aConnection = null; PreparedStatement aPreparedStatement =
	 * null; ResultSet aResultSet = null;
	 * 
	 * try {
	 * 
	 * aConnection = DBUtility.getZoneConnection(); aPreparedStatement =
	 * aConnection.prepareStatement(query);
	 * 
	 * aResultSet = aPreparedStatement.executeQuery();
	 * System.out.println("-----query------>" + query);
	 * 
	 * HttpServletResponse response = (HttpServletResponse) ActionContext
	 * .getContext().get(ServletActionContext.HTTP_RESPONSE);
	 * 
	 * HSSFWorkbook wb = new HSSFWorkbook(); HSSFSheet sheet = wb.createSheet();
	 * HSSFRow row = sheet.createRow(0); CellStyle style = wb.createCellStyle();
	 * style.setWrapText(true);
	 * 
	 * sheet.addMergedRegion(new CellRangeAddress(0, // first row (0-based) 0,
	 * // last row (0-based) 0, // first column (0-based) 4 // last column
	 * (0-based) ));
	 * 
	 * row = sheet.createRow(0); HSSFCell cell = row.createCell(0); cell =
	 * row.createCell(0); cell.setCellValue("ILC REPORT"); row =
	 * sheet.createRow(1); cell = row.createCell(0);
	 * cell.setCellValue("TRANSACTION TYPE"); cell = row.createCell(1);
	 * cell.setCellValue("FREQUENCY RANGE"); cell = row.createCell(2);
	 * cell.setCellValue("COUNT");
	 * 
	 * int i = 2;
	 * 
	 * while (aResultSet.next()) {
	 * 
	 * row = sheet.createRow(i);
	 * 
	 * cell = row.createCell(0); cell.setCellValue(aResultSet.getString(1));
	 * cell = row.createCell(1); cell.setCellValue(aResultSet.getString(2));
	 * cell = row.createCell(2); cell.setCellValue(aResultSet.getString(3));
	 * 
	 * i++;
	 * 
	 * }
	 * 
	 * ByteArrayOutputStream outByteStream = new ByteArrayOutputStream();
	 * wb.write(outByteStream); byte[] outArray = outByteStream.toByteArray();
	 * 
	 * response.setContentType("application/ms-excel");
	 * response.setContentLength(outArray.length);
	 * 
	 * response.setHeader("Expires:", "0"); // eliminates browser caching
	 * response.setHeader("Content-Disposition",
	 * "attachment; filename=ILCReport.xls"); OutputStream outStream =
	 * response.getOutputStream(); logger.info("Before write" +
	 * outArray.length); outStream.write(outArray);
	 * 
	 * logger.info("After write"); outStream.flush(); } catch (Exception e) {
	 * e.printStackTrace(); throw e; } finally {
	 * DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
	 * 
	 * } logger.info(ActionConstants.EXITING_METHOD +
	 * "<<generateSummaryReportInExcel DB Helper"); }
	 */

//	public void generateSummaryReportInExcel(String summaryReportQuery)
//			throws Exception {
//		logger.info(ActionConstants.ENTERING_METHOD
//				+ "<<generateSummaryReportInExcel DB Helper");
//
//		Connection aConnection = null;
//		PreparedStatement aPreparedStatement = null;
//		ResultSet aResultSet = null;
//
//		try {
//
//			aConnection = DBUtility.getZoneConnection();
//			aPreparedStatement = aConnection
//					.prepareStatement(summaryReportQuery);
//
//			aResultSet = aPreparedStatement.executeQuery();
//			System.out.println("-----query------>" + summaryReportQuery);
//
//			HttpServletResponse response = (HttpServletResponse) ActionContext
//					.getContext().get(ServletActionContext.HTTP_RESPONSE);
//
//			HSSFWorkbook wb = new HSSFWorkbook();
//			HSSFSheet sheet = wb.createSheet();
//			HSSFRow row = sheet.createRow(0);
//			CellStyle style = wb.createCellStyle();
//			style.setWrapText(true);
//
//			sheet.addMergedRegion(new CellRangeAddress(0, // first row (0-based)
//					0, // last row (0-based)
//					0, // first column (0-based)
//					4 // last column (0-based)
//			));
//
//			row = sheet.createRow(0);
//			HSSFCell cell = row.createCell(0);
//			cell = row.createCell(0);
//			cell.setCellValue("SUMMARY REPORT");
//			row = sheet.createRow(1);
//			cell = row.createCell(0);
//			cell.setCellValue("TRANSACTION TYPE");
//			cell = row.createCell(1);
//			cell.setCellValue("FREQUENCY RANGE");
//			cell = row.createCell(2);
//			cell.setCellValue("COUNT");
//
//			int i = 2;
//
//			while (aResultSet.next()) {
//
//				row = sheet.createRow(i);
//
//				cell = row.createCell(0);
//				cell.setCellValue(aResultSet.getString(1));
//				cell = row.createCell(1);
//				cell.setCellValue(aResultSet.getString(2));
//				cell = row.createCell(2);
//				cell.setCellValue(aResultSet.getString(4));
//
//				i++;
//
//			}
//
//			ByteArrayOutputStream outByteStream = new ByteArrayOutputStream();
//			wb.write(outByteStream);
//			byte[] outArray = outByteStream.toByteArray();
//
//			response.setContentType("application/ms-excel");
//			response.setContentLength(outArray.length);
//
//			response.setHeader("Expires:", "0"); // eliminates browser caching
//			response.setHeader("Content-Disposition",
//					"attachment; filename=SummaryReport.xls");
//			OutputStream outStream = response.getOutputStream();
//			logger.info("Before write" + outArray.length);
//			outStream.write(outArray);
//
//			logger.info("After write");
//			outStream.flush();
//
//		} catch (Exception e) {
//			e.printStackTrace();
//			throw e;
//		} finally {
//			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
//
//		}
//		logger.info(ActionConstants.EXITING_METHOD
//				+ "<<generateSummaryReportInExcel DB Helper");
//	}

	/*
	 * public void generateDetailedReportInExcel(String query) throws Exception
	 * { logger.info(ActionConstants.ENTERING_METHOD +
	 * "<<generateReportInGridExcel DB Helper");
	 * 
	 * Connection aConnection = null; PreparedStatement aPreparedStatement =
	 * null; ResultSet aResultSet = null;
	 * 
	 * try {
	 * 
	 * aConnection = DBUtility.getZoneConnection(); aPreparedStatement =
	 * aConnection.prepareStatement(query);
	 * 
	 * aResultSet = aPreparedStatement.executeQuery();
	 * logger.info("-----query------>" + query);
	 * 
	 * HttpServletResponse response = (HttpServletResponse) ActionContext
	 * .getContext().get(ServletActionContext.HTTP_RESPONSE);
	 * 
	 * HSSFWorkbook wb = new HSSFWorkbook(); HSSFSheet sheet = wb.createSheet();
	 * HSSFRow row = sheet.createRow(0); CellStyle style = wb.createCellStyle();
	 * style.setWrapText(true);
	 * 
	 * sheet.addMergedRegion(new CellRangeAddress(0, // first row (0-based) 0,
	 * // last row (0-based) 0, // first column (0-based) 12 // last column
	 * (0-based) ));
	 * 
	 * row = sheet.createRow(0); HSSFCell cell = row.createCell(0); cell =
	 * row.createCell(0); cell.setCellValue("ILC REPORT"); row =
	 * sheet.createRow(1); cell = row.createCell(0);
	 * cell.setCellValue("REQUEST TYPE"); cell = row.createCell(1);
	 * cell.setCellValue("SUB PRODUCT"); cell = row.createCell(2);
	 * cell.setCellValue("REQUEST ID"); cell = row.createCell(3);
	 * cell.setCellValue("FINACLE TRANSACTION NO"); cell = row.createCell(4);
	 * cell.setCellValue("TRANSACTION GENERATED TIME"); cell =
	 * row.createCell(5); cell.setCellValue("SOL ID"); cell = row.createCell(6);
	 * cell.setCellValue("BRANCH ALPHA"); cell = row.createCell(7);
	 * cell.setCellValue("CUSTOMER NAME"); cell = row.createCell(8);
	 * cell.setCellValue("CURRENCY"); cell = row.createCell(9);
	 * cell.setCellValue("TRANSACTION AMOUNT"); cell = row.createCell(10);
	 * cell.setCellValue("STATUS"); cell = row.createCell(11);
	 * cell.setCellValue("STATUS CHANGED BY"); cell = row.createCell(12);
	 * cell.setCellValue("STATUS CHANGED TIME"); cell = row.createCell(13);
	 * cell.setCellValue("REQUEST CYCLE");
	 * 
	 * int i = 2;
	 * 
	 * while (aResultSet.next()) {
	 * 
	 * row = sheet.createRow(i);
	 * 
	 * cell = row.createCell(0); cell.setCellValue(aResultSet.getString(1));
	 * cell = row.createCell(1); cell.setCellValue(aResultSet.getString(2));
	 * cell = row.createCell(2); cell.setCellValue(aResultSet.getString(3));
	 * cell = row.createCell(3); cell.setCellValue(aResultSet.getString(4));
	 * cell = row.createCell(4); cell.setCellValue(aResultSet.getString(5));
	 * cell = row.createCell(5); cell.setCellValue(aResultSet.getString(6));
	 * cell = row.createCell(6); cell.setCellValue(aResultSet.getString(7));
	 * cell = row.createCell(7); cell.setCellValue(aResultSet.getString(8));
	 * cell = row.createCell(8); cell.setCellValue(aResultSet.getString(9));
	 * cell = row.createCell(9); cell.setCellValue(aResultSet.getString(10));
	 * cell = row.createCell(10); cell.setCellValue(aResultSet.getString(11));
	 * cell = row.createCell(11); cell.setCellValue(aResultSet.getString(12));
	 * cell = row.createCell(12); cell.setCellValue(aResultSet.getString(13));
	 * cell = row.createCell(13); cell.setCellValue(aResultSet.getString(14));
	 * 
	 * i++;
	 * 
	 * }
	 * 
	 * ByteArrayOutputStream outByteStream = new ByteArrayOutputStream();
	 * wb.write(outByteStream); byte[] outArray = outByteStream.toByteArray();
	 * 
	 * response.setContentType("application/ms-excel");
	 * response.setContentLength(outArray.length);
	 * 
	 * response.setHeader("Expires:", "0"); // eliminates browser caching
	 * response.setHeader("Content-Disposition",
	 * "attachment; filename=ILCReport.xls"); OutputStream outStream =
	 * response.getOutputStream(); logger.info("Before write" +
	 * outArray.length); outStream.write(outArray);
	 * 
	 * logger.info("After write"); outStream.flush(); } catch (Exception e) {
	 * e.printStackTrace(); throw e; } finally {
	 * DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
	 * 
	 * } logger.info(ActionConstants.EXITING_METHOD +
	 * "<<generateReportInGridExcel DB Helper"); }
	 */

	// Report 23012020 ends

	/*
	 * public List<TFBOReminderVO> getTFBOIReminderDetailsFromDB(String query) {
	 * 
	 * TFBOReminderVO aTFBOReminderVO = null; Connection aConnection = null;
	 * ResultSet aResultSet = null; PreparedStatement aPreparedStatement = null;
	 * List<TFBOReminderVO> reminder = new LinkedList<TFBOReminderVO>();
	 * System.out.println("into getTFBOIReminderDetailsFromDB from dbhelper");
	 * try { aConnection = DBUtility.getZoneConnection(); aPreparedStatement =
	 * aConnection.prepareStatement(query); System.out.println("query-->" +
	 * query); aResultSet = aPreparedStatement.executeQuery(); while
	 * (aResultSet.next()) {
	 * 
	 * aTFBOReminderVO = new TFBOReminderVO();
	 * aTFBOReminderVO.setTranId(aResultSet.getString(1));
	 * aTFBOReminderVO.setRequestId(aResultSet.getString(2));
	 * aTFBOReminderVO.setTiReference(aResultSet.getString(3));
	 * aTFBOReminderVO.setProdDescription(aResultSet.getString(4));
	 * aTFBOReminderVO.setEvtDescription(aResultSet.getString(5));
	 * aTFBOReminderVO.setStepStatus(aResultSet.getString(6));
	 * aTFBOReminderVO.setTransCreated(aResultSet.getString(7));
	 * aTFBOReminderVO.setTransModified(aResultSet.getString(8));
	 * aTFBOReminderVO.setSubProductCode(aResultSet.getString(9));
	 * aTFBOReminderVO.setSolId(aResultSet.getString(10));
	 * aTFBOReminderVO.setEmailId(aResultSet.getString(11));
	 * aTFBOReminderVO.setBranchName(aResultSet.getString(12));
	 * aTFBOReminderVO.setCity(aResultSet.getString(13));
	 * aTFBOReminderVO.setProductCode(aResultSet.getString(14));
	 * aTFBOReminderVO.setEventCode(aResultSet.getString(15));
	 * reminder.add(aTFBOReminderVO);
	 * 
	 * } } catch (Exception e) { e.printStackTrace(); } finally {
	 * DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet); }
	 * System.out.println(ActionConstants.EXITING_METHOD + "  " +
	 * reminder.size()); return reminder;
	 * 
	 * }
	 */
	public List<TFBOReminderVO> getTFBOIReminderDetailsFromDB(String query,
			String productCode) {

		TFBOReminderVO aTFBOReminderVO = null;
		Connection aConnection = null;
		ResultSet aResultSet = null;
		PreparedStatement aPreparedStatement = null;
		List<TFBOReminderVO> reminder = new LinkedList<TFBOReminderVO>();
		System.out.println("into getTFBOIReminderDetailsFromDB from dbhelper");
		try {
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);
			System.out.println("query-->" + query);
			aPreparedStatement.setString(1, productCode.trim());
			aResultSet = aPreparedStatement.executeQuery();

			while (aResultSet.next()) {

				aTFBOReminderVO = new TFBOReminderVO();
				aTFBOReminderVO.setTranId(aResultSet.getString(1));
				aTFBOReminderVO.setRequestId(aResultSet.getString(2));
				aTFBOReminderVO.setTiReference(aResultSet.getString(3));
				aTFBOReminderVO.setProdDescription(aResultSet.getString(4));
				aTFBOReminderVO.setEvtDescription(aResultSet.getString(5));
				aTFBOReminderVO.setStepStatus(aResultSet.getString(6));
				aTFBOReminderVO.setTransCreated(aResultSet.getString(7));
				aTFBOReminderVO.setTransModified(aResultSet.getString(8));
				aTFBOReminderVO.setSubProductCode(aResultSet.getString(9));
				aTFBOReminderVO.setSolId(aResultSet.getString(10));
				aTFBOReminderVO.setEmailId(aResultSet.getString(11));
				aTFBOReminderVO.setBranchName(aResultSet.getString(12));
				aTFBOReminderVO.setCity(aResultSet.getString(13));
				aTFBOReminderVO.setProductCode(aResultSet.getString(14));
				aTFBOReminderVO.setEventCode(aResultSet.getString(15));
				reminder.add(aTFBOReminderVO);

			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}
		System.out.println(ActionConstants.EXITING_METHOD + "  "
				+ reminder.size());
		return reminder;

	}

	public List<TFBOReminderVO> getcusDetailsFromDB(String requestId,
			String query) {
		// TFBOReminderVO aTFBOReminderVO = null;
		Connection aConnection = null;
		ResultSet aResultSet = null;
		PreparedStatement aPreparedStatement = null;

		System.out.println("---------DB Helper------" + requestId);
		List<TFBOReminderVO> custReminderDetails = new LinkedList<TFBOReminderVO>();
		try {
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);
			aPreparedStatement.setString(1, requestId.trim());
			aResultSet = aPreparedStatement.executeQuery();
			while (aResultSet.next()) {
				TFBOReminderVO aTFBOReminderVO = new TFBOReminderVO();
				aTFBOReminderVO.setSolId(aResultSet.getString(1));
				aTFBOReminderVO.setCustomeCif(aResultSet.getString(2));
				aTFBOReminderVO.setCustomeName(aResultSet.getString(3));
				aTFBOReminderVO.setAmount(aResultSet.getString(4));
				custReminderDetails.add(aTFBOReminderVO);

			}

			System.out.println("-------size cutstlst------"
					+ custReminderDetails.size());
		}

		catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}
		return custReminderDetails;
	}

	public void setValueODCFlow(String value1, String value2, String value3,
			String value4, String value5, String value6, String query)
			throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD + "setValueInDB");
		Connection aConnection = null;
		ResultSet aResultSet = null;
		PreparedStatement aPreparedStatement = null;

		try {
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);
			logger.info("query-->" + query);
			aPreparedStatement.setString(1, value1);
			aPreparedStatement.setString(2, value2);
			aPreparedStatement.setString(3, value3);
			aPreparedStatement.setString(4, value4);
			aPreparedStatement.setString(5, value5);
			aPreparedStatement.setString(6, value6.trim());
			aPreparedStatement.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}
		logger.info(ActionConstants.EXITING_METHOD + "setValueInDB");
	}

	public void setValueIDCFlow(String value1, String value2, String value3,
			String query) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD + "setValueInDB");
		Connection aConnection = null;
		ResultSet aResultSet = null;
		PreparedStatement aPreparedStatement = null;

		try {
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);
			logger.info("query-->" + query);
			aPreparedStatement.setString(1, value1);
			aPreparedStatement.setString(2, value2);
			aPreparedStatement.setString(3, value3.trim());
			aPreparedStatement.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}
		logger.info(ActionConstants.EXITING_METHOD + "setValueInDB");
	}

	public void setValueELCFlow(String value1, String value2, String value3,
			String query) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD + "setValueInDB");
		Connection aConnection = null;
		ResultSet aResultSet = null;
		PreparedStatement aPreparedStatement = null;

		try {
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);
			logger.info("query-->" + query);
			aPreparedStatement.setString(1, value1);
			aPreparedStatement.setString(2, value2);
			aPreparedStatement.setString(3, value3.trim());
			aPreparedStatement.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}
		logger.info(ActionConstants.EXITING_METHOD + "setValueInDB");
	}

	public List<TFBOSandbyLcVO> getTFBOISB_NIS_KIS_FromDB(String requestId,
			String query) {
		logger.info(ActionConstants.ENTERING_METHOD + " requestId->"
				+ requestId);
		TFBOSandbyLcVO aTFBOSandbyLcVO = null;
		Connection aConnection = null;
		ResultSet aResultSet = null;
		PreparedStatement aPreparedStatement = null;
		List<TFBOSandbyLcVO> isbnisList = new LinkedList<TFBOSandbyLcVO>();

		try {
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);
			logger.info("query-->" + query);
			aPreparedStatement.setString(1, requestId.trim());
			aResultSet = aPreparedStatement.executeQuery();
			while (aResultSet.next()) {
				aTFBOSandbyLcVO = new TFBOSandbyLcVO();
				aTFBOSandbyLcVO.setTiReferanceNo(aResultSet.getString(1));
				aTFBOSandbyLcVO.setSolID(aResultSet.getString(2));
				aTFBOSandbyLcVO.setCustomeCif(aResultSet.getString(3));
				aTFBOSandbyLcVO.setAmount(aResultSet.getString(4));
				aTFBOSandbyLcVO.setCurrency(aResultSet.getString(5));
				aTFBOSandbyLcVO.setTenure(aResultSet.getString(6));
				aTFBOSandbyLcVO.setSubProductCode(aResultSet.getString(7)
						.trim());
				isbnisList.add(aTFBOSandbyLcVO);
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}

		logger.info(ActionConstants.EXITING_METHOD + "   ISB  "
				+ isbnisList.size());
		return isbnisList;

	}

	public void setISBClosurenDB(String requestId, String solID,
			String tiReferanceNo, String customeCif, String customeName,
			String tenure, String amount, String currency,
			String subProductCode, String query) {
		logger.info(ActionConstants.ENTERING_METHOD + "setValueInDB");
		Connection aConnection = null;
		ResultSet aResultSet = null;
		PreparedStatement aPreparedStatement = null;
		try {
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);
			logger.info("query-->" + query);
			aPreparedStatement.setString(1, solID);
			aPreparedStatement.setString(2, tiReferanceNo);
			aPreparedStatement.setString(3, customeCif);
			aPreparedStatement.setString(4, customeName);
			aPreparedStatement.setString(5, tenure);
			aPreparedStatement.setString(6, amount);
			aPreparedStatement.setString(7, currency);
			aPreparedStatement.setString(8, subProductCode);
			aPreparedStatement.setString(9, requestId.trim());
			aPreparedStatement.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();

		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}
		logger.info(ActionConstants.EXITING_METHOD + "setValueInDB");

	}

	public List<TFBOSandbyLcVO> getTFBOISBKISFromDB(String requestId,
			String query) {
		logger.info(ActionConstants.ENTERING_METHOD + " requestId->"
				+ requestId);
		TFBOSandbyLcVO aTFBOSandbyLcVO = null;
		Connection aConnection = null;
		ResultSet aResultSet = null;
		PreparedStatement aPreparedStatement = null;
		List<TFBOSandbyLcVO> isbkisList = new LinkedList<TFBOSandbyLcVO>();
		try {
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);
			logger.info("query-->" + query);
			aPreparedStatement.setString(1, requestId.trim());
			aResultSet = aPreparedStatement.executeQuery();
			while (aResultSet.next()) {
				aTFBOSandbyLcVO = new TFBOSandbyLcVO();
				aTFBOSandbyLcVO.setTiReferanceNo(aResultSet.getString(1));
				aTFBOSandbyLcVO.setSolID(aResultSet.getString(2));
				aTFBOSandbyLcVO.setCustomeCif(aResultSet.getString(3));
				aTFBOSandbyLcVO.setAmount(aResultSet.getString(4));
				aTFBOSandbyLcVO.setCurrency(aResultSet.getString(5));
				aTFBOSandbyLcVO.setTenure(aResultSet.getString(6));
				aTFBOSandbyLcVO.setSubProductCode(aResultSet.getString(7)
						.trim());
				isbkisList.add(aTFBOSandbyLcVO);
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}

		logger.info(ActionConstants.EXITING_METHOD + "   ISB  "
				+ isbkisList.size());
		return isbkisList;

	}

	public void setISBCancelInDB(String requestId, String solID,
			String tiReferanceNo, String customeCif, String customeName,
			String tenure, String amount, String currency,
			String subProductCode, String query) {
		logger.info(ActionConstants.ENTERING_METHOD + "setValueInDB");
		Connection aConnection = null;
		ResultSet aResultSet = null;
		PreparedStatement aPreparedStatement = null;
		try {
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);
			logger.info("query-->" + query);
			aPreparedStatement.setString(1, solID);
			aPreparedStatement.setString(2, tiReferanceNo);
			aPreparedStatement.setString(3, customeCif);
			aPreparedStatement.setString(4, customeName);
			aPreparedStatement.setString(5, tenure);
			aPreparedStatement.setString(6, amount);
			aPreparedStatement.setString(7, currency);
			aPreparedStatement.setString(8, subProductCode);
			aPreparedStatement.setString(9, requestId.trim());
			aPreparedStatement.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();

		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}
		logger.info(ActionConstants.EXITING_METHOD + "setValueInDB");

	}

	public List<TFBOSandbyLcVO> getTFBOISBNISFromDB(String requestId,
			String query) {

		logger.info(ActionConstants.ENTERING_METHOD + " requestId->"
				+ requestId);
		TFBOSandbyLcVO aTFBOSandbyLcVO = null;
		Connection aConnection = null;
		ResultSet aResultSet = null;
		PreparedStatement aPreparedStatement = null;
		List<TFBOSandbyLcVO> isbkisList = new LinkedList<TFBOSandbyLcVO>();
		try {
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);
			logger.info("query-->" + query);
			aPreparedStatement.setString(1, requestId.trim());
			aResultSet = aPreparedStatement.executeQuery();
			while (aResultSet.next()) {
				aTFBOSandbyLcVO = new TFBOSandbyLcVO();
				aTFBOSandbyLcVO.setTiReferanceNo(aResultSet.getString(1));
				aTFBOSandbyLcVO.setSolID(aResultSet.getString(2));
				aTFBOSandbyLcVO.setCustomeCif(aResultSet.getString(3));
				aTFBOSandbyLcVO.setAmount(aResultSet.getString(4));
				aTFBOSandbyLcVO.setCurrency(aResultSet.getString(5));
				aTFBOSandbyLcVO.setTenure(aResultSet.getString(6));
				aTFBOSandbyLcVO.setSubProductCode(aResultSet.getString(7)
						.trim());
				isbkisList.add(aTFBOSandbyLcVO);
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}

		logger.info(ActionConstants.EXITING_METHOD + "   ISB  "
				+ isbkisList.size());
		return isbkisList;
	}

	// REPORTS
	public List<ReportVO> generateILCDetailedReportInGrid(String query,
			ReportVO reportVo) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD
				+ "<<generateILCDetailedReportInGrid DB Helper");

		List<ReportVO> ilcDetailedReportList = null;
		Connection aConnection = null;
		PreparedStatement aPreparedStatement = null;
		ResultSet aResultSet = null;

		try {
			ilcDetailedReportList = new ArrayList<ReportVO>();

			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);

			aResultSet = aPreparedStatement.executeQuery();
			while (aResultSet.next()) {
				reportVo = new ReportVO();
				reportVo.setRequestType(aResultSet.getString(1));
				reportVo.setSubProduct(aResultSet.getString(2));
				reportVo.setRequestId(aResultSet.getString(3));
				reportVo.setFinacleTranNo(aResultSet.getString(4));
				reportVo.setTransTime(aResultSet.getString(5));
				reportVo.setSolid(aResultSet.getString(6));
				reportVo.setBranchAlpha(aResultSet.getString(7));
				reportVo.setCustomerName(aResultSet.getString(8));
				reportVo.setCurrencyDetailed(aResultSet.getString(9));
				reportVo.setTransAmt(aResultSet.getString(10));
				reportVo.setStatus(aResultSet.getString(11));
				reportVo.setStatusChangeBy(aResultSet.getString(12));
				reportVo.setInputuser(aResultSet.getString(13));
				reportVo.setReviewuser(aResultSet.getString(14));
				reportVo.setAuthuser(aResultSet.getString(15));
				reportVo.setFbomaker(aResultSet.getString(16));
				reportVo.setFbochecker(aResultSet.getString(17));
				reportVo.setStatusChangeTime(aResultSet.getString(18));
				reportVo.setRequestCycle(aResultSet.getString(19));
				reportVo.setSenderRefNo("");
				reportVo.setDummyIrex("");
				reportVo.setIfPcfc("");
				reportVo.setAmendNo("");
				reportVo.setUnderLc("");
				reportVo.setDocDisNonDis("");

				ilcDetailedReportList.add(reportVo);

			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}
		logger.info(ActionConstants.EXITING_METHOD
				+ "<<generateILCDetailedReportInGrid DB Helper");
		return ilcDetailedReportList;

	}

	public List<ReportVO> generateELCDetailedReportInGrid(String query,
			ReportVO reportVo) throws Exception {

		logger.info(ActionConstants.ENTERING_METHOD
				+ "<<generateELCDetailedReportInGrid DB Helper");

		List<ReportVO> elcDetailedReportList = null;
		Connection aConnection = null;
		PreparedStatement aPreparedStatement = null;
		ResultSet aResultSet = null;

		try {
			elcDetailedReportList = new ArrayList<ReportVO>();

			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);

			aResultSet = aPreparedStatement.executeQuery();
			while (aResultSet.next()) {
				reportVo = new ReportVO();

				reportVo.setRequestType(aResultSet.getString(1));
				reportVo.setSubProduct(aResultSet.getString(2));
				reportVo.setRequestId(aResultSet.getString(3));
				reportVo.setFinacleTranNo(aResultSet.getString(4));
				reportVo.setTransTime(aResultSet.getString(5));
				reportVo.setSolid(aResultSet.getString(6));
				reportVo.setBranchAlpha(aResultSet.getString(7));
				reportVo.setCustomerName(aResultSet.getString(8));
				reportVo.setCurrencyDetailed(aResultSet.getString(9));
				reportVo.setTransAmt(aResultSet.getString(10));
				reportVo.setStatus(aResultSet.getString(11));
				reportVo.setStatusChangeBy(aResultSet.getString(12));
				reportVo.setInputuser(aResultSet.getString(13));
				reportVo.setReviewuser(aResultSet.getString(14));
				reportVo.setAuthuser(aResultSet.getString(15));
				reportVo.setFbomaker(aResultSet.getString(16));
				reportVo.setFbochecker(aResultSet.getString(17));
				reportVo.setStatusChangeTime(aResultSet.getString(18));
				reportVo.setRequestCycle(aResultSet.getString(19));
				reportVo.setSenderRefNo(aResultSet.getString(20));
				reportVo.setDummyIrex("");
				reportVo.setIfPcfc("");
				reportVo.setAmendNo("");
				reportVo.setUnderLc("");
				reportVo.setDocDisNonDis("");

				elcDetailedReportList.add(reportVo);

			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}
		logger.info(ActionConstants.EXITING_METHOD
				+ "<<generateELCDetailedReportInGrid DB Helper");
		return elcDetailedReportList;

	}

	public List<ReportVO> generateFOCDetailedReportInGrid(String query,
			ReportVO reportVo) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD
				+ "<<generateFOCDetailedReportInGrid DB Helper");

		List<ReportVO> focDetailedReportList = null;
		Connection aConnection = null;
		PreparedStatement aPreparedStatement = null;
		ResultSet aResultSet = null;

		try {
			focDetailedReportList = new ArrayList<ReportVO>();

			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);

			aResultSet = aPreparedStatement.executeQuery();
			while (aResultSet.next()) {
				reportVo = new ReportVO();

				reportVo.setRequestType(aResultSet.getString(1));
				reportVo.setSubProduct(aResultSet.getString(2));
				reportVo.setRequestId(aResultSet.getString(3));
				reportVo.setFinacleTranNo(aResultSet.getString(4));
				reportVo.setTransTime(aResultSet.getString(5));
				reportVo.setSolid(aResultSet.getString(6));
				reportVo.setBranchAlpha(aResultSet.getString(7));
				reportVo.setCustomerName(aResultSet.getString(8));
				reportVo.setCurrencyDetailed(aResultSet.getString(9));
				reportVo.setTransAmt(aResultSet.getString(10));
				reportVo.setStatus(aResultSet.getString(11));
				reportVo.setStatusChangeBy(aResultSet.getString(12));
				reportVo.setInputuser(aResultSet.getString(13));
				reportVo.setReviewuser(aResultSet.getString(14));
				reportVo.setAuthuser(aResultSet.getString(15));
				reportVo.setFbomaker(aResultSet.getString(16));
				reportVo.setFbochecker(aResultSet.getString(17));
				reportVo.setStatusChangeTime(aResultSet.getString(18));
				reportVo.setRequestCycle(aResultSet.getString(19));
				reportVo.setSenderRefNo(aResultSet.getString(20));
				reportVo.setDummyIrex("");
				reportVo.setIfPcfc("");
				reportVo.setAmendNo("");
				reportVo.setUnderLc("");
				reportVo.setDocDisNonDis("");

				focDetailedReportList.add(reportVo);

			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}
		logger.info(ActionConstants.EXITING_METHOD
				+ "<<generateFOCDetailedReportInGrid DB Helper");
		return focDetailedReportList;

	}

	public List<ReportVO> generateISBDetailedReportInGrid(String query,
			ReportVO reportVo) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD
				+ "<<generateISBDetailedReportInGrid DB Helper");

		List<ReportVO> isbDetailedReportList = null;
		Connection aConnection = null;
		PreparedStatement aPreparedStatement = null;
		ResultSet aResultSet = null;

		try {
			isbDetailedReportList = new ArrayList<ReportVO>();

			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);

			aResultSet = aPreparedStatement.executeQuery();
			while (aResultSet.next()) {
				reportVo = new ReportVO();

				reportVo.setRequestType(aResultSet.getString(1));
				reportVo.setSubProduct(aResultSet.getString(2));
				reportVo.setRequestId(aResultSet.getString(3));
				reportVo.setFinacleTranNo(aResultSet.getString(4));
				reportVo.setTransTime(aResultSet.getString(5));
				reportVo.setSolid(aResultSet.getString(6));
				reportVo.setBranchAlpha(aResultSet.getString(7));
				reportVo.setCustomerName(aResultSet.getString(8));
				reportVo.setCurrencyDetailed(aResultSet.getString(9));
				reportVo.setTransAmt(aResultSet.getString(10));
				reportVo.setStatus(aResultSet.getString(11));
				reportVo.setStatusChangeBy(aResultSet.getString(12));
				reportVo.setInputuser(aResultSet.getString(13));
				reportVo.setReviewuser(aResultSet.getString(14));
				reportVo.setAuthuser(aResultSet.getString(15));
				reportVo.setFbomaker(aResultSet.getString(16));
				reportVo.setFbochecker(aResultSet.getString(17));
				reportVo.setStatusChangeTime(aResultSet.getString(18));
				reportVo.setRequestCycle(aResultSet.getString(19));
				reportVo.setSenderRefNo("");
				reportVo.setDummyIrex("");
				reportVo.setIfPcfc("");
				reportVo.setAmendNo("");
				reportVo.setUnderLc("");
				reportVo.setDocDisNonDis("");

				isbDetailedReportList.add(reportVo);

			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}
		logger.info(ActionConstants.EXITING_METHOD
				+ "<<generateISBDetailedReportInGrid DB Helper");
		return isbDetailedReportList;

	}

	public List<ReportVO> generateFSADetailedReportInGrid(String query,
			ReportVO reportVo) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD
				+ "<<generateFSADetailedReportInGrid DB Helper");

		List<ReportVO> fsaDetailedReportList = null;
		Connection aConnection = null;
		PreparedStatement aPreparedStatement = null;
		ResultSet aResultSet = null;

		try {
			fsaDetailedReportList = new ArrayList<ReportVO>();

			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);

			aResultSet = aPreparedStatement.executeQuery();
			while (aResultSet.next()) {
				reportVo = new ReportVO();

				reportVo.setRequestType(aResultSet.getString(1));
				reportVo.setSubProduct(aResultSet.getString(2));
				reportVo.setRequestId(aResultSet.getString(3));
				reportVo.setFinacleTranNo(aResultSet.getString(4));
				reportVo.setTransTime(aResultSet.getString(5));
				reportVo.setSolid(aResultSet.getString(6));
				reportVo.setBranchAlpha(aResultSet.getString(7));
				reportVo.setCustomerName(aResultSet.getString(8));
				reportVo.setCurrencyDetailed(aResultSet.getString(9));
				reportVo.setTransAmt(aResultSet.getString(10));
				reportVo.setStatus(aResultSet.getString(11));
				reportVo.setStatusChangeBy(aResultSet.getString(12));
				reportVo.setInputuser(aResultSet.getString(13));
				reportVo.setReviewuser(aResultSet.getString(14));
				reportVo.setAuthuser(aResultSet.getString(15));
				reportVo.setFbomaker(aResultSet.getString(16));
				reportVo.setFbochecker(aResultSet.getString(17));
				reportVo.setStatusChangeTime(aResultSet.getString(18));
				reportVo.setRequestCycle(aResultSet.getString(19));
				reportVo.setSenderRefNo("");
				reportVo.setDummyIrex("");
				reportVo.setIfPcfc("");
				reportVo.setAmendNo("");
				reportVo.setUnderLc("");
				reportVo.setDocDisNonDis("");

				fsaDetailedReportList.add(reportVo);

			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}
		logger.info(ActionConstants.EXITING_METHOD
				+ "<<generateFSADetailedReportInGrid DB Helper");
		return fsaDetailedReportList;

	}

	public List<ReportVO> generateIDCDetailedReportInGrid(String query,
			ReportVO reportVo) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD
				+ "<<generateIDCDetailedReportInGrid DB Helper");

		List<ReportVO> idcDetailedReportList = null;
		Connection aConnection = null;
		PreparedStatement aPreparedStatement = null;
		ResultSet aResultSet = null;

		try {
			idcDetailedReportList = new ArrayList<ReportVO>();

			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);

			aResultSet = aPreparedStatement.executeQuery();
			while (aResultSet.next()) {
				reportVo = new ReportVO();

				reportVo.setRequestType(aResultSet.getString(1));
				reportVo.setSubProduct(aResultSet.getString(2));
				reportVo.setRequestId(aResultSet.getString(3));
				reportVo.setFinacleTranNo(aResultSet.getString(4));
				reportVo.setTransTime(aResultSet.getString(5));
				reportVo.setSolid(aResultSet.getString(6));
				reportVo.setBranchAlpha(aResultSet.getString(7));
				reportVo.setCustomerName(aResultSet.getString(8));
				reportVo.setCurrencyDetailed(aResultSet.getString(9));
				reportVo.setTransAmt(aResultSet.getString(10));
				reportVo.setStatus(aResultSet.getString(11));
				reportVo.setStatusChangeBy(aResultSet.getString(12));
				reportVo.setInputuser(aResultSet.getString(13));
				reportVo.setReviewuser(aResultSet.getString(14));
				reportVo.setAuthuser(aResultSet.getString(15));
				reportVo.setFbomaker(aResultSet.getString(16));
				reportVo.setFbochecker(aResultSet.getString(17));
				reportVo.setStatusChangeTime(aResultSet.getString(18));
				reportVo.setRequestCycle(aResultSet.getString(19));
				reportVo.setSenderRefNo("");
				reportVo.setDummyIrex("");
				reportVo.setIfPcfc("");
				reportVo.setAmendNo("");
				reportVo.setUnderLc("");
				reportVo.setDocDisNonDis("");

				idcDetailedReportList.add(reportVo);

			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}
		logger.info(ActionConstants.EXITING_METHOD
				+ "<<generateIDCDetailedReportInGrid DB Helper");
		return idcDetailedReportList;

	}

	public List<ReportVO> generateODCDetailedReportInGrid(String query,
			ReportVO reportVo) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD
				+ "<<generateODCDetailedReportInGrid DB Helper");

		List<ReportVO> odcDetailedReportList = null;
		Connection aConnection = null;
		PreparedStatement aPreparedStatement = null;
		ResultSet aResultSet = null;

		try {
			odcDetailedReportList = new ArrayList<ReportVO>();

			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);

			aResultSet = aPreparedStatement.executeQuery();
			while (aResultSet.next()) {
				reportVo = new ReportVO();
				reportVo.setRequestType(aResultSet.getString(1));
				reportVo.setSubProduct(aResultSet.getString(2));
				reportVo.setRequestId(aResultSet.getString(3));
				reportVo.setFinacleTranNo(aResultSet.getString(4));
				reportVo.setTransTime(aResultSet.getString(5));
				reportVo.setSolid(aResultSet.getString(6));
				reportVo.setBranchAlpha(aResultSet.getString(7));
				reportVo.setCustomerName(aResultSet.getString(8));
				reportVo.setCurrencyDetailed(aResultSet.getString(9));
				reportVo.setTransAmt(aResultSet.getString(10));
				reportVo.setStatus(aResultSet.getString(11));
				reportVo.setStatusChangeBy(aResultSet.getString(12));
				reportVo.setInputuser(aResultSet.getString(13));
				reportVo.setReviewuser(aResultSet.getString(14));
				reportVo.setAuthuser(aResultSet.getString(15));
				reportVo.setFbomaker(aResultSet.getString(16));
				reportVo.setFbochecker(aResultSet.getString(17));
				reportVo.setStatusChangeTime(aResultSet.getString(18));
				reportVo.setRequestCycle(aResultSet.getString(19));
				reportVo.setSenderRefNo(aResultSet.getString(20));
				reportVo.setDummyIrex("");
				reportVo.setIfPcfc("");
				reportVo.setAmendNo("");
				reportVo.setUnderLc("");
				reportVo.setDocDisNonDis(aResultSet.getString(21));

				odcDetailedReportList.add(reportVo);

			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}
		logger.info(ActionConstants.EXITING_METHOD
				+ "<<generateODCDetailedReportInGrid DB Helper");
		return odcDetailedReportList;

	}

	public List<ReportVO> generateIGTDetailedReportInGrid(String query,
			ReportVO reportVo) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD
				+ "<<generateIGTDetailedReportInGrid DB Helper");

		List<ReportVO> igtDetailedReportList = null;
		Connection aConnection = null;
		PreparedStatement aPreparedStatement = null;
		ResultSet aResultSet = null;

		try {
			igtDetailedReportList = new ArrayList<ReportVO>();

			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);

			aResultSet = aPreparedStatement.executeQuery();
			while (aResultSet.next()) {
				reportVo = new ReportVO();

				reportVo.setRequestType(aResultSet.getString(1));
				reportVo.setSubProduct(aResultSet.getString(2));
				reportVo.setRequestId(aResultSet.getString(3));
				reportVo.setFinacleTranNo(aResultSet.getString(4));
				reportVo.setTransTime(aResultSet.getString(5));
				reportVo.setSolid(aResultSet.getString(6));
				reportVo.setBranchAlpha(aResultSet.getString(7));
				reportVo.setCustomerName(aResultSet.getString(8));
				reportVo.setCurrencyDetailed(aResultSet.getString(9));
				reportVo.setTransAmt(aResultSet.getString(10));
				reportVo.setStatus(aResultSet.getString(11));
				reportVo.setStatusChangeBy(aResultSet.getString(12));
				reportVo.setInputuser(aResultSet.getString(13));
				reportVo.setReviewuser(aResultSet.getString(14));
				reportVo.setAuthuser(aResultSet.getString(15));
				reportVo.setFbomaker(aResultSet.getString(16));
				reportVo.setFbochecker(aResultSet.getString(17));
				reportVo.setStatusChangeTime(aResultSet.getString(18));
				reportVo.setRequestCycle(aResultSet.getString(19));
				reportVo.setSenderRefNo("");
				reportVo.setDummyIrex("");
				reportVo.setIfPcfc("");
				reportVo.setAmendNo("");
				reportVo.setUnderLc("");
				reportVo.setDocDisNonDis("");

				igtDetailedReportList.add(reportVo);

			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}
		logger.info(ActionConstants.EXITING_METHOD
				+ "<<generateIGTDetailedReportInGrid DB Helper");
		return igtDetailedReportList;

	}

	public List<ReportVO> generateFELDetailedReportInGrid(String query,
			ReportVO reportVo) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD
				+ "<<generateFELDetailedReportInGrid DB Helper");

		List<ReportVO> felDetailedReportList = null;
		Connection aConnection = null;
		PreparedStatement aPreparedStatement = null;
		ResultSet aResultSet = null;

		try {
			felDetailedReportList = new ArrayList<ReportVO>();

			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);

			aResultSet = aPreparedStatement.executeQuery();
			while (aResultSet.next()) {
				reportVo = new ReportVO();

				reportVo.setRequestType(aResultSet.getString(1));
				reportVo.setSubProduct(aResultSet.getString(2));
				reportVo.setRequestId(aResultSet.getString(3));
				reportVo.setFinacleTranNo(aResultSet.getString(4));
				reportVo.setTransTime(aResultSet.getString(5));
				reportVo.setSolid(aResultSet.getString(6));
				reportVo.setBranchAlpha(aResultSet.getString(7));
				reportVo.setCustomerName(aResultSet.getString(8));
				reportVo.setCurrencyDetailed(aResultSet.getString(9));
				reportVo.setTransAmt(aResultSet.getString(10));
				reportVo.setStatus(aResultSet.getString(11));
				reportVo.setStatusChangeBy(aResultSet.getString(12));
				reportVo.setInputuser(aResultSet.getString(13));
				reportVo.setReviewuser(aResultSet.getString(14));
				reportVo.setAuthuser(aResultSet.getString(15));
				reportVo.setFbomaker(aResultSet.getString(16));
				reportVo.setFbochecker(aResultSet.getString(17));
				reportVo.setStatusChangeTime(aResultSet.getString(18));
				reportVo.setRequestCycle(aResultSet.getString(19));
				reportVo.setSenderRefNo(aResultSet.getString(20));
				reportVo.setDummyIrex("");
				reportVo.setIfPcfc("");
				reportVo.setAmendNo("");
				reportVo.setUnderLc("");
				reportVo.setDocDisNonDis("");

				felDetailedReportList.add(reportVo);

			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}
		logger.info(ActionConstants.EXITING_METHOD
				+ "<<generateFELDetailedReportInGrid DB Helper");
		return felDetailedReportList;

	}

	public List<ReportVO> generateCPCIDetailedReportInGrid(String query,
			ReportVO reportVo) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD
				+ "<<generateCPCIDetailedReportInGrid DB Helper");

		List<ReportVO> cpciDetailedReportList = null;
		Connection aConnection = null;
		PreparedStatement aPreparedStatement = null;
		ResultSet aResultSet = null;

		try {
			cpciDetailedReportList = new ArrayList<ReportVO>();

			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);

			aResultSet = aPreparedStatement.executeQuery();
			while (aResultSet.next()) {
				reportVo = new ReportVO();

				reportVo.setRequestType(aResultSet.getString(1));
				reportVo.setSubProduct(aResultSet.getString(2));
				reportVo.setRequestId(aResultSet.getString(3));
				reportVo.setFinacleTranNo(aResultSet.getString(4));
				reportVo.setTransTime(aResultSet.getString(5));
				reportVo.setSolid(aResultSet.getString(6));
				reportVo.setBranchAlpha(aResultSet.getString(7));
				reportVo.setCustomerName(aResultSet.getString(8));
				reportVo.setCurrencyDetailed(aResultSet.getString(9));
				reportVo.setTransAmt(aResultSet.getString(10));
				reportVo.setStatus(aResultSet.getString(11));
				reportVo.setStatusChangeBy(aResultSet.getString(12));
				reportVo.setInputuser(aResultSet.getString(13));
				reportVo.setReviewuser(aResultSet.getString(14));
				reportVo.setAuthuser(aResultSet.getString(15));
				reportVo.setFbomaker(aResultSet.getString(16));
				reportVo.setFbochecker(aResultSet.getString(17));
				reportVo.setStatusChangeTime(aResultSet.getString(18));
				reportVo.setRequestCycle(aResultSet.getString(19));
				reportVo.setSenderRefNo("");
				reportVo.setDummyIrex(aResultSet.getString(20));
				reportVo.setIfPcfc("");
				reportVo.setAmendNo("");
				reportVo.setUnderLc("");
				reportVo.setDocDisNonDis("");

				cpciDetailedReportList.add(reportVo);

			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}
		logger.info(ActionConstants.EXITING_METHOD
				+ "<<generateCPCIDetailedReportInGrid DB Helper");
		return cpciDetailedReportList;

	}

	public List<ReportVO> generateCPCODetailedReportInGrid(String query,
			ReportVO reportVo) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD
				+ "<<generateCPCODetailedReportInGrid DB Helper");

		List<ReportVO> cpcoDetailedReportList = null;
		Connection aConnection = null;
		PreparedStatement aPreparedStatement = null;
		ResultSet aResultSet = null;

		try {
			cpcoDetailedReportList = new ArrayList<ReportVO>();

			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);

			aResultSet = aPreparedStatement.executeQuery();
			while (aResultSet.next()) {
				reportVo = new ReportVO();

				reportVo.setRequestType(aResultSet.getString(1));
				reportVo.setSubProduct(aResultSet.getString(2));
				reportVo.setRequestId(aResultSet.getString(3));
				reportVo.setFinacleTranNo(aResultSet.getString(4));
				reportVo.setTransTime(aResultSet.getString(5));
				reportVo.setSolid(aResultSet.getString(6));
				reportVo.setBranchAlpha(aResultSet.getString(7));
				reportVo.setCustomerName(aResultSet.getString(8));
				reportVo.setCurrencyDetailed(aResultSet.getString(9));
				reportVo.setTransAmt(aResultSet.getString(10));
				reportVo.setStatus(aResultSet.getString(11));
				reportVo.setStatusChangeBy(aResultSet.getString(12));
				reportVo.setInputuser(aResultSet.getString(13));
				reportVo.setReviewuser(aResultSet.getString(14));
				reportVo.setAuthuser(aResultSet.getString(15));
				reportVo.setFbomaker(aResultSet.getString(16));
				reportVo.setFbochecker(aResultSet.getString(17));
				reportVo.setStatusChangeTime(aResultSet.getString(18));
				reportVo.setRequestCycle(aResultSet.getString(19));
				reportVo.setSenderRefNo("");
				reportVo.setDummyIrex("");
				reportVo.setIfPcfc("");
				reportVo.setAmendNo("");
				reportVo.setUnderLc("");
				reportVo.setDocDisNonDis("");

				cpcoDetailedReportList.add(reportVo);

			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}
		logger.info(ActionConstants.EXITING_METHOD
				+ "<<generateCPCODetailedReportInGrid DB Helper");
		return cpcoDetailedReportList;

	}

	public List<ReportVO> generateCORDetailedReportInGrid(String query,
			ReportVO reportVo) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD
				+ "<<generateCORDetailedReportInGrid DB Helper");

		List<ReportVO> corDetailedReportList = null;
		Connection aConnection = null;
		PreparedStatement aPreparedStatement = null;
		ResultSet aResultSet = null;

		try {
			corDetailedReportList = new ArrayList<ReportVO>();

			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);

			aResultSet = aPreparedStatement.executeQuery();
			while (aResultSet.next()) {
				reportVo = new ReportVO();

				reportVo.setRequestType(aResultSet.getString(1));
				reportVo.setSubProduct(aResultSet.getString(2));
				reportVo.setRequestId(aResultSet.getString(3));
				reportVo.setFinacleTranNo(aResultSet.getString(4));
				reportVo.setTransTime(aResultSet.getString(5));
				reportVo.setSolid(aResultSet.getString(6));
				reportVo.setBranchAlpha(aResultSet.getString(7));
				reportVo.setCustomerName(aResultSet.getString(8));
				reportVo.setCurrencyDetailed(aResultSet.getString(9));
				reportVo.setTransAmt(aResultSet.getString(10));
				reportVo.setStatus(aResultSet.getString(11));
				reportVo.setStatusChangeBy(aResultSet.getString(12));
				reportVo.setInputuser(aResultSet.getString(13));
				reportVo.setReviewuser(aResultSet.getString(14));
				reportVo.setAuthuser(aResultSet.getString(15));
				reportVo.setFbomaker(aResultSet.getString(16));
				reportVo.setFbochecker(aResultSet.getString(17));
				reportVo.setStatusChangeTime(aResultSet.getString(18));
				reportVo.setRequestCycle(aResultSet.getString(19));
				reportVo.setSenderRefNo("");
				reportVo.setDummyIrex("");
				reportVo.setIfPcfc("");
				reportVo.setAmendNo("");
				reportVo.setUnderLc("");
				reportVo.setDocDisNonDis("");

				corDetailedReportList.add(reportVo);

			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}
		logger.info(ActionConstants.EXITING_METHOD
				+ "<<generateCORDetailedReportInGrid DB Helper");
		return corDetailedReportList;

	}

	public List<ReportVO> generateALLDetailedReportInGrid(String query,
			ReportVO reportVo) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD
				+ "<<generateALLDetailedReportInGrid DB Helper");

		List<ReportVO> detailedReportList = null;
		Connection aConnection = null;
		PreparedStatement aPreparedStatement = null;
		ResultSet aResultSet = null;

		try {
			detailedReportList = new ArrayList<ReportVO>();

			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);

			aResultSet = aPreparedStatement.executeQuery();
			while (aResultSet.next()) {
				reportVo = new ReportVO();

				reportVo.setRequestType(aResultSet.getString(1));
				reportVo.setSubProduct(aResultSet.getString(2));
				reportVo.setRequestId(aResultSet.getString(3));
				reportVo.setFinacleTranNo(aResultSet.getString(4));
				reportVo.setTransTime(aResultSet.getString(5));
				reportVo.setSolid(aResultSet.getString(6));
				reportVo.setBranchAlpha(aResultSet.getString(7));
				reportVo.setCustomerName(aResultSet.getString(8));
				reportVo.setCurrencyDetailed(aResultSet.getString(9));
				reportVo.setTransAmt(aResultSet.getString(10));
				reportVo.setStatus(aResultSet.getString(11));
				reportVo.setStatusChangeBy(aResultSet.getString(12));
				reportVo.setInputuser(aResultSet.getString(13));
				reportVo.setReviewuser(aResultSet.getString(14));
				reportVo.setAuthuser(aResultSet.getString(15));
				reportVo.setFbomaker(aResultSet.getString(16));
				reportVo.setFbochecker(aResultSet.getString(17));
				reportVo.setStatusChangeTime(aResultSet.getString(18));
				reportVo.setRequestCycle(aResultSet.getString(19));
				reportVo.setSenderRefNo(aResultSet.getString(20));
				reportVo.setDocDisNonDis(aResultSet.getString(21));
				reportVo.setDummyIrex(aResultSet.getString(22));
				reportVo.setIfPcfc("");
				reportVo.setAmendNo("");
				reportVo.setUnderLc("");
				detailedReportList.add(reportVo);

			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}
		logger.info(ActionConstants.EXITING_METHOD
				+ "<<generateALLDetailedReportInGrid DB Helper");
		return detailedReportList;

	}

//	public void generateILCDetailedReportInExcel(String ilcDetailedReportQuery)
//			throws Exception {
//		logger.info(ActionConstants.ENTERING_METHOD
//				+ "<<generateILCDetailedReportInExcel DB Helper");
//
//		Connection aConnection = null;
//		PreparedStatement aPreparedStatement = null;
//		ResultSet aResultSet = null;
//
//		try {
//
//			aConnection = DBUtility.getZoneConnection();
//			aPreparedStatement = aConnection
//					.prepareStatement(ilcDetailedReportQuery);
//
//			aResultSet = aPreparedStatement.executeQuery();
//			logger.info("-----query------>" + ilcDetailedReportQuery);
//
//			HttpServletResponse response = (HttpServletResponse) ActionContext
//					.getContext().get(ServletActionContext.HTTP_RESPONSE);
//
//			HSSFWorkbook wb = new HSSFWorkbook();
//			HSSFSheet sheet = wb.createSheet();
//			HSSFRow row = sheet.createRow(0);
//			CellStyle style = wb.createCellStyle();
//			style.setWrapText(true);
//
//			sheet.addMergedRegion(new CellRangeAddress(0, // first row (0-based)
//					0, // last row (0-based)
//					0, // first column (0-based)
//					12 // last column (0-based)
//			));
//
//			row = sheet.createRow(0);
//			HSSFCell cell = row.createCell(0);
//			cell = row.createCell(0);
//			cell.setCellValue("DETAILED REPORT");
//			row = sheet.createRow(1);
//			cell = row.createCell(0);
//			cell.setCellValue("REQUEST TYPE");
//			cell = row.createCell(1);
//			cell.setCellValue("SUB PRODUCT");
//			cell = row.createCell(2);
//			cell.setCellValue("REQUEST ID");
//			cell = row.createCell(3);
//			cell.setCellValue("FINACLE TRANSACTION NO");
//			cell = row.createCell(4);
//			cell.setCellValue("TRANSACTION GENERATED TIME");
//			cell = row.createCell(5);
//			cell.setCellValue("SOL ID");
//			cell = row.createCell(6);
//			cell.setCellValue("BRANCH ALPHA");
//			cell = row.createCell(7);
//			cell.setCellValue("CUSTOMER NAME");
//			cell = row.createCell(8);
//			cell.setCellValue("CURRENCY");
//			cell = row.createCell(9);
//			cell.setCellValue("TRANSACTION AMOUNT");
//			cell = row.createCell(10);
//			cell.setCellValue("STATUS");
//			cell = row.createCell(11);
//			cell.setCellValue("STATUS CHANGED BY");
//			cell = row.createCell(12);
//			cell.setCellValue("STATUS CHANGED TIME");
//			cell = row.createCell(13);
//			cell.setCellValue("REQUEST CYCLE");
//
//			int i = 2;
//
//			while (aResultSet.next()) {
//
//				row = sheet.createRow(i);
//
//				cell = row.createCell(0);
//				cell.setCellValue(aResultSet.getString(1));
//				cell = row.createCell(1);
//				cell.setCellValue(aResultSet.getString(2));
//				cell = row.createCell(2);
//				cell.setCellValue(aResultSet.getString(3));
//				cell = row.createCell(3);
//				cell.setCellValue(aResultSet.getString(4));
//				cell = row.createCell(4);
//				cell.setCellValue(aResultSet.getString(5));
//				cell = row.createCell(5);
//				cell.setCellValue(aResultSet.getString(6));
//				cell = row.createCell(6);
//				cell.setCellValue(aResultSet.getString(7));
//				cell = row.createCell(7);
//				cell.setCellValue(aResultSet.getString(8));
//				cell = row.createCell(8);
//				cell.setCellValue(aResultSet.getString(9));
//				cell = row.createCell(9);
//				cell.setCellValue(aResultSet.getString(10));
//				cell = row.createCell(10);
//				cell.setCellValue(aResultSet.getString(11));
//				cell = row.createCell(11);
//				cell.setCellValue(aResultSet.getString(12));
//				cell = row.createCell(12);
//				cell.setCellValue(aResultSet.getString(13));
//				cell = row.createCell(13);
//				cell.setCellValue(aResultSet.getString(14));
//
//				i++;
//
//			}
//
//			ByteArrayOutputStream outByteStream = new ByteArrayOutputStream();
//			wb.write(outByteStream);
//			byte[] outArray = outByteStream.toByteArray();
//
//			response.setContentType("application/ms-excel");
//			response.setContentLength(outArray.length);
//
//			response.setHeader("Expires:", "0"); // eliminates browser caching
//			response.setHeader("Content-Disposition",
//					"attachment; filename=DetailedReport.xls");
//			OutputStream outStream = response.getOutputStream();
//			logger.info("Before write" + outArray.length);
//			outStream.write(outArray);
//
//			logger.info("After write");
//			outStream.flush();
//		} catch (Exception e) {
//			e.printStackTrace();
//			throw e;
//		} finally {
//			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
//
//		}
//		logger.info(ActionConstants.EXITING_METHOD
//				+ "<<generateILCDetailedReportInExcel DB Helper");
//	}

//	public void generateELCDetailedReportInExcel(String elcDetailedReportQuery)
//			throws Exception {
//		logger.info(ActionConstants.ENTERING_METHOD
//				+ "<<generateELCDetailedReportInExcel DB Helper");
//
//		Connection aConnection = null;
//		PreparedStatement aPreparedStatement = null;
//		ResultSet aResultSet = null;
//
//		try {
//
//			aConnection = DBUtility.getZoneConnection();
//			aPreparedStatement = aConnection
//					.prepareStatement(elcDetailedReportQuery);
//
//			aResultSet = aPreparedStatement.executeQuery();
//			logger.info("-----query------>" + elcDetailedReportQuery);
//
//			HttpServletResponse response = (HttpServletResponse) ActionContext
//					.getContext().get(ServletActionContext.HTTP_RESPONSE);
//
//			HSSFWorkbook wb = new HSSFWorkbook();
//			HSSFSheet sheet = wb.createSheet();
//			HSSFRow row = sheet.createRow(0);
//			CellStyle style = wb.createCellStyle();
//			style.setWrapText(true);
//
//			sheet.addMergedRegion(new CellRangeAddress(0, // first row (0-based)
//					0, // last row (0-based)
//					0, // first column (0-based)
//					12 // last column (0-based)
//			));
//
//			row = sheet.createRow(0);
//			HSSFCell cell = row.createCell(0);
//			cell = row.createCell(0);
//			cell.setCellValue("DETAILED REPORT");
//			row = sheet.createRow(1);
//			cell = row.createCell(0);
//			cell.setCellValue("REQUEST TYPE");
//			cell = row.createCell(1);
//			cell.setCellValue("SUB PRODUCT");
//			cell = row.createCell(2);
//			cell.setCellValue("REQUEST ID");
//			cell = row.createCell(3);
//			cell.setCellValue("FINACLE TRANSACTION NO");
//			cell = row.createCell(4);
//			cell.setCellValue("TRANSACTION GENERATED TIME");
//			cell = row.createCell(5);
//			cell.setCellValue("SOL ID");
//			cell = row.createCell(6);
//			cell.setCellValue("BRANCH ALPHA");
//			cell = row.createCell(7);
//			cell.setCellValue("CUSTOMER NAME");
//			cell = row.createCell(8);
//			cell.setCellValue("CURRENCY");
//			cell = row.createCell(9);
//			cell.setCellValue("TRANSACTION AMOUNT");
//			cell = row.createCell(10);
//			cell.setCellValue("STATUS");
//			cell = row.createCell(11);
//			cell.setCellValue("STATUS CHANGED BY");
//			cell = row.createCell(12);
//			cell.setCellValue("STATUS CHANGED TIME");
//			cell = row.createCell(13);
//			cell.setCellValue("REQUEST CYCLE");
//			cell = row.createCell(14);
//			cell.setCellValue("SENDER REFERENCE NO");
//
//			int i = 2;
//
//			while (aResultSet.next()) {
//
//				row = sheet.createRow(i);
//
//				cell = row.createCell(0);
//				cell.setCellValue(aResultSet.getString(1));
//				cell = row.createCell(1);
//				cell.setCellValue(aResultSet.getString(2));
//				cell = row.createCell(2);
//				cell.setCellValue(aResultSet.getString(3));
//				cell = row.createCell(3);
//				cell.setCellValue(aResultSet.getString(4));
//				cell = row.createCell(4);
//				cell.setCellValue(aResultSet.getString(5));
//				cell = row.createCell(5);
//				cell.setCellValue(aResultSet.getString(6));
//				cell = row.createCell(6);
//				cell.setCellValue(aResultSet.getString(7));
//				cell = row.createCell(7);
//				cell.setCellValue(aResultSet.getString(8));
//				cell = row.createCell(8);
//				cell.setCellValue(aResultSet.getString(9));
//				cell = row.createCell(9);
//				cell.setCellValue(aResultSet.getString(10));
//				cell = row.createCell(10);
//				cell.setCellValue(aResultSet.getString(11));
//				cell = row.createCell(11);
//				cell.setCellValue(aResultSet.getString(12));
//				cell = row.createCell(12);
//				cell.setCellValue(aResultSet.getString(13));
//				cell = row.createCell(13);
//				cell.setCellValue(aResultSet.getString(14));
//				cell = row.createCell(14);
//				cell.setCellValue(aResultSet.getString(15));
//
//				i++;
//
//			}
//
//			ByteArrayOutputStream outByteStream = new ByteArrayOutputStream();
//			wb.write(outByteStream);
//			byte[] outArray = outByteStream.toByteArray();
//
//			response.setContentType("application/ms-excel");
//			response.setContentLength(outArray.length);
//
//			response.setHeader("Expires:", "0"); // eliminates browser caching
//			response.setHeader("Content-Disposition",
//					"attachment; filename=DetailedReport.xls");
//			OutputStream outStream = response.getOutputStream();
//			logger.info("Before write" + outArray.length);
//			outStream.write(outArray);
//
//			logger.info("After write");
//			outStream.flush();
//		} catch (Exception e) {
//			e.printStackTrace();
//			throw e;
//		} finally {
//			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
//
//		}
//		logger.info(ActionConstants.EXITING_METHOD
//				+ "<<generateELCDetailedReportInExcel DB Helper");
//	}

//	public void generateFOCDetailedReportInExcel(String focDetailedReportQuery)
//			throws Exception {
//		logger.info(ActionConstants.ENTERING_METHOD
//				+ "<<generateFOCDetailedReportInExcel DB Helper");
//
//		Connection aConnection = null;
//		PreparedStatement aPreparedStatement = null;
//		ResultSet aResultSet = null;
//
//		try {
//
//			aConnection = DBUtility.getZoneConnection();
//			aPreparedStatement = aConnection
//					.prepareStatement(focDetailedReportQuery);
//
//			aResultSet = aPreparedStatement.executeQuery();
//			logger.info("-----query------>" + focDetailedReportQuery);
//
//			HttpServletResponse response = (HttpServletResponse) ActionContext
//					.getContext().get(ServletActionContext.HTTP_RESPONSE);
//
//			HSSFWorkbook wb = new HSSFWorkbook();
//			HSSFSheet sheet = wb.createSheet();
//			HSSFRow row = sheet.createRow(0);
//			CellStyle style = wb.createCellStyle();
//			style.setWrapText(true);
//
//			sheet.addMergedRegion(new CellRangeAddress(0, // first row (0-based)
//					0, // last row (0-based)
//					0, // first column (0-based)
//					12 // last column (0-based)
//			));
//
//			row = sheet.createRow(0);
//			HSSFCell cell = row.createCell(0);
//			cell = row.createCell(0);
//			cell.setCellValue("DETAILED REPORT");
//			row = sheet.createRow(1);
//			cell = row.createCell(0);
//			cell.setCellValue("REQUEST TYPE");
//			cell = row.createCell(1);
//			cell.setCellValue("SUB PRODUCT");
//			cell = row.createCell(2);
//			cell.setCellValue("REQUEST ID");
//			cell = row.createCell(3);
//			cell.setCellValue("FINACLE TRANSACTION NO");
//			cell = row.createCell(4);
//			cell.setCellValue("TRANSACTION GENERATED TIME");
//			cell = row.createCell(5);
//			cell.setCellValue("SOL ID");
//			cell = row.createCell(6);
//			cell.setCellValue("BRANCH ALPHA");
//			cell = row.createCell(7);
//			cell.setCellValue("CUSTOMER NAME");
//			cell = row.createCell(8);
//			cell.setCellValue("CURRENCY");
//			cell = row.createCell(9);
//			cell.setCellValue("TRANSACTION AMOUNT");
//			cell = row.createCell(10);
//			cell.setCellValue("STATUS");
//			cell = row.createCell(11);
//			cell.setCellValue("STATUS CHANGED BY");
//			cell = row.createCell(12);
//			cell.setCellValue("STATUS CHANGED TIME");
//			cell = row.createCell(13);
//			cell.setCellValue("REQUEST CYCLE");
//			cell = row.createCell(14);
//			cell.setCellValue("SENDER REFERENCE NO");
//
//			int i = 2;
//
//			while (aResultSet.next()) {
//
//				row = sheet.createRow(i);
//
//				cell = row.createCell(0);
//				cell.setCellValue(aResultSet.getString(1));
//				cell = row.createCell(1);
//				cell.setCellValue(aResultSet.getString(2));
//				cell = row.createCell(2);
//				cell.setCellValue(aResultSet.getString(3));
//				cell = row.createCell(3);
//				cell.setCellValue(aResultSet.getString(4));
//				cell = row.createCell(4);
//				cell.setCellValue(aResultSet.getString(5));
//				cell = row.createCell(5);
//				cell.setCellValue(aResultSet.getString(6));
//				cell = row.createCell(6);
//				cell.setCellValue(aResultSet.getString(7));
//				cell = row.createCell(7);
//				cell.setCellValue(aResultSet.getString(8));
//				cell = row.createCell(8);
//				cell.setCellValue(aResultSet.getString(9));
//				cell = row.createCell(9);
//				cell.setCellValue(aResultSet.getString(10));
//				cell = row.createCell(10);
//				cell.setCellValue(aResultSet.getString(11));
//				cell = row.createCell(11);
//				cell.setCellValue(aResultSet.getString(12));
//				cell = row.createCell(12);
//				cell.setCellValue(aResultSet.getString(13));
//				cell = row.createCell(13);
//				cell.setCellValue(aResultSet.getString(14));
//				cell = row.createCell(14);
//				cell.setCellValue(aResultSet.getString(15));
//
//				i++;
//
//			}
//
//			ByteArrayOutputStream outByteStream = new ByteArrayOutputStream();
//			wb.write(outByteStream);
//			byte[] outArray = outByteStream.toByteArray();
//
//			response.setContentType("application/ms-excel");
//			response.setContentLength(outArray.length);
//
//			response.setHeader("Expires:", "0"); // eliminates browser caching
//			response.setHeader("Content-Disposition",
//					"attachment; filename=DetailedReport.xls");
//			OutputStream outStream = response.getOutputStream();
//			logger.info("Before write" + outArray.length);
//			outStream.write(outArray);
//
//			logger.info("After write");
//			outStream.flush();
//		} catch (Exception e) {
//			e.printStackTrace();
//			throw e;
//		} finally {
//			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
//
//		}
//		logger.info(ActionConstants.EXITING_METHOD
//				+ "<<generateFOCDetailedReportInExcel DB Helper");
//	}

//	public void generateCPCIDetailedReportInExcel(String cpciDetailedReportQuery)
//			throws Exception {
//		logger.info(ActionConstants.ENTERING_METHOD
//				+ "<<generateCPCIDetailedReportInExcel DB Helper");
//
//		Connection aConnection = null;
//		PreparedStatement aPreparedStatement = null;
//		ResultSet aResultSet = null;
//
//		try {
//
//			aConnection = DBUtility.getZoneConnection();
//			aPreparedStatement = aConnection
//					.prepareStatement(cpciDetailedReportQuery);
//
//			aResultSet = aPreparedStatement.executeQuery();
//			logger.info("CPCI detailed Report query------>"
//					+ cpciDetailedReportQuery);
//
//			HttpServletResponse response = (HttpServletResponse) ActionContext
//					.getContext().get(ServletActionContext.HTTP_RESPONSE);
//
//			HSSFWorkbook wb = new HSSFWorkbook();
//			HSSFSheet sheet = wb.createSheet();
//			HSSFRow row = sheet.createRow(0);
//			CellStyle style = wb.createCellStyle();
//			style.setWrapText(true);
//
//			sheet.addMergedRegion(new CellRangeAddress(0, // first row (0-based)
//					0, // last row (0-based)
//					0, // first column (0-based)
//					12 // last column (0-based)
//			));
//
//			row = sheet.createRow(0);
//			HSSFCell cell = row.createCell(0);
//			cell = row.createCell(0);
//			cell.setCellValue("DETAILED REPORT");
//			row = sheet.createRow(1);
//			cell = row.createCell(0);
//			cell.setCellValue("REQUEST TYPE");
//			cell = row.createCell(1);
//			cell.setCellValue("SUB PRODUCT");
//			cell = row.createCell(2);
//			cell.setCellValue("REQUEST ID");
//			cell = row.createCell(3);
//			cell.setCellValue("FINACLE TRANSACTION NO");
//			cell = row.createCell(4);
//			cell.setCellValue("TRANSACTION GENERATED TIME");
//			cell = row.createCell(5);
//			cell.setCellValue("SOL ID");
//			cell = row.createCell(6);
//			cell.setCellValue("BRANCH ALPHA");
//			cell = row.createCell(7);
//			cell.setCellValue("CUSTOMER NAME");
//			cell = row.createCell(8);
//			cell.setCellValue("CURRENCY");
//			cell = row.createCell(9);
//			cell.setCellValue("TRANSACTION AMOUNT");
//			cell = row.createCell(10);
//			cell.setCellValue("STATUS");
//			cell = row.createCell(11);
//			cell.setCellValue("STATUS CHANGED BY");
//			cell = row.createCell(12);
//			cell.setCellValue("STATUS CHANGED TIME");
//			cell = row.createCell(13);
//			cell.setCellValue("REQUEST CYCLE");
//			cell = row.createCell(14);
//			cell.setCellValue("DUMMY IREX");
//
//			int i = 2;
//
//			while (aResultSet.next()) {
//
//				row = sheet.createRow(i);
//
//				cell = row.createCell(0);
//				cell.setCellValue(aResultSet.getString(1));
//				cell = row.createCell(1);
//				cell.setCellValue(aResultSet.getString(2));
//				cell = row.createCell(2);
//				cell.setCellValue(aResultSet.getString(3));
//				cell = row.createCell(3);
//				cell.setCellValue(aResultSet.getString(4));
//				cell = row.createCell(4);
//				cell.setCellValue(aResultSet.getString(5));
//				cell = row.createCell(5);
//				cell.setCellValue(aResultSet.getString(6));
//				cell = row.createCell(6);
//				cell.setCellValue(aResultSet.getString(7));
//				cell = row.createCell(7);
//				cell.setCellValue(aResultSet.getString(8));
//				cell = row.createCell(8);
//				cell.setCellValue(aResultSet.getString(9));
//				cell = row.createCell(9);
//				cell.setCellValue(aResultSet.getString(10));
//				cell = row.createCell(10);
//				cell.setCellValue(aResultSet.getString(11));
//				cell = row.createCell(11);
//				cell.setCellValue(aResultSet.getString(12));
//				cell = row.createCell(12);
//				cell.setCellValue(aResultSet.getString(13));
//				cell = row.createCell(13);
//				cell.setCellValue(aResultSet.getString(14));
//				cell = row.createCell(14);
//				cell.setCellValue(aResultSet.getString(15));
//
//				i++;
//
//			}
//
//			ByteArrayOutputStream outByteStream = new ByteArrayOutputStream();
//			wb.write(outByteStream);
//			byte[] outArray = outByteStream.toByteArray();
//
//			response.setContentType("application/ms-excel");
//			response.setContentLength(outArray.length);
//
//			response.setHeader("Expires:", "0"); // eliminates browser caching
////			response.setHeader("Content-Disposition",
//					"attachment; filename=DetailedReport.xls");
//			OutputStream outStream = response.getOutputStream();
//			logger.info("Before write" + outArray.length);
//			outStream.write(outArray);
//
//			logger.info("After write");
//			outStream.flush();
//		} catch (Exception e) {
//			e.printStackTrace();
//			throw e;
//		} finally {
//			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
//
//		}
//		logger.info(ActionConstants.EXITING_METHOD
//				+ "<<generateCPCIDetailedReportInExcel DB Helper");
//	}

//	public void generateISBDetailedReportInExcel(String isbDetailedReportQuery)
//			throws Exception {
//		logger.info(ActionConstants.ENTERING_METHOD
//				+ "<<generateISBDetailedReportInExcel DB Helper");
//
//		Connection aConnection = null;
//		PreparedStatement aPreparedStatement = null;
//		ResultSet aResultSet = null;
//
//		try {
//
//			aConnection = DBUtility.getZoneConnection();
//			aPreparedStatement = aConnection
//					.prepareStatement(isbDetailedReportQuery);
//
//			aResultSet = aPreparedStatement.executeQuery();
//			logger.info("Getting ISB Detailed Report query------>"
//					+ isbDetailedReportQuery);
//
//			HttpServletResponse response = (HttpServletResponse) ActionContext
//					.getContext().get(ServletActionContext.HTTP_RESPONSE);
//
//			HSSFWorkbook wb = new HSSFWorkbook();
//			HSSFSheet sheet = wb.createSheet();
//			HSSFRow row = sheet.createRow(0);
//			CellStyle style = wb.createCellStyle();
//			style.setWrapText(true);
//
//			sheet.addMergedRegion(new CellRangeAddress(0, // first row (0-based)
//					0, // last row (0-based)
//					0, // first column (0-based)
//					12 // last column (0-based)
//			));
//
//			row = sheet.createRow(0);
//			HSSFCell cell = row.createCell(0);
//			cell = row.createCell(0);
//			cell.setCellValue("DETAILED REPORT");
//			row = sheet.createRow(1);
//			cell = row.createCell(0);
//			cell.setCellValue("REQUEST TYPE");
//			cell = row.createCell(1);
//			cell.setCellValue("SUB PRODUCT");
//			cell = row.createCell(2);
//			cell.setCellValue("REQUEST ID");
//			cell = row.createCell(3);
//			cell.setCellValue("FINACLE TRANSACTION NO");
//			cell = row.createCell(4);
//			cell.setCellValue("TRANSACTION GENERATED TIME");
//			cell = row.createCell(5);
//			cell.setCellValue("SOL ID");
//			cell = row.createCell(6);
//			cell.setCellValue("BRANCH ALPHA");
//			cell = row.createCell(7);
//			cell.setCellValue("CUSTOMER NAME");
//			cell = row.createCell(8);
//			cell.setCellValue("CURRENCY");
//			cell = row.createCell(9);
//			cell.setCellValue("TRANSACTION AMOUNT");
//			cell = row.createCell(10);
//			cell.setCellValue("STATUS");
//			cell = row.createCell(11);
//			cell.setCellValue("STATUS CHANGED BY");
//			cell = row.createCell(12);
//			cell.setCellValue("STATUS CHANGED TIME");
//			cell = row.createCell(13);
//			cell.setCellValue("REQUEST CYCLE");
//
//			int i = 2;
//
//			while (aResultSet.next()) {
//
//				row = sheet.createRow(i);
//
//				cell = row.createCell(0);
//				cell.setCellValue(aResultSet.getString(1));
//				cell = row.createCell(1);
//				cell.setCellValue(aResultSet.getString(2));
//				cell = row.createCell(2);
//				cell.setCellValue(aResultSet.getString(3));
//				cell = row.createCell(3);
//				cell.setCellValue(aResultSet.getString(4));
//				cell = row.createCell(4);
//				cell.setCellValue(aResultSet.getString(5));
//				cell = row.createCell(5);
//				cell.setCellValue(aResultSet.getString(6));
//				cell = row.createCell(6);
//				cell.setCellValue(aResultSet.getString(7));
//				cell = row.createCell(7);
//				cell.setCellValue(aResultSet.getString(8));
//				cell = row.createCell(8);
//				cell.setCellValue(aResultSet.getString(9));
//				cell = row.createCell(9);
//				cell.setCellValue(aResultSet.getString(10));
//				cell = row.createCell(10);
//				cell.setCellValue(aResultSet.getString(11));
//				cell = row.createCell(11);
//				cell.setCellValue(aResultSet.getString(12));
//				cell = row.createCell(12);
//				cell.setCellValue(aResultSet.getString(13));
//				cell = row.createCell(13);
//				cell.setCellValue(aResultSet.getString(14));
//
//				i++;
//
//			}
//
//			ByteArrayOutputStream outByteStream = new ByteArrayOutputStream();
//			wb.write(outByteStream);
//			byte[] outArray = outByteStream.toByteArray();
//
//			response.setContentType("application/ms-excel");
//			response.setContentLength(outArray.length);
//
//			response.setHeader("Expires:", "0"); // eliminates browser caching
//			response.setHeader("Content-Disposition",
//					"attachment; filename=DetailedReport.xls");
//			OutputStream outStream = response.getOutputStream();
//			logger.info("Before write" + outArray.length);
//			outStream.write(outArray);
//
//			logger.info("After write");
//			outStream.flush();
//		} catch (Exception e) {
//			e.printStackTrace();
//			throw e;
//		} finally {
//			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
//
//		}
//		logger.info(ActionConstants.EXITING_METHOD
//				+ "<<generateISBDetailedReportInExcel DB Helper");
//	}

//	public void generateFSADetailedReportInExcel(String fsaDetailedReportQuery)
//			throws Exception {
//		logger.info(ActionConstants.ENTERING_METHOD
//				+ "<<generateFSADetailedReportInExcel DB Helper");
//
//		Connection aConnection = null;
//		PreparedStatement aPreparedStatement = null;
//		ResultSet aResultSet = null;
//
//		try {
//
//			aConnection = DBUtility.getZoneConnection();
//			aPreparedStatement = aConnection
//					.prepareStatement(fsaDetailedReportQuery);
//
//			aResultSet = aPreparedStatement.executeQuery();
//			logger.info("Getting FSA Detailed Report query------>"
//					+ fsaDetailedReportQuery);
//
//			HttpServletResponse response = (HttpServletResponse) ActionContext
//					.getContext().get(ServletActionContext.HTTP_RESPONSE);
//
//			HSSFWorkbook wb = new HSSFWorkbook();
//			HSSFSheet sheet = wb.createSheet();
//			HSSFRow row = sheet.createRow(0);
//			CellStyle style = wb.createCellStyle();
//			style.setWrapText(true);
//
//			sheet.addMergedRegion(new CellRangeAddress(0, // first row (0-based)
//					0, // last row (0-based)
//					0, // first column (0-based)
//					12 // last column (0-based)
//			));
//
//			row = sheet.createRow(0);
//			HSSFCell cell = row.createCell(0);
//			cell = row.createCell(0);
//			cell.setCellValue("DETAILED REPORT");
//			row = sheet.createRow(1);
//			cell = row.createCell(0);
//			cell.setCellValue("REQUEST TYPE");
//			cell = row.createCell(1);
//			cell.setCellValue("SUB PRODUCT");
//			cell = row.createCell(2);
//			cell.setCellValue("REQUEST ID");
//			cell = row.createCell(3);
//			cell.setCellValue("FINACLE TRANSACTION NO");
//			cell = row.createCell(4);
//			cell.setCellValue("TRANSACTION GENERATED TIME");
//			cell = row.createCell(5);
//			cell.setCellValue("SOL ID");
//			cell = row.createCell(6);
//			cell.setCellValue("BRANCH ALPHA");
//			cell = row.createCell(7);
//			cell.setCellValue("CUSTOMER NAME");
//			cell = row.createCell(8);
//			cell.setCellValue("CURRENCY");
//			cell = row.createCell(9);
//			cell.setCellValue("TRANSACTION AMOUNT");
//			cell = row.createCell(10);
//			cell.setCellValue("STATUS");
//			cell = row.createCell(11);
//			cell.setCellValue("STATUS CHANGED BY");
//			cell = row.createCell(12);
//			cell.setCellValue("STATUS CHANGED TIME");
//			cell = row.createCell(13);
//			cell.setCellValue("REQUEST CYCLE");
//
//			int i = 2;
//
//			while (aResultSet.next()) {
//
//				row = sheet.createRow(i);
//
//				cell = row.createCell(0);
//				cell.setCellValue(aResultSet.getString(1));
//				cell = row.createCell(1);
//				cell.setCellValue(aResultSet.getString(2));
//				cell = row.createCell(2);
//				cell.setCellValue(aResultSet.getString(3));
//				cell = row.createCell(3);
//				cell.setCellValue(aResultSet.getString(4));
//				cell = row.createCell(4);
//				cell.setCellValue(aResultSet.getString(5));
//				cell = row.createCell(5);
//				cell.setCellValue(aResultSet.getString(6));
//				cell = row.createCell(6);
//				cell.setCellValue(aResultSet.getString(7));
//				cell = row.createCell(7);
//				cell.setCellValue(aResultSet.getString(8));
//				cell = row.createCell(8);
//				cell.setCellValue(aResultSet.getString(9));
//				cell = row.createCell(9);
//				cell.setCellValue(aResultSet.getString(10));
//				cell = row.createCell(10);
//				cell.setCellValue(aResultSet.getString(11));
//				cell = row.createCell(11);
//				cell.setCellValue(aResultSet.getString(12));
//				cell = row.createCell(12);
//				cell.setCellValue(aResultSet.getString(13));
//				cell = row.createCell(13);
//				cell.setCellValue(aResultSet.getString(14));
//
//				i++;
//
//			}
//
//			ByteArrayOutputStream outByteStream = new ByteArrayOutputStream();
//			wb.write(outByteStream);
//			byte[] outArray = outByteStream.toByteArray();
//
//			response.setContentType("application/ms-excel");
//			response.setContentLength(outArray.length);
//
//			response.setHeader("Expires:", "0"); // eliminates browser caching
//			response.setHeader("Content-Disposition",
//					"attachment; filename=DetailedReport.xls");
//			OutputStream outStream = response.getOutputStream();
//			logger.info("Before write" + outArray.length);
//			outStream.write(outArray);
//
//			logger.info("After write");
//			outStream.flush();
//		} catch (Exception e) {
//			e.printStackTrace();
//			throw e;
//		} finally {
//			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
//
//		}
//		logger.info(ActionConstants.EXITING_METHOD
//				+ "<<generateFSADetailedReportInExcel DB Helper");
//	}

//	public void generateIDCDetailedReportInExcel(String idcDetailedReportQuery)
//			throws Exception {
//		logger.info(ActionConstants.ENTERING_METHOD
//				+ "<<generateIDCDetailedReportInExcel DB Helper");
//
//		Connection aConnection = null;
//		PreparedStatement aPreparedStatement = null;
//		ResultSet aResultSet = null;
//
//		try {
//
//			aConnection = DBUtility.getZoneConnection();
//			aPreparedStatement = aConnection
//					.prepareStatement(idcDetailedReportQuery);
//
//			aResultSet = aPreparedStatement.executeQuery();
//			logger.info("Getting IDC Detailed Report query------>"
//					+ idcDetailedReportQuery);
//
//			HttpServletResponse response = (HttpServletResponse) ActionContext
//					.getContext().get(ServletActionContext.HTTP_RESPONSE);
//
//			HSSFWorkbook wb = new HSSFWorkbook();
//			HSSFSheet sheet = wb.createSheet();
//			HSSFRow row = sheet.createRow(0);
//			CellStyle style = wb.createCellStyle();
//			style.setWrapText(true);
//
//			sheet.addMergedRegion(new CellRangeAddress(0, // first row (0-based)
//					0, // last row (0-based)
//					0, // first column (0-based)
//					12 // last column (0-based)
//			));
//
//			row = sheet.createRow(0);
//			HSSFCell cell = row.createCell(0);
//			cell = row.createCell(0);
//			cell.setCellValue("DETAILED REPORT");
//			row = sheet.createRow(1);
//			cell = row.createCell(0);
//			cell.setCellValue("REQUEST TYPE");
//			cell = row.createCell(1);
//			cell.setCellValue("SUB PRODUCT");
//			cell = row.createCell(2);
//			cell.setCellValue("REQUEST ID");
//			cell = row.createCell(3);
//			cell.setCellValue("FINACLE TRANSACTION NO");
//			cell = row.createCell(4);
//			cell.setCellValue("TRANSACTION GENERATED TIME");
//			cell = row.createCell(5);
//			cell.setCellValue("SOL ID");
//			cell = row.createCell(6);
//			cell.setCellValue("BRANCH ALPHA");
//			cell = row.createCell(7);
//			cell.setCellValue("CUSTOMER NAME");
//			cell = row.createCell(8);
//			cell.setCellValue("CURRENCY");
//			cell = row.createCell(9);
//			cell.setCellValue("TRANSACTION AMOUNT");
//			cell = row.createCell(10);
//			cell.setCellValue("STATUS");
//			cell = row.createCell(11);
//			cell.setCellValue("STATUS CHANGED BY");
//			cell = row.createCell(12);
//			cell.setCellValue("STATUS CHANGED TIME");
//			cell = row.createCell(13);
//			cell.setCellValue("REQUEST CYCLE");
//
//			int i = 2;
//
//			while (aResultSet.next()) {
//
//				row = sheet.createRow(i);
//
//				cell = row.createCell(0);
//				cell.setCellValue(aResultSet.getString(1));
//				cell = row.createCell(1);
//				cell.setCellValue(aResultSet.getString(2));
//				cell = row.createCell(2);
//				cell.setCellValue(aResultSet.getString(3));
//				cell = row.createCell(3);
//				cell.setCellValue(aResultSet.getString(4));
//				cell = row.createCell(4);
//				cell.setCellValue(aResultSet.getString(5));
//				cell = row.createCell(5);
//				cell.setCellValue(aResultSet.getString(6));
//				cell = row.createCell(6);
//				cell.setCellValue(aResultSet.getString(7));
//				cell = row.createCell(7);
//				cell.setCellValue(aResultSet.getString(8));
//				cell = row.createCell(8);
//				cell.setCellValue(aResultSet.getString(9));
//				cell = row.createCell(9);
//				cell.setCellValue(aResultSet.getString(10));
//				cell = row.createCell(10);
//				cell.setCellValue(aResultSet.getString(11));
//				cell = row.createCell(11);
//				cell.setCellValue(aResultSet.getString(12));
//				cell = row.createCell(12);
//				cell.setCellValue(aResultSet.getString(13));
//				cell = row.createCell(13);
//				cell.setCellValue(aResultSet.getString(14));
//
//				i++;
//
//			}
//
//			ByteArrayOutputStream outByteStream = new ByteArrayOutputStream();
//			wb.write(outByteStream);
//			byte[] outArray = outByteStream.toByteArray();
//
//			response.setContentType("application/ms-excel");
//			response.setContentLength(outArray.length);
//
//			response.setHeader("Expires:", "0"); // eliminates browser caching
//			response.setHeader("Content-Disposition",
//					"attachment; filename=DetailedReport.xls");
//			OutputStream outStream = response.getOutputStream();
//			logger.info("Before write" + outArray.length);
//			outStream.write(outArray);
//
//			logger.info("After write");
//			outStream.flush();
//		} catch (Exception e) {
//			e.printStackTrace();
//			throw e;
//		} finally {
//			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
//
//		}
//		logger.info(ActionConstants.EXITING_METHOD
//				+ "<<generateIDCDetailedReportInExcel DB Helper");
//	}

//	public void generateODCDetailedReportInExcel(String odcDetailedReportQuery)
//			throws Exception {
//		logger.info(ActionConstants.ENTERING_METHOD
//				+ "<<generateODCDetailedReportInExcel DB Helper");
//
//		Connection aConnection = null;
//		PreparedStatement aPreparedStatement = null;
//		ResultSet aResultSet = null;
//
//		try {
//
//			aConnection = DBUtility.getZoneConnection();
//			aPreparedStatement = aConnection
//					.prepareStatement(odcDetailedReportQuery);
//
//			aResultSet = aPreparedStatement.executeQuery();
//			logger.info("Getting ODC Detailed Report query------>"
//					+ odcDetailedReportQuery);
//
//			HttpServletResponse response = (HttpServletResponse) ActionContext
//					.getContext().get(ServletActionContext.HTTP_RESPONSE);
//
//			HSSFWorkbook wb = new HSSFWorkbook();
//			HSSFSheet sheet = wb.createSheet();
//			HSSFRow row = sheet.createRow(0);
//			CellStyle style = wb.createCellStyle();
//			style.setWrapText(true);
//
//			sheet.addMergedRegion(new CellRangeAddress(0, // first row (0-based)
//					0, // last row (0-based)
//					0, // first column (0-based)
//					12 // last column (0-based)
//			));
//
//			row = sheet.createRow(0);
//			HSSFCell cell = row.createCell(0);
//			cell = row.createCell(0);
//			cell.setCellValue("DETAILED REPORT");
//			row = sheet.createRow(1);
//			cell = row.createCell(0);
//			cell.setCellValue("REQUEST TYPE");
//			cell = row.createCell(1);
//			cell.setCellValue("SUB PRODUCT");
//			cell = row.createCell(2);
//			cell.setCellValue("REQUEST ID");
//			cell = row.createCell(3);
//			cell.setCellValue("FINACLE TRANSACTION NO");
//			cell = row.createCell(4);
//			cell.setCellValue("TRANSACTION GENERATED TIME");
//			cell = row.createCell(5);
//			cell.setCellValue("SOL ID");
//			cell = row.createCell(6);
//			cell.setCellValue("BRANCH ALPHA");
//			cell = row.createCell(7);
//			cell.setCellValue("CUSTOMER NAME");
//			cell = row.createCell(8);
//			cell.setCellValue("CURRENCY");
//			cell = row.createCell(9);
//			cell.setCellValue("TRANSACTION AMOUNT");
//			cell = row.createCell(10);
//			cell.setCellValue("STATUS");
//			cell = row.createCell(11);
//			cell.setCellValue("STATUS CHANGED BY");
//			cell = row.createCell(12);
//			cell.setCellValue("STATUS CHANGED TIME");
//			cell = row.createCell(13);
//			cell.setCellValue("REQUEST CYCLE");
//			cell = row.createCell(14);
//			cell.setCellValue("SENDER REFERENCR NO");
//			cell = row.createCell(15);
//			cell.setCellValue("DOCUMENT DISPATCH");
//
//			int i = 2;
//
//			while (aResultSet.next()) {
//
//				row = sheet.createRow(i);
//
//				cell = row.createCell(0);
//				cell.setCellValue(aResultSet.getString(1));
//				cell = row.createCell(1);
//				cell.setCellValue(aResultSet.getString(2));
//				cell = row.createCell(2);
//				cell.setCellValue(aResultSet.getString(3));
//				cell = row.createCell(3);
//				cell.setCellValue(aResultSet.getString(4));
//				cell = row.createCell(4);
//				cell.setCellValue(aResultSet.getString(5));
//				cell = row.createCell(5);
//				cell.setCellValue(aResultSet.getString(6));
//				cell = row.createCell(6);
//				cell.setCellValue(aResultSet.getString(7));
//				cell = row.createCell(7);
//				cell.setCellValue(aResultSet.getString(8));
//				cell = row.createCell(8);
//				cell.setCellValue(aResultSet.getString(9));
//				cell = row.createCell(9);
//				cell.setCellValue(aResultSet.getString(10));
//				cell = row.createCell(10);
//				cell.setCellValue(aResultSet.getString(11));
//				cell = row.createCell(11);
//				cell.setCellValue(aResultSet.getString(12));
//				cell = row.createCell(12);
//				cell.setCellValue(aResultSet.getString(13));
//				cell = row.createCell(13);
//				cell.setCellValue(aResultSet.getString(14));
//				cell = row.createCell(14);
//				cell.setCellValue(aResultSet.getString(15));
//				cell = row.createCell(15);
//				cell.setCellValue(aResultSet.getString(16));
//
//				i++;
//
//			}
//
//			ByteArrayOutputStream outByteStream = new ByteArrayOutputStream();
//			wb.write(outByteStream);
//			byte[] outArray = outByteStream.toByteArray();
//
//			response.setContentType("application/ms-excel");
//			response.setContentLength(outArray.length);
//
//			response.setHeader("Expires:", "0"); // eliminates browser caching
//			response.setHeader("Content-Disposition",
//					"attachment; filename=DetailedReport.xls");
//			OutputStream outStream = response.getOutputStream();
//			logger.info("Before write" + outArray.length);
//			outStream.write(outArray);
//
//			logger.info("After write");
//			outStream.flush();
//		} catch (Exception e) {
//			e.printStackTrace();
//			throw e;
//		} finally {
//			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
//
//		}
//		logger.info(ActionConstants.EXITING_METHOD
//				+ "<<generateODCDetailedReportInExcel DB Helper");
//	}

//	public void generateALLDetailedReportInExcel(String DetailedReportQuery)
//			throws Exception {
//		logger.info(ActionConstants.ENTERING_METHOD
//				+ "<<generateALLDetailedReportInExcel DB Helper");
//
//		Connection aConnection = null;
//		PreparedStatement aPreparedStatement = null;
//		ResultSet aResultSet = null;
//
//		try {
//
//			aConnection = DBUtility.getZoneConnection();
//			aPreparedStatement = aConnection
//					.prepareStatement(DetailedReportQuery);
//
//			aResultSet = aPreparedStatement.executeQuery();
//			logger.info("Getting Detailed report query (ALL) ------>"
//					+ DetailedReportQuery);
//
//			HttpServletResponse response = (HttpServletResponse) ActionContext
//					.getContext().get(ServletActionContext.HTTP_RESPONSE);
//
//			HSSFWorkbook wb = new HSSFWorkbook();
//			HSSFSheet sheet = wb.createSheet();
//			HSSFRow row = sheet.createRow(0);
//			CellStyle style = wb.createCellStyle();
//			style.setWrapText(true);
//
//			sheet.addMergedRegion(new CellRangeAddress(0, // first row (0-based)
//					0, // last row (0-based)
//					0, // first column (0-based)
//					12 // last column (0-based)
//			));
//
//			row = sheet.createRow(0);
//			HSSFCell cell = row.createCell(0);
//			cell = row.createCell(0);
//			cell.setCellValue("DETAILED REPORT");
//			row = sheet.createRow(1);
//			cell = row.createCell(0);
//			cell.setCellValue("REQUEST TYPE");
//			cell = row.createCell(1);
//			cell.setCellValue("SUB PRODUCT");
//			cell = row.createCell(2);
//			cell.setCellValue("REQUEST ID");
//			cell = row.createCell(3);
//			cell.setCellValue("FINACLE TRANSACTION NO");
//			cell = row.createCell(4);
//			cell.setCellValue("TRANSACTION GENERATED TIME");
//			cell = row.createCell(5);
//			cell.setCellValue("SOL ID");
//			cell = row.createCell(6);
//			cell.setCellValue("BRANCH ALPHA");
//			cell = row.createCell(7);
//			cell.setCellValue("CUSTOMER NAME");
//			cell = row.createCell(8);
//			cell.setCellValue("CURRENCY");
//			cell = row.createCell(9);
//			cell.setCellValue("TRANSACTION AMOUNT");
//			cell = row.createCell(10);
//			cell.setCellValue("STATUS");
//			cell = row.createCell(11);
//			cell.setCellValue("STATUS CHANGED BY");
//			cell = row.createCell(12);
//			cell.setCellValue("STATUS CHANGED TIME");
//			cell = row.createCell(13);
//			cell.setCellValue("REQUEST CYCLE");
//			cell = row.createCell(14);
//			cell.setCellValue("SENDER REFERENCR NO");
//			cell = row.createCell(15);
//			cell.setCellValue("DOCUMENT DISPATCH");
//			cell = row.createCell(16);
//			cell.setCellValue("Dummy IREX");
//
//			int i = 2;
//
//			while (aResultSet.next()) {
//
//				row = sheet.createRow(i);
//
//				cell = row.createCell(0);
//				cell.setCellValue(aResultSet.getString(1));
//				cell = row.createCell(1);
//				cell.setCellValue(aResultSet.getString(2));
//				cell = row.createCell(2);
//				cell.setCellValue(aResultSet.getString(3));
//				cell = row.createCell(3);
//				cell.setCellValue(aResultSet.getString(4));
//				cell = row.createCell(4);
//				cell.setCellValue(aResultSet.getString(5));
//				cell = row.createCell(5);
//				cell.setCellValue(aResultSet.getString(6));
//				cell = row.createCell(6);
//				cell.setCellValue(aResultSet.getString(7));
//				cell = row.createCell(7);
//				cell.setCellValue(aResultSet.getString(8));
//				cell = row.createCell(8);
//				cell.setCellValue(aResultSet.getString(9));
//				cell = row.createCell(9);
//				cell.setCellValue(aResultSet.getString(10));
//				cell = row.createCell(10);
//				cell.setCellValue(aResultSet.getString(11));
//				cell = row.createCell(11);
//				cell.setCellValue(aResultSet.getString(12));
//				cell = row.createCell(12);
//				cell.setCellValue(aResultSet.getString(13));
//				cell = row.createCell(13);
//				cell.setCellValue(aResultSet.getString(14));
//				cell = row.createCell(14);
//				cell.setCellValue(aResultSet.getString(15));
//				cell = row.createCell(15);
//				cell.setCellValue(aResultSet.getString(16));
//				cell = row.createCell(16);
//				cell.setCellValue(aResultSet.getString(17));
//
//				i++;
//
//			}
//
//			ByteArrayOutputStream outByteStream = new ByteArrayOutputStream();
//			wb.write(outByteStream);
//			byte[] outArray = outByteStream.toByteArray();
//
//			response.setContentType("application/ms-excel");
//			response.setContentLength(outArray.length);
//
//			response.setHeader("Expires:", "0"); // eliminates browser caching
//			response.setHeader("Content-Disposition",
//					"attachment; filename=DetailedReport.xls");
//			OutputStream outStream = response.getOutputStream();
//			logger.info("Before write" + outArray.length);
//			outStream.write(outArray);
//
//			logger.info("After write");
//			outStream.flush();
//		} catch (Exception e) {
//			e.printStackTrace();
//			throw e;
//		} finally {
//			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
//
//		}
//		logger.info(ActionConstants.EXITING_METHOD
//				+ "<<generateALLDetailedReportInExcel DB Helper");
//	}

//	public void generateCPCODetailedReportInExcel(String cpcoDetailedReportQuery)
//			throws Exception {
//		logger.info(ActionConstants.ENTERING_METHOD
//				+ "<<generateCPCODetailedReportInExcel DB Helper");
//
//		Connection aConnection = null;
//		PreparedStatement aPreparedStatement = null;
//		ResultSet aResultSet = null;
//
//		try {
//
//			aConnection = DBUtility.getZoneConnection();
//			aPreparedStatement = aConnection
//					.prepareStatement(cpcoDetailedReportQuery);
//
//			aResultSet = aPreparedStatement.executeQuery();
//			logger.info("Getting CPCO Detailed Report query------>"
//					+ cpcoDetailedReportQuery);
//
//			HttpServletResponse response = (HttpServletResponse) ActionContext
//					.getContext().get(ServletActionContext.HTTP_RESPONSE);
//
//			HSSFWorkbook wb = new HSSFWorkbook();
//			HSSFSheet sheet = wb.createSheet();
//			HSSFRow row = sheet.createRow(0);
//			CellStyle style = wb.createCellStyle();
//			style.setWrapText(true);
//
//			sheet.addMergedRegion(new CellRangeAddress(0, // first row (0-based)
//					0, // last row (0-based)
//					0, // first column (0-based)
//					12 // last column (0-based)
//			));
//
//			row = sheet.createRow(0);
//			HSSFCell cell = row.createCell(0);
//			cell = row.createCell(0);
//			cell.setCellValue("DETAILED REPORT");
//			row = sheet.createRow(1);
//			cell = row.createCell(0);
//			cell.setCellValue("REQUEST TYPE");
//			cell = row.createCell(1);
//			cell.setCellValue("SUB PRODUCT");
//			cell = row.createCell(2);
//			cell.setCellValue("REQUEST ID");
//			cell = row.createCell(3);
//			cell.setCellValue("FINACLE TRANSACTION NO");
//			cell = row.createCell(4);
//			cell.setCellValue("TRANSACTION GENERATED TIME");
//			cell = row.createCell(5);
//			cell.setCellValue("SOL ID");
//			cell = row.createCell(6);
//			cell.setCellValue("BRANCH ALPHA");
//			cell = row.createCell(7);
//			cell.setCellValue("CUSTOMER NAME");
//			cell = row.createCell(8);
//			cell.setCellValue("CURRENCY");
//			cell = row.createCell(9);
//			cell.setCellValue("TRANSACTION AMOUNT");
//			cell = row.createCell(10);
//			cell.setCellValue("STATUS");
//			cell = row.createCell(11);
//			cell.setCellValue("STATUS CHANGED BY");
//			cell = row.createCell(12);
//			cell.setCellValue("STATUS CHANGED TIME");
//			cell = row.createCell(13);
//			cell.setCellValue("REQUEST CYCLE");
//
//			int i = 2;
//
//			while (aResultSet.next()) {
//
//				row = sheet.createRow(i);
//
//				cell = row.createCell(0);
//				cell.setCellValue(aResultSet.getString(1));
//				cell = row.createCell(1);
//				cell.setCellValue(aResultSet.getString(2));
//				cell = row.createCell(2);
//				cell.setCellValue(aResultSet.getString(3));
//				cell = row.createCell(3);
//				cell.setCellValue(aResultSet.getString(4));
//				cell = row.createCell(4);
//				cell.setCellValue(aResultSet.getString(5));
//				cell = row.createCell(5);
//				cell.setCellValue(aResultSet.getString(6));
//				cell = row.createCell(6);
//				cell.setCellValue(aResultSet.getString(7));
//				cell = row.createCell(7);
//				cell.setCellValue(aResultSet.getString(8));
//				cell = row.createCell(8);
//				cell.setCellValue(aResultSet.getString(9));
//				cell = row.createCell(9);
//				cell.setCellValue(aResultSet.getString(10));
//				cell = row.createCell(10);
//				cell.setCellValue(aResultSet.getString(11));
//				cell = row.createCell(11);
//				cell.setCellValue(aResultSet.getString(12));
//				cell = row.createCell(12);
//				cell.setCellValue(aResultSet.getString(13));
//				cell = row.createCell(13);
//				cell.setCellValue(aResultSet.getString(14));
//
//				i++;
//
//			}
//
//			ByteArrayOutputStream outByteStream = new ByteArrayOutputStream();
//			wb.write(outByteStream);
//			byte[] outArray = outByteStream.toByteArray();
//
//			response.setContentType("application/ms-excel");
//			response.setContentLength(outArray.length);
//
//			response.setHeader("Expires:", "0"); // eliminates browser caching
//			response.setHeader("Content-Disposition",
//					"attachment; filename=DetailedReport.xls");
//			OutputStream outStream = response.getOutputStream();
//			logger.info("Before write" + outArray.length);
//			outStream.write(outArray);
//
//			logger.info("After write");
//			outStream.flush();
//		} catch (Exception e) {
//			e.printStackTrace();
//			throw e;
//		} finally {
//			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
//
//		}
//		logger.info(ActionConstants.EXITING_METHOD
//				+ "<<generateCPCODetailedReportInExcel DB Helper");
//	}

//	public void generateIGTDetailedReportInExcel(String igtDetailedReportQuery)
//			throws Exception {
//		logger.info(ActionConstants.ENTERING_METHOD
//				+ "<<generateFSADetailedReportInExcel DB Helper");
//
//		Connection aConnection = null;
//		PreparedStatement aPreparedStatement = null;
//		ResultSet aResultSet = null;
//
//		try {
//
//			aConnection = DBUtility.getZoneConnection();
//			aPreparedStatement = aConnection
//					.prepareStatement(igtDetailedReportQuery);
//
//			aResultSet = aPreparedStatement.executeQuery();
//			logger.info("Getting IGT Detailed Report query------>"
//					+ igtDetailedReportQuery);
//
//			HttpServletResponse response = (HttpServletResponse) ActionContext
//					.getContext().get(ServletActionContext.HTTP_RESPONSE);
//
//			HSSFWorkbook wb = new HSSFWorkbook();
//			HSSFSheet sheet = wb.createSheet();
//			HSSFRow row = sheet.createRow(0);
//			CellStyle style = wb.createCellStyle();
//			style.setWrapText(true);
//
//			sheet.addMergedRegion(new CellRangeAddress(0, // first row (0-based)
//					0, // last row (0-based)
//					0, // first column (0-based)
//					12 // last column (0-based)
//			));
//
//			row = sheet.createRow(0);
//			HSSFCell cell = row.createCell(0);
//			cell = row.createCell(0);
//			cell.setCellValue("DETAILED REPORT");
//			row = sheet.createRow(1);
//			cell = row.createCell(0);
//			cell.setCellValue("REQUEST TYPE");
//			cell = row.createCell(1);
//			cell.setCellValue("SUB PRODUCT");
//			cell = row.createCell(2);
//			cell.setCellValue("REQUEST ID");
//			cell = row.createCell(3);
//			cell.setCellValue("FINACLE TRANSACTION NO");
//			cell = row.createCell(4);
//			cell.setCellValue("TRANSACTION GENERATED TIME");
//			cell = row.createCell(5);
//			cell.setCellValue("SOL ID");
//			cell = row.createCell(6);
//			cell.setCellValue("BRANCH ALPHA");
//			cell = row.createCell(7);
//			cell.setCellValue("CUSTOMER NAME");
//			cell = row.createCell(8);
//			cell.setCellValue("CURRENCY");
//			cell = row.createCell(9);
//			cell.setCellValue("TRANSACTION AMOUNT");
//			cell = row.createCell(10);
//			cell.setCellValue("STATUS");
//			cell = row.createCell(11);
//			cell.setCellValue("STATUS CHANGED BY");
//			cell = row.createCell(12);
//			cell.setCellValue("STATUS CHANGED TIME");
//			cell = row.createCell(13);
//			cell.setCellValue("REQUEST CYCLE");
//
//			int i = 2;
//
//			while (aResultSet.next()) {
//
//				row = sheet.createRow(i);
//
//				cell = row.createCell(0);
//				cell.setCellValue(aResultSet.getString(1));
//				cell = row.createCell(1);
//				cell.setCellValue(aResultSet.getString(2));
//				cell = row.createCell(2);
//				cell.setCellValue(aResultSet.getString(3));
//				cell = row.createCell(3);
//				cell.setCellValue(aResultSet.getString(4));
//				cell = row.createCell(4);
//				cell.setCellValue(aResultSet.getString(5));
//				cell = row.createCell(5);
//				cell.setCellValue(aResultSet.getString(6));
//				cell = row.createCell(6);
//				cell.setCellValue(aResultSet.getString(7));
//				cell = row.createCell(7);
//				cell.setCellValue(aResultSet.getString(8));
//				cell = row.createCell(8);
//				cell.setCellValue(aResultSet.getString(9));
//				cell = row.createCell(9);
//				cell.setCellValue(aResultSet.getString(10));
//				cell = row.createCell(10);
//				cell.setCellValue(aResultSet.getString(11));
//				cell = row.createCell(11);
//				cell.setCellValue(aResultSet.getString(12));
//				cell = row.createCell(12);
//				cell.setCellValue(aResultSet.getString(13));
//				cell = row.createCell(13);
//				cell.setCellValue(aResultSet.getString(14));
//
//				i++;
//
//			}
//
//			ByteArrayOutputStream outByteStream = new ByteArrayOutputStream();
//			wb.write(outByteStream);
//			byte[] outArray = outByteStream.toByteArray();
//
//			response.setContentType("application/ms-excel");
//			response.setContentLength(outArray.length);
//
//			response.setHeader("Expires:", "0"); // eliminates browser caching
//			response.setHeader("Content-Disposition",
//					"attachment; filename=DetailedReport.xls");
//			OutputStream outStream = response.getOutputStream();
//			logger.info("Before write" + outArray.length);
//			outStream.write(outArray);
//
//			logger.info("After write");
//			outStream.flush();
//		} catch (Exception e) {
//			e.printStackTrace();
//			throw e;
//		} finally {
//			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
//
//		}
//		logger.info(ActionConstants.EXITING_METHOD
//				+ "<<generateIGTDetailedReportInExcel DB Helper");
//	}

//	public void generateFELDetailedReportInExcel(String felDetailedReportQuery)
//			throws Exception {
//		logger.info(ActionConstants.ENTERING_METHOD
//				+ "<<generateFELDetailedReportInExcel DB Helper");
//
//		Connection aConnection = null;
//		PreparedStatement aPreparedStatement = null;
//		ResultSet aResultSet = null;
//
//		try {
//
//			aConnection = DBUtility.getZoneConnection();
//			aPreparedStatement = aConnection
//					.prepareStatement(felDetailedReportQuery);
//
//			aResultSet = aPreparedStatement.executeQuery();
//			logger.info("Getting FEL Detailed Report query------>"
//					+ felDetailedReportQuery);
//
//			HttpServletResponse response = (HttpServletResponse) ActionContext
//					.getContext().get(ServletActionContext.HTTP_RESPONSE);
//
//			HSSFWorkbook wb = new HSSFWorkbook();
//			HSSFSheet sheet = wb.createSheet();
//			HSSFRow row = sheet.createRow(0);
//			CellStyle style = wb.createCellStyle();
//			style.setWrapText(true);
//
//			sheet.addMergedRegion(new CellRangeAddress(0, // first row (0-based)
//					0, // last row (0-based)
//					0, // first column (0-based)
//					12 // last column (0-based)
//			));
//
//			row = sheet.createRow(0);
//			HSSFCell cell = row.createCell(0);
//			cell = row.createCell(0);
//			cell.setCellValue("DETAILED REPORT");
//			row = sheet.createRow(1);
//			cell = row.createCell(0);
//			cell.setCellValue("REQUEST TYPE");
//			cell = row.createCell(1);
//			cell.setCellValue("SUB PRODUCT");
//			cell = row.createCell(2);
//			cell.setCellValue("REQUEST ID");
//			cell = row.createCell(3);
//			cell.setCellValue("FINACLE TRANSACTION NO");
//			cell = row.createCell(4);
//			cell.setCellValue("TRANSACTION GENERATED TIME");
//			cell = row.createCell(5);
//			cell.setCellValue("SOL ID");
//			cell = row.createCell(6);
//			cell.setCellValue("BRANCH ALPHA");
//			cell = row.createCell(7);
//			cell.setCellValue("CUSTOMER NAME");
//			cell = row.createCell(8);
//			cell.setCellValue("CURRENCY");
//			cell = row.createCell(9);
//			cell.setCellValue("TRANSACTION AMOUNT");
//			cell = row.createCell(10);
//			cell.setCellValue("STATUS");
//			cell = row.createCell(11);
//			cell.setCellValue("STATUS CHANGED BY");
//			cell = row.createCell(12);
//			cell.setCellValue("STATUS CHANGED TIME");
//			cell = row.createCell(13);
//			cell.setCellValue("REQUEST CYCLE");
//			cell = row.createCell(14);
//			cell.setCellValue("SENDER REFERENCE NO");
//
//			int i = 2;
//
//			while (aResultSet.next()) {
//
//				row = sheet.createRow(i);
//
//				cell = row.createCell(0);
//				cell.setCellValue(aResultSet.getString(1));
//				cell = row.createCell(1);
//				cell.setCellValue(aResultSet.getString(2));
//				cell = row.createCell(2);
//				cell.setCellValue(aResultSet.getString(3));
//				cell = row.createCell(3);
//				cell.setCellValue(aResultSet.getString(4));
//				cell = row.createCell(4);
//				cell.setCellValue(aResultSet.getString(5));
//				cell = row.createCell(5);
//				cell.setCellValue(aResultSet.getString(6));
//				cell = row.createCell(6);
//				cell.setCellValue(aResultSet.getString(7));
//				cell = row.createCell(7);
//				cell.setCellValue(aResultSet.getString(8));
//				cell = row.createCell(8);
//				cell.setCellValue(aResultSet.getString(9));
//				cell = row.createCell(9);
//				cell.setCellValue(aResultSet.getString(10));
//				cell = row.createCell(10);
//				cell.setCellValue(aResultSet.getString(11));
//				cell = row.createCell(11);
//				cell.setCellValue(aResultSet.getString(12));
//				cell = row.createCell(12);
//				cell.setCellValue(aResultSet.getString(13));
//				cell = row.createCell(13);
//				cell.setCellValue(aResultSet.getString(14));
//				cell = row.createCell(14);
//				cell.setCellValue(aResultSet.getString(15));
//
//				i++;
//
//			}
//
//			ByteArrayOutputStream outByteStream = new ByteArrayOutputStream();
//			wb.write(outByteStream);
//			byte[] outArray = outByteStream.toByteArray();
//
//			response.setContentType("application/ms-excel");
//			response.setContentLength(outArray.length);
//
//			response.setHeader("Expires:", "0"); // eliminates browser caching
//			response.setHeader("Content-Disposition",
//					"attachment; filename=DetailedReport.xls");
//			OutputStream outStream = response.getOutputStream();
//			logger.info("Before write" + outArray.length);
//			outStream.write(outArray);
//
//			logger.info("After write");
//			outStream.flush();
//		} catch (Exception e) {
//			e.printStackTrace();
//			throw e;
//		} finally {
//			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
//
//		}
//		logger.info(ActionConstants.EXITING_METHOD
//				+ "<<generateFELDetailedReportInExcel DB Helper");
//	}

//	public void generateCORDetailedReportInExcel(String corDetailedReportQuery)
//			throws Exception {
//		logger.info(ActionConstants.ENTERING_METHOD
//				+ "<<generateCORDetailedReportInExcel DB Helper");
//
//		Connection aConnection = null;
//		PreparedStatement aPreparedStatement = null;
//		ResultSet aResultSet = null;
//
//		try {
//
//			aConnection = DBUtility.getZoneConnection();
//			aPreparedStatement = aConnection
//					.prepareStatement(corDetailedReportQuery);
//
//			aResultSet = aPreparedStatement.executeQuery();
//			logger.info("Getting COR Detailed Report query------>"
//					+ corDetailedReportQuery);
//
//			HttpServletResponse response = (HttpServletResponse) ActionContext
//					.getContext().get(ServletActionContext.HTTP_RESPONSE);
//
//			HSSFWorkbook wb = new HSSFWorkbook();
//			HSSFSheet sheet = wb.createSheet();
//			HSSFRow row = sheet.createRow(0);
//			CellStyle style = wb.createCellStyle();
//			style.setWrapText(true);
//
//			sheet.addMergedRegion(new CellRangeAddress(0, // first row (0-based)
//					0, // last row (0-based)
//					0, // first column (0-based)
//					12 // last column (0-based)
//			));
//
//			row = sheet.createRow(0);
//			HSSFCell cell = row.createCell(0);
//			cell = row.createCell(0);
//			cell.setCellValue("DETAILED REPORT");
//			row = sheet.createRow(1);
//			cell = row.createCell(0);
//			cell.setCellValue("REQUEST TYPE");
//			cell = row.createCell(1);
//			cell.setCellValue("SUB PRODUCT");
//			cell = row.createCell(2);
//			cell.setCellValue("REQUEST ID");
//			cell = row.createCell(3);
//			cell.setCellValue("FINACLE TRANSACTION NO");
//			cell = row.createCell(4);
//			cell.setCellValue("TRANSACTION GENERATED TIME");
//			cell = row.createCell(5);
//			cell.setCellValue("SOL ID");
//			cell = row.createCell(6);
//			cell.setCellValue("BRANCH ALPHA");
//			cell = row.createCell(7);
//			cell.setCellValue("CUSTOMER NAME");
//			cell = row.createCell(8);
//			cell.setCellValue("CURRENCY");
//			cell = row.createCell(9);
//			cell.setCellValue("TRANSACTION AMOUNT");
//			cell = row.createCell(10);
//			cell.setCellValue("STATUS");
//			cell = row.createCell(11);
//			cell.setCellValue("STATUS CHANGED BY");
//			cell = row.createCell(12);
//			cell.setCellValue("STATUS CHANGED TIME");
//			cell = row.createCell(13);
//			cell.setCellValue("REQUEST CYCLE");
//
//			int i = 2;
//
//			while (aResultSet.next()) {
//
//				row = sheet.createRow(i);
//
//				cell = row.createCell(0);
//				cell.setCellValue(aResultSet.getString(1));
//				cell = row.createCell(1);
//				cell.setCellValue(aResultSet.getString(2));
//				cell = row.createCell(2);
//				cell.setCellValue(aResultSet.getString(3));
//				cell = row.createCell(3);
//				cell.setCellValue(aResultSet.getString(4));
//				cell = row.createCell(4);
//				cell.setCellValue(aResultSet.getString(5));
//				cell = row.createCell(5);
//				cell.setCellValue(aResultSet.getString(6));
//				cell = row.createCell(6);
//				cell.setCellValue(aResultSet.getString(7));
//				cell = row.createCell(7);
//				cell.setCellValue(aResultSet.getString(8));
//				cell = row.createCell(8);
//				cell.setCellValue(aResultSet.getString(9));
//				cell = row.createCell(9);
//				cell.setCellValue(aResultSet.getString(10));
//				cell = row.createCell(10);
//				cell.setCellValue(aResultSet.getString(11));
//				cell = row.createCell(11);
//				cell.setCellValue(aResultSet.getString(12));
//				cell = row.createCell(12);
//				cell.setCellValue(aResultSet.getString(13));
//				cell = row.createCell(13);
//				cell.setCellValue(aResultSet.getString(14));
//
//				i++;
//
//			}
//
//			ByteArrayOutputStream outByteStream = new ByteArrayOutputStream();
//			wb.write(outByteStream);
//			byte[] outArray = outByteStream.toByteArray();
//
//			response.setContentType("application/ms-excel");
//			response.setContentLength(outArray.length);
//
//			response.setHeader("Expires:", "0"); // eliminates browser caching
//			response.setHeader("Content-Disposition",
//					"attachment; filename=DetailedReport.xls");
//			OutputStream outStream = response.getOutputStream();
//			logger.info("Before write" + outArray.length);
//			outStream.write(outArray);
//
//			logger.info("After write");
//			outStream.flush();
//		} catch (Exception e) {
//			e.printStackTrace();
//			throw e;
//		} finally {
//			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
//
//		}
//		logger.info(ActionConstants.EXITING_METHOD
//				+ "<<generateCORDetailedReportInExcel DB Helper");
//	}

	/*
	 * public void updatemakerMiscellComment(UserTransactionVO userVo, String
	 * query, String missComment) { String reqID = userVo.getRequestId(); String
	 * userName = userVo.getSessionUserName(); PreparedStatement
	 * aPreparedStatement = null; Connection aConnection = null; try {
	 * aConnection = DBUtility.getZoneConnection(); aPreparedStatement =
	 * aConnection.prepareStatement(query); aPreparedStatement.setString(1,
	 * missComment); aPreparedStatement.setString(2, reqID.trim());
	 * aPreparedStatement.setString(3, userName.trim());
	 * aPreparedStatement.executeUpdate(); } catch (Exception e) {
	 * e.printStackTrace(); } finally { DBUtility.surrenderDB(aConnection,
	 * aPreparedStatement, null); } logger.info(ActionConstants.EXITING_METHOD +
	 * "getValueFromDB"); }
	 * 
	 * public void updateMiscellCheckerComment(UserTransactionVO userVo, String
	 * query, String misscheckerComment) { String reqID = userVo.getRequestId();
	 * String userName = userVo.getSessionUserName(); PreparedStatement
	 * aPreparedStatement = null; Connection aConnection = null; try {
	 * aConnection = DBUtility.getZoneConnection(); aPreparedStatement =
	 * aConnection.prepareStatement(query); aPreparedStatement.setString(1,
	 * misscheckerComment); aPreparedStatement.setString(2, userName.trim());
	 * aPreparedStatement.setString(3, reqID.trim());
	 * aPreparedStatement.executeUpdate(); } catch (Exception e) {
	 * e.printStackTrace(); } finally { DBUtility.surrenderDB(aConnection,
	 * aPreparedStatement, null); } logger.info(ActionConstants.EXITING_METHOD +
	 * "getValueFromDB");
	 * 
	 * }
	 * 
	 * public void getmiscellCommentFromDB(UserTransactionVO userVo, String
	 * query) { ResultSet aResultSet = null; PreparedStatement
	 * aPreparedStatement = null; Connection aConnection = null;
	 * 
	 * try { aConnection = DBUtility.getZoneConnection(); aPreparedStatement =
	 * aConnection.prepareStatement(query); aPreparedStatement.setString(1,
	 * userVo.getRequestId().trim()); aResultSet =
	 * aPreparedStatement.executeQuery(); while (aResultSet.next()) {
	 * userVo.setMiscellComment(aResultSet.getString(1)); }
	 * System.out.println(userVo.getMiscellComment() + "-----cmt----"); } catch
	 * (Exception e) { e.printStackTrace(); } finally {
	 * DBUtility.surrenderDB(aConnection, aPreparedStatement, null); } }
	 */
	/*
	 * public void updatemakerMiscellComment(UserTransactionVO userVo, String
	 * query, String missComment) { String reqID = userVo.getRequestId(); String
	 * userName = userVo.getSessionUserName(); String satus =
	 * "Fbo Maker Release"; String flag = "1"; PreparedStatement
	 * aPreparedStatement = null; Connection aConnection = null; try {
	 * aConnection = DBUtility.getZoneConnection(); aPreparedStatement =
	 * aConnection.prepareStatement(query); aPreparedStatement.setString(1,
	 * missComment); aPreparedStatement.setString(2, reqID.trim());
	 * aPreparedStatement.setString(3, userName.trim());
	 * aPreparedStatement.setString(4, satus.trim());
	 * aPreparedStatement.setString(5, flag.trim());
	 * aPreparedStatement.executeUpdate(); } catch (Exception e) {
	 * e.printStackTrace(); } finally { DBUtility.surrenderDB(aConnection,
	 * aPreparedStatement, null); } logger.info(ActionConstants.EXITING_METHOD +
	 * "getValueFromDB"); }
	 */
	/*
	 * public void updateMiscellCheckerComment(UserTransactionVO userVo, String
	 * query, String misscheckerComment) { String reqID = userVo.getRequestId();
	 * String userName = userVo.getSessionUserName(); String satus =
	 * "Fbo Checker Release"; String flag = "0"; PreparedStatement
	 * aPreparedStatement = null; Connection aConnection = null; ResultSet
	 * aResultSet = null; // int count = 0; try { aConnection =
	 * DBUtility.getZoneConnection(); aPreparedStatement =
	 * aConnection.prepareStatement(query); System.out.println("query=====" +
	 * query); // aResultSet = aPreparedStatement.executeQuery();
	 * aPreparedStatement.setString(1, misscheckerComment);
	 * aPreparedStatement.setString(2, userName.trim());
	 * aPreparedStatement.setString(3, satus.trim());
	 * aPreparedStatement.setString(4, flag.trim());
	 * aPreparedStatement.setString(5, reqID.trim());
	 * 
	 * aResultSet = aPreparedStatement.executeQuery();
	 * 
	 * } catch (Exception e) { e.printStackTrace(); } finally {
	 * DBUtility.surrenderDB(aConnection, aPreparedStatement, null); }
	 * logger.info(ActionConstants.EXITING_METHOD + "getValueFromDB");
	 * 
	 * }
	 */

	/*
	 * public void getmiscellCommentFromDB(UserTransactionVO userVo, String
	 * query) { ResultSet aResultSet = null; PreparedStatement
	 * aPreparedStatement = null; Connection aConnection = null;
	 * 
	 * try { aConnection = DBUtility.getZoneConnection(); aPreparedStatement =
	 * aConnection.prepareStatement(query); aPreparedStatement.setString(1,
	 * userVo.getRequestId().trim()); aResultSet =
	 * aPreparedStatement.executeQuery(); while (aResultSet.next()) {
	 * userVo.setMiscellComment(aResultSet.getString(1)); }
	 * System.out.println(userVo.getMiscellComment() + "-----cmt----"); } catch
	 * (Exception e) { e.printStackTrace(); } finally {
	 * DBUtility.surrenderDB(aConnection, aPreparedStatement, null); } }
	 */

	/*
	 * public void getmiscellCommentFromDB(UserTransactionVO userVo, String
	 * query) { ResultSet aResultSet = null; PreparedStatement
	 * aPreparedStatement = null; Connection aConnection = null;
	 * 
	 * try { aConnection = DBUtility.getZoneConnection(); aPreparedStatement =
	 * aConnection.prepareStatement(query); aPreparedStatement.setString(1,
	 * userVo.getRequestId().trim()); aResultSet =
	 * aPreparedStatement.executeQuery(); while (aResultSet.next()) {
	 * userVo.setMiscellComment(aResultSet.getString(1));
	 * userVo.setMiscellcheckerComment(aResultSet.getString(2)); }
	 * 
	 * } catch (Exception e) { e.printStackTrace(); } finally {
	 * DBUtility.surrenderDB(aConnection, aPreparedStatement, null); } }
	 */
	public void updatemakerMiscellComment(UserTransactionVO userVo,
			String query, String missComment) {
		String reqID = userVo.getRequestId();
		String userName = userVo.getSessionUserName();
		String satus = "Fbo Maker Release";
		String flag = "1";
		PreparedStatement aPreparedStatement = null;
		Connection aConnection = null;
		try {
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);
			aPreparedStatement.setString(1, missComment);
			aPreparedStatement.setString(2, reqID.trim());
			aPreparedStatement.setString(3, userName.trim());
			aPreparedStatement.setString(4, satus.trim());
			aPreparedStatement.setString(5, flag.trim());
			aPreparedStatement.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, null);
		}
		logger.info(ActionConstants.EXITING_METHOD + "getValueFromDB");
	}

	public void updateMiscellCheckerComment(UserTransactionVO userVo,
			String query, String misscheckerComment) {
		String reqID = userVo.getRequestId();
		String userName = userVo.getSessionUserName();
		String satus = "Fbo Checker Release";
		String flag = "0";
		PreparedStatement aPreparedStatement = null;
		Connection aConnection = null;
		ResultSet aResultSet = null;
		// int count = 0;
		try {
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);
			System.out.println("query=====" + query);
			// aResultSet = aPreparedStatement.executeQuery();
			aPreparedStatement.setString(1, misscheckerComment);
			aPreparedStatement.setString(2, userName.trim());
			aPreparedStatement.setString(3, satus.trim());
			aPreparedStatement.setString(4, flag.trim());
			aPreparedStatement.setString(5, reqID.trim());

			aResultSet = aPreparedStatement.executeQuery();

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, null);
		}
		logger.info(ActionConstants.EXITING_METHOD + "getValueFromDB");

	}

	public void getmiscellCommentFromDB(UserTransactionVO userVo, String query) {
		ResultSet aResultSet = null;
		PreparedStatement aPreparedStatement = null;
		Connection aConnection = null;

		try {
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);
			aPreparedStatement.setString(1, userVo.getRequestId().trim());
			aResultSet = aPreparedStatement.executeQuery();
			while (aResultSet.next()) {
				userVo.setMiscellComment(aResultSet.getString(1));
				userVo.setMiscellcheckerComment(aResultSet.getString(2));
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, null);
		}
	}

	public boolean getTIInprogressCount(String value, String requestId,
			String query) throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD + "getValueFromDB");
		int resultValue = 0;
		Connection aConnection = null;
		ResultSet aResultSet = null;
		PreparedStatement aPreparedStatement = null;
		boolean flag = false;

		try {
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);
			logger.info("query-->" + query);
			aPreparedStatement.setString(1, requestId);
			aPreparedStatement.setString(2, value);
			aResultSet = aPreparedStatement.executeQuery();
			while (aResultSet.next()) {
				resultValue = aResultSet.getInt(1);
			}
			if (resultValue > 0) {
				flag = true;
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}
		logger.info(ActionConstants.EXITING_METHOD + "getValueFromDB");
		return flag;
	}

	public void setValuesIGTExpire(String requestId, String solID,
			String tiReferanceNo, String customeCif, String customeName,
			String amount, String currency, String tenure, String query) {

		Connection aConnection = null;
		ResultSet aResultSet = null;
		PreparedStatement aPreparedStatement = null;
		try {
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);
			logger.info("query-->" + query);
			aPreparedStatement.setString(1, solID);
			aPreparedStatement.setString(2, tiReferanceNo);
			aPreparedStatement.setString(3, customeCif);
			aPreparedStatement.setString(4, customeName);
			aPreparedStatement.setString(5, amount);
			aPreparedStatement.setString(6, currency);
			aPreparedStatement.setString(7, tenure);
			aPreparedStatement.setString(8, requestId.trim());
			aPreparedStatement.executeQuery();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}

	}

	public List<TFBOImportGTVO> getTFBOIGTExpireFromDB(String requestId,
			String query) {

		Connection aConnection = null;
		PreparedStatement aPreparedStatement = null;
		ResultSet aResultset = null;
		List<TFBOImportGTVO> importGTVOList = new LinkedList<TFBOImportGTVO>();
		TFBOImportGTVO importGTVO = null;
		logger.info("query >>-->" + query);
		try {
			importGTVO = new TFBOImportGTVO();
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);
			aPreparedStatement.setString(1, requestId.trim());
			aResultset = aPreparedStatement.executeQuery();
			while (aResultset.next()) {
				importGTVO.setTiReferenceNo(aResultset.getString(1));
				importGTVO.setSolID(aResultset.getString(2));
				importGTVO.setCustomeCif(aResultset.getString(3));
				importGTVO.setAmount(aResultset.getString(4));
				importGTVO.setCurrency(aResultset.getString(5));
				importGTVO.setTenure(aResultset.getString(6));
				importGTVO.setSubProductCode(aResultset.getString(7));
				importGTVOList.add(importGTVO);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, null);
		}
		return importGTVOList;
	}

 // Added by Kamakshya - for multiple login issue starts
	// CHECK USER AVAILABILITY
	public Boolean isUserAvailableInDBLOG(String userName, String query) {
		logger.info(ActionConstants.ENTERING_METHOD + "checkuserFromDBLOG");
		boolean resultValue = false;
		Connection aConnection = null;
		ResultSet aResultSet = null;
		PreparedStatement aPreparedStatement = null;
		try {
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);
			System.out.println("query-->" + query);
			aPreparedStatement.setString(1, userName);
			aResultSet = aPreparedStatement.executeQuery();
			System.out.println(userName);
			while (aResultSet.next()) {
				resultValue = true;
				System.out.println("result value" + resultValue);
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.info(ActionConstants.EXITING_METHOD + "checkuserFromDBLOG");
			return resultValue;
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}
		logger.info(ActionConstants.EXITING_METHOD + "checkuserFromDBLOG");
		return resultValue;
	}

	// Insert into DBLOG TABLE
	public Boolean isValueInsertDB(String userName, int flag, String query) {
		logger.info(ActionConstants.ENTERING_METHOD + "insertValueDB");
		Connection aConnection = null;
		ResultSet aResultSet = null;
		PreparedStatement aPreparedStatement = null;
		Boolean resultValue1 = false;
		try {
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);
			resultValue1 = true;
			logger.info("query-->" + query);
			System.out.println(query);
			System.out.println("INSIDE DB HELPER");
			aPreparedStatement.setString(1, userName);
			aPreparedStatement.setInt(2, flag);
			aPreparedStatement.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();
			logger.info(ActionConstants.EXITING_METHOD + "insertValueDB");
			resultValue1 = false;
			return resultValue1;
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}
		logger.info(ActionConstants.EXITING_METHOD + "insertValueDB");
		return resultValue1;
	}

	// isFlag Available in DBLOG table
	public Boolean isFlagAvailableInDBLOG(String userName, String query) {
		logger.info(ActionConstants.ENTERING_METHOD + "isFlagAvailableInDBLOG");
		boolean resultValue = false;
		Connection aConnection = null;
		ResultSet aResultSet = null;
		PreparedStatement aPreparedStatement = null;
		try {
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);
			System.out.println("query-->" + query);
			aPreparedStatement.setString(1, userName);
			aResultSet = aPreparedStatement.executeQuery();
			System.out.println(userName);
			System.out.println("TOTAL ROWS" + aResultSet.getRow());
			while (aResultSet.next()) {
				resultValue = true;
				System.out.println("hiiii" + resultValue);
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.info(ActionConstants.EXITING_METHOD
					+ "isFlagAvailableInDBLOG");
			return resultValue;
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}
		logger.info(ActionConstants.EXITING_METHOD + "checkuserFromDBLOG");
		return resultValue;
	}

	// Update flag and date in DBLOG table
	public void updateDBLOG(String userName, int flag, String query) {
		logger.info(ActionConstants.ENTERING_METHOD + "updateDBLOG");
		Connection aConnection = null;
		ResultSet aResultSet = null;
		PreparedStatement aPreparedStatement = null;
		try {
			aConnection = DBUtility.getZoneConnection();
			aPreparedStatement = aConnection.prepareStatement(query);
			logger.info("query-->" + query);
			System.out.println("FLAG" + flag);
			aPreparedStatement.setInt(1, flag);
			aPreparedStatement.setString(2, userName);
			aPreparedStatement.executeUpdate();
			System.out.println(query);
		} catch (Exception e) {
			e.printStackTrace();
			logger.info(ActionConstants.EXITING_METHOD + "updateDBLOG");
		} finally {
			DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
		}
		logger.info(ActionConstants.EXITING_METHOD + "updateDBLOG");
	}
	
  // Added by Kamakshya - for multiple login issue ends
	
  // Added by Kamakshya for SAC transaction start
			public void updateSACTransaction(String userNameSAC,String requestIDSAC) {
				logger.info(ActionConstants.ENTERING_METHOD + "updateSACTransaction");
				Connection aConnection = null;
				ResultSet aResultSet = null;
				PreparedStatement aPreparedStatement = null;
				try {
					aConnection = DBUtility.getZoneConnection();
					System.out.println(userNameSAC);
					System.out.println(requestIDSAC);
					String query = "UPDATE TFBO_TRANS SET TRAN_LOCK = 0 WHERE TRAN_LOCK = 1 ";
					if(userNameSAC != null && !userNameSAC.trim().equals("")){
						userNameSAC = userNameSAC.trim();
						query = query		+ "AND TRLKUSR = '"+userNameSAC+"'";
					}
					else
						userNameSAC = null;
					if(requestIDSAC != null && !requestIDSAC.trim().equals("")){
						requestIDSAC = requestIDSAC.trim();
						query = query	+ "AND REQUESTID = '"+requestIDSAC+"' ";
					}
					else
						requestIDSAC = null;
					aPreparedStatement = aConnection.prepareStatement(query);
					logger.info("query-->" + query);
					System.out.println("INSIDE QUERY");
					System.out.println(userNameSAC);
					System.out.println(requestIDSAC);
					int rowCount = aPreparedStatement.executeUpdate(query);
					System.out.println(rowCount);
					System.out.println(query);
				} catch (Exception e) {
					e.printStackTrace();
					logger.info(ActionConstants.EXITING_METHOD + "updateSACTransaction");
				} finally {
					DBUtility.surrenderDB(aConnection, aPreparedStatement, aResultSet);
				}
				logger.info(ActionConstants.EXITING_METHOD + "updateSACTransaction");
			}	
  // Added by Kamakshya for SAC transaction ends


}
