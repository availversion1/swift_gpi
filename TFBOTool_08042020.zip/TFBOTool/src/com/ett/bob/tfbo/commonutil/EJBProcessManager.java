package com.ett.bob.tfbo.commonutil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.Timestamp;
import java.util.Date;
import java.util.Hashtable;
import java.util.Properties;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.rmi.PortableRemoteObject;

import org.apache.log4j.Logger;

import com.ett.bob.tfbo.dbutil.DBUtility;
import com.ett.bob.tfbo.dbutil.PropertyUtil;
import com.ett.bob.tfbo.model.UserTransactionVO;
import com.ett.bob.tfbo.util.ActionConstants;
import com.misys.tiplus2.service.access.ejb.EnigmaServiceAccess;
import com.misys.tiplus2.service.access.ejb.EnigmaServiceAccessHome;

public class EJBProcessManager {
	private static Logger logger = Logger.getLogger(EJBProcessManager.class
			.getName());

	public Boolean postTIXml(String inputXML, UserTransactionVO userVo) {
		logger.info("Entering postTIXml method");
		CommonMethods aCommonMethods = new CommonMethods();
		Timestamp tiReqTime = getSqlLocalDateTime();
		Timestamp tiResTime = null;
		String responseXML = "";
		try {
			Properties aProperties = PropertyUtil.getPropertiesValue();
			String ejbPushUrl = aProperties.getProperty("EjbUrl");
			logger.info("Request XML to push in TI-----> " + inputXML);

			logger.info("EjbPushUrl-----> " + ejbPushUrl);
			responseXML = processInWS(inputXML, ejbPushUrl); // Cloud ENV
			// responseXML = processInWL(inputXML, ejbPushUrl); // BOB ENV
			tiResTime = getSqlLocalDateTime();
			if (!responseXML.equals("")) {
				if (aCommonMethods.getTagValue("Status", responseXML).equals(
						"SUCCEEDED")) {
					logger.info("Exiting postTIXml method");
					return true;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.info(e.getMessage());
			logger.info("Exiting postTIXml method");
			return false;
		} finally {
			insertIntoTFBOTransLogTable(userVo, inputXML, responseXML,
					tiReqTime, tiResTime,
					ActionConstants.INSERTINTOTFBOTRANSLOG);
		}
		logger.info("Exiting postTIXml method");
		return false;
	}

	/**
	 * EJB Method for Web logic
	 * 
	 * @param message
	 * @param EjbClientUrl
	 * @return ejbResponse
	 */
	public static String processInWL(String message, String EjbClientUrl) {
		logger.info("ENTERING_METHOD");
		logger.info("Entering fetchEJBResponse method");
		String result = "";
		Hashtable<String, String> env = new Hashtable<String, String>();
		logger.info("EjbClientUrl >>--->" + EjbClientUrl);
		try {
			logger.info("***********ENTERING EJB TRY************");
			logger.info("EJB Step1");
			env.put(Context.INITIAL_CONTEXT_FACTORY,
					"weblogic.jndi.WLInitialContextFactory");
			logger.info("EJB Step2");
			env.put(Context.PROVIDER_URL, EjbClientUrl);
			logger.info("EJB Step3");
			Context ctx = new InitialContext(env);
			Object ejbObject = ctx.lookup("ejb/EnigmaServiceAccess");
			logger.info("EJB Step4");
			EnigmaServiceAccessHome accessBeanHome = (EnigmaServiceAccessHome) PortableRemoteObject
					.narrow(ejbObject, EnigmaServiceAccessHome.class);
			logger.info("EJB Step5");
			EnigmaServiceAccess accessB = accessBeanHome.create();
			logger.info("EJB Step6");
			result = accessB.process(message);
			logger.info("EJB Step7");
			logger.info("Debugmessage:: EJB Response inside method-->" + result);
			logger.info("***********Exiting EJB TRY************");
		} catch (Exception e) {
			result = "Exception! >>--->" + e.getMessage();
			logger.error(EjbClientUrl + " Exception!" + e.getMessage());
			e.printStackTrace();
			return result;
		}
		logger.info("EXITING_METHOD");

		return result;
	}

	/**
	 * EJB Method for Web Sphere
	 * 
	 * @param message
	 * @param EjbClientUrl
	 * @return ejbResponse
	 */
	public static String processInWS(String message, String EjbClientUrl) {
		logger.info("ENTERING_METHOD");
		logger.info("Entering fetchEJBResponse method");
		String result = "";
		logger.info("EjbClientUrl >>--->" + EjbClientUrl);
		try {
			logger.info("***********ENTERING EJB TRY************");
			logger.info("EJB Step1");
			System.getProperties().put("java.naming.factory.initial",
					"com.ibm.websphere.naming.WsnInitialContextFactory");
			logger.info("EJB Step2");
			System.getProperties()
					.put("java.naming.provider.url", EjbClientUrl);
			logger.info("EJB Step3");
			Context ctx = new InitialContext();
			Object ejbObject = ctx.lookup("ejb/EnigmaServiceAccess");
			logger.info("EJB Step4");
			EnigmaServiceAccessHome accessBeanHome = (EnigmaServiceAccessHome) PortableRemoteObject
					.narrow(ejbObject, EnigmaServiceAccessHome.class);
			logger.info("EJB Step5");
			EnigmaServiceAccess accessB = accessBeanHome.create();
			logger.info("EJB Step6");
			result = accessB.process(message);
			logger.info("EJB Step7");
			logger.info("Debugmessage:: EJB Response inside method-->" + result);
			logger.info("***********Exiting EJB TRY************");
		} catch (Exception e) {
			result = "Exception! >>--->" + e.getMessage();
			logger.error(EjbClientUrl + " Exception!" + e.getMessage());
			e.printStackTrace();
			return result;
		}
		logger.info("EXITING_METHOD");
		return result;
	}

	public void insertIntoTFBOTransLogTable(UserTransactionVO userVo,
			String tiReqXML, String tiResXML, Timestamp tiReqTime,
			Timestamp tiResTime, String query) {
		Connection conn = null;
		PreparedStatement pst = null;
		int result = 0;
		CommonMethods aCommonMethods = new CommonMethods();

		try {
			String status = aCommonMethods.getTagValue("Status", tiResXML);
			conn = DBUtility.getZoneConnection();
			pst = conn.prepareStatement(query);

			pst.setString(1, "TI");
			pst.setString(2, userVo.getRequestId());
			if (aCommonMethods.isValueAvailable(userVo.getTiReferanceNo()))
				pst.setString(3, userVo.getTiReferanceNo());
			else if(aCommonMethods.isValueAvailable(userVo.getLcRefNum()))
				pst.setString(3, userVo.getLcRefNum());
			else
				pst.setString(3, userVo.getTiRefNo());
			pst.setString(4, status);
			pst.setString(5, tiReqXML);
			pst.setString(6, tiResXML);
			pst.setTimestamp(7, tiReqTime);
			pst.setTimestamp(8, tiResTime);
			result = pst.executeUpdate();
			logger.info("Inserted rows--->" + result);
		} catch (Exception e) {
			e.printStackTrace();
			e.getMessage();
		} finally {
			DBUtility.surrenderDB(conn, pst, null);
		}
	}

	public static Timestamp getSqlLocalDateTime() {
		Date date = new Date();
		long t = date.getTime();
		Timestamp sqlTimestamp = new Timestamp(t);
		return sqlTimestamp;
	}
}
