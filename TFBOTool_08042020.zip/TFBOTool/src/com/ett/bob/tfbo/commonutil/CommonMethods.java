package com.ett.bob.tfbo.commonutil;

import java.io.StringReader;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.servlet.http.HttpServletResponse;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.apache.log4j.Logger;
import org.apache.struts2.ServletActionContext;
import org.w3c.dom.Document;
import org.xml.sax.InputSource;

import com.ett.bob.tfbo.dbutil.PropertyUtil;
import com.ett.bob.tfbo.model.AlertMessagesVO;
import com.ett.bob.tfbo.util.ActionConstants;
import com.opensymphony.xwork2.ActionContext;

public class CommonMethods {
	private static Logger logger = Logger.getLogger(CommonMethods.class
			.getName());

	public String getTagValue(String tagName, String responseMessage)
			throws Exception {
		logger.info("Entering getTagValue method");
		logger.info("tagName-->" + tagName);
		logger.info("responseMessage-->" + responseMessage);
		DocumentBuilder aDocumentBuilder = DocumentBuilderFactory.newInstance()
				.newDocumentBuilder();
		InputSource aInputSource = new InputSource();
		aInputSource.setCharacterStream(new StringReader(responseMessage));
		Document aDocument = aDocumentBuilder.parse(aInputSource);
		String tagValue = aDocument.getElementsByTagName(tagName).item(0)
				.getTextContent();
		logger.info("Exiting getTagValue method");
		return tagValue;
	}

	public boolean isValueAvailable(String inputVal) {
		logger.info("Validating NULL method inputVal-->" + inputVal);
		if (inputVal != null && !inputVal.trim().isEmpty()) {
			return true;
		} else {
			return false;
		}
	}

	public List<AlertMessagesVO> setErrorInList(String errorMessage,
			List<AlertMessagesVO> errorDetailList) {
		AlertMessagesVO aAlertMessagesVO = new AlertMessagesVO();
		aAlertMessagesVO.setErrorDetails(errorMessage);
		errorDetailList.add(aAlertMessagesVO);
		return errorDetailList;
	}

	public void closeWindow() throws Exception {
		logger.info(ActionConstants.ENTERING_METHOD);
		Properties aProperties = PropertyUtil.getPropertiesValue();
		String closeUrl = aProperties.getProperty("CLOSEURL");
		Map<String, Object> userSession = ActionContext.getContext()
				.getSession();
		HttpServletResponse response = (HttpServletResponse) ActionContext
				.getContext().get(ServletActionContext.HTTP_RESPONSE);
		userSession.clear();
		response.sendRedirect(closeUrl);
		logger.info(ActionConstants.EXITING_METHOD);
	}
}
