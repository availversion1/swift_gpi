package com.ett.bob.tfbo.commonutil;

import java.util.UUID;

import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.apache.struts2.ServletActionContext;

public class CSRFTokenServlet {

	private final static Logger logger = Logger
			.getLogger(CSRFTokenServlet.class);

	public static String RandomId() {
		return UUID.randomUUID().toString();

	}

	public Boolean Csrf(String formToken) {

		logger.info("Entered");
		logger.info("........Process entered into Transaction Log Servlet........");
		Boolean tokenChecker = false;
		HttpSession session = ServletActionContext.getRequest().getSession();
		String sessionToken = (String) session.getAttribute("csrftoken");
		logger.info("csrfToken >= " + sessionToken);
		logger.info("form token >=" + formToken);

		if (sessionToken.trim().equals(formToken)) {
			logger.info("CSRFToken is Matching");
			tokenChecker = true;
		} else {
			logger.debug("CSRFToken is Missmatch");
			logger.debug("Token Checker from Servlet is ---> " + tokenChecker);
			tokenChecker = false;
		}
		return tokenChecker;
	}

}
