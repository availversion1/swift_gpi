package com.ett.bob.tfbo.commonutil;

import java.util.Date;
import java.util.Properties;

import javax.mail.BodyPart;
import javax.mail.Message;
import javax.mail.Multipart;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

import org.apache.log4j.Logger;

import com.ett.bob.tfbo.dbutil.PropertyUtil;

public class EmailProcessManager {
	private static Logger logger = Logger.getLogger(EmailProcessManager.class
			.getName());

	public void sendMail(final String emailUserId, final String emailPassword,
			final String[] toEmailId, String emailSubject, String emailBodyText) {
		boolean sendMailResponse;
		CommonMethods aCommonMethods = new CommonMethods();
		try {
			Properties aProperties = PropertyUtil.getPropertiesValue();
			String smtpHostname = aProperties.getProperty("SMTPHost");
			String smtpPortNo = aProperties.getProperty("SMTPPort");
			logger.info("emailUserId-->" + emailUserId);
			logger.info("toEmailId-->" + toEmailId);
			logger.info("emailSubject-->" + emailSubject);
			logger.info("emailBodyText-->" + emailBodyText);

			Properties bProperties = System.getProperties();
			bProperties.put("mail.smtp.host", smtpHostname);
			bProperties.put("mail.smtp.port", smtpPortNo);

			if (aCommonMethods.isValueAvailable(emailPassword)) {
				bProperties.put("mail.smtp.starttls.enable", "true");
				bProperties.put("mail.smtp.ssl.trust", "smtp.gmail.com");
				bProperties.put("mail.smtp.auth", "true");
			} else {
				bProperties.put("mail.smtp.auth", false);
			}
			logger.info("Milestone 02 : Get session");
			Session aSession = Session.getInstance(bProperties,
					new javax.mail.Authenticator() {
						protected PasswordAuthentication getPasswordAuthentication() {
							return new PasswordAuthentication(emailUserId,
									emailPassword);
						}
					});
			Message aMessage = new MimeMessage(aSession);
			aMessage.setFrom(new InternetAddress(emailUserId));
			logger.info("Milestone 03 : Set TO address");
			InternetAddress[] toAddress = new InternetAddress[toEmailId.length];
			for (int i = 0; i < toEmailId.length; i++) {
				logger.info("TO Email Id " + i + " = " + toEmailId[i]);
				if (!toEmailId[i].trim().isEmpty()) {
					toAddress[i] = new InternetAddress(toEmailId[i]);
				}
			}
			for (int i = 0; i < toAddress.length; i++) {
				if (toAddress[i] != null) {
					aMessage.addRecipient(Message.RecipientType.TO,
							toAddress[i]);
					logger.info(" " + toAddress[i] + "<<--<");
				}
			}
			logger.info("Milestone 06 : Set Subject and Body");
			aMessage.setSubject(emailSubject);
			aMessage.setSentDate(new Date());
			Multipart aMultipart = new MimeMultipart();
			BodyPart aBodyPart = new MimeBodyPart();
			aBodyPart.setContent(emailBodyText, "text/plain");
			aMultipart.addBodyPart(aBodyPart);
			logger.info("Milestone 08 : Set Content");
			aMessage.setContent(aMultipart);
			Transport.send(aMessage);
			sendMailResponse = true;
			logger.info("Milestone 09 : Email Sent successfully..! sendMailResponse"
					+ sendMailResponse);
		} catch (Exception e) {
			logger.info("EMail sending failed due to " + e.getMessage());
			e.printStackTrace();
			sendMailResponse = false;
		}
	}
}
