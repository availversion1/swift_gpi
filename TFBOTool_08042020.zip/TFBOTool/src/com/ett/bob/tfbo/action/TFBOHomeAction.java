package com.ett.bob.tfbo.action;

import java.io.File;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;
import org.apache.struts2.ServletActionContext;

import com.ett.bob.tfbo.businessdelegate.TFBODashboardBD;
import com.ett.bob.tfbo.businessdelegate.TFBOHomeActionBD;
import com.ett.bob.tfbo.commonutil.CSRFTokenServlet;
import com.ett.bob.tfbo.commonutil.CommonMethods;
import com.ett.bob.tfbo.dao.TFBOHomeDAO;
import com.ett.bob.tfbo.dao.TFBOUploadDAO;
import com.ett.bob.tfbo.dbutil.PropertyUtil;
import com.ett.bob.tfbo.model.AlertMessagesVO;
import com.ett.bob.tfbo.model.CustomerProfileManageVO;
import com.ett.bob.tfbo.model.ProfileManagementVO;
import com.ett.bob.tfbo.model.ReportVO;
import com.ett.bob.tfbo.model.TFBODashboardVO;
import com.ett.bob.tfbo.model.TFBOReminderVO;
import com.ett.bob.tfbo.model.UserTransactionVO;
import com.ett.bob.tfbo.util.ActionConstants;
import com.ett.bob.tfbo.workflowutil.TFBOWorkflow;
import com.opensymphony.xwork2.ActionContext;

public class TFBOHomeAction {
	/**
	 * 
	 */

	private static Logger logger = Logger.getLogger(TFBOHomeAction.class
			.getName());

	TFBODashboardVO branchDB;
	UserTransactionVO userVo;
	CustomerProfileManageVO custProfileVo;
	ProfileManagementVO profileVo;
	Map<String, String> mtReceived;
	Map<String, String> productTypeIDC;
	Map<String, String> documentDispatch;
	Map<String, String> financeSameDay;
	private List<String> currency;
	private List<String> finCurrency;
	private List<String> productDetailsList;
	private List<String> eventDetailsList;
	private List<String> productDetailsFilterList;
	private List<String> eventDetailsFilterList;

	public List<String> getSubProductDetailsFilterList() {
		return subProductDetailsFilterList;
	}

	public void setSubProductDetailsFilterList(
			List<String> subProductDetailsFilterList) {
		this.subProductDetailsFilterList = subProductDetailsFilterList;
	}

	private List<String> subProductDetailsFilterList;
	Map<String, String> statusFilter;
	private List<String> billReference;
	File inputFile;
	String inputFileContentType;
	String inputFileFileName;
	String formToken;
	public List<String> billReferenceList;

	public List<String> getBillReferenceList() {
		return billReferenceList;
	}

	public void setBillReferenceList(List<String> billReferenceList) {
		this.billReferenceList = billReferenceList;
	}

	public List<String> getProductDetailsFilterList() {
		return productDetailsFilterList;
	}

	public void setProductDetailsFilterList(
			List<String> productDetailsFilterList) {
		this.productDetailsFilterList = productDetailsFilterList;
	}

	public List<String> getEventDetailsFilterList() {
		return eventDetailsFilterList;
	}

	public ProfileManagementVO getProfileVo() {
		return profileVo;
	}

	public void setProfileVo(ProfileManagementVO profileVo) {
		this.profileVo = profileVo;
	}

	public void setEventDetailsFilterList(List<String> eventDetailsFilterList) {
		this.eventDetailsFilterList = eventDetailsFilterList;
	}

	public List<String> getProductDetailsList() {
		return productDetailsList;
	}

	public void setProductDetailsList(List<String> productDetailsList) {
		this.productDetailsList = productDetailsList;
	}

	public List<String> getEventDetailsList() {
		return eventDetailsList;
	}

	public void setEventDetailsList(List<String> eventDetailsList) {
		this.eventDetailsList = eventDetailsList;
	}

	public String getFormToken() {
		return formToken;
	}

	public void setFormToken(String formToken) {
		this.formToken = formToken;
	}

	public Map<String, String> getFinanceSameDay() {
		return ActionConstants.FINANCE_SAME_DAY;
	}

	public void setFinanceSameDay(Map<String, String> financeSameDay) {
		this.financeSameDay = financeSameDay;
	}

	public Map<String, String> getDocumentDispatch() {
		return ActionConstants.DOCUMENT_DISPATCH;
	}

	public void setDocumentDispatch(Map<String, String> documentDispatch) {
		this.documentDispatch = documentDispatch;
	}

	public Map<String, String> getProductTypeIDC() {
		return ActionConstants.IDC_PRODUCT_TYPE;
	}

	public void setProductTypeIDC(Map<String, String> productTypeIDC) {
		this.productTypeIDC = productTypeIDC;
	}

	public Map<String, String> getMtReceived() {
		return ActionConstants.MT_RECEIVED;
	}

	public void setMtReceived(Map<String, String> mtReceived) {
		this.mtReceived = mtReceived;
	}

	public List<String> getCurrency() {
		return currency;
	}

	public void setCurrency(List<String> currency) {
		this.currency = currency;
	}

	public List<String> getFinCurrency() {
		return finCurrency;
	}

	public void setFinCurrency(List<String> finCurrency) {
		this.finCurrency = finCurrency;
	}
	
	public static Logger getLogger() {
		return logger;
	}

	public static void setLogger(Logger logger) {
		TFBOHomeAction.logger = logger;
	}

	public TFBODashboardVO getBranchDB() {
		return branchDB;
	}

	public void setBranchDB(TFBODashboardVO branchDB) {
		this.branchDB = branchDB;
	}

	public String getInputFileContentType() {
		return inputFileContentType;
	}

	public void setInputFileContentType(String inputFileContentType) {
		this.inputFileContentType = inputFileContentType;
	}

	public String getInputFileFileName() {
		return inputFileFileName;
	}

	public void setInputFileFileName(String inputFileFileName) {
		this.inputFileFileName = inputFileFileName;
	}

	public File getInputFile() {
		return inputFile;
	}

	public void setInputFile(File inputFile) {
		this.inputFile = inputFile;
	}

	public Map<String, String> getStatusFilter() {
		return ActionConstants.STATUS_LIST;
	}

	public void setStatusFilter(Map<String, String> statusFilter) {
		this.statusFilter = statusFilter;
	}

	public UserTransactionVO getUserVo() {
		return userVo;
	}

	public void setUserVo(UserTransactionVO userVo) {
		this.userVo = userVo;
	}

	public List<String> getBillReference() {
		return billReference;
	}

	public void setBillReference(List<String> billReference) {
		this.billReference = billReference;
	}

	public CustomerProfileManageVO getCustProfileVo() {
		return custProfileVo;
	}

	public void setCustProfileVo(CustomerProfileManageVO custProfileVo) {
		this.custProfileVo = custProfileVo;
	}

	// Report 23012020 Starts

	Map<String, String> rstatusFilter;
	Map<String, String> reportFrequency;
	private List<String> productCodeList;
	private List<String> userIdList;

	public List<ReportVO> summaryList;
	public List<ReportVO> detailedList;

	public List<ReportVO> getDetailedList() {
		return detailedList;
	}

	public void setDetailedList(List<ReportVO> detailedList) {
		this.detailedList = detailedList;
	}

	public List<ReportVO> getSummaryList() {
		return summaryList;
	}

	public void setSummaryList(List<ReportVO> summaryList) {
		this.summaryList = summaryList;
	}

	ReportVO reportVo;

	public List<String> getUserIdList() {
		return userIdList;
	}

	public void setUserIdList(List<String> userIdList) {
		this.userIdList = userIdList;
	}

	public List<String> getProductCodeList() {
		return productCodeList;
	}

	public void setProductCodeList(List<String> productCodeList) {
		this.productCodeList = productCodeList;
	}

	public Map<String, String> getReportFrequency() {
		return ActionConstants.FREQUENCY_LIST;
	}

	public void setReportFrequency(Map<String, String> reportFrequency) {
		this.reportFrequency = reportFrequency;
	}

	public ReportVO getReportVo() {
		return reportVo;
	}

	public void setReportVo(ReportVO reportVo) {
		this.reportVo = reportVo;
	}

	public Map<String, String> getRstatusFilter() {
		return ActionConstants.REPORT_STATUS_LIST;
	}

	public void setRstatusFilter(Map<String, String> rstatusFilter) {
		this.rstatusFilter = rstatusFilter;
	}

	public String productReport() {
		TFBOHomeActionBD aTFBOHomeActionBD = new TFBOHomeActionBD();
		if (!aTFBOHomeActionBD.isValidSession(getFormToken())) {
			return "invalidSession";
		}
		return "success";
	}

	/*
	 * public String generateReportInGrid() {
	 * logger.info("Entering method action >>--> generateReportInGrid Action");
	 * TFBOHomeActionBD aTFBOHomeActionBD = new TFBOHomeActionBD();
	 * CommonMethods aCommonMethods = new CommonMethods(); if
	 * (!aTFBOHomeActionBD.isValidSession(getFormToken())) { return
	 * "invalidSession"; } try { String reportType =
	 * reportVo.getReportCheckList(); if
	 * (aCommonMethods.isValueAvailable(reportType)) { if
	 * (reportType.equalsIgnoreCase("S")) { summaryList = aTFBOHomeActionBD
	 * .generateSummaryReportInGrid(reportVo); } else { detailedList =
	 * aTFBOHomeActionBD .generateDetailedTableReport(reportVo); } } } catch
	 * (Exception e) { e.printStackTrace(); return "Exception"; }
	 * logger.info("Existing method action>>--> generateReportInGrid Action");
	 * return "success"; }
	 * 
	 * public String generateReportInExcel() {
	 * logger.info(ActionConstants.ENTERING_METHOD +
	 * "<<generateReportInExcel Action"); TFBOHomeActionBD aTFBOHomeActionBD =
	 * new TFBOHomeActionBD(); try {
	 * aTFBOHomeActionBD.generateReportInExcel(reportVo);
	 * 
	 * } catch (Exception e) { e.printStackTrace(); return "Exception"; }
	 * logger.info(ActionConstants.EXITING_METHOD +
	 * "<<generateReportInExcel Action"); return "success"; }
	 */
//	public String generateReportInGrid() {
//		logger.info("Entering method action >>--> generateReportInGrid Action");
//		TFBOHomeActionBD aTFBOHomeActionBD = new TFBOHomeActionBD();
//		CommonMethods aCommonMethods = new CommonMethods();
//		if (!aTFBOHomeActionBD.isValidSession(getFormToken())) {
//			return "invalidSession";
//		}
//		try {
//			String reportType = reportVo.getReportCheckList();
//			if (aCommonMethods.isValueAvailable(reportType)) {
//				if (reportType.equalsIgnoreCase("S")) {
//					summaryList = aTFBOHomeActionBD
//							.generateSummaryReportInGrid(reportVo);
//				} else {
//					detailedList = aTFBOHomeActionBD
//							.generateDetailedReportInGrid(reportVo);
//				}
//			}
//		} catch (Exception e) {
//			e.printStackTrace();
//			return "Exception";
//		}
//		logger.info("Existing method action>>--> generateReportInGrid Action");
//		return "success";
//	}

//	public String generateReportInExcel() {
//		logger.info(ActionConstants.ENTERING_METHOD
//				+ "<<generateReportInExcel Action");
//		TFBOHomeActionBD aTFBOHomeActionBD = new TFBOHomeActionBD();
//		CommonMethods aCommonMethods = new CommonMethods();
//
//		try {
//
//			String reportType = reportVo.getReportCheckList();
//			if (aCommonMethods.isValueAvailable(reportType)) {
//				if (reportType.equalsIgnoreCase("S")) {
//					aTFBOHomeActionBD.generateSummaryReportInExcel(reportVo);
//				} else {
//					aTFBOHomeActionBD.generateDetailedReportInExcel(reportVo);
//				}
//			}
//
//		} catch (Exception e) {
//			e.printStackTrace();
//			return "Exception";
//		}
//		logger.info(ActionConstants.EXITING_METHOD
//				+ "<<generateReportInExcel Action");
//		return "success";
//	}

	// Report 23012020 ends
	public String validateUserCheck() {
		System.out.println(ActionConstants.ENTERING_METHOD + ">>getEventList");
		logger.info(ActionConstants.ENTERING_METHOD + ">>getEventList");
		TFBOHomeActionBD aTFBOHomeActionBD = new TFBOHomeActionBD();
		if (aTFBOHomeActionBD.validateSessionUser(userVo)) {
			logger.info(ActionConstants.EXITING_METHOD + ">>getEventList");
			return "success";
		}
		logger.info(ActionConstants.EXITING_METHOD + ">>getEventList");
		return "failed";
	}

	public String BranchProfilemgmt() {
		logger.info(">>-->BranchProfilemgmt<--<<");
		return "success";
	}

	public String toolHomePage() {
		TFBOHomeDAO aTFBOHomeDAO = new TFBOHomeDAO();
		TFBOHomeActionBD aTFBOHomeActionBD = new TFBOHomeActionBD();
		if (userVo == null)
			userVo = new UserTransactionVO();
		try {
			userVo.setSessionUserName(aTFBOHomeActionBD.getSessionUser());
			if (aTFBOHomeDAO.isUserMaker(userVo.getSessionUserName())) {
				userVo.setUserFlag("MAKER");
			} else if (aTFBOHomeDAO.isUserChecker(userVo.getSessionUserName())) {
				userVo.setUserFlag("CHECKER");
			} else if (aTFBOHomeDAO.isUserScrutinizer(userVo
					.getSessionUserName())) {
				userVo.setUserFlag("SCRUTINIZER");
			}
			// ADDED BY CHANDRU
			if (aTFBOHomeDAO.selectTFBOTranLockDashBoard(userVo,
					ActionConstants.SELECTTRANSLOCK,
					userVo.getSessionUserName()))
				aTFBOHomeDAO.updateTFBOTranLockStatus(userVo,
						ActionConstants.LOCKFALSE);
			// ADDED BY CHANDRU
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "success";
	}

	// constructor
	public TFBOHomeAction() {
		logger.info(ActionConstants.ENTERING_METHOD + ">>Constructor method");
		TFBOHomeActionBD aTFBOHomeActionBD = new TFBOHomeActionBD();
		currency = new ArrayList<String>();
		finCurrency = new ArrayList<String>();
		productDetailsList = new ArrayList<String>();
		eventDetailsList = new ArrayList<String>();
		eventDetailsFilterList = new ArrayList<String>();
		billReference = new ArrayList<String>();
		// Sub product type drop down filter changes starts 13012020
		subProductDetailsFilterList = new ArrayList<String>();
		// Sub product type drop down filter changes ends 13012020
		try {
			productDetailsList = aTFBOHomeActionBD.getProductList();
			logger.info("productDetailsList size-->"
					+ productDetailsList.size());
			productDetailsFilterList = aTFBOHomeActionBD.getProductList();
			// Report 23012020 starts

			productCodeList = aTFBOHomeActionBD.getProductCodeList();
			userIdList = aTFBOHomeActionBD.getUserIdList();

			// Report 23012020 ends

			logger.info("productDetailsFilterList size-->"
					+ productDetailsList.size());
			currency = aTFBOHomeActionBD.getCurrency();
			finCurrency = aTFBOHomeActionBD.getCurrency();
		} catch (Exception e) {
			e.printStackTrace();
			logger.info(e.getMessage());
		}
		logger.info(ActionConstants.EXITING_METHOD + ">>Constructor method");
	}

	public String displayDashboard() {
		logger.info(ActionConstants.ENTERING_METHOD + ">>displayDashboard");
		TFBODashboardBD aTFBODashboardBD = new TFBODashboardBD();
		TFBOHomeDAO aTFBOHomeDAO = new TFBOHomeDAO();
		TFBOHomeActionBD aTFBOHomeActionBD = new TFBOHomeActionBD();
		branchDB = new TFBODashboardVO();
		if (userVo == null)
			userVo = new UserTransactionVO();
		try {
			aTFBODashboardBD.setDashboard(branchDB);
			userVo.setSessionUserName(aTFBOHomeActionBD.getSessionUser());
			if (aTFBOHomeDAO.isUserMaker(userVo.getSessionUserName())) {
				userVo.setUserFlag("MAKER");
			} else if (aTFBOHomeDAO.isUserChecker(userVo.getSessionUserName())) {
				userVo.setUserFlag("CHECKER");
			} else if (aTFBOHomeDAO.isUserScrutinizer(userVo
					.getSessionUserName())) {
				userVo.setUserFlag("SCRUTINIZER");
			}

			// ADDED BY CHANDRU
			if (aTFBOHomeDAO.selectTFBOTranLockDashBoard(userVo,
					ActionConstants.SELECTTRANSLOCK,
					userVo.getSessionUserName()))
				aTFBOHomeDAO.updateTFBOTranLockStatus(userVo,
						ActionConstants.LOCKFALSE);
			// ADDED BY CHANDRU
		} catch (Exception e) {
			e.printStackTrace();
			logger.info(e.getMessage());
			logger.info(ActionConstants.EXITING_METHOD + ">>displayDashboard");
			return "exception";
		}
		logger.info(ActionConstants.EXITING_METHOD + ">>displayDashboard");
		return "success";
	}

	// Changed by onsite team 26122019 starts
	/*
	 * public String fetchTransDetails() {
	 * logger.info(ActionConstants.ENTERING_METHOD + ">>getEventList");
	 * TFBOHomeActionBD aTFBOHomeActionBD = new TFBOHomeActionBD();
	 * CommonMethods aCommonMethods = new CommonMethods(); TFBOHomeDAO
	 * aTFBOHomeDAO = new TFBOHomeDAO(); String tiReferenceNo=""; tiReferenceNo
	 * = userVo.getTiRefNo(); if
	 * (userVo.getProductCode().equalsIgnoreCase("FEL")) { tiReferenceNo =
	 * userVo.getLcRefNum(); } logger.info("TI Reference Number=" +
	 * tiReferenceNo); try { if
	 * (!aTFBOHomeActionBD.isValidSession(getFormToken())) { return
	 * "invalidSession"; } aTFBOHomeActionBD.getTransDetails(userVo,
	 * tiReferenceNo);
	 * aTFBOHomeDAO.deleteTFBOTransChecklist(userVo.getRequestId(),
	 * userVo.getProductCode(), userVo.getEventCode()); if
	 * (aCommonMethods.isValueAvailable(userVo.getSubProductCode())) {
	 * aTFBOHomeDAO.insertIntoTFBOTransChecklist( userVo.getRequestId(),
	 * userVo.getProductCode(), userVo.getEventCode(),
	 * userVo.getSubProductCode()); } aTFBOHomeDAO.getMakerChecklist(userVo); }
	 * catch (Exception e) { e.printStackTrace(); logger.info(e.getMessage());
	 * List<AlertMessagesVO> errorDetailList = new
	 * LinkedList<AlertMessagesVO>(); errorDetailList =
	 * aCommonMethods.setErrorInList( ActionConstants.ERRORCODE998,
	 * errorDetailList); userVo.setErrorDetailsList(errorDetailList); return
	 * userVo.getCurrentPage(); } logger.info(ActionConstants.EXITING_METHOD +
	 * ">>getEventList"); return userVo.getCurrentPage(); }
	 */
	public String fetchTransDetails() {
		logger.info(ActionConstants.ENTERING_METHOD + ">>getEventList");
		TFBOHomeActionBD aTFBOHomeActionBD = new TFBOHomeActionBD();
		CommonMethods aCommonMethods = new CommonMethods();
		TFBOHomeDAO aTFBOHomeDAO = new TFBOHomeDAO();
		String tiReferenceNo = "";
		tiReferenceNo = userVo.getTiRefNo();
		if (userVo.getProductCode().equalsIgnoreCase("FEL")) {
			tiReferenceNo = userVo.getLcRefNum();
		} else if (userVo.getProductCode().equalsIgnoreCase("ISB")) {
			tiReferenceNo = userVo.getTiReferanceNo();// CHANGED BY CHANDRU
		} else if (userVo.getProductCode().equalsIgnoreCase("ODC")) {
			tiReferenceNo = userVo.getTiReferanceNo();// CHANGED BY SAI
		}
		/* Miscellanous changes starts 08-01-2020 */
		else if (userVo.getProductCode().equalsIgnoreCase("COR")) {
			logger.info("Set TI reference in fetchTransDetails Method - Miscellanous ");
			tiReferenceNo = userVo.getMasReferanceNo();
		}
		/* Miscellanous changes ends 08-01-2020 */
		logger.info("TI Reference Number=" + tiReferenceNo);
		try {
			if (!aTFBOHomeActionBD.isValidSession(getFormToken())) {
				return "invalidSession";
			}
			aTFBOHomeActionBD.getTransDetails(userVo, tiReferenceNo);
			aTFBOHomeDAO.deleteTFBOTransChecklist(userVo.getRequestId(),
					userVo.getProductCode(), userVo.getEventCode());
			if (aCommonMethods.isValueAvailable(userVo.getSubProductCode())) {

				// code changes for checklist by pandi starts 06012020
				if (userVo.getProductCode().equals("ILC")
						&& (userVo.getEventCode().equals("POCP")
								|| userVo.getEventCode().equals("POCA") || userVo
								.getEventCode().equals("POCD"))) {
					aTFBOHomeDAO.insertIntoTFBOTransChecklist_pocp(
							userVo.getRequestId(), userVo.getProductCode(),
							userVo.getEventCode(), userVo.getSubProductCode(),
							userVo.getLcType());
				} else {

					// code changes for checklist by pandi ends 06012020
					aTFBOHomeDAO.insertIntoTFBOTransChecklist(
							userVo.getRequestId(), userVo.getProductCode(),
							userVo.getEventCode(), userVo.getSubProductCode());
				}
			}
			aTFBOHomeDAO.getMakerChecklist(userVo);
		} catch (Exception e) {
			e.printStackTrace();
			logger.info(e.getMessage());
			List<AlertMessagesVO> errorDetailList = new LinkedList<AlertMessagesVO>();
			errorDetailList = aCommonMethods.setErrorInList(
					ActionConstants.ERRORCODE998, errorDetailList);
			userVo.setErrorDetailsList(errorDetailList);
			return userVo.getCurrentPage();
		}
		logger.info(ActionConstants.EXITING_METHOD + ">>getEventList");
		return userVo.getCurrentPage();
	}

	// Changed by onsite team 26122019 ends
	public String fetchCustomerName() {
		logger.info(ActionConstants.ENTERING_METHOD + ">>getEventList");
		CommonMethods aCommonMethods = new CommonMethods();
		TFBOHomeActionBD aTFBOHomeActionBD = new TFBOHomeActionBD();
		List<AlertMessagesVO> errorDetailList = new LinkedList<AlertMessagesVO>();
		String customerName = "";
		String customerCif = userVo.getCustCif().trim();
		logger.info("Customer Id=" + customerCif);
		System.out.println("Customer Id=" + customerCif);
		try {
			if (!aTFBOHomeActionBD.isValidSession(getFormToken())) {
				return "invalidSession";
			}
			if (aCommonMethods.isValueAvailable(customerCif)) {
				customerName = aTFBOHomeActionBD.getCustomerName(customerCif);
				if (!aCommonMethods.isValueAvailable(customerName)) {
					errorDetailList = aCommonMethods.setErrorInList(
							ActionConstants.ERRORCODE010, errorDetailList);
					userVo.setErrorDetailsList(errorDetailList);
					logger.info("Error for User validation-->"
							+ userVo.getErrorDetailsList().size());
					logger.info(ActionConstants.EXITING_METHOD
							+ ">>getEventList");
					return userVo.getCurrentPage();
				}
			}
			userVo.customeName = customerName;
			logger.info("Customer Name=" + userVo.customeName);
		} catch (Exception e) {
			e.printStackTrace();
			errorDetailList = aCommonMethods.setErrorInList(
					ActionConstants.ERRORCODE997, errorDetailList);
			userVo.setErrorDetailsList(errorDetailList);
			return userVo.getCurrentPage();
		}
		logger.info(ActionConstants.EXITING_METHOD + ">>getEventList");
		return userVo.getCurrentPage();
	}

	/*
	 * public String getEventList() {
	 * logger.info(ActionConstants.ENTERING_METHOD + ">>getEventList");
	 * TFBOHomeActionBD aTFBOHomeActionBD = new TFBOHomeActionBD();
	 * CommonMethods aCommonMethods = new CommonMethods(); try { if
	 * (!aTFBOHomeActionBD.isValidSession(getFormToken())) { return
	 * "invalidSession"; }
	 * userVo.setProductCode(aTFBOHomeActionBD.getProductCode(userVo
	 * .getProductName())); if (userVo.getProductCode() != null) {
	 * eventDetailsList = aTFBOHomeActionBD.getEventList(userVo
	 * .getProductCode()); }
	 * userVo.setProductCodeFilter(aTFBOHomeActionBD.getProductCode(userVo
	 * .getProductFilter())); if (userVo.getProductCodeFilter() != null) {
	 * eventDetailsFilterList = aTFBOHomeActionBD.getEventList(userVo
	 * .getProductCodeFilter()); } logger.info("eventDetailsList size-->" +
	 * eventDetailsList.size()); } catch (Exception e) { List<AlertMessagesVO>
	 * errorDetailList = new LinkedList<AlertMessagesVO>(); errorDetailList =
	 * aCommonMethods.setErrorInList( ActionConstants.ERRORCODE996,
	 * errorDetailList); userVo.setErrorDetailsList(errorDetailList);
	 * logger.info(ActionConstants.EXITING_METHOD + ">>getEventList");
	 * logger.info(e.getMessage()); return "success"; }
	 * logger.info(ActionConstants.EXITING_METHOD + ">>getEventList"); return
	 * "success"; }
	 */

	public String getEventList() {
		logger.info(ActionConstants.ENTERING_METHOD + ">>getEventList");
		TFBOHomeActionBD aTFBOHomeActionBD = new TFBOHomeActionBD();
		CommonMethods aCommonMethods = new CommonMethods();
		try {
			if (!aTFBOHomeActionBD.isValidSession(getFormToken())) {
				return "invalidSession";
			}

			if (!aCommonMethods.isValueAvailable(userVo.getProductName())) {
				userVo.setProductName("");
			}

			userVo.setProductCode(aTFBOHomeActionBD.getProductCode(userVo
					.getProductName()));
			if (userVo.getProductCode() != null) {
				eventDetailsList = aTFBOHomeActionBD.getEventList(userVo
						.getProductCode());
			}
			userVo.setProductCodeFilter(aTFBOHomeActionBD.getProductCode(userVo
					.getProductFilter()));
			if (userVo.getProductCodeFilter() != null) {
				eventDetailsFilterList = aTFBOHomeActionBD.getEventList(userVo
						.getProductCodeFilter());
			}
			logger.info("eventDetailsList size-->" + eventDetailsList.size());

			// Sub product type drop down filter changes starts 13012020
			subProductDetailsFilterList = aTFBOHomeActionBD
					.getSubProductList(userVo.getProductCodeFilter());
			// Sub product type drop down filter changes ends 13012020

		} catch (Exception e) {
			List<AlertMessagesVO> errorDetailList = new LinkedList<AlertMessagesVO>();
			errorDetailList = aCommonMethods.setErrorInList(
					ActionConstants.ERRORCODE996, errorDetailList);
			userVo.setErrorDetailsList(errorDetailList);
			logger.info(ActionConstants.EXITING_METHOD + ">>getEventList");
			logger.info(e.getMessage());
			return "success";
		}
		logger.info(ActionConstants.EXITING_METHOD + ">>getEventList");
		return "success";
	}

	public String loadHomePage() {
		logger.info(ActionConstants.ENTERING_METHOD + ">>loadHomePage");
		TFBOHomeActionBD aTFBOHomeActionBD = new TFBOHomeActionBD();
		TFBOHomeDAO aTFBOHomeDAO = new TFBOHomeDAO();
		CommonMethods aCommonMethods = new CommonMethods();
		CSRFTokenServlet aCSRFTokenServlet = new CSRFTokenServlet();

		// ADDED BY CHANDRU

		if (userVo == null)
			userVo = new UserTransactionVO();

		userVo.setSessionUserName(aTFBOHomeActionBD.getSessionUser());
		if (aTFBOHomeDAO.isUserMaker(userVo.getSessionUserName())) {
			userVo.setUserFlag("MAKER");
		} else if (aTFBOHomeDAO.isUserChecker(userVo.getSessionUserName())) {
			userVo.setUserFlag("CHECKER");
		} else if (aTFBOHomeDAO.isUserScrutinizer(userVo.getSessionUserName())) {
			userVo.setUserFlag("SCRUTINIZER");
		}

		if (aTFBOHomeDAO.selectTFBOTranLockDashBoard(userVo,
				ActionConstants.SELECTTRANSLOCK, userVo.getSessionUserName()))
			aTFBOHomeDAO.updateTFBOTranLockStatus(userVo,
					ActionConstants.LOCKFALSE);

		// ADDED BY CHANDRU

		if (!aCSRFTokenServlet.Csrf(getFormToken())) {
			return "invalidSession";
		}
		aTFBOHomeActionBD.isUserMaker(userVo);
		if (aCommonMethods.isValueAvailable(userVo.getReturnPage())) {
			logger.info(ActionConstants.EXITING_METHOD + ">>loadHomePage");
			return "invalidSession";
		}
		logger.info(ActionConstants.EXITING_METHOD + ">>loadHomePage");
		return "success";
	}

	public String openThisTransaction() {
		logger.info(ActionConstants.ENTERING_METHOD);
		TFBOHomeActionBD aTFBOHomeActionBD = new TFBOHomeActionBD();
		CommonMethods aCommonMethods = new CommonMethods();
		String returnPage = "";
		try {
			if (!aTFBOHomeActionBD.isValidSession(getFormToken())) {
				return "invalidSession";
			}
			userVo.setSessionUserName(aTFBOHomeActionBD.getSessionUser());
			userVo.setProductCode(userVo.getProductCodeGridValue());
			userVo.setEventCode(userVo.getEventCodeGridValue());
			returnPage = aTFBOHomeActionBD.openThisTransaction(userVo);
			userVo.setReturnPage(returnPage);

		} catch (Exception e) {
			e.printStackTrace();
			logger.info(e.getMessage());
			List<AlertMessagesVO> errorDetailList = new LinkedList<AlertMessagesVO>();
			errorDetailList = aCommonMethods.setErrorInList(
					ActionConstants.ERRORCODE995, errorDetailList);
			userVo.setErrorDetailsList(errorDetailList);
			return "failed";
		}
		logger.info("returnPage-->" + userVo.getReturnPage());
		return returnPage;
	}

	public String searchTransaction() {
		logger.info(ActionConstants.ENTERING_METHOD);
		TFBOHomeActionBD aTFBOHomeActionBD = new TFBOHomeActionBD();
		CommonMethods aCommonMethods = new CommonMethods();
		try {
			if (!aTFBOHomeActionBD.isValidSession(getFormToken())) {
				return "invalidSession";
			}
			logger.info("UserFlag-->" + userVo.getUserFlag());

			// Sub product type drop down filter changes starts 13012020
			getEventList();
			// Sub product type drop down filter changes ends 13012020
			userVo.setTransactionList(aTFBOHomeActionBD
					.getTFBOTransList(userVo));
		} catch (Exception e) {
			e.printStackTrace();
			List<AlertMessagesVO> errorDetailList = new LinkedList<AlertMessagesVO>();
			errorDetailList = aCommonMethods.setErrorInList(
					ActionConstants.ERRORCODE994, errorDetailList);
			userVo.setErrorDetailsList(errorDetailList);
			return "failed";
		}
		return "success";
	}

	/*
	 * public String openThisCount() {
	 * logger.info(ActionConstants.ENTERING_METHOD); userVo = new
	 * UserTransactionVO(); TFBOHomeActionBD aTFBOHomeActionBD = new
	 * TFBOHomeActionBD(); TFBOHomeDAO aTFBOHomeDAO = new TFBOHomeDAO();
	 * CSRFTokenServlet aCSRFTokenServlet = new CSRFTokenServlet();
	 * HttpServletRequest request = (HttpServletRequest) ActionContext
	 * .getContext().get(ServletActionContext.HTTP_REQUEST); CommonMethods
	 * aCommonMethods = new CommonMethods(); try { String formToken =
	 * request.getParameter("token"); if (!aCSRFTokenServlet.Csrf(formToken)) {
	 * return "invalidSession"; } aTFBOHomeActionBD.isUserMaker(userVo); if
	 * (aCommonMethods.isValueAvailable(userVo.getReturnPage())) { return
	 * "invalidSession"; } String sno = request.getParameter("sno"); String
	 * product = request.getParameter("product"); logger.info("sno-->" + sno);
	 * logger.info("product-->" + product);
	 * userVo.setProductCodeFilter(product); if (Integer.parseInt(sno) == 1) {
	 * userVo.setStepFilter(ActionConstants.INPUT);
	 * userVo.setStatusFilter(ActionConstants.INPUT_ASSIGNED); } else if
	 * (Integer.parseInt(sno) == 2) {
	 * userVo.setStepFilter(ActionConstants.REVIEW);
	 * userVo.setStatusFilter(ActionConstants.REVIEW_ASSIGNED); } else if
	 * (Integer.parseInt(sno) == 3) {
	 * userVo.setStepFilter(ActionConstants.INPUT);
	 * userVo.setStatusFilter(ActionConstants.INPUT_ASSIGNED);
	 * userVo.setIsQueriedFilter("1"); } else if (Integer.parseInt(sno) == 4) {
	 * userVo.setStatusFilter(ActionConstants.BRANCH_ABORTED); } else if
	 * (Integer.parseInt(sno) == 5) {
	 * userVo.setStepFilter(ActionConstants.RELEASE);
	 * userVo.setStatusFilter(ActionConstants.RELEASED); } else if
	 * (Integer.parseInt(sno) == 6) {
	 * userVo.setStepFilter(ActionConstants.AUTHORIZE);
	 * userVo.setStatusFilter(ActionConstants.AUTHORIZE_ASSIGNED); } else if
	 * (Integer.parseInt(sno) == 7) {
	 * userVo.setStepFilter(ActionConstants.AUTHORIZE);
	 * userVo.setStatusFilter(ActionConstants.AUTHORIZE_ASSIGNED);
	 * userVo.setIsQueriedFilter("1"); } else if (Integer.parseInt(sno) == 8) {
	 * userVo.setStatusFilter(ActionConstants.FBO_ABORTED); } else if
	 * (Integer.parseInt(sno) == 9) { userVo.setStepFilter("a1");
	 * userVo.setStatusFilter("i"); userVo.setIsTiTransFlag("Y"); } else if
	 * (Integer.parseInt(sno) == 10) { userVo.setStepFilter("i");
	 * userVo.setStatusFilter("i"); userVo.setIsTiTransFlag("Y"); } else if
	 * (Integer.parseInt(sno) == 11) { userVo.setStatusFilter("c");
	 * userVo.setIsTiTransFlag("Y"); } // CHANGES BY CHANDRU 10012020 STARTS
	 * 
	 * userVo.setTransactionList(aTFBOHomeDAO .getTFBOTransListFromDB(userVo));
	 * 
	 * aTFBOHomeDAO.updateTIReferenceInTool(userVo);
	 * 
	 * userVo.setTransactionList(aTFBOHomeDAO
	 * .getTFBOTransListFromDBFilter(userVo)); // CHANGES BY CHANDRU 10012020
	 * ENDS } catch (Exception e) { e.printStackTrace(); List<AlertMessagesVO>
	 * errorDetailList = new LinkedList<AlertMessagesVO>(); errorDetailList =
	 * aCommonMethods.setErrorInList( ActionConstants.ERRORCODE994,
	 * errorDetailList); userVo.setErrorDetailsList(errorDetailList); return
	 * "failed"; } return "success"; }
	 */
	public String openThisCount() {
		logger.info(ActionConstants.ENTERING_METHOD);
		userVo = new UserTransactionVO();
		TFBOHomeActionBD aTFBOHomeActionBD = new TFBOHomeActionBD();
		TFBOHomeDAO aTFBOHomeDAO = new TFBOHomeDAO();
		CSRFTokenServlet aCSRFTokenServlet = new CSRFTokenServlet();
		HttpServletRequest request = (HttpServletRequest) ActionContext
				.getContext().get(ServletActionContext.HTTP_REQUEST);
		CommonMethods aCommonMethods = new CommonMethods();
		try {
			String formToken = request.getParameter("token");
			if (!aCSRFTokenServlet.Csrf(formToken)) {
				return "invalidSession";
			}
			aTFBOHomeActionBD.isUserMaker(userVo);
			if (aCommonMethods.isValueAvailable(userVo.getReturnPage())) {
				return "invalidSession";
			}
			String sno = request.getParameter("sno");
			String product = request.getParameter("product");
			// CHANGED BY CHANDRU

			String directOption = request.getParameter("Direct");
			String directCompFlag = request.getParameter("Flag");
			String IdenType = request.getParameter("Iden");

			if (directOption != null && !directOption.equals("")) {
				if (directOption.equals("Y")) {
					userVo.setDirectOption(directOption);
				} else {
					userVo.setDirectOption(directOption);
				}
			}

			if (IdenType != null && !IdenType.equals("")) {
				userVo.setIdenOdcType(IdenType);
			}

			if (directCompFlag != null && directCompFlag.equals("Y")) {
				userVo.setDirectCompFlag(directCompFlag);
			}

			// ENDS
			logger.info("sno-->" + sno);
			logger.info("product-->" + product);
			userVo.setProductCodeFilter(product);
			userVo.setLockTransno(sno);
			if (Integer.parseInt(sno) == 1) {
				userVo.setStepFilter(ActionConstants.INPUT);
				userVo.setStatusFilter(ActionConstants.INPUT_ASSIGNED);
			} else if (Integer.parseInt(sno) == 2) {
				userVo.setStepFilter(ActionConstants.REVIEW);
				userVo.setStatusFilter(ActionConstants.REVIEW_ASSIGNED);
			} else if (Integer.parseInt(sno) == 3) {
				userVo.setStepFilter(ActionConstants.INPUT);
				userVo.setStatusFilter(ActionConstants.INPUT_ASSIGNED);
				userVo.setIsQueriedFilter("1");
			} else if (Integer.parseInt(sno) == 4) {
				userVo.setStatusFilter(ActionConstants.BRANCH_ABORTED);
			} else if (Integer.parseInt(sno) == 5) {
				userVo.setStepFilter(ActionConstants.RELEASE);
				userVo.setStatusFilter(ActionConstants.RELEASED);
			} else if (Integer.parseInt(sno) == 6) {
				userVo.setStepFilter(ActionConstants.AUTHORIZE);
				userVo.setStatusFilter(ActionConstants.AUTHORIZE_ASSIGNED);
			} else if (Integer.parseInt(sno) == 7) {
				userVo.setStepFilter(ActionConstants.AUTHORIZE);
				userVo.setStatusFilter(ActionConstants.AUTHORIZE_ASSIGNED);
				userVo.setIsQueriedFilter("1");
			} else if (Integer.parseInt(sno) == 8) {
				userVo.setStatusFilter(ActionConstants.FBO_ABORTED);
			} else if (Integer.parseInt(sno) == 9) {

				userVo.setStatusFilter("Transaction With FBO maker");// pandi
				userVo.setIsTiTransFlag("Y");
				userVo.setBevStatus("D");
				//bevstepphase = "D";

			} else if (Integer.parseInt(sno) == 10) {

				userVo.setStatusFilter("Transaction With FBO checker");// pandi
				userVo.setIsTiTransFlag("Y");
				userVo.setBevStatus("V");
				//bevstepphase = "V";

			} else if (Integer.parseInt(sno) == 11) {

				userVo.setStatusFilter("Authrorized-Completed in Baroda Insta");// pandi
				userVo.setIsTiTransFlag("Y");
				userVo.setBevStatus("R");
			}
			// CHANGES BY CHANDRU 10012020 STARTS
			/*
			 * userVo.setTransactionList(aTFBOHomeDAO
			 * .getTFBOTransListFromDB(userVo));
			 */
			aTFBOHomeDAO.updateTIReferenceInTool(userVo);

			userVo.setTransactionList(aTFBOHomeDAO
					.getTFBOTransListFromDBFilter(userVo));
			// CHANGES BY CHANDRU 10012020 ENDS
		} catch (Exception e) {
			e.printStackTrace();
			List<AlertMessagesVO> errorDetailList = new LinkedList<AlertMessagesVO>();
			errorDetailList = aCommonMethods.setErrorInList(
					ActionConstants.ERRORCODE994, errorDetailList);
			userVo.setErrorDetailsList(errorDetailList);
			return "failed";
		}
		return "success";
	}

	public String pendTransaction() {
		logger.info(ActionConstants.ENTERING_METHOD);
		TFBOHomeActionBD aTFBOHomeActionBD = new TFBOHomeActionBD();
		TFBOWorkflow aTFBOWorkflow = new TFBOWorkflow();
		String pendStatus = "";
		String stepName = "";
		String currentPage = "";
		try {
			if (!aTFBOHomeActionBD.isValidSession(getFormToken())) {
				return "invalidSession";
			}
			stepName = aTFBOHomeActionBD.getCurrentStep(userVo.requestId);
			currentPage = userVo.getCurrentPage();
			logger.info("currentPage-->" + currentPage);
			pendStatus = aTFBOWorkflow.getPendStatus(stepName);
			userVo.setSessionUserName(aTFBOHomeActionBD.getSessionUser());
			logger.info("SessionUser-->" + userVo.getSessionUserName());
			if (aTFBOHomeActionBD.isValidUser(userVo, stepName)) {
				aTFBOHomeActionBD.makerPendTransaction(userVo, pendStatus,
						stepName);
			}
			if (userVo.getErrorDetailsList() != null) {
				return currentPage;
			}
		} catch (Exception e) {
			e.printStackTrace();
			return "exception";
		}
		return "success";
	}

	public String initiateTransaction() {
		logger.info(ActionConstants.ENTERING_METHOD);
		TFBOHomeActionBD aTFBOHomeActionBD = new TFBOHomeActionBD();
		TFBOWorkflow aTFBOWorkflow = new TFBOWorkflow();
		String firstStep = "";
		String stepStatus = "";
		String userFlag = "";
		String returnPage = "";
		try {
			if (!aTFBOHomeActionBD.isValidSession(getFormToken())) {
				return "invalidSession";
			}
			userFlag = userVo.getUserFlag();
			userVo.setSessionUserName(aTFBOHomeActionBD.getSessionUser());
			logger.info("userFlag-->" + userFlag);
			userVo.setProductCode(aTFBOHomeActionBD.getProductCode(userVo
					.getProductName()));
			if (userVo.getProductCode() != null) {
				userVo.setEventCode(aTFBOHomeActionBD.getEventCode(
						userVo.getProductCode(), userVo.getEventName()));
			}
			if (!aTFBOHomeActionBD.isValidTransactionRequest(userVo)) {
				userVo.setProductCode(aTFBOHomeActionBD.getProductCode(userVo
						.getProductName()));
				if (userVo.getProductCode() != null) {
					eventDetailsList = aTFBOHomeActionBD.getEventList(userVo
							.getProductCode());
				}
				logger.info("Transaction has some error"
						+ userVo.getErrorDetailsList().size());
				return "failed";
			}

			firstStep = aTFBOWorkflow.getFirstStep();
			stepStatus = aTFBOWorkflow.getAssignStatus(firstStep);
			logger.info("firstStep-->" + firstStep);
			logger.info("SessionUserName-->" + userVo.getSessionUserName());
			logger.info("ProductCode-->" + userVo.getProductCode());
			logger.info("EventCode-->" + userVo.getEventCode());
			logger.info("stepStatus-->" + stepStatus);
			if (aTFBOHomeActionBD.isValidUser(userVo, firstStep)) {
				userVo.setRequestId(aTFBOHomeActionBD.generateRequestID(userVo
						.getProductCode()));
				logger.info("requestId-->" + userVo.getRequestId());
				returnPage = aTFBOHomeActionBD.createNewTransaction(userVo,
						firstStep, stepStatus);

				return returnPage;
			}
		} catch (Exception e) {
			e.printStackTrace();
			return "exception";
		}
		return "failed";
	}

	public String makerVerify() {
		logger.info(ActionConstants.ENTERING_METHOD);
		TFBOHomeActionBD aTFBOHomeActionBD = new TFBOHomeActionBD();
		TFBOUploadDAO aTFBOUploadDAO = new TFBOUploadDAO();
		TFBOWorkflow aTFBOWorkflow = new TFBOWorkflow();
		TFBOHomeDAO aTFBOHomeDAO = new TFBOHomeDAO();
		String stepName = "";
		String newStatus = "";
		String newStepName = "";
		String currentPage = "";
		try {
			if (!aTFBOHomeActionBD.isValidSession(getFormToken())) {
				return "invalidSession";
			}
			currentPage = userVo.getCurrentPage();
			logger.info("currentPage-->" + currentPage);
			aTFBOUploadDAO.getDocumentList(userVo);
			aTFBOHomeDAO.getUserCommentList(userVo);
			userVo.setSessionUserName(aTFBOHomeActionBD.getSessionUser());
			if (!aTFBOHomeActionBD.isValidTransactionCreation(userVo)) {
				logger.info("Transaction has some error"
						+ userVo.getErrorDetailsList().size());
				return currentPage;
			}
			stepName = aTFBOHomeActionBD.getCurrentStep(userVo.getRequestId());
			logger.info("getCurrentStep-->" + stepName);
			newStatus = aTFBOWorkflow.getCompletedStatus(stepName);
			newStepName = aTFBOWorkflow.getNextStep(stepName);
			logger.info("requestId-->" + userVo.getRequestId());
			logger.info("stepName-->" + stepName);
			logger.info("SessionUserName-->" + userVo.getSessionUserName());
			logger.info("CustomeCif-->" + userVo.getCustomeCif());
			logger.info("Amount-->" + userVo.getAmount());
			logger.info("Currency-->" + userVo.getCurrency());
			logger.info("SolID-->" + userVo.getSolID());
			System.out.println("RATE TAKEN >>--> " + userVo.getRateTaken());
			System.out.println("RATE >>--> " + userVo.getRate());
			System.out.println("TOKEN >>--> " + userVo.getToken());
			System.out.println("K VALUE>>--> " + userVo.getValueK());
			System.out.println("direct >>-->" + userVo.getDirect());
			System.out.println("direct event >>-->"
					+ userVo.getDirectCREEvent());
			if (aTFBOHomeActionBD.isValidUser(userVo, stepName)) {
				aTFBOHomeActionBD.makerVerifyTransaction(userVo, newStatus,
						newStepName, stepName);
				return "success";
			}
		} catch (Exception e) {
			e.printStackTrace();
			return "exception";
		}
		return currentPage;
	}

	public String fboRaiseQuery() {
		logger.info(ActionConstants.ENTERING_METHOD);
		TFBOHomeActionBD aTFBOHomeActionBD = new TFBOHomeActionBD();
		TFBOWorkflow aTFBOWorkflow = new TFBOWorkflow();
		String stepName = "";
		String newStatus = "";
		String newStepName = "";
		String currentPage = "";
		try {
			currentPage = userVo.getCurrentPage();
			userVo.setSessionUserName(aTFBOHomeActionBD.getSessionUser());
			if (!aTFBOHomeActionBD.isValidSession(getFormToken())) {
				return "invalidSession";
			}
			if (!aTFBOHomeActionBD.isValidUserTransaction(userVo)) {
				logger.info("Transaction has some error"
						+ userVo.getErrorDetailsList().size());
				return currentPage;
			}

			logger.info("currentPage-->" + currentPage);

			stepName = aTFBOHomeActionBD.getCurrentStep(userVo.getRequestId());
			logger.info("getCurrentStep-->" + stepName);
			newStepName = aTFBOWorkflow.getPreviousStep(stepName);
			newStatus = aTFBOWorkflow.getRejectStatus(stepName);
			logger.info("requestId-->" + userVo.getRequestId());
			logger.info("SessionUserName-->" + userVo.getSessionUserName());
			if (aTFBOHomeActionBD.isValidUser(userVo, stepName)) {
				aTFBOHomeActionBD.fboRaiseQueryTransaction(userVo, newStatus,
						newStepName, stepName);
				return "success";
			}
		} catch (Exception e) {
			e.printStackTrace();
			return "exception";
		}
		return currentPage;
	}

	public String checkerVerify() {
		logger.info(ActionConstants.ENTERING_METHOD);
		TFBOHomeActionBD aTFBOHomeActionBD = new TFBOHomeActionBD();
		TFBOWorkflow aTFBOWorkflow = new TFBOWorkflow();
		String stepName = "";
		String newStatus = "";
		String newStepName = "";
		String currentPage = "";
		try {
			currentPage = userVo.getCurrentPage();
			userVo.setSessionUserName(aTFBOHomeActionBD.getSessionUser());
			if (!aTFBOHomeActionBD.isValidSession(getFormToken())) {
				return "invalidSession";
			}
			if (!aTFBOHomeActionBD.isValidUserTransaction(userVo)) {
				logger.info("Transaction has some error"
						+ userVo.getErrorDetailsList().size());
				return currentPage;
			}

			logger.info("currentPage-->" + currentPage);

			stepName = aTFBOHomeActionBD.getCurrentStep(userVo.getRequestId());
			logger.info("getCurrentStep-->" + stepName);
			newStatus = aTFBOWorkflow.getCompletedStatus(stepName);
			newStepName = aTFBOWorkflow.getNextStep(stepName);
			logger.info("requestId-->" + userVo.getRequestId());
			logger.info("stepName-->" + stepName);
			logger.info("SessionUserName-->" + userVo.getSessionUserName());
			if (aTFBOHomeActionBD.isValidUser(userVo, stepName)) {
				aTFBOHomeActionBD.checkerVerifyTransaction(userVo, newStatus,
						newStepName, stepName);
				return "success";
			}
		} catch (Exception e) {
			e.printStackTrace();
			return "exception";
		}
		return currentPage;
	}

	public String scrutinizerRaiseQuery() {
		logger.info(ActionConstants.ENTERING_METHOD);
		TFBOHomeActionBD aTFBOHomeActionBD = new TFBOHomeActionBD();
		TFBOWorkflow aTFBOWorkflow = new TFBOWorkflow();
		String stepName = "";
		String newStatus = "";
		String newStepName = "";
		String currentPage = "";
		try {
			currentPage = userVo.getCurrentPage();
			logger.info("currentPage-->" + currentPage);
			userVo.setSessionUserName(aTFBOHomeActionBD.getSessionUser());
			if (!aTFBOHomeActionBD.isValidSession(getFormToken())) {
				return "invalidSession";
			}
			if (!aTFBOHomeActionBD.isValidUserTransaction(userVo)) {
				logger.info("Transaction has some error"
						+ userVo.getErrorDetailsList().size());
				return currentPage;
			}

			stepName = aTFBOHomeActionBD.getCurrentStep(userVo.getRequestId());
			logger.info("getCurrentStep-->" + stepName);
			newStepName = aTFBOWorkflow.getPreviousStep(stepName);
			newStatus = aTFBOWorkflow.getRejectStatus(stepName);
			logger.info("requestId-->" + userVo.getRequestId());
			logger.info("stepName-->" + stepName);
			logger.info("SessionUserName-->" + userVo.getSessionUserName());
			if (aTFBOHomeActionBD.isValidUser(userVo, stepName)) {
				aTFBOHomeActionBD.scrutinizerRaiseQueryTransaction(userVo,
						newStatus, newStepName, stepName);
				return "success";
			}
		} catch (Exception e) {
			e.printStackTrace();
			return "exception";
		}
		return currentPage;
	}

	public String scrutinizerVerify() {
		logger.info(ActionConstants.ENTERING_METHOD);
		TFBOHomeActionBD aTFBOHomeActionBD = new TFBOHomeActionBD();
		TFBOWorkflow aTFBOWorkflow = new TFBOWorkflow();
		String stepName = "";
		String newStatus = "";
		String newStepName = "";
		String currentPage = "";
		try {
			if (!aTFBOHomeActionBD.isValidSession(getFormToken())) {
				return "invalidSession";
			}
			currentPage = userVo.getCurrentPage();
			logger.info("currentPage-->" + currentPage);
			userVo.setSessionUserName(aTFBOHomeActionBD.getSessionUser());
			if (!aTFBOHomeActionBD.isValidScrutinizerVerify(userVo)) {
				logger.info("Transaction has some error"
						+ userVo.getErrorDetailsList().size());
				return currentPage;
			}
			aTFBOHomeActionBD.updateTFBOScrutinizerDetails(userVo);
			// userVo.setSessionUserName(aTFBOHomeActionBD.getSessionUser());
			stepName = aTFBOHomeActionBD.getCurrentStep(userVo.getRequestId());
			logger.info("getCurrentStep-->" + stepName);
			newStepName = aTFBOWorkflow.getNextStep(stepName);
			newStatus = aTFBOWorkflow.getCompletedStatus(stepName);
			logger.info("requestId-->" + userVo.getRequestId());
			logger.info("stepName-->" + stepName);
			logger.info("SessionUserName-->" + userVo.getSessionUserName());
			if (aTFBOHomeActionBD.isValidUser(userVo, stepName)) {
				logger.info("Currency in scrutinizerVerify method--> "
						+ userVo.getCurrency());
				aTFBOHomeActionBD.scrutinizerVerifyTransaction(userVo,
						newStatus, newStepName, stepName);
				if (userVo.getErrorDetailsList().size() != 0) {
					return currentPage;
				}
				return "success";
			}
		} catch (Exception e) {
			e.printStackTrace();
			return "exception";
		}
		return currentPage;
	}

	public String abortTransaction() {
		logger.info(ActionConstants.ENTERING_METHOD);
		TFBOHomeActionBD aTFBOHomeActionBD = new TFBOHomeActionBD();
		TFBOWorkflow aTFBOWorkflow = new TFBOWorkflow();
		String stepName = "";
		String newStatus = "";
		String currentPage = "";
		try {
			currentPage = userVo.getCurrentPage();
			logger.info("currentPage-->" + currentPage);
			userVo.setSessionUserName(aTFBOHomeActionBD.getSessionUser());
			if (!aTFBOHomeActionBD.isValidSession(getFormToken())) {
				return "invalidSession";
			}
			if (!aTFBOHomeActionBD.isValidUserTransaction(userVo)) {
				logger.info("Transaction has some error"
						+ userVo.getErrorDetailsList().size());
				return currentPage;
			}

			stepName = aTFBOHomeActionBD.getCurrentStep(userVo.getRequestId());
			newStatus = aTFBOWorkflow.getAbortStatus(stepName);
			logger.info("getCurrentStep-->" + stepName);
			logger.info("requestId-->" + userVo.getRequestId());
			logger.info("SessionUserName-->" + userVo.getSessionUserName());
			if (aTFBOHomeActionBD.isValidUser(userVo, stepName)) {
				aTFBOHomeActionBD.abortTransaction(userVo, newStatus, stepName);
				return "success";
			}
		} catch (Exception e) {
			e.printStackTrace();
			return "exception";
		}
		return currentPage;
	}

	public String uploadFile() {
		TFBOUploadDAO aTFBOUploadDAO = new TFBOUploadDAO();
		CommonMethods aCommonMethods = new CommonMethods();
		TFBOHomeDAO aTFBOHomeDAO = new TFBOHomeDAO();
		logger.info("transID-->" + userVo.getRequestId());
		TFBOHomeActionBD aTFBOHomeActionBD = new TFBOHomeActionBD();
		List<AlertMessagesVO> errorDetailList = new LinkedList<AlertMessagesVO>();
		String currentPage = "";
		try {
			if (!aTFBOHomeActionBD.isValidSession(getFormToken())) {
				return "invalidSession";
			}
			currentPage = userVo.getCurrentPage();
			logger.info("currentPage-->" + currentPage);
			Properties aProperties = PropertyUtil.getPropertiesValue();
			String sreverDestinationFilePath = aProperties
					.getProperty("SERVERDESTINATIONFILEPATH");
			userVo.setSessionUserName(aTFBOHomeActionBD.getSessionUser());
			String fileLocation = sreverDestinationFilePath
					+ userVo.getRequestId();
			logger.info("Src File name: " + inputFileFileName);
			logger.info("Src File path: " + inputFile.getAbsolutePath());
			logger.info("SessionUserName: " + userVo.sessionUserName);
			File destFile = new File(fileLocation, inputFileFileName);
			FileUtils.copyFile(inputFile, destFile);
			aTFBOUploadDAO.uploadDocumentInDB(userVo.getRequestId(),
					inputFileFileName, fileLocation + "/" + inputFileFileName,
					userVo.sessionUserName, userVo.getTypeOfDoc());
			userVo.setTypeOfDoc("");
			/*
			 * System.out.println("File Extension >>--> " +
			 * getFileExtension(destFile)); String extention =
			 * getFileExtension(destFile);
			 * 
			 * if (!extention.equals("pdf")) { errorDetailList =
			 * aCommonMethods.setErrorInList( ActionConstants.ERRORCODE143,
			 * errorDetailList); userVo.setErrorDetailsList(errorDetailList); }
			 */

			aTFBOUploadDAO.getDocumentList(userVo);
			aTFBOHomeDAO.getUserCommentList(userVo);
			// CHANGED BY CHANDRU
			userVo.setBillReferenceList(aTFBOHomeDAO.getBillReference(userVo,
					userVo.getTiReferanceNo()));
			// CHANGED BY CHANDRU
		} catch (Exception e) {
			errorDetailList = aCommonMethods.setErrorInList(
					ActionConstants.ERRORCODE888, errorDetailList);
			userVo.setErrorDetailsList(errorDetailList);
			e.printStackTrace();
			return currentPage;
		}
		return currentPage;
	}

	/*
	 * public static String getFileExtension(File destFile) {
	 * 
	 * String fileName = destFile.getName();
	 * System.out.println("fileName >>--->" + fileName); if
	 * (fileName.lastIndexOf(".") != -1 && fileName.lastIndexOf(".") != 0) {
	 * System.out.println("fileName >>--> " +
	 * fileName.substring(fileName.lastIndexOf(".") + 1)); return
	 * fileName.substring(fileName.lastIndexOf(".") + 1); } else return "";
	 * 
	 * }
	 */

	public String deleteDocument() {
		TFBOUploadDAO aTFBOUploadDAO = new TFBOUploadDAO();
		CommonMethods aCommonMethods = new CommonMethods();
		TFBOHomeActionBD aTFBOHomeActionBD = new TFBOHomeActionBD();
		TFBOHomeDAO aTFBOHomeDAO = new TFBOHomeDAO();
		logger.info("Entering displayDocument method");
		logger.info("docID-->" + userVo.docID);
		String currentPage = "";
		try {
			if (!aTFBOHomeActionBD.isValidSession(getFormToken())) {
				return "invalidSession";
			}
			currentPage = userVo.getCurrentPage();
			logger.info("currentPage-->" + currentPage);
			userVo.setSessionUserName(aTFBOHomeActionBD.getSessionUser());
			aTFBOUploadDAO.deleteDocument(userVo.docID);
			logger.info("userVo requestId-->" + userVo.getRequestId());
			aTFBOUploadDAO.getDocumentList(userVo);
			aTFBOHomeDAO.getUserCommentList(userVo);
			logger.info("Exiting displayDocument method");
			// CHANGED BY CHANDRU
			userVo.setBillReferenceList(aTFBOHomeDAO.getBillReference(userVo,
					userVo.getTiReferanceNo()));
			// CHANGED BY CHANDRU
		} catch (Exception e) {
			List<AlertMessagesVO> errorDetailList = new LinkedList<AlertMessagesVO>();
			errorDetailList = aCommonMethods.setErrorInList(
					ActionConstants.ERRORCODE887, errorDetailList);
			userVo.setErrorDetailsList(errorDetailList);
			e.printStackTrace();
			return currentPage;
		}
		return currentPage;
	}

	public String refreshChecklist() {
		logger.info(ActionConstants.ENTERING_METHOD);
		TFBOHomeActionBD aTFBOHomeActionBD = new TFBOHomeActionBD();
		CommonMethods aCommonMethods = new CommonMethods();
		TFBOHomeDAO aTFBOHomeDAO = new TFBOHomeDAO();
		String currentPage = "";
		try {
			if (!aTFBOHomeActionBD.isValidSession(getFormToken())) {
				return "invalidSession";
			}
			currentPage = userVo.getCurrentPage();
			logger.info("currentPage-->" + currentPage);
			aTFBOHomeDAO.deleteTFBOTransChecklist(userVo.getRequestId(),
					userVo.getProductCode(), userVo.getEventCode());
			if (aCommonMethods.isValueAvailable(userVo.getSubProductCode())) {
				// Code added By pandi For IDC Direct Check list issue starts
				// here
				if (userVo.getProductCode().equals("IDC")) {
					if (userVo.getDirect().equals("true")) {

						aTFBOHomeDAO.insertIntoTFBOTransChecklist_IDC_DIRECT(
								userVo.getRequestId(), userVo.getProductCode(),
								userVo.getEventCode(),
								userVo.getSubProductCode(), userVo.getDirect());

					} else {
						aTFBOHomeDAO.insertIntoTFBOTransChecklist(
								userVo.getRequestId(), userVo.getProductCode(),
								userVo.getEventCode(),
								userVo.getSubProductCode());
					}
				} else {
					// Code added By pandi For IDC Direct Check list issue ends
					// here
					aTFBOHomeDAO.insertIntoTFBOTransChecklist(
							userVo.getRequestId(), userVo.getProductCode(),
							userVo.getEventCode(), userVo.getSubProductCode());
				}
			}
			aTFBOHomeDAO.getMakerChecklist(userVo);
			if (userVo.getProductCode().trim().equalsIgnoreCase("FEL")) {
				if (userVo.getEventCode().trim().equalsIgnoreCase("CSA4")) {
					if (aCommonMethods.isValueAvailable(userVo.getLcRefNum())) {
						userVo.setBillReferenceList(aTFBOHomeDAO
								.getBillReference(userVo, userVo.getLcRefNum()));
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			List<AlertMessagesVO> errorDetailList = new LinkedList<AlertMessagesVO>();
			errorDetailList = aCommonMethods.setErrorInList(
					ActionConstants.ERRORCODE993, errorDetailList);
			userVo.setErrorDetailsList(errorDetailList);
			return currentPage;
		}
		return currentPage;
	}

	public String fetchLCDetails() {
		logger.info(ActionConstants.ENTERING_METHOD + ">>getEventList");
		TFBOHomeActionBD aTFBOHomeActionBD = new TFBOHomeActionBD();
		String tiReferenceNo = userVo.getLcRefNum();
		billReferenceList = new ArrayList<String>();
		logger.info("TI Reference Number=" + tiReferenceNo);
		try {
			if (!aTFBOHomeActionBD.isValidSession(getFormToken())) {
				return "invalidSession";
			}
			aTFBOHomeActionBD.getLCDetails(userVo, tiReferenceNo);
			billReferenceList = userVo.getBillReferenceList();
		} catch (Exception e) {
			e.printStackTrace();
			return userVo.getCurrentPage();
		}
		logger.info(ActionConstants.EXITING_METHOD + ">>getEventList");
		return userVo.getCurrentPage();
	}

	public String fetchDevolmentAmount() {
		try {
			logger.info("Entering method >>--> fetchDevolmentAmount");
			TFBOHomeActionBD aTFBOHomeActionBD = new TFBOHomeActionBD();
			String currentPage = userVo.getCurrentPage();

			aTFBOHomeActionBD.fetchDevolmentAmount(userVo);

			if (userVo.getDevolvementAmount() != null) {
				return currentPage;
			}
		} catch (Exception e) {
			e.printStackTrace();
			return "Exception";
		}
		return "success";

	}

	// Changes for ELC and IGT Starts 25-12-2019
	public String fetchExpiryDate() {
		logger.info("Entering method >>--> fetchDevolmentAmount");
		TFBOHomeActionBD aTFBOHomeActionBD = new TFBOHomeActionBD();
		String currentPage = userVo.getCurrentPage();
		try {
			aTFBOHomeActionBD.fetchExpiryDate(userVo);
		} catch (Exception e) {
			e.printStackTrace();
			return "Exception";
		}
		return currentPage;

	}

	// Changes for ELC and IGT ends 25-12-2019
	// Changes for acceptance amount fetch starts 08012020

	public String fetchAcceptanceAmount() {
		logger.info("Entering method >>--> fetchDevolmentAmount");
		TFBOHomeActionBD aTFBOHomeActionBD = new TFBOHomeActionBD();
		String currentPage = userVo.getCurrentPage();
		try {
			aTFBOHomeActionBD.fetchAcceptanceAmount(userVo);
		} catch (Exception e) {
			e.printStackTrace();
			return "Exception";
		}
		return currentPage;

	}
	
	public String fetchIGTBillAmount() {
		logger.info("Entering method >>--> fetchDevolmentAmount");
		TFBOHomeActionBD aTFBOHomeActionBD = new TFBOHomeActionBD();
		String currentPage = userVo.getCurrentPage();
		try {
			aTFBOHomeActionBD.fetchIGTBillAmount(userVo);
		} catch (Exception e) {
			e.printStackTrace();
			return "Exception";
		}
		return currentPage;

	}
	
	

	// Changes for acceptance amount fetch ends 08012020

	/* Tat Report Action starts */

	public String tatReport() {
		return "success";
	}

//	public String generateTATReport() {
//		TFBOHomeActionBD aTFBOHomeActionBD = new TFBOHomeActionBD();
//		try {
//
//			aTFBOHomeActionBD.generateTATReport(userVo);
//
//		} catch (Exception e) {
//			e.printStackTrace();
//			return "Exception";
//		}
//		return "success";
//	}

	/* Tat Report Action ends */

	// branchProfileVerify
	public String branchProfileVerify() {
		logger.info("Entering method >>--> branchProfileVerify");
		TFBOHomeActionBD aTFBOHomeActionBD = new TFBOHomeActionBD();
		String solid = "";
		solid = profileVo.getSolID();
		try {
			aTFBOHomeActionBD.branchProfileVerify(profileVo, solid);

			System.out.println("profileVo.AlphaCode = SSS.getAlphaCode();"
					+ profileVo.AlphaCode);
		} catch (Exception e) {
			e.printStackTrace();
			return profileVo.getCurrentPage();
		}
		return profileVo.getCurrentPage();
	}

	/* Changes for branch profile 14012020 ends */
	public String branchMgmtmaker_Verify() {
		System.out.println("Entering method >>--> branchMgmtmaker_Verify");
		TFBOHomeActionBD aTFBOHomeActionBD = new TFBOHomeActionBD();
		String solid = profileVo.getSolID();
		String mobile = profileVo.getBRPhoneSTD();
		String address = profileVo.getBranchAddr();
		String swift_bic = profileVo.getSwiftCode();

		System.out.println("Sol_ID====" + solid);
		System.out.println("mobile====" + mobile);
		System.out.println("address===" + address);
		System.out.println("swift_bic==" + swift_bic);
		try {
			aTFBOHomeActionBD.branchMgmtmaker_Verify(profileVo);
			System.out.println("branchMgmtmaker_Verify IN aCTION COMPLETED");
		} catch (Exception e) {
			e.printStackTrace();
			return "exception";
		}
		return "success";
	}

	/* ADDED FOR CUSTOMER PROFILE BY CHANDRU ON 15012020 */

	public String tfboCustomerProfile() {//
		logger.info(ActionConstants.ENTERING_METHOD + ">>loadHomePage");
		TFBOHomeActionBD aTFBOHomeActionBD = new TFBOHomeActionBD();
		CSRFTokenServlet aCSRFTokenServlet = new CSRFTokenServlet();
		custProfileVo = new CustomerProfileManageVO();
		try {
			userVo = new UserTransactionVO();
			if (!aCSRFTokenServlet.Csrf(getFormToken())) {
				return "invalidSession";
			}
			// userVo = aTFBOHomeActionBD.isUserMaker(userVo);
			aTFBOHomeActionBD.getBranchProfileDetails(
					aTFBOHomeActionBD.getSessionUser(),
					aTFBOHomeActionBD.getSessionSolId(), custProfileVo);

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		/*
		 * if (aCommonMethods.isValueAvailable(userVo.getReturnPage())) {
		 * logger.info(ActionConstants.EXITING_METHOD + ">>loadHomePage");
		 * return "invalidSession"; }
		 */

		logger.info(ActionConstants.EXITING_METHOD + ">>loadHomePage");
		return "success";
	}

	public String fetchCustDetails() {
		logger.info("Entering method >>--> fetchDevolmentAmount");
		TFBOHomeActionBD aTFBOHomeActionBD = new TFBOHomeActionBD();
		String currentPage = custProfileVo.getCurrentPage();
		try {
			custProfileVo.flag = "FALSE";
			aTFBOHomeActionBD.fetchCustomerDetails(custProfileVo);

		} catch (Exception e) {
			e.printStackTrace();
			return "Exception";
		}
		return currentPage;
	}

	public String customerProfileManagement() {//
		TFBOHomeActionBD aTFBOHomeActionBD = new TFBOHomeActionBD();
		List<AlertMessagesVO> errorDetailList = new LinkedList<AlertMessagesVO>();
		CommonMethods aCommonMethods = new CommonMethods();
		String currentPage = custProfileVo.getCurrentPage();
		try {
			int resultValue = aTFBOHomeActionBD
					.UpdateCustomerDtails(custProfileVo);
			if (resultValue > 0) {
				// addActionMessage("CUSTOMER CREATED/UPDATED SUCCESSFULLY");
				custProfileVo.setErrorDetailsList(aCommonMethods
						.setErrorInList(
								"CUSTOMER CREATED/UPDATED SUCCESSFULLY",
								errorDetailList));
				custProfileVo.custID = "";
				custProfileVo.custName = "";
				custProfileVo.operAccNo = "";
				custProfileVo.operSolID = "";
				custProfileVo.alphaCode = "";
				custProfileVo.lineofActivity = "";
				custProfileVo.emailID = "";
				custProfileVo.rateMarginFrom = "";
				custProfileVo.rateMarginTo = "";
				custProfileVo.mobileNo = "";
				custProfileVo.documentList = null;
			} else {
				// addActionMessage("CUSTOMER CREATED/UPDATED FAILED");
				custProfileVo.setErrorDetailsList(aCommonMethods
						.setErrorInList("CUSTOMER CREATED/UPDATED FAILED",
								errorDetailList));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return currentPage;
	}

	public String uploadCustomerFile() {//
		TFBOUploadDAO aTFBOUploadDAO = new TFBOUploadDAO();
		CommonMethods aCommonMethods = new CommonMethods();
		TFBOHomeActionBD aTFBOHomeActionBD = new TFBOHomeActionBD();
		String currentPage = "";
		try {
			if (!aTFBOHomeActionBD.isValidSession(getFormToken())) {
				return "invalidSession";
			}
			currentPage = custProfileVo.getCurrentPage();
			logger.info("currentPage-->" + currentPage);
			Properties aProperties = PropertyUtil.getPropertiesValue();
			String sreverDestinationFilePath = aProperties
					.getProperty("SERVERDESTINATIONFILEPATHCUST");
			custProfileVo
					.setSessionUserName(aTFBOHomeActionBD.getSessionUser());
			String fileLocation = sreverDestinationFilePath
					+ custProfileVo.getCustID();
			logger.info("Src File name: " + inputFileFileName);
			logger.info("Src File path: " + inputFile.getAbsolutePath());
			logger.info("SessionUserName: " + custProfileVo.sessionUserName);
			File destFile = new File(fileLocation, inputFileFileName);
			FileUtils.copyFile(inputFile, destFile);
			aTFBOUploadDAO
					.uploadCustDocumentInDB(custProfileVo.getCustID(),
							inputFileFileName, fileLocation + "/"
									+ inputFileFileName,
							custProfileVo.sessionUserName,
							custProfileVo.getTypeOfDoc());
			custProfileVo.setTypeOfDoc("");
			aTFBOUploadDAO.getCustDocumentList(custProfileVo);
		} catch (Exception e) {
			List<AlertMessagesVO> errorDetailList = new LinkedList<AlertMessagesVO>();
			errorDetailList = aCommonMethods.setErrorInList(
					ActionConstants.ERRORCODE888, errorDetailList);
			userVo.setErrorDetailsList(errorDetailList);
			e.printStackTrace();
			return currentPage;
		}
		return currentPage;
	}

	public String customerProfileView() {//
		TFBOHomeActionBD aTFBOHomeActionBD = new TFBOHomeActionBD();
		try {
			HttpServletRequest request = (HttpServletRequest) ActionContext
					.getContext().get(ServletActionContext.HTTP_REQUEST);
			String custID = request.getParameter("Id");
			custProfileVo = new CustomerProfileManageVO();
			custProfileVo.setFlag("NO");
			if (custID != null && !custID.trim().equals("")) {
				custProfileVo.setCustID(custID);
				aTFBOHomeActionBD.fetchCustomerDetailsView(custProfileVo);
				aTFBOHomeActionBD.getBranchProfileDetails(
						aTFBOHomeActionBD.getSessionUser(),
						custProfileVo.getCustSolId(), custProfileVo);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "custProfileHome";
	}

	public String customerProfileVerifyView() {//
		TFBOHomeActionBD aTFBOHomeActionBD = new TFBOHomeActionBD();
		try {
			aTFBOHomeActionBD.fetchCustomerDetailsVerifyView(custProfileVo);
			aTFBOHomeActionBD.getBranchProfileDetails(
					aTFBOHomeActionBD.getSessionUser(),
					custProfileVo.getCustSolId(), custProfileVo);

		} catch (Exception e) {
			e.printStackTrace();
		}
		return "custProfileHome";
	}

	public String verifyCustomer() {//
		TFBOHomeActionBD aTFBOHomeActionBD = new TFBOHomeActionBD();
		try {
			String custID = custProfileVo.getCustID();

			if (custID != null && !custID.trim().equals("")) {

				aTFBOHomeActionBD.verifyCustomer(
						aTFBOHomeActionBD.getSessionUser(), custProfileVo);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "verifyCustomer";

	}

	public String deleteCustDocument() {
		TFBOUploadDAO aTFBOUploadDAO = new TFBOUploadDAO();
		CommonMethods aCommonMethods = new CommonMethods();
		TFBOHomeActionBD aTFBOHomeActionBD = new TFBOHomeActionBD();
		logger.info("Entering displayDocument method");
		logger.info("docID-->" + custProfileVo.docID);
		String currentPage = "";
		try {
			if (!aTFBOHomeActionBD.isValidSession(getFormToken())) {
				return "invalidSession";
			}
			currentPage = custProfileVo.getCurrentPage();
			logger.info("currentPage-->" + currentPage);
			custProfileVo
					.setSessionUserName(aTFBOHomeActionBD.getSessionUser());
			aTFBOUploadDAO.deleteCustDocument(custProfileVo.docID);
			logger.info("userVo requestId-->" + custProfileVo.getCustID());
			aTFBOUploadDAO.getCustDocumentList(custProfileVo);
			logger.info("Exiting displayDocument method");
		} catch (Exception e) {
			List<AlertMessagesVO> errorDetailList = new LinkedList<AlertMessagesVO>();
			errorDetailList = aCommonMethods.setErrorInList(
					ActionConstants.ERRORCODE887, errorDetailList);
			custProfileVo.setErrorDetailsList(errorDetailList);
			e.printStackTrace();
			return currentPage;
		}
		return currentPage;
	}

	public String openTIDocumentsHomePage() {
		TFBOUploadDAO aTFBOUploadDAO = new TFBOUploadDAO();
		TFBOHomeActionBD aTFBOHomeActionBD = new TFBOHomeActionBD();
		logger.info("Entering displayDocument method");
		String requestId = "";
		String custId = "";
		HttpServletRequest request = (HttpServletRequest) ActionContext
				.getContext().get(ServletActionContext.HTTP_REQUEST);
		try {
			custProfileVo = new CustomerProfileManageVO();
			requestId = request.getParameter("reqId");
			custId = request.getParameter("custId");
			if (custId != null && !custId.trim().equals(""))
				custProfileVo.setCustID(custId.trim());
			else
				custProfileVo.setCustID("");

			aTFBOUploadDAO.getTransLevelDetails(custProfileVo, requestId);
			custProfileVo
					.setSessionUserName(aTFBOHomeActionBD.getSessionUser());
			logger.info("Exiting displayDocument method");
		} catch (Exception e) {
			e.printStackTrace();
			return "Exception";
		}
		return "openTIDocumentsHomePage";
	}

	/* ADDED FOR CUSTOMER PROFILE BY CHANDRU ON 15012020 */

	// Raise Query starts 17012020

	public String checkerRaiseQuery() {
		System.out.println(ActionConstants.ENTERING_METHOD);
		TFBOHomeActionBD aTFBOHomeActionBD = new TFBOHomeActionBD();
		TFBOWorkflow aTFBOWorkflow = new TFBOWorkflow();
		String stepName = "";
		String newStatus = "";
		String newStepName = "";
		String currentPage = "";
		try {
			currentPage = userVo.getCurrentPage();
			userVo.setSessionUserName(aTFBOHomeActionBD.getSessionUser());
			if (!aTFBOHomeActionBD.isValidSession(getFormToken())) {
				return "invalidSession";
			}
			if (!aTFBOHomeActionBD.isValidUserTransaction(userVo)) {
				logger.info("Transaction has some error"
						+ userVo.getErrorDetailsList().size());
				return currentPage;
			}

			stepName = aTFBOHomeActionBD.getCurrentStep(userVo.getRequestId());
			System.out.println("getCurrentStep-->" + stepName);
			newStepName = aTFBOWorkflow.getPreviousStep(stepName);
			newStatus = aTFBOWorkflow.getRejectStatus(stepName);
			System.out.println("requestId-->" + userVo.getRequestId());
			System.out.println("stepName-->" + stepName);
			System.out.println("SessionUserName-->"
					+ userVo.getSessionUserName());
			if (aTFBOHomeActionBD.isValidUser(userVo, stepName)) {
				aTFBOHomeActionBD.checkerRaiseQueryTransaction(userVo,
						newStatus, newStepName, stepName);
				return "success";
			}
		} catch (Exception e) {
			e.printStackTrace();
			return "exception";
		}
		return "failed";
	}

	// Raise Query ends 17012020
	/*
	 * public String fetchReminderDetails() { System.out
	 * .println("Entering method -->>-->  fetchfetchReminderDetails");
	 * TFBOHomeActionBD aTFBOHomeActionBD = new TFBOHomeActionBD(); // String
	 * currentPage = userVo.getCurrentPage(); // String result="";
	 * 
	 * try { reminderVo = new TFBOReminderVO();
	 * aTFBOHomeActionBD.fetchReminderDetails(reminderVo);
	 * System.out.println("-----si---" + reminderVo.getReminderList().size());
	 * 
	 * } catch (Exception e) { e.printStackTrace(); return "Exception"; } return
	 * "scrutinizerReminder";
	 * 
	 * }
	 */
	public String fetchReminderFilter() {

		return "scrutinizerReminder";

	}

	private String getProductCode(String productFilter) throws Exception {
		TFBOHomeActionBD aTFBOHomeActionBD = new TFBOHomeActionBD();
		userVo.setProductCode(aTFBOHomeActionBD.getProductCode(userVo
				.getProductName()));
		return "success";

	}

	// Raise Query ends 17012020
//	public String fetchReminderDetails() throws Exception {
//		System.out
//				.println("Entering method -->>-->  fetchfetchReminderDetails");
//		TFBOHomeActionBD aTFBOHomeActionBD = new TFBOHomeActionBD();
//		CommonMethods aCommonMethods = new CommonMethods();
//		TFBOHomeDAO aTFBOHomeDAO = new TFBOHomeDAO();
//		// String currentPage = userVo.getCurrentPage();
//		// String result="";
//		// userVo.setProductCodeFilter(aTFBOHomeDAO.getRequestProdFromDB(userVo.getRequestIdFilter()));
//		if (aCommonMethods.isValueAvailable(userVo.getProductFilter())) {
//
//			userVo.setProductCodeFilter(getProductCode(userVo
//					.getProductFilter()));
//
//		}
//		try {
//			reminderVo = new TFBOReminderVO();
//			aTFBOHomeActionBD.fetchReminderDetails(reminderVo, userVo);
//			System.out.println("-----si---"
//					+ reminderVo.getReminderList().size());
//
//		} catch (Exception e) {
//			e.printStackTrace();
//			return "Exception";
//		}
//		return "scrutinizerReminder";
//
//	}

	TFBOReminderVO reminderVo;

	public TFBOReminderVO getReminderVo() {
		return reminderVo;
	}

	public void setReminderVo(TFBOReminderVO reminderVo) {
		this.reminderVo = reminderVo;
	}

	/*
	 * public String sendReminderEmail() throws Exception {
	 * System.out.println("entering sendReminderEmail()"); TFBOHomeActionBD
	 * aTFBOHomeActionBD = new TFBOHomeActionBD(); CommonMethods aCommonMethods
	 * = new CommonMethods(); List<AlertMessagesVO> errorDetailList = new
	 * LinkedList<AlertMessagesVO>(); try {
	 * 
	 * if (!aTFBOHomeActionBD.isValidSession(getFormToken())) { return
	 * "invalidSession"; }
	 * 
	 * if (aCommonMethods.isValueAvailable(reminderVo.toString())) {
	 * System.out.println(userVo.getCurrentPage());
	 * 
	 * int resultcount = aTFBOHomeActionBD .sendReminderEmail(reminderVo); if
	 * (resultcount > 0) {
	 * 
	 * reminderVo.setErrorDetailsList(aCommonMethods
	 * .setErrorInList("Email Sent Successfully", errorDetailList));
	 * 
	 * } else {
	 * 
	 * reminderVo.setErrorDetailsList(aCommonMethods
	 * .setErrorInList("Email Sent Failed", errorDetailList)); }
	 * aTFBOHomeActionBD.fetchReminderDetails(reminderVo); return
	 * reminderVo.getCurrentPage(); }
	 * 
	 * } catch (Exception e) { e.printStackTrace(); logger.info(e.getMessage());
	 * errorDetailList = aCommonMethods.setErrorInList(
	 * ActionConstants.ERRORCODE995, errorDetailList);
	 * userVo.setErrorDetailsList(errorDetailList);
	 * 
	 * return "exception"; } return "failed"; }
	 */
	// //KARTHIK MISSLANEOUS 01022020 STARTS
//	public String sendReminderEmail() throws Exception {
//		System.out.println("entering sendReminderEmail()");
//		TFBOHomeActionBD aTFBOHomeActionBD = new TFBOHomeActionBD();
//		CommonMethods aCommonMethods = new CommonMethods();
//		List<AlertMessagesVO> errorDetailList = new LinkedList<AlertMessagesVO>();
//		try {
//			/*
//			 * if (!aTFBOHomeActionBD.isValidSession(getFormToken())) { return
//			 * "invalidSession"; }
//			 */
//			if (aCommonMethods.isValueAvailable(reminderVo.toString())) {
//				System.out.println(userVo.getCurrentPage());
//
//				int resultcount = aTFBOHomeActionBD
//						.sendReminderEmail(reminderVo);
//				if (resultcount > 0) {
//
//					reminderVo.setErrorDetailsList(aCommonMethods
//							.setErrorInList("Email Sent Successfully",
//									errorDetailList));
//
//				} else {
//
//					reminderVo.setErrorDetailsList(aCommonMethods
//							.setErrorInList("Email Sent Failed",
//									errorDetailList));
//				}
//				aTFBOHomeActionBD.fetchReminderDetails(reminderVo, userVo);
//				return reminderVo.getCurrentPage();
//			}
//
//		} catch (Exception e) {
//			e.printStackTrace();
//			logger.info(e.getMessage());
//			errorDetailList = aCommonMethods.setErrorInList(
//					ActionConstants.ERRORCODE995, errorDetailList);
//			userVo.setErrorDetailsList(errorDetailList);
//
//			return "exception";
//		}
//		return "failed";
//	}

	/*
	 * public String miscellanousmakerComments() {
	 * 
	 * TFBOHomeActionBD aTFBOHomeActionBD = new TFBOHomeActionBD(); String
	 * currentPage = ""; try { if
	 * (!aTFBOHomeActionBD.isValidSession(getFormToken())) { return
	 * "invalidSession"; } currentPage = userVo.getCurrentPage(); String
	 * missComment = userVo.getMiscellComment();
	 * userVo.setSessionUserName(aTFBOHomeActionBD.getSessionUser().trim()); if
	 * (missComment != null) { aTFBOHomeActionBD
	 * .updateMiscellanousComment(missComment, userVo); }
	 * System.out.println(userVo.getSessionUserName() +
	 * "------------User Name----------"); } catch (Exception e) {
	 * e.printStackTrace(); }
	 * 
	 * return "success";
	 * 
	 * }
	 */
	/*
	 * public String miscellanouscheckerComments() {
	 * 
	 * TFBOHomeActionBD aTFBOHomeActionBD = new TFBOHomeActionBD(); String
	 * currentPage = ""; try { if
	 * (!aTFBOHomeActionBD.isValidSession(getFormToken())) { return
	 * "invalidSession"; } currentPage = userVo.getCurrentPage(); String
	 * misscheckerComment = userVo.getMiscellcheckerComment();
	 * userVo.setSessionUserName(aTFBOHomeActionBD.getSessionUser()); if
	 * (misscheckerComment != null) {
	 * aTFBOHomeActionBD.updateMiscellcheckerComment( misscheckerComment,
	 * userVo); } } catch (Exception e) { e.printStackTrace(); }
	 * 
	 * return "success";
	 * 
	 * }
	 */

	/*public String miscellanousmakerComments() {

		TFBOHomeActionBD aTFBOHomeActionBD = new TFBOHomeActionBD();
		String currentPage = "";
		try {
			if (!aTFBOHomeActionBD.isValidSession(getFormToken())) {
				return "invalidSession";
			}
			currentPage = userVo.getCurrentPage();
			String missComment = userVo.getMiscellComment();
			userVo.setSessionUserName(aTFBOHomeActionBD.getSessionUser().trim());
			if (missComment != null) {
				aTFBOHomeActionBD
						.updateMiscellanousComment(missComment, userVo);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return "success";

	}
*/
	/*public String miscellanouscheckerComments() {

		TFBOHomeActionBD aTFBOHomeActionBD = new TFBOHomeActionBD();
		String currentPage = "";
		try {
			if (!aTFBOHomeActionBD.isValidSession(getFormToken())) {
				return "invalidSession";
			}
			currentPage = userVo.getCurrentPage();
			String misscheckerComment = userVo.getMiscellcheckerComment();
			userVo.setSessionUserName(aTFBOHomeActionBD.getSessionUser());
			if (misscheckerComment != null) {
				aTFBOHomeActionBD.updateMiscellcheckerComment(
						misscheckerComment, userVo);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return "success";

	}*/

	// //KARTHIK MISSLANEOUS 01022020 ENDS

	/*public String fbomakerSubmit() {

		TFBOHomeActionBD aTFBOHomeActionBD = new TFBOHomeActionBD();
		TFBOWorkflow aTFBOWorkflow = new TFBOWorkflow();

		String stepName = "";
		String newStatus = "";
		String newStepName = "";
		String currentPage = "";

		try {
			currentPage = userVo.getCurrentPage();
			userVo.setSessionUserName(aTFBOHomeActionBD.getSessionUser());
			if (!aTFBOHomeActionBD.isValidSession(getFormToken())) {
				return "invalidSession";
			}
			if (!aTFBOHomeActionBD.isValidUserTransaction(userVo)) {
				logger.info("Transaction has some error"
						+ userVo.getErrorDetailsList().size());
				return currentPage;
			}

			stepName = aTFBOHomeActionBD.getCurrentStep(userVo.getRequestId());
			newStatus = aTFBOWorkflow.getCompletedStatus(stepName);
			newStepName = aTFBOWorkflow.getNextStep(stepName);

			String missComment = userVo.getMiscellComment();
			userVo.setSessionUserName(aTFBOHomeActionBD.getSessionUser().trim());
			if (missComment != null) {
				aTFBOHomeActionBD
						.updateMiscellanousComment(missComment, userVo);
			}
			
			if (aTFBOHomeActionBD.isValidUser(userVo, stepName)) {

				aTFBOHomeActionBD.fbomakerSubmitTransaction(userVo, newStatus,
						newStepName, stepName);

			}
		} catch (Exception e) {
			e.printStackTrace();
			return "exception";
		}

		return "success";
	}

	public String fboCheckerSubmit() {

		TFBOHomeActionBD aTFBOHomeActionBD = new TFBOHomeActionBD();
		TFBOWorkflow aTFBOWorkflow = new TFBOWorkflow();

		String stepName = "";
		String newStatus = "";
		String newStepName = "";
		String currentPage = "";

		try {
			currentPage = userVo.getCurrentPage();
			userVo.setSessionUserName(aTFBOHomeActionBD.getSessionUser());

			if (!aTFBOHomeActionBD.isValidSession(getFormToken())) {
				return "invalidSession";
			}
			if (!aTFBOHomeActionBD.isValidUserTransaction(userVo)) {
				logger.info("Transaction has some error"
						+ userVo.getErrorDetailsList().size());
				return currentPage;
			}

			stepName = aTFBOHomeActionBD.getCurrentStep(userVo.getRequestId());
			newStatus = aTFBOWorkflow.getCompletedStatus(stepName);
			newStepName = aTFBOWorkflow.getNextStep(stepName);

			String misscheckerComment = userVo.getMiscellcheckerComment();
			userVo.setSessionUserName(aTFBOHomeActionBD.getSessionUser());
			if (misscheckerComment != null) {
				aTFBOHomeActionBD.updateMiscellcheckerComment(
						misscheckerComment, userVo);
			}
			
			if (aTFBOHomeActionBD.isValidUser(userVo, stepName)) {
				aTFBOHomeActionBD.fboCheckerSubmitTransaction(userVo,
						newStatus, newStepName, stepName);
			}
		} catch (Exception e) {
			e.printStackTrace();
			return "exception";
		}

		return "success";
	}
	*/
	
	public String fbomakerSubmit() {

		TFBOHomeActionBD aTFBOHomeActionBD = new TFBOHomeActionBD();
		TFBOWorkflow aTFBOWorkflow = new TFBOWorkflow();
		CommonMethods aCommonMethods = new CommonMethods();
		List<AlertMessagesVO> errorDetailList = new LinkedList<AlertMessagesVO>();
		
		String stepName = "";
		String newStatus = "";
		String newStepName = "";
		String currentPage = "";
		String stepPhase = "";

		try {
			currentPage = userVo.getCurrentPage();
			userVo.setSessionUserName(aTFBOHomeActionBD.getSessionUser());
			if (!aTFBOHomeActionBD.isValidSession(getFormToken())) {
				return "invalidSession";
			}
			if (!aTFBOHomeActionBD.isValidUserTransaction(userVo)) {
				logger.info("Transaction has some error"
						+ userVo.getErrorDetailsList().size());
				return currentPage;
			}

			stepName = aTFBOHomeActionBD.getCurrentStep(userVo.getRequestId());
			newStatus = aTFBOWorkflow.getCompletedStatus(stepName);
			newStepName = aTFBOWorkflow.getNextStep(stepName);
			
			stepPhase  = aTFBOHomeActionBD.getStepPhaseFromTi(userVo.getRequestId());
			System.out.println("-----stepPhase------>"+stepPhase);
			
			if (stepPhase.equalsIgnoreCase("D")){
				System.out.println("------------"+ActionConstants.ERRORCODE113);
				errorDetailList = aCommonMethods.setErrorInList(
						ActionConstants.ERRORCODE115, errorDetailList);
				userVo.setErrorDetailsList(errorDetailList);
				return currentPage;
			}else{
				if (aTFBOHomeActionBD.isValidUser(userVo, stepName)) {
					aTFBOHomeActionBD.fbomakerSubmitTransaction(userVo, newStatus,
							newStepName, stepName);
					return "success";
				}
			}
			
		} catch (Exception e) {
			e.printStackTrace();
			errorDetailList = aCommonMethods.setErrorInList(
					ActionConstants.ERRORCODE995, errorDetailList);
			userVo.setErrorDetailsList(errorDetailList);

			return "exception";
		}
		System.out.println("currentPage------------"+currentPage);
		return "success";
	}

	public String fboCheckerSubmit() {

		TFBOHomeActionBD aTFBOHomeActionBD = new TFBOHomeActionBD();
		TFBOWorkflow aTFBOWorkflow = new TFBOWorkflow();
		CommonMethods aCommonMethods = new CommonMethods();
		List<AlertMessagesVO> errorDetailList = new LinkedList<AlertMessagesVO>();
		
		String stepName = "";
		String newStatus = "";
		String newStepName = "";
		String currentPage = "";
		String stepPhase = "";

		try {
			currentPage = userVo.getCurrentPage();
			userVo.setSessionUserName(aTFBOHomeActionBD.getSessionUser());

			if (!aTFBOHomeActionBD.isValidSession(getFormToken())) {
				return "invalidSession";
			}
			if (!aTFBOHomeActionBD.isValidUserTransaction(userVo)) {
				logger.info("Transaction has some error"
						+ userVo.getErrorDetailsList().size());
				return currentPage;
			}

			stepName = aTFBOHomeActionBD.getCurrentStep(userVo.getRequestId());
			newStatus = aTFBOWorkflow.getCompletedStatus(stepName);
			newStepName = aTFBOWorkflow.getNextStep(stepName);

			stepPhase  = aTFBOHomeActionBD.getStepPhaseFromTi(userVo.getRequestId());
			System.out.println("-----stepPhase------>"+stepPhase);
			
			if (stepPhase.equalsIgnoreCase("V") || stepPhase.equalsIgnoreCase("D")){
				errorDetailList = aCommonMethods.setErrorInList(
						ActionConstants.ERRORCODE115, errorDetailList);
				userVo.setErrorDetailsList(errorDetailList);
				return currentPage;
			
				
			}else{
				if (aTFBOHomeActionBD.isValidUser(userVo, stepName)) {
					aTFBOHomeActionBD.fboCheckerSubmitTransaction(userVo,
							newStatus, newStepName, stepName);
					return "success";
				}
			}
			
		} catch (Exception e) {
			e.printStackTrace();
			return "exception";
		}

		return "success";
	}
	


	public String validateSACTransaction() {
		TFBOHomeActionBD aTFBOHomeActionBD = new TFBOHomeActionBD();
		try {

			aTFBOHomeActionBD.validateSACTransaction(userVo);

		} catch (Exception e) {
			e.printStackTrace();
			return "Exception";
		}
		return "success";
	}

	/* Added by Kamakshya for SAC transaction ends */

	// Added by Kamakshya for multiple login Starts ---> code  to be uncomment after  SAC module given
	// for resetting flag to 0 after clicking logout
	
	public String logOutSessionUser() {
		TFBOHomeActionBD aTFBOHomeActionBD = new TFBOHomeActionBD();
		if (userVo == null) {
			userVo = new UserTransactionVO();
		}
		try {
			userVo.setSessionUserName(aTFBOHomeActionBD.getSessionUser().trim());
			aTFBOHomeActionBD.logOutSessionUser(userVo);
		} catch (Exception e) {
			e.getMessage();
		} finally {
		}
		return "success";
	}// Added by Kamakshya Ends --->

}
