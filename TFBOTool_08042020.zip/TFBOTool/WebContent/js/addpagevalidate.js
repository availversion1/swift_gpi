/**
 * @author Administrator
 */
 /* <![CDATA[ */
            jQuery(function(){
                
				jQuery("#slct1").validate({
                    expression: "if (VAL !='0') return true; else return false;",
                    message: "Please make a selection"
                });
				
				jQuery("#slct2").validate({
                    expression: "if (VAL !='0') return true; else return false;",
                    message: "Please make a selection"
                });
				
				jQuery("#txt1").validate({
                    expression: "if (VAL) return true; else return false;",
                    message: "Enter the page name"
                });
				
				jQuery("#txt2").validate({
                    expression: "if (VAL) return true; else return false;",
                    message: "Enter the page title"
                });
				
                jQuery("#txt3").validate({
                    expression: "if (VAL) return true; else return false;",
                    message: "Enter the comment"
                });
                                
            });
            /* ]]> */